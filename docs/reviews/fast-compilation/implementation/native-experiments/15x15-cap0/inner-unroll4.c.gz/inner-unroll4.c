/* Generated from a freshly checked beryl bounded loop program. */
#include <ctype.h>
#include <errno.h>
#include <inttypes.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

_Static_assert(CHAR_BIT == 8, "eight-bit bytes required");
_Static_assert(sizeof(int32_t) == 4, "four-byte i32 required");
_Static_assert(sizeof(int64_t) == 8, "eight-byte i64 required");
enum { BERYL_HEIGHT = 15, BERYL_WIDTH = 15,
       BERYL_INPUT_COUNT = 256, BERYL_OUTPUT_COUNT = 225 };

/* Caller owns disjoint initialized arrays of the exact compiled counts.
 * No alias, offset view, concurrent access, or lifetime change is permitted. */
int32_t beryl_kernel(const int32_t *input, int32_t *output) {
    for (int32_t i = 0; i < 256; ++i)
        if (input[i] < 0 || input[i] > 1023) return i + 1;
    const int32_t ax_v_one = (int32_t)(1LL);
    (void)ax_v_one;
    for (int32_t ax_i_r = 0; ax_i_r < 15; ++ax_i_r) {
#if defined(__clang__)
        #pragma clang loop unroll_count(4)
#endif
        for (int32_t ax_i_c = 0; ax_i_c < 15; ++ax_i_c) {
            int32_t ax_index_1 = (int32_t)(0LL);
            int32_t ax_term_1_0 = (int32_t)((int64_t)ax_i_r + 0LL);
            ax_term_1_0 = (int32_t)(16LL * (int64_t)ax_term_1_0);
            ax_index_1 = (int32_t)((int64_t)ax_index_1 + (int64_t)ax_term_1_0);
            int32_t ax_term_1_1 = (int32_t)((int64_t)ax_i_c + 0LL);
            ax_term_1_1 = (int32_t)(1LL * (int64_t)ax_term_1_1);
            ax_index_1 = (int32_t)((int64_t)ax_index_1 + (int64_t)ax_term_1_1);
            const int32_t ax_v_aload = input[ax_index_1];
            (void)ax_v_aload;
            const int32_t ax_v_ainc = (int32_t)((int64_t)ax_v_aload + (int64_t)ax_v_one);
            (void)ax_v_ainc;
            const int32_t ax_v_avalue = (int32_t)((int64_t)ax_v_ainc * (int64_t)ax_v_ainc);
            (void)ax_v_avalue;
            int32_t ax_index_2 = (int32_t)(1LL);
            int32_t ax_term_2_0 = (int32_t)((int64_t)ax_i_r + 0LL);
            ax_term_2_0 = (int32_t)(16LL * (int64_t)ax_term_2_0);
            ax_index_2 = (int32_t)((int64_t)ax_index_2 + (int64_t)ax_term_2_0);
            int32_t ax_term_2_1 = (int32_t)((int64_t)ax_i_c + 0LL);
            ax_term_2_1 = (int32_t)(1LL * (int64_t)ax_term_2_1);
            ax_index_2 = (int32_t)((int64_t)ax_index_2 + (int64_t)ax_term_2_1);
            const int32_t ax_v_bload = input[ax_index_2];
            (void)ax_v_bload;
            const int32_t ax_v_binc = (int32_t)((int64_t)ax_v_bload + (int64_t)ax_v_one);
            (void)ax_v_binc;
            const int32_t ax_v_bvalue = (int32_t)((int64_t)ax_v_binc * (int64_t)ax_v_binc);
            (void)ax_v_bvalue;
            int32_t ax_index_3 = (int32_t)(0LL);
            int32_t ax_term_3_0 = (int32_t)((int64_t)ax_i_r + 1LL);
            ax_term_3_0 = (int32_t)(16LL * (int64_t)ax_term_3_0);
            ax_index_3 = (int32_t)((int64_t)ax_index_3 + (int64_t)ax_term_3_0);
            int32_t ax_term_3_1 = (int32_t)((int64_t)ax_i_c + 0LL);
            ax_term_3_1 = (int32_t)(1LL * (int64_t)ax_term_3_1);
            ax_index_3 = (int32_t)((int64_t)ax_index_3 + (int64_t)ax_term_3_1);
            const int32_t ax_v_dload = input[ax_index_3];
            (void)ax_v_dload;
            const int32_t ax_v_dinc = (int32_t)((int64_t)ax_v_dload + (int64_t)ax_v_one);
            (void)ax_v_dinc;
            const int32_t ax_v_dvalue = (int32_t)((int64_t)ax_v_dinc * (int64_t)ax_v_dinc);
            (void)ax_v_dvalue;
            int32_t ax_index_4 = (int32_t)(1LL);
            int32_t ax_term_4_0 = (int32_t)((int64_t)ax_i_r + 1LL);
            ax_term_4_0 = (int32_t)(16LL * (int64_t)ax_term_4_0);
            ax_index_4 = (int32_t)((int64_t)ax_index_4 + (int64_t)ax_term_4_0);
            int32_t ax_term_4_1 = (int32_t)((int64_t)ax_i_c + 0LL);
            ax_term_4_1 = (int32_t)(1LL * (int64_t)ax_term_4_1);
            ax_index_4 = (int32_t)((int64_t)ax_index_4 + (int64_t)ax_term_4_1);
            const int32_t ax_v_eload = input[ax_index_4];
            (void)ax_v_eload;
            const int32_t ax_v_einc = (int32_t)((int64_t)ax_v_eload + (int64_t)ax_v_one);
            (void)ax_v_einc;
            const int32_t ax_v_evalue = (int32_t)((int64_t)ax_v_einc * (int64_t)ax_v_einc);
            (void)ax_v_evalue;
            const int32_t ax_v_ab = (int32_t)((int64_t)ax_v_avalue + (int64_t)ax_v_bvalue);
            (void)ax_v_ab;
            const int32_t ax_v_abd = (int32_t)((int64_t)ax_v_ab + (int64_t)ax_v_dvalue);
            (void)ax_v_abd;
            const int32_t ax_v_total = (int32_t)((int64_t)ax_v_abd + (int64_t)ax_v_evalue);
            (void)ax_v_total;
            int32_t ax_index_5 = (int32_t)(0LL);
            int32_t ax_term_5_0 = (int32_t)((int64_t)ax_i_r + 0LL);
            ax_term_5_0 = (int32_t)(15LL * (int64_t)ax_term_5_0);
            ax_index_5 = (int32_t)((int64_t)ax_index_5 + (int64_t)ax_term_5_0);
            int32_t ax_term_5_1 = (int32_t)((int64_t)ax_i_c + 0LL);
            ax_term_5_1 = (int32_t)(1LL * (int64_t)ax_term_5_1);
            ax_index_5 = (int32_t)((int64_t)ax_index_5 + (int64_t)ax_term_5_1);
            output[ax_index_5] = ax_v_total;
        }
    }
    return 0;
}

/* Read a bounded token before numeric conversion. %n counts at most 63 bytes;
 * whitespace is consumed separately so embedded NUL bytes cannot hide a suffix.
 * Reading one separator also prevents a long token from becoming two numbers. */
static int beryl_read_i32(int32_t *value) {
    char token[64];
    int length = 0;
    int next;
    do { next = fgetc(stdin); }
    while (next != EOF && isspace((unsigned char)next));
    if (next == EOF || ungetc(next, stdin) == EOF) return 0;
    if (scanf("%63s%n", token, &length) != 1) return 0;
    next = fgetc(stdin);
    if ((next != EOF && !isspace((unsigned char)next)) || ferror(stdin)) return 0;
    int index = (token[0] == '+' || token[0] == '-') ? 1 : 0;
    if (index == length) return 0;
    for (; index < length; ++index)
        if (token[index] < '0' || token[index] > '9') return 0;
    errno = 0;
    char *end;
    long long parsed = strtoll(token, &end, 10);
    if (errno == ERANGE || end != token + length ||
        parsed < INT32_MIN || parsed > INT32_MAX) return 0;
    *value = (int32_t)parsed;
    return 1;
}

static int beryl_end_of_input(void) {
    int next;
    while ((next = fgetc(stdin)) != EOF)
        if (!isspace((unsigned char)next)) return 0;
    return !ferror(stdin);
}

int main(void) {
    int32_t height, width;
    if (!beryl_read_i32(&height) || !beryl_read_i32(&width) ||
        height != BERYL_HEIGHT || width != BERYL_WIDTH) return 64;
    int32_t input[BERYL_INPUT_COUNT] = {0};
    int32_t output[BERYL_OUTPUT_COUNT] = {0};
    for (int32_t i = 0; i < BERYL_INPUT_COUNT; ++i)
        if (!beryl_read_i32(&input[i])) return 65;
    if (!beryl_end_of_input()) return 65;
    if (beryl_kernel(input, output) != 0) return 66;
    if (putchar('[') == EOF) return 74;
    for (int32_t i = 0; i < BERYL_OUTPUT_COUNT; ++i) {
        if (i && putchar(',') == EOF) return 74;
        if (printf("%" PRId32, output[i]) < 0) return 74;
    }
    if (puts("]") == EOF || fflush(stdout) == EOF) return 74;
    return 0;
}

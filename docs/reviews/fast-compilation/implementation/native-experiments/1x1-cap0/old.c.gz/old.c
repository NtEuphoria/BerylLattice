/* Generated from a freshly checked finite beryl physical plan. */
#include <ctype.h>
#include <errno.h>
#include <inttypes.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

_Static_assert(CHAR_BIT == 8, "eight-bit bytes required");
_Static_assert(sizeof(int32_t) == 4, "four-byte i32 required");
_Static_assert(sizeof(int64_t) == 8, "eight-byte i64 required");
enum { BERYL_HEIGHT = 1, BERYL_WIDTH = 1,
       BERYL_INPUT_COUNT = 4, BERYL_OUTPUT_COUNT = 1 };

/* Caller owns disjoint initialized arrays of the exact compiled counts.
 * No alias, offset view, concurrent access, or lifetime change is permitted. */
int32_t beryl_kernel(const int32_t *input, int32_t *output) {
    for (int32_t i = 0; i < 4; ++i)
        if (input[i] < 0 || input[i] > 1023) return i + 1;
    const int32_t ax_v0 = (int32_t)(1LL);
    (void)ax_v0;
    const int32_t ax_v1 = input[0];
    (void)ax_v1;
    const int32_t ax_v2 = (int32_t)((int64_t)ax_v1 + (int64_t)ax_v0);
    (void)ax_v2;
    const int32_t ax_v3 = (int32_t)((int64_t)ax_v2 * (int64_t)ax_v2);
    (void)ax_v3;
    const int32_t ax_v4 = input[1];
    (void)ax_v4;
    const int32_t ax_v5 = (int32_t)((int64_t)ax_v4 + (int64_t)ax_v0);
    (void)ax_v5;
    const int32_t ax_v6 = (int32_t)((int64_t)ax_v5 * (int64_t)ax_v5);
    (void)ax_v6;
    const int32_t ax_v7 = input[2];
    (void)ax_v7;
    const int32_t ax_v8 = (int32_t)((int64_t)ax_v7 + (int64_t)ax_v0);
    (void)ax_v8;
    const int32_t ax_v9 = (int32_t)((int64_t)ax_v8 * (int64_t)ax_v8);
    (void)ax_v9;
    const int32_t ax_v10 = input[3];
    (void)ax_v10;
    const int32_t ax_v11 = (int32_t)((int64_t)ax_v10 + (int64_t)ax_v0);
    (void)ax_v11;
    const int32_t ax_v12 = (int32_t)((int64_t)ax_v11 * (int64_t)ax_v11);
    (void)ax_v12;
    const int32_t ax_v13 = (int32_t)((int64_t)ax_v3 + (int64_t)ax_v6);
    (void)ax_v13;
    const int32_t ax_v14 = (int32_t)((int64_t)ax_v13 + (int64_t)ax_v9);
    (void)ax_v14;
    const int32_t ax_v15 = (int32_t)((int64_t)ax_v14 + (int64_t)ax_v12);
    (void)ax_v15;
    output[0] = ax_v15;
    return 0;
}

/* Read a bounded token before numeric conversion. %n counts at most 63 bytes;
 * whitespace is consumed separately so embedded NUL bytes cannot hide a suffix.
 * Reading one separator also prevents a long token from becoming two numbers. */
static int beryl_read_i32(int32_t *value) {
    char token[64];
    int length = 0;
    int next;
    do { next = fgetc(stdin); }
    while (next != EOF && isspace((unsigned char)next));
    if (next == EOF || ungetc(next, stdin) == EOF) return 0;
    if (scanf("%63s%n", token, &length) != 1) return 0;
    next = fgetc(stdin);
    if ((next != EOF && !isspace((unsigned char)next)) || ferror(stdin)) return 0;
    int index = (token[0] == '+' || token[0] == '-') ? 1 : 0;
    if (index == length) return 0;
    for (; index < length; ++index)
        if (token[index] < '0' || token[index] > '9') return 0;
    errno = 0;
    char *end;
    long long parsed = strtoll(token, &end, 10);
    if (errno == ERANGE || end != token + length ||
        parsed < INT32_MIN || parsed > INT32_MAX) return 0;
    *value = (int32_t)parsed;
    return 1;
}

static int beryl_end_of_input(void) {
    int next;
    while ((next = fgetc(stdin)) != EOF)
        if (!isspace((unsigned char)next)) return 0;
    return !ferror(stdin);
}

int main(void) {
    int32_t height, width;
    if (!beryl_read_i32(&height) || !beryl_read_i32(&width) ||
        height != BERYL_HEIGHT || width != BERYL_WIDTH) return 64;
    int32_t input[BERYL_INPUT_COUNT] = {0};
    int32_t output[BERYL_OUTPUT_COUNT] = {0};
    for (int32_t i = 0; i < BERYL_INPUT_COUNT; ++i)
        if (!beryl_read_i32(&input[i])) return 65;
    if (!beryl_end_of_input()) return 65;
    if (beryl_kernel(input, output) != 0) return 66;
    if (putchar('[') == EOF) return 74;
    for (int32_t i = 0; i < BERYL_OUTPUT_COUNT; ++i) {
        if (i && putchar(',') == EOF) return 74;
        if (printf("%" PRId32, output[i]) < 0) return 74;
    }
    if (puts("]") == EOF || fflush(stdout) == EOF) return 74;
    return 0;
}

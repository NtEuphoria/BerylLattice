"""Deterministic research accounting for explicit C1 hand artifacts.

This is a work model, not elapsed time, a public certificate checker, or a gate.
Decoder byte/token/span/depth bookkeeping is retained in a separate counter;
source semantic work, all proof tables and identity bytes remain charged work.
The source-admission reservation is auditable but deliberately distinguished
from instrumented primitive charges. Unproved envelope steps stay explicit.
"""
from dataclasses import dataclass, fields, is_dataclass, replace
import hashlib
import json
from pathlib import Path

from axiom.model import (BinaryExpression, GroupExpression, IntegerLiteral,
                         NameReference, ReadExpression)
from axiom.source_profiles import SourceLimitsV2, SourceProfileV2, admit_source_v2
from loop_proof_graph import (TABLES, Index, canonical, construct_hand_derivation,
                              encode_hand_derivation, plain)


QUOTAS = {'source_bytes':65536,'plan_bytes':262144,'certificate_bytes':524288,
          'ir_nodes':4096,'scalar_definitions':4096,'loop_depth':4,'affine_terms':16,
          'active_facts':256,'region_pieces':1024,'proof_nodes':16384,
          'parity_cases':16,'symbolic_nodes':65536,'symbolic_depth':256,
          'integer_width':256,'total_work':1000000}


@dataclass(frozen=True)
class AccountingSpec:
    version: str = 'c1-deterministic-work-1'
    work_limit: int = 1000000
    integer_width: int = 256
    decoder_limit: int = 100000000

    def __post_init__(self):
        if self.version!='c1-deterministic-work-1':raise ValueError('accounting version')
        for name,limit in (('work_limit',1000000),('integer_width',256),('decoder_limit',100000000)):
            if type(getattr(self,name)) is not int or not 1<=getattr(self,name)<=limit:
                raise ValueError('accounting limit only tightens')


@dataclass(frozen=True)
class SourceEnvelope:
    source_bytes: int = 65536
    max_height: int = 8192
    max_width: int = 8192
    max_input_cells: int = 2**23

    def __post_init__(self):
        if (self.source_bytes,self.max_height,self.max_width,self.max_input_cells)!=(65536,8192,8192,2**23):
            raise ValueError('unchanged C2 source envelope required')


@dataclass(frozen=True)
class WorkEvent:
    owner: str
    family: str
    inputs: tuple
    widths: tuple
    structural: int
    bits: int
    memo: str = ''
    decoder: bool = False
    kind: str = 'executed-model'


@dataclass(frozen=True)
class WorkLedger:
    outcome: str
    events: tuple
    total_work: int
    decoder_work: int
    structural_work: int
    integer_bit_work: int
    plan_sha256: str
    certificate_sha256: str
    dependency_hashes: tuple
    event_sha256: str
    unresolved: tuple


@dataclass(frozen=True)
class QuotaObservation:
    name: str
    limit: int
    measured: int
    bound: int | None
    reason: str


@dataclass(frozen=True)
class BoundReport:
    outline: str
    quotas: tuple
    recurrences: tuple
    source_features: tuple
    dependency_hashes: tuple
    unresolved: tuple
    measured_ledger: WorkLedger


class WorkExhausted(ValueError):
    """Incomplete resource outcome, never a semantic counterexample."""


def width(x):return max(1,abs(x).bit_length())


class ChargedWork:
    def __init__(self,spec):
        spec.__post_init__();self.spec=spec;self.total=0;self.decoder=0;self.events=[]

    def charge(self,owner,family,inputs=(),structural=1,bits=0,*,memo='',decoder=False,kind='executed-model'):
        if not owner or structural<0 or bits<0:raise ValueError('work event')
        widths=tuple(width(x) for x in inputs)
        if any(type(x) is not int or w>self.spec.integer_width for x,w in zip(inputs,widths)):
            raise WorkExhausted('integer width')
        cost=structural+bits
        if (self.decoder+cost>self.spec.decoder_limit if decoder else self.total+cost>self.spec.work_limit):
            raise WorkExhausted('decoder quota' if decoder else 'work quota')
        if decoder:self.decoder+=cost
        else:self.total+=cost
        self.events.append(WorkEvent(owner,family,tuple(inputs),widths,structural,bits,memo,decoder,kind))

    def integer(self,value):
        if type(value) is not int or width(value)>self.spec.integer_width:raise WorkExhausted('integer width')
        return value

    def add(self,owner,family,a,b):
        self.integer(a);self.integer(b)
        self.charge(owner,family,(a,b),bits=max(width(a),width(b)))
        return self.integer(a+b)

    def mul(self,owner,family,a,b):
        self.integer(a);self.integer(b)
        self.charge(owner,family,(a,b),bits=width(a)*width(b))
        return self.integer(a*b)

    def le(self,owner,family,a,b):
        self.integer(a);self.integer(b)
        self.charge(owner,family,(a,b),bits=max(width(a),width(b)))
        return a<=b


class ExactKeys:
    """Binary trie over prefix-free signed integer tuple keys.

    A key starts with tuple length. Each integer is sign, unary magnitude width,
    zero separator and exactly that many magnitude bits. Arrays implement trie
    children: no random hashing or amortized collision assumption is involved.
    Charge the entire bit walk before inspecting or allocating its first node.
    """
    def __init__(self,budget):self.budget=budget;self.nodes=[[-1,-1,-1]];self.count=0

    @staticmethod
    def bits(key):
        bits=[]
        for x in (len(key),)+tuple(key):
            n=width(x);bits.extend((1 if x<0 else 0,));bits.extend((1,)*n);bits.append(0)
            bits.extend((abs(x)>>k)&1 for k in range(n-1,-1,-1))
        return tuple(bits)

    def lookup(self,owner,key):
        for value in key:self.budget.integer(value)
        bit_count=sum(2*width(x)+2 for x in (len(key),)+tuple(key))
        # Field construction, bit extraction and two trie actions per bit.
        self.budget.charge(owner,'key.exact',tuple(key),structural=len(key)+3*bit_count+2,memo='pending')
        bits=self.bits(tuple(key))
        node=0
        for bit in bits:
            child=self.nodes[node][bit]
            if child<0:
                child=len(self.nodes);self.nodes[node][bit]=child;self.nodes.append([-1,-1,-1])
            node=child
        found=self.nodes[node][2]
        hit=found>=0
        if not hit:found=self.count;self.count+=1;self.nodes[node][2]=found
        self.budget.events[-1]=replace(self.budget.events[-1],memo='hit' if hit else 'miss')
        return found,hit


def work_families():
    return tuple(json.loads((Path(__file__).parent/'fixtures/loop_proof_obligations.json').read_text())['work_families'])


def dependency_hashes():
    root=Path(__file__).resolve().parents[1]
    paths=('src/axiom/frontend.py','src/axiom/source_profiles.py','src/axiom/source_names_v2.py','src/axiom/model.py',
           'research/loop_proof_graph.py','research/loop_proof_cost.py',
           'research/fixtures/loop_proof_obligations.json')
    return tuple((p,hashlib.sha256((root/p).read_bytes()).hexdigest()) for p in paths)


def _walk(value):
    yield value
    if is_dataclass(value):
        for f in fields(value):
            yield from _walk(getattr(value,f.name))
    elif isinstance(value,tuple):
        for x in value:yield from _walk(x)


def _features(module):
    # SourceModule.source_bytes is visited as a field, never iterated as an AST.
    objects=tuple(_walk(module.declarations))
    expressions=tuple(x for x in objects if isinstance(x,(GroupExpression,IntegerLiteral,NameReference,ReadExpression,BinaryExpression)))
    groups=sum(isinstance(x,GroupExpression) for x in expressions)
    return expressions,groups,len(module.constraints)


def _identity_bytes(k):
    from axiom.frontend import _canonical_profile
    p=k.profile
    family={'identity_version':'axiom-loop-family-v2','source_profile':{
        'profile_id':p.profile_id,'version':p.version,'max_height':p.max_height,'max_width':p.max_width,
        'max_input_cells':p.max_input_cells,'index_semantics':p.index_semantics},
        'normalized_profile':_canonical_profile(),'arithmetic':'checked-i32-per-scalar-node-including-dead-operations',
        'boundary':'row-major-preflight-first-invalid-preserve-input-and-original-output-before-scratch-or-body'}
    spec={'identity_version':'axiom-loop-specialization-v2','family_semantics_sha256':k.family_digest,
          'height':k.height,'width':k.width,'dimensions':'fixed-source-parameters-runtime-input-and-host-buffers'}
    constraint={'identity_version':'axiom-loop-source-constraints-v2','plan_workspace_bytes':k.cap}
    objective={'identity_version':'axiom-loop-source-objective-v2','objective':k.objective.value}
    return tuple(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode() for x in (family,spec,constraint,objective))


def _source_work(d,b):
    k=admit_source_v2(d.source_bytes,profile=SourceProfileV2(),limits=SourceLimitsV2())
    expressions,g,c=_features(k.source_module)
    n=56+g+c;B=len(d.source_bytes)
    # Explicit decoder reservation: UTF8/NUL/scanner/comment-prefix/punctuation,
    # token-copy/decode; parser depth dictionary worst-case integer-key probes,
    # node/depth/span/digit bookkeeping. Not silently counted as semantic work.
    b.charge('frontend._lex byte scans','source.decoder',(B,),structural=16*B+1,decoder=True,kind='audited-upper-bound')
    b.charge('frontend._Parser node/depth/span/token/digit bookkeeping','source.parser',(n,g,c,B),
             structural=(n+40+g)*n+64*n+24*B,decoder=True,kind='audited-upper-bound')
    # The source semantic pass inventory is exact for the admitted normalized
    # family, independent of wrappers. Endpoint bit work uses the audit's
    # explicit 22 additions, 33 comparisons, 4 signed-i32 comparisons, etc.
    b.charge('frontend._validate/_profile dispatch','source.validation',(g,c),structural=54+g+c+5)
    b.charge('frontend._constant/_interval and v2 profile inequalities','source.validation',
             (k.height,k.width,-2**31,2**31-1),structural=22+33+4+4+1+1+16,bits=1350,kind='audited-upper-bound')
    cap=None
    for i,constraint in enumerate(k.source_constraints):
        value=constraint.value
        b.charge(f'constraint[{i}].property-name comparisons','source.names',(),structural=42,kind='audited-upper-bound')
        b.le(f'constraint[{i}].lower','source.validation',0,value)
        b.le(f'constraint[{i}].upper','source.validation',value,2**31-1)
        if cap is not None:
            b.le(f'constraint[{i}].intersection','source.validation',value,cap)
            cap=min(cap,value)
        else:cap=value
    b.charge('frontend._profile normalized AST and equality','source.normalization',(g,),structural=54+g+165+785)
    # The v2 adapter scans original names once. The source-proof binding pass
    # is independent and is charged separately below; no alias-map reuse is
    # inferred from retaining the original public AST.
    from axiom.source_names_v2 import _build_name_view
    view=_build_name_view(k.source_module);w=view.work
    b.charge('v2 necessary shape/cardinality/rank guards','source.validation',(g,),structural=16+g)
    b.charge('v2 private-view declaration/axis/expression dispatch','source.validation',
             (),structural=w.declaration_visits+w.axis_visits+w.expression_visits)
    b.charge('v2 private-view immutable record field copies','source.validation',(),
             structural=8*w.rebuilt_records+2*w.declaration_visits+2*w.axis_visits+16,kind='audited-upper-bound')
    b.charge('v2 private-view original-name registry','source.names',(),
             structural=4*w.name_occurrences+3*w.candidate_comparisons+w.character_comparisons)
    m=k.source_module
    role_names=tuple(x.name for x in m.shapes)+(m.inputs[0].name,m.producers[0].name,m.outputs[0].name)+tuple(a.name for eq in (m.producers[0],m.outputs[0]) for a in eq.axes)
    lengths=tuple(len(name.encode('ascii')) for name in role_names)
    for i,(key,candidate) in enumerate(_binding_name_edges()):
        b.charge(f'source.binding-pass comparison[{i}]','source.names',
                 (lengths[key],lengths[candidate]),structural=3+min(lengths[key],lengths[candidate]))
    for i,(owner,key,keys) in enumerate(_name_schedule()):
        if owner.startswith('source.'):continue
        # Fixed one-byte aliases only. This explicit conservative allowance is
        # provisional pending the pinned dict/set probe audit; it never bounds
        # arbitrary original-name comparisons or assumes cached original hashes.
        b.charge(f'{owner}[{i}].fixed-alias map','source.names',(len(keys),),
                 structural=1024,kind='fixed-alias-probe-upper-bound')
    b.charge('source retained AST origin index','source.origins',(g,c),structural=54+g+c+10)
    b.charge('source exact SHA256 input','source.identities',(B,),structural=B)
    for i,data in enumerate(_identity_bytes(k)):
        # Serialization, UTF8 byte emission, SHA256 input; fixed dictionary
        # sorting/container traversal gets one separately disclosed allowance.
        b.charge(f'source identity[{i}] serialize/encode/hash','source.identities',(len(data),),structural=3*len(data)+512,kind='audited-upper-bound')
    # Only the independent open source T/E reconstruction is needed by this
    # model. Physical expected values use the reachable substitution algorithm.
    formal_scope=next(i for i,s in enumerate(d.scopes) if s.binders==d.formals)
    visits=tuple(v for v in d.source_visits if v.scope==formal_scope)
    for i,visit in enumerate(visits):
        b.charge(f'open-source.visit[{i}]','source.reconstruction',(visit.origin,visit.result),structural=1+len(visit.replacements))
    return k,(B,g,c,n)


class _SubstitutionWork:
    def __init__(self,d,b):
        self.d,self.b=d,b
        self.indices=ExactKeys(b);self.terms=ExactKeys(b);self.memo=ExactKeys(b)
        self.index_rows=list(d.indices);self.memo_values=[]
        for i,x in enumerate(d.indices):self.indices.lookup(f'index[{i}].intern',self.index_key(x))
        for i,t in enumerate(d.terms):self.terms.lookup(f'term[{i}].intern',self.term_key(t.operator,t.payload,t.children,t.context))

    @staticmethod
    def index_key(x):return (x.modulo,x.constant,len(x.coefficients))+tuple(y for pair in x.coefficients for y in pair)

    @staticmethod
    def term_key(op,payload,children,context):
        return (('const','input','add','mul').index(op),context,len(payload),*payload,len(children),*children)

    def index(self,owner,i,replacements):
        x=self.d.indices[i];constant=x.constant;coefficients={}
        for binder,c in x.coefficients:
            if binder in replacements:
                r=self.d.indices[replacements[binder]]
                constant=self.b.add(owner,'affine.arithmetic',constant,self.b.mul(owner,'affine.arithmetic',c,r.constant))
                for v,k in r.coefficients:
                    value=self.b.mul(owner,'affine.arithmetic',c,k)
                    coefficients[v]=self.b.add(owner,'affine.arithmetic',coefficients.get(v,0),value)
            else:coefficients[binder]=self.b.add(owner,'affine.arithmetic',coefficients.get(binder,0),c)
        row=Index(constant,tuple(sorted((v,c) for v,c in coefficients.items() if c)),x.modulo)
        result,hit=self.indices.lookup(owner+'.index-key',self.index_key(row))
        if not hit:self.index_rows.append(row)
        return result

    def apply(self,owner,root,substitution,context):
        t=self.d.terms[root]
        sub=self.d.substitutions[substitution]
        self.b.charge(owner+'.scope','substitution.scope',(root,sub.source_scope,sub.target_scope),structural=1+len(sub.replacements)+len(t.free))
        pairs=tuple((v,x) for v,x in sub.replacements if v in t.free)
        target=context if t.free else -1
        key=(root,target,len(pairs))+tuple(y for pair in pairs for y in pair)
        entry,hit=self.memo.lookup(owner+'.memo',key)
        self.b.charge(owner,'substitution.reachable',key,memo='hit' if hit else 'miss')
        if hit:return self.memo_values[entry]
        self.memo_values.append(-1)
        replacements=dict(pairs)
        children=tuple(self.apply(owner+f'.child[{i}]',child,substitution,context) for i,child in enumerate(t.children))
        payload=tuple(self.index(owner,i,replacements) for i in t.payload) if t.operator=='input' else t.payload
        result,_=self.terms.lookup(owner+'.term-key',self.term_key(t.operator,payload,children,target))
        self.memo_values[entry]=result
        return result


def _intervals(d,b):
    # Pure interval lemmas are checked once per interned exact term. Physical
    # definitions each pay the separate interval premise/reference traversal.
    for i,t in enumerate(d.terms):
        owner=f'term[{i}].interval'
        if t.operator in ('add','mul'):
            a,c=(d.terms[x].interval for x in t.children)
            if t.operator=='add':
                values=(b.add(owner,'scalar.interval',a[0],c[0]),b.add(owner,'scalar.interval',a[1],c[1]))
            else:
                values=tuple(b.mul(owner,'scalar.interval',x,y) for x in a for y in c)
                for value in values[1:]:b.le(owner,'scalar.interval',value,values[0]);b.le(owner,'scalar.interval',values[0],value)
        b.le(owner+'.lower','scalar.interval',-2**31,t.interval[0])
        b.le(owner+'.upper','scalar.interval',t.interval[1],2**31-1)


def _affine(d,b):
    def bounds(i,scope,owner):
        x=d.indices[i];low=high=x.constant;domains={}
        chain=[]
        while scope>=0:chain.append(d.scopes[scope]);scope=d.scopes[scope].parent
        for sc in reversed(chain):domains.update((v,(a,z)) for v,a,z in sc.domain)
        for v,c in x.coefficients:
            a,z=domains[v];a=d.indices[a].constant;z=d.indices[z].constant
            b.le(owner,'affine.arithmetic',a,z)
            lo,hi=(a,z) if c>=0 else (z,a)
            low=b.add(owner,'affine.arithmetic',low,b.mul(owner,'affine.arithmetic',c,lo))
            high=b.add(owner,'affine.arithmetic',high,b.mul(owner,'affine.arithmetic',c,hi))
        return low,high
    for i,p in enumerate(d.proofs):
        if p.rule=='affine_le':
            a,c,difference,lo,hi=p.payload
            bounds(difference,p.scope,f'proof[{i}].affine')
            b.le(f'proof[{i}].inequality','affine.arithmetic',hi,0)
        elif p.rule=='parity':
            pvalue,nextslot,q,r,r1,decomp,succ,normal,carry=p.payload
            value=b.add(f'proof[{i}].successor','affine.arithmetic',pvalue,1)
            right=b.add(f'proof[{i}].decomposition','affine.arithmetic',b.mul(f'proof[{i}].carry','affine.arithmetic',2,carry),nextslot)
            b.le(f'proof[{i}].identity','affine.arithmetic',value,right)


def enumerate_work(derivation,accounting_spec=AccountingSpec()):
    """Enumerate this fixed checking model; incomplete never means invalid."""
    d=derivation;b=ChargedWork(accounting_spec);encoded=encode_hand_derivation(d)
    unresolved=['Source admission accounting depends on the new alpha-renaming adapter and its independent acceptance; fixed-alias probe and private-view field-copy inventories still require final audit.',
                'Rule-payload semantic replay beyond enumerated table/reference/arithmetic/substitution actions still needs complete charged call-site reconciliation.'];outcome='complete'
    try:
        _source_work(d,b)
        # All global tables are checked, including source/layout rows which are
        # not ancestors of the final effect spine. Trace rows are not proof rows.
        for table in TABLES:
            if table=='source_visits':continue
            for i,row in enumerate(getattr(d,table)):
                owner=f'{table}[{i}]'
                b.charge(owner,'table.rows')
                for j,value in enumerate(_walk(row)):
                    if type(value) is int:b.charge(owner+f'.field[{j}]','table.references',(value,),bits=width(value))
                    elif type(value) is str:b.charge(owner+f'.field[{j}]','table.references',(),structural=len(value)+1)
                    else:b.charge(owner+f'.field[{j}]','table.references')
        for i,s in enumerate(d.substitutions):
            b.charge(f'substitution[{i}].binder scopes','substitution.scope',(s.source_scope,s.target_scope),structural=1+len(s.replacements)*len(d.scopes))
        for i,s in enumerate(d.scopes):
            b.charge(f'scope[{i}].hypothesis ownership','scope.hypotheses',(s.parent,),structural=1+len(s.binders)+3*len(s.domain)+len(s.parity))
        for i,r in enumerate(d.regions):
            b.charge(f'region[{i}].typed geometry and closure','region.geometry',r.domain+r.physical_map+(r.closure,),structural=1+len(r.domain)+len(r.physical_map))
        for i,s in enumerate(d.states):
            b.charge(f'state[{i}].complete scalar/scratch/ledger','state.ledger',(s.environment,),structural=1+2*(len(s.scratch)+len(s.ledger))+2*len(d.scalar_envs[s.environment].bindings))
        for i,p in enumerate(d.proofs):
            if p.rule=='sequence':b.charge(f'proof[{i}].ordered cursor','physical.coverage',(p.incoming,p.outgoing,*p.premises),structural=1+3*len(p.premises))
        _intervals(d,b);_affine(d,b)
        substitutions=_SubstitutionWork(d,b)
        for i,p in enumerate(d.proofs):
            if p.rule=='membership':
                fact,row,col,sub,expected=p.payload
                result=substitutions.apply(f'proof[{i}].read-value',d.source_roots[0],sub,p.scope)
                b.le(f'proof[{i}].ordered value equality','table.references',result,expected)
                if result!=expected:raise ValueError('substitution result differs from actual source term')
            elif p.rule=='source_equal':
                actual,expected,root,sub=p.payload
                result=substitutions.apply(f'proof[{i}].store-value',root,sub,p.scope)
                b.le(f'proof[{i}].ordered value equality','table.references',result,actual)
                if result!=actual:raise ValueError('substitution result differs from actual physical term')
        for kind,data in (('plan',encoded.plan),('certificate',encoded.certificate)):
            b.charge(kind+'.serialize/hash/replay identity','artifact.identity',(len(data),),structural=3*len(data))
    except WorkExhausted as exc:
        outcome='incomplete';unresolved.append(str(exc))
    events=tuple(b.events)
    structural=sum(e.structural for e in events if not e.decoder)
    bits=sum(e.bits for e in events if not e.decoder)
    digest=hashlib.sha256(canonical(plain(events))).hexdigest()
    return WorkLedger(outcome,events,b.total,b.decoder,structural,bits,encoded.plan_sha256,encoded.certificate_sha256,
                      dependency_hashes(),digest,tuple(unresolved))


def reconcile_work(d,ledger):
    missing=[]
    required=set(work_families())
    observed={e.family for e in ledger.events}
    missing.extend('missing work family: '+x for x in sorted(required-observed))
    if ledger.event_sha256!=hashlib.sha256(canonical(plain(ledger.events))).hexdigest():missing.append('event sequence identity')
    if ledger.total_work!=sum(e.structural+e.bits for e in ledger.events if not e.decoder):missing.append('work total')
    if ledger.decoder_work!=sum(e.structural+e.bits for e in ledger.events if e.decoder):missing.append('decoder total')
    encoded=encode_hand_derivation(d)
    if (ledger.plan_sha256,ledger.certificate_sha256)!=(encoded.plan_sha256,encoded.certificate_sha256):missing.append('artifact identity')
    return tuple(missing)


def _measure(d,ledger):
    encoded=encode_hand_derivation(d)
    proof_tables=tuple(t for t in TABLES if t not in ('source_visits','operations','blocks'))
    integer_values=[v for table in TABLES if table!='source_visits' for row in getattr(d,table) for v in _walk(row) if type(v) is int]
    return {'source_bytes':len(d.source_bytes),'plan_bytes':len(encoded.plan),'certificate_bytes':len(encoded.certificate),
            'ir_nodes':len(d.operations),'scalar_definitions':sum(o.opcode not in ('for','scratch_store','output_store') for o in d.operations),
            'loop_depth':2,'affine_terms':max(len(x.coefficients) for x in d.indices),
            'active_facts':_active_inventory(d)[0],
            'region_pieces':_active_inventory(d)[1],
            'proof_nodes':sum(len(getattr(d,t)) for t in proof_tables),'parity_cases':sum(p.rule=='parity' for p in d.proofs),
            'symbolic_nodes':len(d.terms),'symbolic_depth':max(t.depth for t in d.terms),
            'integer_width':max(32,max(width(v) for v in integer_values)),'total_work':ledger.total_work}


def bound_hand_family(outline,source_envelope=SourceEnvelope(),accounting_spec=AccountingSpec()):
    """Return measured facts and independently justified bounds, never guesses.

    An unresolved total is deliberately represented as None; the earlier 32/64/
    128 reserved tables are not reused or silently upgraded to proof evidence.
    """
    source_envelope.__post_init__()
    from loop_proof_feasibility import source_bytes
    d=construct_hand_derivation(source_bytes(8191,1023),outline)
    ledger=enumerate_work(d,accounting_spec);measure=_measure(d,ledger)
    envelope=artifact_envelope(outline)
    fixed={name:envelope[name] for name in ('plan_bytes','certificate_bytes','proof_nodes','active_facts','region_pieces')}
    fixed.update({'source_bytes':65536,'ir_nodes':measure['ir_nodes'],'scalar_definitions':measure['scalar_definitions'],
           'loop_depth':2,'affine_terms':2,'parity_cases':measure['parity_cases'],
           'symbolic_nodes':measure['symbolic_nodes'],'symbolic_depth':6,'integer_width':32})
    reasons={name:'Finite hand syntax: fixed bodies and two parity cases; H/W appear only as affine literals.' for name in fixed}
    reasons['integer_width']='Signed-i32 lower endpoint has 32 magnitude bits; P<=2**23, pitch<=8193, bounded affine differences and intervals.'
    for name in ('plan_bytes','certificate_bytes','proof_nodes'):
        reasons[name]='Symbolic H/W constructor recurrence; exact containers/strings, eleven-byte numeric fields, B axis-name bytes and six bytes per origin.'
    for name in ('active_facts','region_pieces'):
        reasons[name]='Current complete scalar/scratch/ledger state plus every ancestor induction hypothesis and domain/parity assumption.'
    # Correctly keep expansion/accounting steps that need a checked recurrence
    # open, rather than derive an alleged envelope from a few numeric samples.
    unresolved=('F1: full deterministic source-name and rule-payload work envelope is not yet established.',
                'Decoder policy separates bounded ingestion from semantic work and requires explicit review; rejected-source paths are not covered by this accepted-family bound.')
    quotas=tuple(QuotaObservation(name,limit,measure[name],fixed.get(name),reasons.get(name,'No proved envelope bound; exact instance only.')) for name,limit in QUOTAS.items())
    recurrences=('Primitive instances: inline=4*4+3+1=20; materialize=5+8=13; rows2=5+2*(5+8)=31.',
                 'Induction instances: inline=2; materialize=2+2=4; rows2=1+1+2*(1+1)=6.',
                 'Ordered source DAG: open E=16; inline=16+15; materialize=16+3+15; rows2=16+3+2*(3+15).',
                 'Accepted-source AST N=56+G+C; G<=54*31; 31*C+D<=B<=65536; validation/profile visits=108+2G.',
                 'Exact trie attempt cost=len(fields)+3*prefix_free_key_bits+2; memo keys restrict replacements to actual free binders.')
    return BoundReport(outline,quotas,recurrences,(('bytes',65536),('groups',1674),('constraints',2048),('parser_nodes',3778)),dependency_hashes(),unresolved,ledger)


# Role numbers: H,W,input,producer,output,producer-axis0/1,output-axis0/1.
# Every entry corresponds to a retained source identifier token, not a guessed
# identifier-length cap. The accepted normalized AST fixes these multiplicities.
_NAME_MULTIPLICITIES=(4,4,3,5,1,3,3,5,5)


def _name_schedule():
    """Small-map access expansion of frontend.py plus open T/E reconstruction."""
    accesses=[]
    def access(owner,key,keys,times=1):
        for _ in range(times):accesses.append((owner,key,tuple(keys)))
    names=[];shapes=[];tensors=[]
    for role in (0,1,2,3,4):
        access('validate.declaration uniqueness',role,names,2);names.append(role)
        if role<2:
            access('validate.shape insert',role,shapes);shapes.append(role)
        elif role==2:
            for shape in (0,1):access('validate.input dimension',shape,shapes,2)
            access('validate.input tensor insert',role,tensors);tensors.append(role)
        else:
            axes=(5,6) if role==3 else (7,8)
            seen=[]
            for axis,shape in zip(axes,(0,1)):
                access('validate.axis uniqueness/insert',axis,seen,2);seen.append(axis)
                access('validate.axis upper',shape,shapes,2)
            reads=2 if role==3 else 4
            tensor=2 if role==3 else 3
            access('validate.scalar tensor',tensor,tensors,2*reads)
            for axis in axes:access('validate.scalar index',axis,axes,2*reads)
            for axis in axes:access('validate.tensor axis dimensions',axis,axes,2)
            access('validate.tensor insert',role,tensors);tensors.append(role)
    for role in (0,1):access('v2.dimension extraction',role,(0,1))
    for role in (0,1):access('profile.shape map',role,tuple(range(role)))
    for role in (2,3,4):access('profile.tensor map',role,tuple(range(2,role)))
    for axes in ((5,6),(7,8)):
        local=[0,1]
        access('profile.axis temporary map',axes[0],())
        access('profile.axis temporary map',axes[1],(axes[0],))
        for axis in axes:access('profile.local update',axis,local);local.append(axis)
        for shape in (0,1):access('profile.axis upper',shape,(0,1))
        reads=2 if axes==(5,6) else 4
        tensor=2 if axes==(5,6) else 3
        access('profile.scalar tensor',tensor,(2,3,4),reads)
        for axis in axes:access('profile.scalar index',axis,local,reads)
    for shape in (0,1):access('profile.input dimension',shape,(0,1))
    # Resolve retained AST names to numeric binder/tensor roles ONCE before
    # repeated producer expansion; subsequent substitution uses numeric IDs.
    for axes,repetitions in (((5,6),1),((7,8),1)):
        access('source.local axis insert',axes[1],(axes[0],),repetitions)
        reads=2 if axes==(5,6) else 4
        tensor=2 if axes==(5,6) else 3
        access('source.tensor identity',tensor,(2,) if tensor==2 else (2,3),reads*repetitions)
        for axis in axes:access('source.index lookup',axis,axes,reads*repetitions)
    return tuple(accesses)


def _adapter_name_edges():
    # Declaration order is forced by dependency visibility; constraints do not
    # resolve names. Names denote roles, so this is independent of spelling.
    occurrences=(0,1,2,0,1,3,5,0,6,1,2,5,6,2,5,6,4,7,0,8,1,
                 3,7,8,3,7,8,3,7,8,3,7,8)
    residents=[];edges=[]
    for key in occurrences:
        candidates=residents[:residents.index(key)+1] if key in residents else residents[:]
        edges.extend((key,candidate) for candidate in candidates)
        if key not in residents:residents.append(key)
    return tuple(edges)


def _binding_name_edges():
    edges=[]
    for axes,reads,tensor in (((5,6),2,2),((7,8),4,3)):
        for key in axes:
            edges.extend((key,candidate) for _ in range(reads) for candidate in axes[:axes.index(key)+1])
        edges.extend((tensor,candidate) for _ in range(reads) for candidate in ((2,) if tensor==2 else (2,3)))
    return tuple(edges)


def name_envelope():
    """Exact finite layer-cake bound for TWO original-name resolution passes.

    min(a,b)=sum_{k>=1}1[a>=k and b>=k]. Each depth selects one of 511
    nonempty role subsets. The adapter prefix scan and source-binding scan use
    their actual comparison graphs; four axis-spelling artifact/table passes
    are included. Same-spelling roles merge registry entries, shortening scans.
    No original-name hashing or cache assumption appears in this bound.
    """
    edges=_adapter_name_edges()+_binding_name_edges()
    best_num=0;best_den=1;best_mask=0
    for mask in range(1,1<<9):
        denominator=sum(m for i,m in enumerate(_NAME_MULTIPLICITIES) if mask&(1<<i))
        numerator=sum(1 for key,candidate in edges if mask&(1<<key) and mask&(1<<candidate))
        numerator+=4*sum(bool(mask&(1<<i)) for i in (5,6,7,8))
        if numerator*best_den>best_num*denominator:best_num,best_den,best_mask=numerator,denominator,mask
    return best_num,best_den,best_mask,33+18,len(edges)


class _EnvelopeInteger(int):
    """Polynomial labels prevent specialization coincidences from interning.

    Numeric values only follow the already-proved fixed control path. The
    expression identity, never these representative numbers, decides sharing.
    Multiplication is exact polynomial multiplication; quotient labels are opaque
    independent atoms, which may conservatively prevent additional sharing.
    """
    def __new__(cls,value,expression):
        result=int.__new__(cls,value)
        result.expression=tuple(sorted((m,c) for m,c in expression if c))
        return result

    @staticmethod
    def of(value):
        return value if isinstance(value,_EnvelopeInteger) else _EnvelopeInteger(value,(((),int(value)),))

    @staticmethod
    def parameter(name,value):return _EnvelopeInteger(value,(((name,),1),))

    def __add__(self,other):
        other=self.of(other);terms={}
        for monomial,c in self.expression+other.expression:terms[monomial]=terms.get(monomial,0)+c
        return _EnvelopeInteger(int(self)+int(other),tuple(terms.items()))
    __radd__=__add__

    def __neg__(self):return _EnvelopeInteger(-int(self),tuple((m,-c) for m,c in self.expression))
    def __sub__(self,other):return self+-self.of(other)
    def __rsub__(self,other):return self.of(other)+-self

    def __mul__(self,other):
        other=self.of(other);terms={}
        for a,x in self.expression:
            for b,y in other.expression:
                monomial=tuple(sorted(a+b));terms[monomial]=terms.get(monomial,0)+x*y
        return _EnvelopeInteger(int(self)*int(other),tuple(terms.items()))
    __rmul__=__mul__

    def __floordiv__(self,other):
        other=self.of(other)
        atom='floor('+repr(self.expression)+'/'+repr(other.expression)+')'
        return _EnvelopeInteger(int(self)//int(other),(((atom,),1),))

    def __eq__(self,other):
        return isinstance(other,int) and self.expression==self.of(other).expression
    def __ne__(self,other):return not self==other
    def __hash__(self):return hash(self.expression)


def _abstract_constructor(outline):
    from loop_proof_graph import _Builder
    from loop_proof_feasibility import source_bytes
    return _Builder(source_bytes(8191,1023),outline,_shape_lift=_EnvelopeInteger.parameter).construct()


def _active_inventory(d):
    """Simultaneous whole-state facts plus every open induction hypothesis.

    Persistent table rows are not active assertions. For a proof scope count its
    current scalar bindings, scratch facts and ledger pieces; add each ancestor
    hypothesis in full and its domain/parity assumptions. Counting the current
    hypothesis twice is conservative at its own introduction row.
    """
    hypotheses={p.scope:p.incoming for p in d.proofs if p.rule=='hypothesis'}
    def size(state):
        if state<0:return 0,0
        s=d.states[state];pieces=len(s.scratch)+len(s.ledger)
        return len(d.scalar_envs[s.environment].bindings)+pieces,pieces
    active=pieces=0
    for p in d.proofs:
        inherited=ipieces=0;scope=p.scope
        while scope>=0:
            sc=d.scopes[scope]
            inherited+=2*len(sc.domain)+(1 if sc.parity else 0)
            if scope in hypotheses:
                a,r=size(hypotheses[scope]);inherited+=a;ipieces+=r
            scope=sc.parent
        for state in (p.incoming,p.outgoing):
            a,r=size(state);active=max(active,a+inherited);pieces=max(pieces,r+ipieces)
    return active,pieces


def artifact_envelope(outline):
    """Constructive row/byte recurrence, independent of specialization sharing.

    H and W are polynomial atoms for table interning. The finite syntax contains
    no extent-dependent loop: two scalar source trees, one or two induction
    bodies, and exactly two ring cases. Empty prefix/one-cell join choices depend
    on affine coefficients and fixed literal offsets, not numeric H/W values.
    Ring slot choices depend on the fixed case remainder only. Thus numerical
    specialization can merge symbolic rows but cannot split one. Quotients are
    fresh atoms, conservatively preventing any extra quotient sharing.

    Source wrappers do not allocate proof/index/term rows; their original offsets
    occur in one header origin array. The only unbounded strings are the four
    source-axis spellings, appearing once each in the binder table. Their total
    byte length is at most B. Every other string and container is serialized
    exactly here. Every numeric field is replaced by eleven bytes, the maximum
    signed 32-magnitude-bit decimal width. This also covers all source offsets
    and spans, IDs and fixed quota/profile integers.
    """
    d=_abstract_constructor(outline)
    encoded=encode_hand_derivation(d)
    def wide(value):
        if isinstance(value,int):return -9999999999  # eleven bytes including sign
        if isinstance(value,list):return [wide(x) for x in value]
        return value
    plan=wide(json.loads(encoded.plan));certificate=wide(json.loads(encoded.certificate))
    # Origin offsets are unsigned <=65536, each <=5 decimal bytes. Include a
    # separate comma per entry, overcounting the final entry by one byte.
    certificate[5]=[]
    for table,rows in certificate[9]:
        if table=='binders':
            for row in rows:
                if row[0]=='source':row[2]=''
    origin_bound=64+1674+2048
    rows={t:len(getattr(d,t)) for t in TABLES if t!='source_visits'}
    proof_tables=tuple(t for t in rows if t not in ('operations','blocks'))
    active,pieces=_active_inventory(d)
    return {'rows':rows,'plan_bytes':len(canonical(plan)),
            'certificate_bytes':len(canonical(certificate))+65536+6*origin_bound,
            'proof_nodes':sum(rows[t] for t in proof_tables)+origin_bound,
            'active_facts':active,'region_pieces':pieces,
            'origin_entries':origin_bound,
            'constructor_calls':d.constructor_calls,
            'row_widths':tuple((t,tuple(len(canonical(wide(plain(row)))) for row in getattr(d,t))) for t in rows)}

"""Complete hand examples are research artifacts, never eligibility receipts."""
import dataclasses
import importlib.util
import json
import unittest
from loop_proof_feasibility import source_bytes

class ConstructiveGraphTests(unittest.TestCase):
    def api(self):
        self.assertIsNotNone(importlib.util.find_spec('loop_proof_graph'), 'P1 requires actual typed hand graphs')
        import loop_proof_graph
        return loop_proof_graph

    def test_complete_inventories_state_links_and_encoding(self):
        api = self.api()
        for outline, primitives, inductions, physical in (('inline',20,2,22),('materialize',13,4,17),('rows2',31,6,22)):
            with self.subTest(outline=outline):
                graph = api.construct_hand_derivation(source_bytes(32,33),outline)
                self.assertEqual(api.audit_hand_derivation(graph),())
                self.assertEqual(sum(p.rule=='primitive' for p in graph.proofs),primitives)
                self.assertEqual(sum(p.rule=='induction' for p in graph.proofs),inductions)
                self.assertEqual(len(graph.operations),physical)
                encoded = api.encode_hand_derivation(graph)
                self.assertEqual(encoded,api.encode_hand_derivation(graph))
                self.assertEqual(json.dumps(json.loads(encoded.certificate),separators=(',',':'),ensure_ascii=False).encode(),encoded.certificate)
                self.assertLess(len(encoded.certificate),524288)
                self.assertLess(len(encoded.plan),262144)
                self.assertFalse(hasattr(graph,'eligible'))
                self.assertGreater(len(graph.states),primitives)
                self.assertEqual(graph.states[graph.initial_state].ledger,())
                self.assertEqual(len(graph.states[graph.final_state].ledger),1)
                if outline!='inline':
                    self.assertEqual(max(len(s.scratch) for s in graph.states),3)

    def test_source_formals_are_separate_and_original_tree_is_preserved(self):
        api = self.api()
        graph = api.construct_hand_derivation(source_bytes(1,1),'rows2')
        self.assertTrue({'source','physical','region','parity'} <= {b.namespace for b in graph.binders})
        self.assertTrue(all(c.formals==graph.formals for c in graph.closures))
        self.assertEqual(len(graph.terms),55)
        self.assertTrue(graph.source_visits)
        self.assertTrue(all(v.origin in graph.origins for v in graph.source_visits))

    def test_deleted_or_reordered_operation_and_disconnected_state_are_detected(self):
        api=self.api()
        graph=api.construct_hand_derivation(source_bytes(4,5),'inline')
        self.assertTrue(api.audit_hand_derivation(dataclasses.replace(graph,operations=graph.operations[:-1])))
        primitive=next(i for i,p in enumerate(graph.proofs) if p.rule=='primitive')
        rows=list(graph.proofs)
        rows[primitive]=dataclasses.replace(rows[primitive],incoming=graph.final_state)
        self.assertTrue(api.audit_hand_derivation(dataclasses.replace(graph,proofs=tuple(rows))))
        rows=list(graph.blocks)
        body=next(i for i,b in enumerate(rows) if len(b.operations)>2)
        rows[body]=dataclasses.replace(rows[body],operations=tuple(reversed(rows[body].operations)))
        self.assertTrue(api.audit_hand_derivation(dataclasses.replace(graph,blocks=tuple(rows))))

    def test_graph_size_is_extent_independent(self):
        api=self.api()
        for outline in ('inline','materialize','rows2'):
            graphs=[api.construct_hand_derivation(source_bytes(h,w),outline) for h,w in ((1,1),(32,32),(128,128),(512,512),(2048,2048),(8191,1023),(8192,1022),(1023,8191),(1022,8192))]
            self.assertEqual(len({tuple(len(getattr(g,t)) for t in api.TABLES if t!='indices') for g in graphs}),1)
            self.assertLessEqual(max(len(g.indices) for g in graphs),64)
            for graph in graphs:
                self.assertEqual(api.audit_hand_derivation(graph),())

if __name__=='__main__': unittest.main()

class AdversarialGraphTests(unittest.TestCase):
    def setUp(self):
        from loop_proof_graph import construct_hand_derivation
        self.graph=construct_hand_derivation(source_bytes(3,4),'rows2')

    def reject(self,table,index,**changes):
        from loop_proof_graph import audit_hand_derivation
        rows=list(getattr(self.graph,table))
        rows[index]=dataclasses.replace(rows[index],**changes)
        mutated=dataclasses.replace(self.graph,**{table:tuple(rows)})
        self.assertTrue(audit_hand_derivation(mutated),f'undetected {table}[{index}] {changes}')

    def test_reset_ledger_wrong_successor_missing_base_and_escaped_hypothesis(self):
        g=self.graph
        induction=next(p for p in g.proofs if p.rule=='induction' and g.states[p.payload[1]].ledger)
        hypothesis=induction.payload[1]
        self.reject('states',hypothesis,ledger=())
        self.reject('proofs',induction.premises[0],rule='omitted_base')
        step=g.proofs[induction.premises[3]]
        sub=step.payload[0]
        binder=g.operations[induction.operation].binder
        wrong=next(i for i,x in enumerate(g.indices) if x.constant==0 and x.coefficients==((binder,1),))
        self.reject('substitutions',sub,replacements=((binder,wrong),))
        self.reject('proofs',induction.premises[4],scope=induction.payload[0])

    def test_closure_capture_wrong_scope_and_incompatible_ring_map(self):
        g=self.graph
        self.reject('closures',0,formals=(g.formals[0],g.formals[0]))
        self.reject('substitutions',0,source_scope=0)
        idx=next(i for i,r in enumerate(g.regions) if r.kind=='scratch' and r.domain[2]!=r.domain[3] and r.domain[0]!=r.domain[1] and g.indices[r.physical_map[0]].constant==1 and not g.indices[r.physical_map[0]].coefficients)
        zero=next(i for i,x in enumerate(g.indices) if x.constant==0 and not x.coefficients and not x.modulo)
        self.reject('regions',idx,physical_map=(zero,g.regions[idx].physical_map[1]))

    def test_parity_omission_duplicate_and_cross_scope_premise(self):
        g=self.graph
        i=next(i for i,p in enumerate(g.proofs) if p.rule=='cases')
        self.reject('proofs',i,premises=g.proofs[i].premises[:1])
        self.reject('proofs',i,premises=(g.proofs[i].premises[0],)*2)
        p=next(i for i,p in enumerate(g.proofs) if p.rule=='parity')
        self.reject('proofs',p,scope=0)

    def test_input_coordinate_scalar_association_and_origin(self):
        g=self.graph
        i=next(i for i,o in enumerate(g.operations) if o.opcode=='input_load')
        op=g.operations[i]
        self.reject('operations',i,indices=tuple(reversed(op.indices)))
        self.reject('operations',i,origins=(len(g.source_bytes)-2,))
        i=next(i for i,t in enumerate(g.terms) if t.operator=='add' and t.depth==6)
        self.reject('terms',i,children=tuple(reversed(g.terms[i].children)))

    def test_grouped_indices_and_long_spelling_reconstruct(self):
        from loop_proof_graph import construct_hand_derivation,audit_hand_derivation,encode_hand_derivation
        source=source_bytes(2,3).replace(b'image[r,c]',b'image[((r)),((c))]').replace(b'p[r,c+1]',b'p[(r),(c+(1))]')
        graph=construct_hand_derivation(source,'rows2')
        self.assertEqual(audit_hand_derivation(graph),())
        self.assertEqual(len(graph.terms),55)
        self.assertGreater(len(graph.source_visits),len(self.graph.source_visits))
        self.assertLess(len(encode_hand_derivation(graph).certificate),524288)

class PhysicalAddressTests(unittest.TestCase):
    def test_ring_load_addresses_are_part_of_exact_plan(self):
        from loop_proof_graph import construct_hand_derivation,encode_hand_derivation,audit_hand_derivation
        graph=construct_hand_derivation(source_bytes(3,4),'rows2')
        for op in graph.operations:
            if op.opcode in ('scratch_load','scratch_store'):
                self.assertEqual(len(op.indices),3)
                self.assertEqual(graph.indices[op.indices[2]].modulo,2)
        # The informational example label is absent from both artifacts and
        # does not participate in either local rule audit.
        relabelled=dataclasses.replace(graph,outline='untrusted-label')
        self.assertEqual(encode_hand_derivation(graph),encode_hand_derivation(relabelled))
        self.assertEqual(audit_hand_derivation(relabelled),())

    def test_changed_physical_load_map_is_detected(self):
        from loop_proof_graph import construct_hand_derivation,audit_hand_derivation
        graph=construct_hand_derivation(source_bytes(3,4),'rows2')
        rows=list(graph.operations)
        i=next(i for i,o in enumerate(rows) if o.opcode=='scratch_load')
        rows[i]=dataclasses.replace(rows[i],indices=rows[i].indices[:2]+(rows[i].indices[0],))
        self.assertTrue(audit_hand_derivation(dataclasses.replace(graph,operations=tuple(rows))))

class RulePayloadTests(unittest.TestCase):
    def test_each_required_rule_rejects_empty_payload_and_missing_premises(self):
        from loop_proof_graph import construct_hand_derivation,audit_hand_derivation
        graph=construct_hand_derivation(source_bytes(3,4),'rows2')
        for rule in ('source','layout','membership','address','invalidate','scope_projection','euclidean_partition'):
            with self.subTest(rule=rule):
                rows=list(graph.proofs);i=next(i for i,p in enumerate(rows) if p.rule==rule)
                rows[i]=dataclasses.replace(rows[i],payload=(),premises=())
                self.assertTrue(audit_hand_derivation(dataclasses.replace(graph,proofs=tuple(rows))))
        self.assertTrue(audit_hand_derivation(dataclasses.replace(graph,source_roots=(1,1))))

    def test_exit_eliminates_discharged_invariant_not_substituted_successor(self):
        from loop_proof_graph import construct_hand_derivation
        graph=construct_hand_derivation(source_bytes(3,4),'inline')
        for p in graph.proofs:
            if p.rule=='induction':
                exit=graph.proofs[p.premises[-1]]
                self.assertEqual(exit.incoming,p.incoming)
                self.assertEqual(exit.payload[1],p.payload[1])
                self.assertIn(p.premises[0],exit.premises)

class RemainingSchemaControls(unittest.TestCase):
    def test_store_physical_map_is_checked_against_proof(self):
        from loop_proof_graph import construct_hand_derivation,audit_hand_derivation
        graph=construct_hand_derivation(source_bytes(3,4),'rows2')
        rows=list(graph.operations)
        i=next(i for i,o in enumerate(rows) if o.opcode=='scratch_store' and graph.indices[o.indices[0]].coefficients)
        zero=next(i for i,x in enumerate(graph.indices) if x.constant==0 and not x.coefficients and not x.modulo)
        rows[i]=dataclasses.replace(rows[i],indices=rows[i].indices[:2]+(zero,))
        self.assertTrue(audit_hand_derivation(dataclasses.replace(graph,operations=tuple(rows))))

    def test_source_binding_table_and_visit_binder_keys_are_checked(self):
        from loop_proof_graph import construct_hand_derivation,audit_hand_derivation
        graph=construct_hand_derivation(source_bytes(3,4),'rows2')
        self.assertTrue(audit_hand_derivation(dataclasses.replace(graph,source_bindings=())))
        visits=list(graph.source_visits)
        visits[0]=dataclasses.replace(visits[0],replacements=tuple((999,x) for _,x in visits[0].replacements))
        self.assertTrue(audit_hand_derivation(dataclasses.replace(graph,source_visits=tuple(visits))))

    def test_origin_inventory_is_reconstructed_from_original_ast(self):
        from loop_proof_graph import construct_hand_derivation,audit_hand_derivation
        graph=construct_hand_derivation(source_bytes(3,4),'inline')
        self.assertTrue(audit_hand_derivation(dataclasses.replace(graph,origins=graph.origins+(65535,))))

"""Accounting tests exercise actual events, not a success/eligibility token."""
import dataclasses
import importlib.util
import unittest
from loop_proof_feasibility import source_bytes
from loop_proof_graph import construct_hand_derivation

class WorkTests(unittest.TestCase):
    def api(self):
        self.assertIsNotNone(importlib.util.find_spec('loop_proof_cost'),'P1 requires explicit charged work')
        import loop_proof_cost
        return loop_proof_cost

    def test_all_manifest_families_are_charged_and_event_omission_is_detected(self):
        api=self.api()
        graph=construct_hand_derivation(source_bytes(32,33),'rows2')
        ledger=api.enumerate_work(graph,api.AccountingSpec())
        self.assertEqual(ledger.outcome,'complete')
        self.assertEqual(ledger.total_work,sum(e.structural+e.bits for e in ledger.events if not e.decoder))
        self.assertEqual(api.reconcile_work(graph,ledger),())
        for family in api.work_families():
            with self.subTest(family=family):
                missing=dataclasses.replace(ledger,events=tuple(e for e in ledger.events if e.family!=family))
                self.assertTrue(api.reconcile_work(graph,missing))
        self.assertTrue(all(e.owner and e.widths==tuple(max(1,abs(x).bit_length()) for x in e.inputs) for e in ledger.events))
        self.assertTrue(ledger.dependency_hashes)
        self.assertGreater(ledger.decoder_work,0)

    def test_arithmetic_exact_limit_and_negative_i32_width(self):
        api=self.api()
        b=api.ChargedWork(api.AccountingSpec(work_limit=33))
        self.assertTrue(b.le('test','affine.arithmetic',-2**31,0))
        self.assertEqual(b.total,33)
        with self.assertRaises(api.WorkExhausted): b.add('test','affine.arithmetic',0,0)
        self.assertEqual(b.total,33)
        b=api.ChargedWork(api.AccountingSpec())
        with self.assertRaises(api.WorkExhausted):b.mul('test','affine.arithmetic',1<<255,2)

    def test_exact_keys_shared_dag_and_scope_distinctions(self):
        api=self.api()
        budget=api.ChargedWork(api.AccountingSpec())
        keys=api.ExactKeys(budget)
        self.assertEqual(keys.lookup('first',(1,2,3)),(0,False))
        self.assertEqual(keys.lookup('equal-prefix',(1,2,4)),(1,False))
        self.assertEqual(keys.lookup('hit',(1,2,3)),(0,True))
        self.assertGreater(budget.total,0)
        graph=construct_hand_derivation(source_bytes(2,3),'rows2')
        ledger=api.enumerate_work(graph,api.AccountingSpec())
        substitutions=[e for e in ledger.events if e.family=='substitution.reachable']
        self.assertTrue(substitutions)
        self.assertTrue(any(e.memo=='hit' for e in ledger.events))

    def test_envelope_distinguishes_measurements_bounds_and_unknowns(self):
        api=self.api()
        for outline in ('inline','materialize','rows2'):
            bound=api.bound_hand_family(outline,api.SourceEnvelope(),api.AccountingSpec())
            self.assertEqual({q.name for q in bound.quotas},set(api.QUOTAS))
            self.assertTrue(all(q.measured>=0 and (q.bound is None or q.bound>=q.measured) for q in bound.quotas))
            self.assertTrue(bound.recurrences)
            self.assertFalse(hasattr(bound,'eligible'))

if __name__=='__main__':unittest.main()

class FrozenAccountingTests(unittest.TestCase):
    def test_frozen_quota_constants(self):
        from loop_proof_cost import QUOTAS
        self.assertEqual(QUOTAS['scalar_definitions'],4096)
        self.assertEqual(QUOTAS['loop_depth'],4)
        self.assertEqual(QUOTAS['parity_cases'],16)

    def test_key_allocation_is_after_quota_charge(self):
        from loop_proof_cost import ExactKeys,ChargedWork,AccountingSpec,WorkExhausted
        from unittest.mock import patch
        keys=ExactKeys(ChargedWork(AccountingSpec(work_limit=1)))
        with patch.object(ExactKeys,'bits',side_effect=AssertionError('allocated before charge')):
            with self.assertRaises(WorkExhausted):keys.lookup('quota',(1,2,3))

class SourceEnvelopeControls(unittest.TestCase):
    def test_source_spelling_extremes_and_limit_plus_one(self):
        from loop_proof_cost import enumerate_work,AccountingSpec
        from axiom.model import DiagnosticError
        base=source_bytes(2,3)
        comment=base+b'//'+b'x'*(65536-len(base)-2)
        variants=(comment,base.replace(b'result',b'z'*64000),base+b'require plan_workspace_bytes<=2147483647;\n'*1500,
                  base.replace(b'image[r,c]',b'image['+b'('*20+b'r'+b')'*20+b',c]'))
        for source in variants:
            with self.subTest(length=len(source)):
                graph=construct_hand_derivation(source,'rows2')
                ledger=enumerate_work(graph,AccountingSpec())
                self.assertEqual(ledger.outcome,'complete')
                self.assertTrue(ledger.unresolved)  # No conditional cost can approve F1.
                self.assertLessEqual(ledger.total_work,1000000)
        with self.assertRaises(DiagnosticError):construct_hand_derivation(comment+b'x','rows2')

    def test_name_bound_is_finite_layer_cake_not_numeric_shape_sampling(self):
        from loop_proof_cost import name_envelope
        numerator,denominator,mask,actions,edges=name_envelope()
        self.assertEqual(numerator*11,denominator*67)
        self.assertEqual(edges,185)
        self.assertGreater(actions,0)

class ConstructiveSizeEnvelopeTests(unittest.TestCase):
    def test_symbolic_rows_and_exact_width_bytes_dominate_specializations(self):
        from loop_proof_cost import artifact_envelope
        from loop_proof_graph import TABLES,encode_hand_derivation
        for outline in ('inline','materialize','rows2'):
            bound=artifact_envelope(outline)
            self.assertLess(bound['plan_bytes'],262144)
            self.assertLess(bound['certificate_bytes'],524288)
            self.assertLess(bound['proof_nodes'],16384)
            for h,w in ((1,1),(2,3),(32,32),(8191,1023),(1023,8191)):
                graph=construct_hand_derivation(source_bytes(h,w),outline)
                encoded=encode_hand_derivation(graph)
                self.assertLessEqual(len(encoded.plan),bound['plan_bytes'])
                self.assertLessEqual(len(encoded.certificate),bound['certificate_bytes'])
                for table in TABLES:
                    if table!='source_visits':self.assertLessEqual(len(getattr(graph,table)),bound['rows'][table])

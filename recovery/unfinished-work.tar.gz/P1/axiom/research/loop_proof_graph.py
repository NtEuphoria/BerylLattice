"""Explicit, immutable C1 hand derivations. No arbitrary-plan acceptance API.

The constructor emits ordinary rule instances. Schedule names select examples;
no rule reads that name. ``audit_hand_derivation`` is a research consistency
check, not the future C4/C5 hostile-input checker or a proof eligibility token.
References are zero-based and typed by the dataclass field and table directory.
"""
from dataclasses import dataclass, fields, is_dataclass, replace
import hashlib
import json
from pathlib import Path

from axiom.model import BinaryExpression, GroupExpression, IntegerLiteral, NameReference, ReadExpression
from axiom.source_profiles import SourceLimitsV2, SourceProfileV2, admit_source_v2


class ConstructionError(ValueError):
    pass


def need(value, message):
    if not value:
        raise ConstructionError(message)


@dataclass(frozen=True)
class Binder:
    namespace: str
    owner: int
    name: str


@dataclass(frozen=True)
class Scope:
    parent: int
    binders: tuple
    domain: tuple  # (binder, lower-index, inclusive-upper-index)
    parity: tuple  # (physical row binder, quotient binder, remainder)


@dataclass(frozen=True)
class Index:
    constant: int
    coefficients: tuple
    modulo: int = 0  # 0 = affine, 2 = Euclidean remainder of this affine


@dataclass(frozen=True)
class Term:
    operator: str
    payload: tuple
    children: tuple
    free: tuple
    interval: tuple
    depth: int
    context: int


@dataclass(frozen=True)
class Substitution:
    source_scope: int
    target_scope: int
    replacements: tuple


@dataclass(frozen=True)
class Closure:
    root: int
    formals: tuple
    substitution: int


@dataclass(frozen=True)
class Region:
    domain: tuple
    physical_map: tuple
    closure: int
    kind: str


@dataclass(frozen=True)
class ScalarEnvironment:
    bindings: tuple  # ordered (physical SSA operation id, term id)


@dataclass(frozen=True)
class State:
    environment: int
    scratch: tuple
    ledger: tuple


@dataclass(frozen=True)
class Operation:
    opcode: str
    block: int
    operands: tuple
    indices: tuple
    literal: int
    body: int
    binder: int
    bounds: tuple
    origins: tuple


@dataclass(frozen=True)
class Block:
    operations: tuple


@dataclass(frozen=True)
class Proof:
    rule: str
    scope: int
    operation: int
    incoming: int
    outgoing: int
    payload: tuple
    premises: tuple


@dataclass(frozen=True)
class SourceVisit:
    origin: int
    scope: int
    replacements: tuple
    result: int
    kind: str
    length: int
    node_kind: str


@dataclass(frozen=True)
class SourceBinding:
    origin: int
    length: int
    kind: str
    target: int


@dataclass(frozen=True)
class HandDerivation:
    outline: str
    source_bytes: bytes
    identities: tuple
    shape: tuple
    pitch: int
    capacity: int
    formals: tuple
    source_roots: tuple
    origins: tuple
    binders: tuple
    scopes: tuple
    indices: tuple
    terms: tuple
    substitutions: tuple
    closures: tuple
    regions: tuple
    scalar_envs: tuple
    states: tuple
    operations: tuple
    blocks: tuple
    proofs: tuple
    source_visits: tuple
    source_bindings: tuple
    root: int
    initial_state: int
    final_state: int
    constructor_calls: tuple


TABLES = ('binders','scopes','indices','terms','substitutions','closures','regions',
          'scalar_envs','states','operations','blocks','proofs','source_visits','source_bindings')


@dataclass(frozen=True)
class EncodedHandArtifact:
    plan: bytes
    certificate: bytes
    plan_sha256: str
    certificate_sha256: str
    row_widths: tuple


def plain(value):
    if is_dataclass(value):
        return [plain(getattr(value,f.name)) for f in fields(value)]
    if isinstance(value, tuple):
        return [plain(v) for v in value]
    return value


def canonical(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False).encode('utf-8')


def encode_hand_derivation(d):
    plan = canonical(['c1-hand-plan-1',d.identities,d.shape,d.pitch,d.capacity,
                      plain(d.operations),plain(d.blocks)])
    plan_hash = hashlib.sha256(plan).hexdigest()
    tables = tuple(t for t in TABLES if t not in ('operations','blocks','source_visits'))
    certificate = canonical(['c1-hand-proof-1',d.identities,plan_hash,d.formals,d.source_roots,
                             d.origins,d.root,d.initial_state,d.final_state,
                             [[t,plain(getattr(d,t))] for t in tables]])
    widths = tuple((t,tuple(len(canonical(plain(row))) for row in getattr(d,t))) for t in TABLES)
    return EncodedHandArtifact(plan,certificate,plan_hash,hashlib.sha256(certificate).hexdigest(),widths)


class _Builder:
    def __init__(self, source, outline, *, _shape_lift=None):
        need(outline in ('inline','materialize','rows2'),'unsupported outline')
        self.kernel = admit_source_v2(source,profile=SourceProfileV2(),limits=SourceLimitsV2())
        self.outline = outline
        self.h,self.w = self.kernel.height,self.kernel.width
        if _shape_lift is not None:
            self.h,self.w=_shape_lift('H',self.h),_shape_lift('W',self.w)
        self.pitch = self.w+1
        self.capacity = {'inline':0,'materialize':(self.h+1)*self.pitch,'rows2':2*self.pitch}[outline]
        self.calls={}
        for t in TABLES:
            setattr(self,t,[])
        self.scopes.append(Scope(-1,(),(),()))
        self.scalar_envs.append(ScalarEnvironment(()))
        self.initial = self.state((),())
        self.module = self.kernel.source_module
        self.producer,self.output = self.module.producers[0],self.module.outputs[0]
        self.origin_nodes = {}
        def walk(obj):
            if is_dataclass(obj):
                if hasattr(obj,'span'):
                    self.origin_nodes.setdefault(obj.span.offset,[]).append(type(obj).__name__)
                for f in fields(obj):
                    if f.name not in ('span','name_span'):
                        walk(getattr(obj,f.name))
            elif isinstance(obj,tuple):
                for x in obj: walk(x)
        walk(self.module)
        self.source_axes = tuple(self.binder('source',0,a.name) for decl in (self.producer,self.output) for a in decl.axes)
        self.source_node_axes = {}
        self.source_slots = {}
        self.source_tensor_roles = {}
        def source_axes(node, axes):
            self.source_node_axes[id(node)] = axes
            if isinstance(node,NameReference):
                slot=next(i for i,b in enumerate(axes) if self.binders[b].name==node.name)
                self.source_slots[id(node)]=slot
                self.source_bindings.append(SourceBinding(node.span.offset,node.span.length,'index',axes[slot]))
            if isinstance(node,ReadExpression):
                role=0 if node.name==self.module.inputs[0].name else 1
                need(role==0 or node.name==self.producer.name,'source tensor resolution')
                self.source_tensor_roles[id(node)]=role
                self.source_bindings.append(SourceBinding(node.span.offset,node.span.length,'tensor',role))
            if isinstance(node,GroupExpression): source_axes(node.expression,axes)
            elif isinstance(node,BinaryExpression):
                source_axes(node.left,axes);source_axes(node.right,axes)
            elif isinstance(node,ReadExpression):
                for child in node.indices: source_axes(child,axes)
        source_axes(self.producer.expression,self.source_axes[:2])
        source_axes(self.output.expression,self.source_axes[2:])
        self.formals = (self.binder('region',0,'u'),self.binder('region',0,'v'))
        self.formal_scope = self.scope(0,self.formals,())
        self.uv = tuple(self.var(b) for b in self.formals)
        self.troot = self.expand(self.producer.expression,self.uv,self.formal_scope)
        self.eroot = self.expand(self.output.expression,self.uv,self.formal_scope)
        self.proof('source',0,payload=(self.troot,self.eroot,*self.source_axes,*self.formals))
        self.proof('layout',0,payload=(self.pitch,self.capacity,self.h,self.w))
        self.build_plan()

    def add(self,table,row):
        self.calls['allocate.'+table]=self.calls.get('allocate.'+table,0)+1
        values=getattr(self,table)
        values.append(row)
        return len(values)-1

    def intern(self,table,row):
        self.calls['intern.'+table]=self.calls.get('intern.'+table,0)+1
        values=getattr(self,table)
        try: return values.index(row)
        except ValueError: return self.add(table,row)

    def binder(self,space,owner,name):
        return self.add('binders',Binder(space,owner,name))

    def scope(self,parent,binders,domain,parity=()):
        return self.add('scopes',Scope(parent,tuple(binders),tuple(domain),tuple(parity)))

    def idx(self,constant=0,coefficients=(),modulo=0):
        merged={}
        for b,c in coefficients: merged[b]=merged.get(b,0)+c
        return self.intern('indices',Index(constant,tuple(sorted((b,c) for b,c in merged.items() if c)),modulo))

    def var(self,b): return self.idx(0,((b,1),))

    def plus(self,a,b):
        x,y=self.indices[a],self.indices[b]
        need(not x.modulo and not y.modulo,'affine addition of remainder')
        return self.idx(x.constant+y.constant,x.coefficients+y.coefficients)

    def shift(self,a,n): return self.plus(a,self.idx(n))

    def modulo(self,a):
        x=self.indices[a]
        return self.idx(x.constant,x.coefficients,2)

    def substitution(self,source_scope,target_scope,pairs):
        return self.intern('substitutions',Substitution(source_scope,target_scope,tuple(sorted(pairs))))

    def term(self,op,payload=(),children=(),context=0):
        if op=='const': interval=(payload[0],payload[0]); free=()
        elif op=='input':
            interval=(0,1023)
            free=tuple(sorted({b for i in payload for b,_ in self.indices[i].coefficients}))
        else:
            x,y=(self.terms[c] for c in children)
            free=tuple(sorted(set(x.free)|set(y.free)))
            if op=='add': interval=(x.interval[0]+y.interval[0],x.interval[1]+y.interval[1])
            else:
                ends=tuple(a*b for a in x.interval for b in y.interval)
                interval=(min(ends),max(ends))
        need(-2**31<=interval[0]<=interval[1]<=2**31-1,'scalar overflow')
        depth=1+max((self.terms[c].depth for c in children),default=0)
        return self.intern('terms',Term(op,tuple(payload),tuple(children),free,interval,depth,context if free else -1))

    def index_expr(self,e,env,scope):
        env=tuple(env.values()) if isinstance(env,dict) else tuple(env)
        if isinstance(e,GroupExpression): result=self.index_expr(e.expression,env,scope)
        elif isinstance(e,IntegerLiteral): result=self.idx(e.value)
        elif isinstance(e,NameReference): result=env[self.source_slots[id(e)]]
        elif isinstance(e,BinaryExpression) and e.operator=='+': result=self.plus(self.index_expr(e.left,env,scope),self.index_expr(e.right,env,scope))
        else: raise ConstructionError('unsupported admitted index')
        self.source_visits.append(SourceVisit(e.span.offset,scope,tuple(zip(self.source_node_axes[id(e)],env)),result,'index',e.span.length,type(e).__name__))
        return result

    def expand(self,e,env,scope):
        env=tuple(env.values()) if isinstance(env,dict) else tuple(env)
        if isinstance(e,GroupExpression): result=self.expand(e.expression,env,scope)
        elif isinstance(e,IntegerLiteral): result=self.term('const',(e.value,),context=scope)
        elif isinstance(e,BinaryExpression): result=self.term({'+':'add','*':'mul'}[e.operator],children=(self.expand(e.left,env,scope),self.expand(e.right,env,scope)),context=scope)
        elif isinstance(e,ReadExpression):
            coordinates=tuple(self.index_expr(i,env,scope) for i in e.indices)
            if self.source_tensor_roles[id(e)]==0: result=self.term('input',coordinates,context=scope)
            else:
                result=self.expand(self.producer.expression,coordinates,scope)
        else: raise ConstructionError('unsupported admitted scalar')
        self.source_visits.append(SourceVisit(e.span.offset,scope,tuple(zip(self.source_node_axes[id(e)],env)),result,'term',e.span.length,type(e).__name__))
        return result

    def proof(self,rule,scope,operation=-1,incoming=-1,outgoing=-1,payload=(),premises=()):
        need(all(0<=p<len(self.proofs) for p in premises),'forward proof')
        return self.add('proofs',Proof(rule,scope,operation,incoming,outgoing,tuple(payload),tuple(premises)))

    def state(self,scratch,ledger,env=0):
        return self.add('states',State(env,tuple(scratch),tuple(ledger)))

    def region(self,domain,kind,scope,physical_row=None):
        sub=self.substitution(self.formal_scope,scope,zip(self.formals,self.uv))
        closure=self.intern('closures',Closure(self.troot if kind=='scratch' else self.eroot,self.formals,sub))
        mapping=(self.uv[0] if physical_row is None else physical_row,self.uv[1])
        return self.intern('regions',Region(tuple(domain),mapping,closure,kind))

    def rect(self,a,b,c,d,kind,scope,physical_row=None):
        return self.region((a,b,c,d),kind,scope,physical_row)

    def block(self): return self.add('blocks',Block(()))

    def op(self,block,opcode,operands=(),indices=(),literal=0,body=-1,binder=-1,bounds=(),origins=()):
        i=self.add('operations',Operation(opcode,block,tuple(operands),tuple(indices),literal,body,binder,tuple(bounds),tuple(origins)))
        self.blocks[block]=Block(self.blocks[block].operations+(i,))
        return i

    def loop_plan(self,block,name,upper):
        body=self.block()
        binder=self.binder('physical',body,name)
        op=self.op(block,'for',body=body,binder=binder,bounds=(0,upper))
        return op,body,self.var(binder)

    def scalar_plan(self,block,e,env,memo=None):
        # Exact retained order; repeated producer Add subexpressions may share an
        # SSA definition, but the Mul still reads it twice. Origins retain both.
        memo={} if memo is None else memo
        if isinstance(e,GroupExpression): return self.scalar_plan(block,e.expression,env,memo)
        if isinstance(e,IntegerLiteral): op='const'; args=(); coords=(); literal=e.value
        elif isinstance(e,BinaryExpression):
            op={'+':'add','*':'mul'}[e.operator]
            args=(self.scalar_plan(block,e.left,env,memo),self.scalar_plan(block,e.right,env,memo));coords=();literal=0
        elif isinstance(e,ReadExpression):
            coords=tuple(self.index_expr(i,env,0) for i in e.indices)
            if self.source_tensor_roles[id(e)]!=0:
                if self.outline=='inline':
                    # Each coordinate gets its own const and add definitions.
                    return self.scalar_plan(block,self.producer.expression,coords,{})
                op='scratch_load'
                coords=coords+(self.modulo(coords[0]) if self.outline=='rows2' else coords[0],)
            else: op='input_load'
            args=(); literal=0
        else: raise ConstructionError('plan expression')
        key=(op,args,coords,literal)
        if key in memo:
            old=memo[key]
            self.operations[old]=replace(self.operations[old],origins=tuple(sorted(set(self.operations[old].origins+(e.span.offset,)))))
            return old
        i=self.op(block,op,args,coords,literal,origins=(e.span.offset,))
        memo[key]=i
        return i

    def producer_plan(self,body,row,col,slot=None):
        value=self.scalar_plan(body,self.producer.expression,(row,col))
        self.op(body,'scratch_store',(value,),(row,col,self.modulo(row) if slot is not None else row),origins=(self.producer.expression.span.offset,))

    def consumer_plan(self,body,row,col):
        value=self.scalar_plan(body,self.output.expression,(row,col))
        self.op(body,'output_store',(value,),(row,col),origins=(self.output.expression.span.offset,))

    def build_plan(self):
        root=self.block()
        if self.outline=='materialize':
            outer,body,a=self.loop_plan(root,'a',self.h+1)
            inner,leaf,b=self.loop_plan(body,'b',self.w+1)
            self.producer_plan(leaf,a,b)
        if self.outline=='rows2':
            stage,leaf,b=self.loop_plan(root,'b0',self.w+1)
            self.producer_plan(leaf,self.idx(0),b,True)
        outer,body,r=self.loop_plan(root,'r',self.h)
        if self.outline=='rows2':
            refill,leaf,b=self.loop_plan(body,'b',self.w+1)
            self.producer_plan(leaf,self.shift(r,1),b,True)
        inner,leaf,c=self.loop_plan(body,'c',self.w)
        self.consumer_plan(leaf,r,c)

    def domains(self,scope):
        result={}
        chain=[]
        while scope>=0:
            chain.append(self.scopes[scope]);scope=self.scopes[scope].parent
        for s in reversed(chain): result.update((b,(lo,hi)) for b,lo,hi in s.domain)
        return result

    def bounds(self,index,scope):
        x=self.indices[index]
        lo=hi=x.constant
        domain=self.domains(scope)
        for b,c in x.coefficients:
            need(b in domain,'unbound inequality index')
            a,z=domain[b]
            a=self.bounds(a,scope)[0];z=self.bounds(z,scope)[1]
            lo+=c*(a if c>=0 else z);hi+=c*(z if c>=0 else a)
        return (0,1) if x.modulo else (lo,hi)

    def le(self,a,b,scope,premises=()):
        x,y=self.indices[a],self.indices[b]
        need(not x.modulo and not y.modulo,'unresolved remainder inequality')
        diff=self.idx(x.constant-y.constant,x.coefficients+tuple((v,-c) for v,c in y.coefficients))
        lo,hi=self.bounds(diff,scope)
        need(hi<=0,'unproved affine bound')
        return self.proof('affine_le',scope,payload=(a,b,diff,lo,hi),premises=premises)

    def coordinate_bounds(self,row,col,height,width,scope):
        z=self.idx(0)
        return (self.le(z,row,scope),self.le(self.shift(row,1),self.idx(height),scope),
                self.le(z,col,scope),self.le(self.shift(col,1),self.idx(width),scope))

    def address_bounds(self,physical,col,scope):
        physical=self.resolve_physical(physical,scope)
        x,y=self.indices[physical],self.indices[col]
        address=self.idx(self.pitch*x.constant+y.constant,tuple((b,c*self.pitch) for b,c in x.coefficients)+y.coefficients)
        lower=self.le(self.idx(0),address,scope)
        upper=self.le(self.shift(address,1),self.idx(self.capacity),scope)
        return (self.proof('address',scope,payload=(physical,col,address,self.pitch,self.capacity),premises=(lower,upper)),)

    def resolve_physical(self,physical,scope):
        x=self.indices[physical]
        if not x.modulo: return physical
        need(x.modulo==2,'unsupported physical remainder')
        return self.resolved_slot(self.idx(x.constant,x.coefficients),scope)

    def resolved_slot(self,row,scope):
        x=self.indices[row]
        if not x.coefficients: return self.idx(x.constant%2)
        at=scope
        while at>=0:
            parity=self.scopes[at].parity
            if parity:
                binder,q,p=parity
                if x.coefficients==((binder,1),): return self.idx((p+x.constant)%2)
            at=self.scopes[at].parent
        return self.modulo(row)

    def mapped_domain(self,region,scope):
        r=self.regions[region]
        row=self.indices[r.physical_map[0]]
        if r.physical_map[0]==self.uv[0]: return r.domain
        if not row.coefficients and not row.modulo:
            return (r.physical_map[0],self.shift(r.physical_map[0],1),r.domain[2],r.domain[3])
        # Ring invariant has exactly one logical row.
        slot=self.resolved_slot(r.domain[0],scope)
        return (slot,self.shift(slot,1),r.domain[2],r.domain[3])

    def disjoint(self,left,right,scope):
        a,b=self.mapped_domain(left,scope),self.mapped_domain(right,scope)
        for x,y in ((a[1],b[0]),(b[1],a[0]),(a[3],b[2]),(b[3],a[2])):
            try: premise=self.le(x,y,scope)
            except ConstructionError: continue
            return self.proof('disjoint',scope,payload=(left,right),premises=(premise,))
        raise ConstructionError('overlapping regions')

    def join(self,a,b,scope):
        x,y=self.regions[a],self.regions[b]
        cx,cy=self.closures[x.closure],self.closures[y.closure]
        need((x.kind,x.physical_map,cx.root)==(y.kind,y.physical_map,cy.root),'incompatible region values/maps')
        if x.domain[:2]==y.domain[:2] and x.domain[3]==y.domain[2]: domain=x.domain[:3]+(y.domain[3],)
        elif x.domain[2:]==y.domain[2:] and x.domain[1]==y.domain[0]: domain=(x.domain[0],y.domain[1])+x.domain[2:]
        else: raise ConstructionError('nonadjacent join')
        out=self.region(domain,x.kind,scope,x.physical_map[0])
        disjoint=self.disjoint(a,b,scope)
        proof=self.proof('join',scope,payload=(a,b,out),premises=(disjoint,))
        return out,proof

    def normal_regions(self,ids,scope):
        result=[]
        for i in ids:
            d=self.regions[i].domain
            if d[0]==d[1] or d[2]==d[3]: continue
            result.append(i)
        changed=True
        while changed:
            changed=False
            for i in range(len(result)-1):
                try: joined,_=self.join(result[i],result[i+1],scope)
                except ConstructionError: continue
                result[i:i+2]=[joined];changed=True;break
        return tuple(result)

    def region_key(self,r,scope):
        x=self.regions[r]
        rowmap = x.physical_map[0]
        if self.indices[rowmap].modulo:
            rowmap = self.resolved_slot(x.domain[0],scope)
        return x.domain,(rowmap,x.physical_map[1]),self.closures[x.closure].root,x.kind

    def equality(self,a,b,scope,rule='state_equal',payload=(),premises=()):
        x,y=self.states[a],self.states[b]
        checks=[]
        normalization_start=len(self.proofs)
        for old,new in ((x.scratch,y.scratch),(x.ledger,y.ledger)):
            left=self.normal_regions(old,scope);right=self.normal_regions(new,scope)
            need(tuple(self.region_key(r,scope) for r in left)==tuple(self.region_key(r,scope) for r in right),'whole-state region equality')
            checks.extend((left,right))
        normalization=tuple(range(normalization_start,len(self.proofs)))
        oldenv=self.scalar_envs[x.environment].bindings
        newenv=self.scalar_envs[y.environment].bindings
        need(oldenv[:len(newenv)]==newenv,'scalar environment frame')
        projection=self.proof('scope_projection',scope,incoming=a,outgoing=b,payload=(x.environment,y.environment,oldenv[len(newenv):]))
        equal=self.proof('state_equal',scope,incoming=a,outgoing=b,payload=tuple(checks),premises=normalization+(projection,))
        return self.proof(rule,scope,incoming=a,outgoing=b,payload=tuple(payload),premises=tuple(premises)+(equal,))

    def primitive(self,operation,incoming,scope):
        op=self.operations[operation];state=self.states[incoming]
        env=dict(self.scalar_envs[state.environment].bindings)
        premises=[self.proof('origin',scope,operation,payload=op.origins)]
        for operand in op.operands:
            need(operand in env,'undefined scalar operand')
            premises.append(self.proof('operand',scope,operation,incoming,incoming,payload=(operand,env[operand])))
        scratch,ledger=state.scratch,state.ledger
        if op.opcode in ('input_load','scratch_load'):
            row,col=op.indices[:2]
            premises.extend(self.coordinate_bounds(row,col,self.h+1,self.w+1,scope))
            if op.opcode=='input_load': term=self.term('input',(row,col),context=scope)
            else:
                expected=self.expand(self.producer.expression,(row,col),scope)
                matches=[]
                for region in scratch:
                    r=self.regions[region];a,b,c,d=r.domain
                    try:
                        membership=(self.le(a,row,scope),self.le(self.shift(row,1),b,scope),self.le(c,col,scope),self.le(self.shift(col,1),d,scope))
                    except ConstructionError: continue
                    actual_row=self.resolve_physical(op.indices[2],scope)
                    mapped=self.regions[region].physical_map[0]
                    expected_row=row if mapped==self.uv[0] else self.mapped_domain(region,scope)[0]
                    need(actual_row==expected_row,'scratch physical slot')
                    sub=self.substitution(self.formal_scope,scope,zip(self.formals,(row,col)))
                    matches.append(self.proof('membership',scope,operation,incoming,incoming,payload=(region,row,col,sub,expected),premises=membership))
                need(matches,'uninitialized scratch read')
                premises.append(matches[0]);term=expected
                premises.extend(self.address_bounds(op.indices[2],col,scope))
        elif op.opcode=='const': term=self.term('const',(op.literal,),context=scope)
        elif op.opcode in ('add','mul'): term=self.term(op.opcode,children=tuple(env[x] for x in op.operands),context=scope)
        else:
            row,col=op.indices[:2]
            kind='scratch' if op.opcode=='scratch_store' else 'output'
            declaration=self.producer if kind=='scratch' else self.output
            expected=self.expand(declaration.expression,(row,col),scope)
            need(env[op.operands[0]]==expected,'ordered source equality')
            premises.append(self.proof('source_equal',scope,operation,payload=(env[op.operands[0]],expected,self.troot if kind=='scratch' else self.eroot,self.substitution(self.formal_scope,scope,zip(self.formals,(row,col))))))
            premises.extend(self.coordinate_bounds(row,col,self.h+1 if kind=='scratch' else self.h,self.w+1 if kind=='scratch' else self.w,scope))
            if kind=='scratch': premises.extend(self.address_bounds(op.indices[2],col,scope))
            physical=self.resolve_physical(op.indices[2],scope) if kind=='scratch' and op.indices[2]!=row else None
            singleton=self.rect(row,self.shift(row,1),col,self.shift(col,1),kind,scope,physical)
            old=scratch if kind=='scratch' else ledger
            frames=tuple(self.disjoint(r,singleton,scope) for r in old)
            premises.extend(frames)
            premises.append(self.proof('invalidate' if kind=='scratch' else 'ledger_append',scope,operation,incoming,incoming,payload=(old,old,singleton),premises=frames))
            new=old+(singleton,)
            transient=self.state(new if kind=='scratch' else scratch,new if kind=='output' else ledger,state.environment)
            store=self.proof('singleton_store',scope,operation,incoming,transient,(singleton,),tuple(premises))
            need(len(new)>=2,'store missing prefix')
            joined,joinproof=self.join(new[-2],new[-1],scope)
            new=new[:-2]+(joined,)
            outgoing=self.state(new if kind=='scratch' else scratch,new if kind=='output' else ledger,state.environment)
            compose=self.proof('region_represent',scope,incoming=transient,outgoing=outgoing,payload=(kind,),premises=(joinproof,))
            return outgoing,self.proof('primitive',scope,operation,incoming,outgoing,premises=(store,compose))
        interval=self.proof('interval',scope,operation,payload=(term,*self.terms[term].interval))
        premises.append(interval)
        newenv=self.add('scalar_envs',ScalarEnvironment(self.scalar_envs[state.environment].bindings+((operation,term),)))
        outgoing=self.state(scratch,ledger,newenv)
        return outgoing,self.proof('primitive',scope,operation,incoming,outgoing,payload=(term,),premises=premises)

    def leaf(self,block,incoming,scope):
        current=incoming;proofs=[]
        for cursor,op in enumerate(self.blocks[block].operations):
            current,p=self.primitive(op,current,scope);proofs.append(p)
        return current,self.proof('sequence',scope,incoming=incoming,outgoing=current,payload=(block,),premises=proofs)

    def loop(self,operation,incoming,parent,invariant,body):
        op=self.operations[operation];lower,upper=op.bounds
        baseS,baseL=invariant(self.idx(lower),parent)
        base=self.state(baseS,baseL,self.states[incoming].environment)
        bp=self.equality(incoming,base,parent,'base',payload=(operation,lower))
        scope=self.scope(parent,(op.binder,),((op.binder,self.idx(lower),self.idx(upper-1)),))
        k=self.var(op.binder)
        hs,hl=invariant(k,scope)
        hypothesis=self.state(hs,hl,self.states[incoming].environment)
        hp=self.proof('hypothesis',scope,operation,hypothesis,hypothesis,payload=(operation,))
        result,bodyproof=body(op.body,hypothesis,scope,k)
        if self.proofs[bodyproof].rule not in ('sequence','cases'):
            bodyproof=self.proof('sequence',scope,incoming=hypothesis,outgoing=result,payload=(op.body,),premises=(bodyproof,))
        ss,sl=invariant(self.shift(k,1),scope)
        successor=self.state(ss,sl,self.states[incoming].environment)
        sub=self.substitution(scope,scope,((op.binder,self.shift(k,1)),))
        step=self.equality(result,successor,scope,'successor',payload=(sub,),premises=(hp,bodyproof))
        discharge=self.proof('discharge',parent,operation,payload=(scope,hp),premises=(step,))
        es,el=invariant(self.idx(upper),parent)
        exitstate=self.state(es,el,self.states[incoming].environment)
        exsub=self.substitution(scope,parent,((op.binder,self.idx(upper)),))
        exitproof=self.proof('exit',parent,operation,incoming,exitstate,(exsub,hypothesis),premises=(bp,discharge))
        return exitstate,self.proof('induction',parent,operation,incoming,exitstate,(scope,hypothesis,successor,base), (bp,hp,bodyproof,step,discharge,exitproof))

    def output_outer(self,operation,incoming,parent):
        z=self.idx(0);W=self.idx(self.w)
        oldS=self.states[incoming].scratch;oldL=self.states[incoming].ledger
        def invariant(r,scope):
            scratch=oldS
            if self.outline=='rows2': scratch=(self.rect(r,self.shift(r,1),z,self.idx(self.w+1),'scratch',scope,self.modulo(self.uv[0])),)
            return scratch,oldL+(self.rect(z,r,z,W,'output',scope),)
        def inner_consume(block,state,scope,r):
            consume=self.blocks[block].operations[-1]
            before=self.states[state]
            def inv(c,s): return before.scratch,before.ledger+(self.rect(r,self.shift(r,1),z,c,'output',s),)
            return self.loop(consume,state,scope,inv,lambda b,st,s,c:self.leaf(b,st,s))
        def body(block,state,scope,r):
            if self.outline!='rows2': return inner_consume(block,state,scope,r)
            caseproofs=[];casestates=[]
            nonnegative=(self.le(z,r,scope),self.le(z,self.shift(r,1),scope))
            partition=self.proof('euclidean_partition',scope,payload=(r,self.shift(r,1),2),premises=nonnegative)
            for p in (0,1):
                q=self.binder('parity',scope,'q')
                case=self.scope(scope,(q,),((q,self.idx(0),self.idx((self.h-1)//2)),),(self.indices[r].coefficients[0][0],q,p))
                decomposition=self.idx(p,((q,2),))
                successor=self.idx(p+1,((q,2),))
                carry=(p+1)//2
                normalized=self.idx(2*carry+(1-p),((q,2),))
                need(successor==normalized,'parity successor identity')
                parity=self.proof('parity',case,payload=(p,1-p,q,r,self.shift(r,1),decomposition,successor,normalized,carry),premises=(partition,))
                before=self.states[state]
                current=self.rect(r,self.shift(r,1),z,self.idx(self.w+1),'scratch',case,self.idx(p))
                entry=self.state((current,),before.ledger,before.environment)
                entryproof=self.equality(state,entry,case,'case_entry',premises=(parity,))
                refill=self.blocks[block].operations[0]
                def inv(c,s):
                    prefix=self.rect(self.shift(r,1),self.shift(r,2),z,c,'scratch',s,self.idx(1-p))
                    return (current,prefix),before.ledger
                filled,fillproof=self.loop(refill,entry,case,inv,lambda b,st,s,c:self.leaf(b,st,s))
                consumed,consumeproof=inner_consume(block,filled,case,r)
                consumedstate=self.states[consumed]
                kept=consumedstate.scratch[1:]
                weakened=self.state(kept,consumedstate.ledger,before.environment)
                weaken=self.proof('scratch_weaken',case,incoming=consumed,outgoing=weakened,payload=(current,))
                targetS,targetL=invariant(self.shift(r,1),scope)
                target=self.state(targetS,targetL,before.environment)
                eq=self.equality(weakened,target,case,'case_successor',premises=(weaken,))
                seq=self.proof('sequence',case,incoming=entry,outgoing=consumed,payload=(block,),premises=(fillproof,consumeproof))
                cp=self.proof('case_discharge',scope,incoming=state,outgoing=target,payload=(case,p),premises=(parity,entryproof,seq,weaken,eq))
                caseproofs.append(cp);casestates.append(target)
            need(self.states[casestates[0]]==self.states[casestates[1]],'parity conclusions differ')
            return casestates[0],self.proof('cases',scope,incoming=state,outgoing=casestates[0],payload=(0,1),premises=caseproofs)
        return self.loop(operation,incoming,parent,invariant,body)

    def construct(self):
        z=self.idx(0);pitch=self.idx(self.w+1)
        state=self.initial;proofs=[]
        rootops=self.blocks[0].operations
        if self.outline=='materialize':
            def outerinv(a,s): return (self.rect(z,a,z,pitch,'scratch',s),),()
            def outerbody(block,st,s,a):
                before=self.states[st]
                def innerinv(b,sc): return before.scratch+(self.rect(a,self.shift(a,1),z,b,'scratch',sc),),before.ledger
                return self.loop(self.blocks[block].operations[0],st,s,innerinv,lambda b,st,s,k:self.leaf(b,st,s))
            state,p=self.loop(rootops[0],state,0,outerinv,outerbody);proofs.append(p)
        elif self.outline=='rows2':
            def inv(b,s): return (self.rect(z,self.idx(1),z,b,'scratch',s,self.idx(0)),),()
            state,p=self.loop(rootops[0],state,0,inv,lambda b,st,s,k:self.leaf(b,st,s));proofs.append(p)
        state,p=self.output_outer(rootops[-1],state,0);proofs.append(p)
        root=self.proof('sequence',0,incoming=self.initial,outgoing=state,payload=(0,),premises=proofs)
        final_region=self.rect(z,self.idx(self.h),z,self.idx(self.w),'output',0)
        final=self.state(self.states[state].scratch,(final_region,))
        done=self.equality(state,final,0,'final',premises=(root,))
        ids=tuple(getattr(self.kernel,n) for n in ('source_digest','family_digest','specialization_digest','constraint_digest','objective_digest'))
        return HandDerivation(self.outline,self.kernel.source_bytes,ids,(self.h,self.w),self.pitch,self.capacity,self.formals,(self.troot,self.eroot),tuple(sorted(self.origin_nodes)),
                              *(tuple(getattr(self,t)) for t in TABLES),done,self.initial,final,tuple(sorted(self.calls.items())))


def construct_hand_derivation(source_bytes,outline):
    return _Builder(source_bytes,outline).construct()


def audit_hand_derivation(d):
    """Report local graph defects; this is deliberately not an admission API.

    Every checked property is reported separately in the manifest. The future
    decoder and generic rule soundness are not inferred from this local audit.
    """
    errors=[]
    def check(ok,reason):
        if not ok: errors.append(reason)
    try:
        for i,p in enumerate(d.proofs):
            check(all(type(j) is int and 0<=j<i for j in p.premises),f'proof[{i}]: backward premises')
            check(0<=p.scope<len(d.scopes),f'proof[{i}]: scope')
            if p.rule=='sequence':
                block=d.blocks[p.payload[0]]
                children=[d.proofs[x] for x in p.premises]
                check(tuple(x.operation for x in children)==block.operations,f'proof[{i}]: ordered coverage')
                current=p.incoming
                for child in children:
                    check(child.incoming==current,f'proof[{i}]: disconnected transition')
                    current=child.outgoing
                check(current==p.outgoing,f'proof[{i}]: sequence exit')
            if p.rule=='primitive':
                op=d.operations[p.operation]
                before,after=d.states[p.incoming],d.states[p.outgoing]
                if op.opcode not in ('scratch_store','output_store'):
                    check(before.scratch==after.scratch and before.ledger==after.ledger,f'proof[{i}]: scalar effects')
                    check(d.scalar_envs[after.environment].bindings[:-1]==d.scalar_envs[before.environment].bindings,f'proof[{i}]: scalar linkage')
                children=[d.proofs[x] for x in p.premises]
                if op.opcode.endswith('_store'):
                    check(len(children)==2 and children[0].incoming==p.incoming and children[0].outgoing==children[1].incoming and children[1].outgoing==p.outgoing,f'proof[{i}]: store linkage')
                else:
                    check(children[0].rule=='origin' and children[0].operation==p.operation,f'proof[{i}]: origin premise')
            if p.rule=='origin': check(p.payload==d.operations[p.operation].origins and all(o in d.origins for o in p.payload),f'proof[{i}]: source origin')
            if p.rule=='induction':
                children=[d.proofs[x] for x in p.premises]
                check(tuple(x.rule for x in children)==('base','hypothesis','sequence' if children[2].rule=='sequence' else 'cases','successor','discharge','exit'),f'proof[{i}]: induction premises')
                base,hyp,body,step,discharge,exit=children
                check(base.incoming==p.incoming and hyp.outgoing==body.incoming and body.outgoing==step.incoming and exit.incoming==p.incoming and exit.outgoing==p.outgoing,f'proof[{i}]: induction state linkage')
                op=d.operations[p.operation]
                sub=d.substitutions[step.payload[0]]
                expected=Index(1,((op.binder,1),))
                check(len(sub.replacements)==1 and sub.replacements[0][0]==op.binder and d.indices[sub.replacements[0][1]]==expected,f'proof[{i}]: successor substitution')
                check(discharge.payload==(hyp.scope,p.premises[1]),f'proof[{i}]: hypothesis discharge')
            if p.rule=='cases':
                check(p.payload==(0,1) and tuple(d.proofs[x].payload[1] for x in p.premises)==(0,1),f'proof[{i}]: exhaustive parity')
            if p.rule=='source_equal': check(p.payload[0]==p.payload[1],f'proof[{i}]: source equality')
        for i,b in enumerate(d.blocks):
            check(all(0<=op<len(d.operations) and d.operations[op].block==i for op in b.operations),f'block[{i}]: operation ownership')
        coverage=tuple(op for b in d.blocks for op in b.operations)
        check(sorted(coverage)==list(range(len(d.operations))),'physical operation multiplicity')
        for i,c in enumerate(d.closures):
            check(c.formals==d.formals and set(d.terms[c.root].free)<=set(c.formals),f'closure[{i}]: free binder scope')
        for i,s in enumerate(d.substitutions):
            check(0<=s.source_scope<len(d.scopes) and 0<=s.target_scope<len(d.scopes),f'substitution[{i}]: scope')
            check(len({b for b,_ in s.replacements})==len(s.replacements),f'substitution[{i}]: duplicate capture')
        for i,t in enumerate(d.terms):
            check(all(0<=c<i for c in t.children),f'term[{i}]: backward references')
        check(d.proofs[d.root].outgoing==d.final_state,'final root linkage')
    except (IndexError,TypeError,ValueError,AttributeError):
        errors.append('malformed research graph reference')
    try:
        errors.extend(_semantic_audit(d))
    except (IndexError,TypeError,ValueError,AttributeError,KeyError,RecursionError):
        errors.append('malformed semantic graph reference')
    return tuple(errors)


def _semantic_audit(d):
    """Local semantic replay, independent of the schedule constructor."""
    errors=[]
    def check(ok,reason):
        if not ok: errors.append(reason)
    def index(i):
        x=d.indices[i]
        return (x.constant,x.coefficients,x.modulo)
    def add(a,b):
        need(a[2]==b[2]==0,'nonaffine addition')
        values={}
        for v,c in a[1]+b[1]: values[v]=values.get(v,0)+c
        return a[0]+b[0],tuple(sorted((v,c) for v,c in values.items() if c)),0
    def literal(n): return n,(),0
    def substitute(x,replacements):
        out=literal(x[0])
        for v,c in x[1]:
            value=replacements.get(v,(0,((v,1),),0))
            need(not value[2],'nonaffine substitution')
            out=add(out,(value[0]*c,tuple((b,k*c) for b,k in value[1]),0))
        return out[:2]+(x[2],)
    def scopechain(s):
        seen=set()
        while s>=0:
            need(s not in seen,'cyclic scope')
            seen.add(s);yield s;s=d.scopes[s].parent
    def bound(x,scope):
        domains={}
        for s in reversed(tuple(scopechain(scope))): domains.update((b,(a,z)) for b,a,z in d.scopes[s].domain)
        def visit(v,seen=()):
            low=high=v[0]
            for b,c in v[1]:
                need(b not in seen and b in domains,'scope or cyclic dependent domain')
                a,z=domains[b];a=visit(index(a),seen+(b,))[0];z=visit(index(z),seen+(b,))[1]
                low+=c*(a if c>=0 else z);high+=c*(z if c>=0 else a)
            return (0,1) if v[2] else (low,high)
        return visit(x)
    def mapping(row,domain,scope):
        if row[2]:
            # The ring map is only used on a singleton logical row.
            check(row[1]==((d.formals[0],1),),'noncanonical ring region map')
            value=domain[0]
            if not value[1]: return literal(value[0]%2)
            for s in scopechain(scope):
                parity=d.scopes[s].parity
                if parity and value[1]==((parity[0],1),): return literal((value[0]+parity[2])%2)
            return value[:2]+(2,)
        return row
    def region(i,scope,replacements=None):
        r=d.regions[i];c=d.closures[r.closure]
        repl={} if replacements is None else replacements
        domain=tuple(substitute(index(x),repl) for x in r.domain)
        maps=tuple(substitute(index(x),repl) for x in r.physical_map)
        maps=(mapping(maps[0],domain,scope),maps[1])
        sub=d.substitutions[c.substitution]
        values=tuple((b,substitute(index(x),repl)) for b,x in sub.replacements)
        return domain,maps,c.root,values,r.kind
    def normalize(items):
        out=[]
        for r in items:
            a=r[0]
            if a[0]==a[1] or a[2]==a[3]: continue
            out.append(r)
        changed=True
        while changed:
            changed=False
            for i in range(len(out)-1):
                a,b=out[i],out[i+1]
                if a[1:]!=b[1:]: continue
                x,y=a[0],b[0]
                if x[:2]==y[:2] and x[3]==y[2]: domain=x[:3]+(y[3],)
                elif x[2:]==y[2:] and x[1]==y[0]: domain=(x[0],y[1])+x[2:]
                else: continue
                out[i:i+2]=[(domain,)+a[1:]];changed=True;break
        return tuple(out)
    def state(i,scope,replacements=None):
        s=d.states[i]
        return tuple(normalize(tuple(region(r,scope,replacements) for r in ids)) for ids in (s.scratch,s.ledger))
    # Recompute all term values by ordered typed keys; no schedule token.
    term_table=[]
    def intern(key):
        try:return term_table.index(key)
        except ValueError:term_table.append(key);return len(term_table)-1
    term_keys=[]
    for i,t in enumerate(d.terms):
        payload=tuple(index(x) for x in t.payload) if t.operator=='input' else t.payload
        children=tuple(term_keys[x] for x in t.children)
        term_keys.append(intern((t.operator,payload,children,t.context)))
        if t.operator=='const': expected=(t.payload[0],)*2;free=();depth=1
        elif t.operator=='input':
            expected=(0,1023);free=tuple(sorted({v for x in t.payload for v,c in d.indices[x].coefficients}));depth=1
        else:
            a,b=(d.terms[x] for x in t.children)
            if t.operator=='add':expected=(a.interval[0]+b.interval[0],a.interval[1]+b.interval[1])
            elif t.operator=='mul':
                values=tuple(x*y for x in a.interval for y in b.interval);expected=(min(values),max(values))
            else: raise ConstructionError('unknown scalar term')
            free=tuple(sorted(set(a.free)|set(b.free)));depth=1+max(a.depth,b.depth)
        check((t.interval,t.free,t.depth)==(expected,free,depth),f'term[{i}]: interval/free/depth')
        check(-2**31<=expected[0]<=expected[1]<=2**31-1,f'term[{i}]: i32')
    kernel=admit_source_v2(d.source_bytes,profile=SourceProfileV2(),limits=SourceLimitsV2())
    identities=tuple(getattr(kernel,n) for n in ('source_digest','family_digest','specialization_digest','constraint_digest','objective_digest'))
    check(d.identities==identities and d.shape==(kernel.height,kernel.width),'source identities')
    module=kernel.source_module;producer=module.producers[0];output=module.outputs[0]
    actual_origins=set()
    def origins(obj):
        if is_dataclass(obj):
            if hasattr(obj,'span'):actual_origins.add(obj.span.offset)
            for field in fields(obj):
                if field.name not in ('span','name_span'):origins(getattr(obj,field.name))
        elif isinstance(obj,tuple):
            for child in obj:origins(child)
    origins(module)
    check(d.origins==tuple(sorted(actual_origins)),'retained original-AST origin inventory')
    nodes={}
    def collect(e,axes):
        nodes[e.span.offset,e.span.length,type(e).__name__]=(e,axes)
        if isinstance(e,GroupExpression):collect(e.expression,axes)
        elif isinstance(e,BinaryExpression):collect(e.left,axes);collect(e.right,axes)
        elif isinstance(e,ReadExpression):
            for x in e.indices:collect(x,axes)
    collect(producer.expression,tuple(a.name for a in producer.axes))
    collect(output.expression,tuple(a.name for a in output.axes))
    source_binders=tuple(i for i,b in enumerate(d.binders) if b.namespace=='source')
    expected_bindings=[];expected_axes={}
    def binding_rows(e,names,binders):
        expected_axes[e.span.offset,e.span.length,type(e).__name__]=binders
        if isinstance(e,NameReference):
            expected_bindings.append(SourceBinding(e.span.offset,e.span.length,'index',binders[names.index(e.name)]))
        elif isinstance(e,ReadExpression):
            expected_bindings.append(SourceBinding(e.span.offset,e.span.length,'tensor',0 if e.name==module.inputs[0].name else 1))
        if isinstance(e,GroupExpression):binding_rows(e.expression,names,binders)
        elif isinstance(e,BinaryExpression):binding_rows(e.left,names,binders);binding_rows(e.right,names,binders)
        elif isinstance(e,ReadExpression):
            for x in e.indices:binding_rows(x,names,binders)
    binding_rows(producer.expression,tuple(a.name for a in producer.axes),source_binders[:2])
    binding_rows(output.expression,tuple(a.name for a in output.axes),source_binders[2:])
    check(d.source_bindings==tuple(expected_bindings),'complete retained source binding table')
    def source_index(e,env):
        if isinstance(e,GroupExpression):return source_index(e.expression,env)
        if isinstance(e,IntegerLiteral):return literal(e.value)
        if isinstance(e,NameReference):return env[e.name]
        return add(source_index(e.left,env),source_index(e.right,env))
    def source_term(e,env,scope):
        if isinstance(e,GroupExpression):return source_term(e.expression,env,scope)
        if isinstance(e,IntegerLiteral):return intern(('const',(e.value,),(),-1))
        if isinstance(e,BinaryExpression):
            children=(source_term(e.left,env,scope),source_term(e.right,env,scope))
            return intern(({'+':'add','*':'mul'}[e.operator],(),children,scope))
        coords=tuple(source_index(x,env) for x in e.indices)
        if e.name==module.inputs[0].name:return intern(('input',coords,(),scope))
        return source_term(producer.expression,dict(zip((a.name for a in producer.axes),coords)),scope)
    formal_scope=next(i for i,s in enumerate(d.scopes) if s.binders==d.formals)
    uv=tuple((0,((b,1),),0) for b in d.formals)
    roots=(source_term(producer.expression,dict(zip((a.name for a in producer.axes),uv)),formal_scope),source_term(output.expression,dict(zip((a.name for a in output.axes),uv)),formal_scope))
    check(tuple(term_keys[x] for x in d.source_roots)==roots,'reconstructed source root identities')
    for i,v in enumerate(d.source_visits):
        e,names=nodes[v.origin,v.length,v.node_kind]
        check(tuple(b for b,_ in v.replacements)==expected_axes[v.origin,v.length,v.node_kind],f'source_visit[{i}]: source binder keys')
        env=dict(zip(names,(index(x) for _,x in v.replacements)))
        expected=source_index(e,env) if v.kind=='index' else source_term(e,env,v.scope)
        actual=index(v.result) if v.kind=='index' else term_keys[v.result]
        check(actual==expected,f'source_visit[{i}]: retained source reconstruction')
    for i,s in enumerate(d.substitutions):
        available={b for scope in scopechain(s.source_scope) for b in d.scopes[scope].binders}
        check(all(b in available for b,x in s.replacements),f'substitution[{i}]: source binder scope')
        available={b for scope in scopechain(s.target_scope) for b in d.scopes[scope].binders}|set(d.formals)
        check(all(b in available for _,x in s.replacements for b,c in d.indices[x].coefficients),f'substitution[{i}]: target binder scope')
    for i,p in enumerate(d.proofs):
        prefix=f'proof[{i}]: '
        if p.rule=='source':
            check(p.payload==d.source_roots+tuple(i for i,b in enumerate(d.binders) if b.namespace=='source')+d.formals,prefix+'source root/renaming payload')
        elif p.rule=='layout':
            check(p.payload==(d.pitch,d.capacity,*d.shape) and 0<d.pitch<=8193 and 0<=d.capacity<=(d.shape[0]+1)*(d.shape[1]+1),prefix+'layout/capacity')
        elif p.rule=='scope_projection':
            a,b,dropped=p.payload
            check((a,b)==(d.states[p.incoming].environment,d.states[p.outgoing].environment),prefix+'projection environments')
            before,after=d.scalar_envs[a].bindings,d.scalar_envs[b].bindings
            check(before==after+dropped,prefix+'projection exact frame')
            owners={d.binders[v].owner for sc in scopechain(p.scope) for v in d.scopes[sc].binders if d.binders[v].namespace=='physical'}
            check(all(d.operations[op].block in owners for op,t in dropped),prefix+'projection lexical locals')
        elif p.rule=='address':
            physical,col,address,pitch,capacity=p.payload
            x=index(physical)
            expected=add((x[0]*pitch,tuple((v,c*pitch) for v,c in x[1]),0),index(col))
            check(index(address)==expected and (pitch,capacity)==(d.pitch,d.capacity),prefix+'explicit physical address')
            check(len(p.premises)==2 and tuple(d.proofs[x].rule for x in p.premises)==('affine_le','affine_le') and bound(expected,p.scope)[0]>=0 and bound(expected,p.scope)[1]<capacity,prefix+'address capacity bounds')
        elif p.rule=='membership':
            fact,row,col,sub,term=p.payload
            check(fact in d.states[p.incoming].scratch and p.incoming==p.outgoing,prefix+'initialized membership provenance')
            r=d.regions[fact]
            check(d.closures[r.closure].root==d.source_roots[0],prefix+'membership closure')
            check(d.substitutions[sub].replacements==tuple(zip(d.formals,(row,col))),prefix+'membership substitution')
            expected=source_term(producer.expression,dict(zip((a.name for a in producer.axes),(index(row),index(col)))),p.scope)
            check(term_keys[term]==expected and len(p.premises)==4,prefix+'membership source equality/premises')
        elif p.rule in ('invalidate','ledger_append'):
            old,kept,singleton=p.payload
            stateids=d.states[p.incoming].scratch if p.rule=='invalidate' else d.states[p.incoming].ledger
            check(old==stateids and kept==old and len(p.premises)==len(old),prefix+'complete preserved frame inventory')
            check(tuple(d.proofs[x].payload for x in p.premises)==tuple((r,singleton) for r in old),prefix+'every frame disjoint')
        elif p.rule=='euclidean_partition':
            r,r1,modulus=p.payload
            check(modulus==2 and index(r1)==add(index(r),literal(1)) and bound(index(r),p.scope)[0]>=0 and len(p.premises)==2,prefix+'nonnegative exhaustive partition')
        elif p.rule=='source_equal':
            actual,expected,root,sub=p.payload
            op=d.operations[p.operation]
            decl=producer if op.opcode=='scratch_store' else output
            check(root==d.source_roots[0 if op.opcode=='scratch_store' else 1] and d.substitutions[sub].replacements==tuple(zip(d.formals,op.indices[:2])),prefix+'source closure substitution')
            rebuilt=source_term(decl.expression,dict(zip((a.name for a in decl.axes),(index(x) for x in op.indices[:2]))),p.scope)
            check(term_keys[actual]==term_keys[expected]==rebuilt,prefix+'actual source value')
        elif p.rule=='affine_le':
            a,b,difference,lo,hi=p.payload
            delta=add(index(a),(-index(b)[0],tuple((v,-c) for v,c in index(b)[1]),0))
            check(delta==index(difference) and bound(delta,p.scope)==(lo,hi) and hi<=0,prefix+'affine implication')
        elif p.rule=='state_equal':
            check(state(p.incoming,p.scope)==state(p.outgoing,p.scope),prefix+'complete state equality')
        elif p.rule=='primitive':
            op=d.operations[p.operation]
            before,after=d.states[p.incoming],d.states[p.outgoing]
            env=dict(d.scalar_envs[before.environment].bindings)
            if op.opcode in ('input_load','const','add','mul'):
                term=d.terms[p.payload[0]]
                if op.opcode=='input_load': check((term.operator,term.payload)==('input',op.indices),prefix+'input coordinates')
                elif op.opcode=='const':check((term.operator,term.payload)==('const',(op.literal,)),prefix+'constant')
                else:check((term.operator,term.children)==(op.opcode,tuple(env[x] for x in op.operands)),prefix+'ordered scalar operands')
                check(d.scalar_envs[after.environment].bindings[-1]==(p.operation,p.payload[0]),prefix+'SSA result')
            elif op.opcode=='scratch_load':
                expected=source_term(producer.expression,dict(zip((a.name for a in producer.axes),(index(x) for x in op.indices[:2]))),p.scope)
                check(term_keys[p.payload[0]]==expected,prefix+'scratch value')
                physical=index(op.indices[2])
                if physical[2]:
                    base=physical[:2]+(0,)
                    if not base[1]: physical=literal(base[0]%2)
                    else:
                        for sc in scopechain(p.scope):
                            parity=d.scopes[sc].parity
                            if parity and base[1]==((parity[0],1),):physical=literal((base[0]+parity[2])%2);break
                address=[d.proofs[j] for j in p.premises if d.proofs[j].rule=='address']
                check(len(address)==1 and index(address[0].payload[0])==physical and address[0].payload[1]==op.indices[1],prefix+'physical load address')
        elif p.rule=='singleton_store':
            op=d.operations[p.operation];a,b=d.states[p.incoming],d.states[p.outgoing]
            singleton=p.payload[0]
            if op.opcode=='scratch_store':check(b.scratch==a.scratch+(singleton,) and b.ledger==a.ledger,prefix+'scratch singleton/full ledger')
            else:check(b.ledger==a.ledger+(singleton,) and b.scratch==a.scratch,prefix+'output singleton/full scratch')
            r=d.regions[singleton]
            row,col=map(index,op.indices[:2])
            check(tuple(index(x) for x in r.domain)==(row,add(row,literal(1)),col,add(col,literal(1))),prefix+'singleton coordinate')
            if op.opcode=='scratch_store':
                physical=index(op.indices[2])
                physical=mapping((0,((d.formals[0],1),),2),(physical[:2]+(0,),),p.scope) if physical[2] else physical
                addresses=[d.proofs[j] for j in p.premises if d.proofs[j].rule=='address']
                expected_map=row if index(r.physical_map[0])==(0,((d.formals[0],1),),0) else index(r.physical_map[0])
                check(len(addresses)==1 and index(addresses[0].payload[0])==physical and addresses[0].payload[1]==op.indices[1] and expected_map==physical,prefix+'physical store address and singleton map')
        elif p.rule=='region_represent':check(state(p.incoming,p.scope)==state(p.outgoing,p.scope),prefix+'region denotation')
        elif p.rule=='scratch_weaken':
            a,b=d.states[p.incoming],d.states[p.outgoing]
            check(a.ledger==b.ledger and b.scratch==tuple(r for r in a.scratch if r not in p.payload),prefix+'weakening/full ledger')
        elif p.rule=='induction':
            op=d.operations[p.operation];scope,hyp,successor,base=p.payload
            children=[d.proofs[x] for x in p.premises]
            exitstate=p.outgoing
            check(state(hyp,p.scope,{op.binder:literal(op.bounds[0])})==state(base,p.scope),prefix+'induction base substitution')
            check(state(hyp,scope,{op.binder:(1,((op.binder,1),),0)})==state(successor,scope),prefix+'induction successor substitution')
            check(state(hyp,p.scope,{op.binder:literal(op.bounds[1])})==state(exitstate,p.scope),prefix+'induction exit substitution')
            check(children[5].payload[1]==hyp and children[5].incoming==p.incoming and children[5].premises==(p.premises[0],p.premises[4]),prefix+'induction elimination')
            check(children[4].scope==p.scope and d.scopes[scope].parent==p.scope,prefix+'hypothesis nonescape')
        elif p.rule=='parity':
            a,b,q,r,r1,decomp,succ,normalized,carry=p.payload
            check(d.scopes[p.scope].parity==(d.indices[r].coefficients[0][0],q,a),prefix+'parity context')
            check(a in (0,1) and b==1-a and carry==(a+1)//2 and index(decomp)==(a,((q,2),),0) and index(succ)==index(normalized)==(a+1,((q,2),),0),prefix+'Euclidean successor')
        elif p.rule=='disjoint':
            a,b=(region(x,p.scope) for x in p.payload)
            # Physical rows are either the logical affine row or a singleton slot.
            def footprint(r):
                domain,maps=r[:2]
                if maps[0]==(0,((d.formals[0],1),),0):return domain
                return maps[0],add(maps[0],literal(1)),domain[2],domain[3]
            a,b=footprint(a),footprint(b)
            checks=tuple(bound(add(x,(-y[0],tuple((v,-c) for v,c in y[1]),0)),p.scope)[1]<=0 for x,y in ((a[1],b[0]),(b[1],a[0]),(a[3],b[2]),(b[3],a[2])))
            check(any(checks),prefix+'physical disjointness')
        elif p.rule=='join':
            a,b,c=(region(x,p.scope) for x in p.payload)
            check(normalize((a,b))==normalize((c,)),prefix+'compatible exact union')
    return errors

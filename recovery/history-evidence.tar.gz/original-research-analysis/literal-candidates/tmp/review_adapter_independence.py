from pathlib import Path
import json, os, shutil, unittest
from tests.test_evaluate_adapter import Fixture, PYTHON, EVALUATOR, ns
import evaluate_adapter as adapter

case=unittest.TestCase()
f=Fixture(case,held_out=True)
try:
    for binding in f.bindings:
        receipt=f.root/binding['receipt']['path']
        record=json.loads(receipt.read_bytes())
        record['identity']['session_id']='reused-session'
        raw_path=record['instrumentation']['raw']['path']
        raw=json.loads((f.root/raw_path).read_bytes())
        raw['identity']['session_id']='reused-session'
        record['instrumentation']['raw']=f.ref(raw_path,raw)
        binding['receipt'].update(f.ref(binding['receipt']['path'],record))
        measured=json.loads((f.root/binding['measurement']['path']).read_bytes())
        measured['session_id']='reused-session'
        binding['measurement'].update(f.ref(binding['measurement']['path'],measured))
    for blocks in (f.pilot['blocks'],f.request_record['blocks']):
        for block in blocks:
            record=json.loads((f.root/block['independence']['path']).read_bytes())
            record['method']='verified_reset_equivalence'
            block['independence'].update(f.ref(block['independence']['path'],record))
    f.pilot_ref.update(f.ref('pilot.json',f.pilot))
    seal=f.ev.freeze(f.ev.Reader(f.root),f.pilot_ref,ns('2026-10-01T06:00:00Z'))
    f.request_record['freeze']=f.ref('freeze.json',seal)
    f.envelope['request']=f.ref('request.json',f.request_record)
    f.save_envelope()
    print('frozen_mode:',f.experiment.spec.sampling.session_mode,flush=True)
    print('distinct_sessions: 1 across all',len(f.bindings),'measurements; reset_evidence: null',flush=True)
    admission=adapter.admit_export(f.request,f.experiment,PYTHON,EVALUATOR)
    try:
        result=adapter.evaluate(admission,f.request,PYTHON,EVALUATOR,f.root/'result.json')
        print('ADMITTED:',result.result['decision'],'units:',result.result['independent_units'],'native:',result.native_eligible,flush=True)
    finally:
        for directory, _, _ in os.walk(admission.snapshot_root): Path(directory).chmod(0o755)
        shutil.rmtree(admission.snapshot_root)
finally:
    case.doCleanups()

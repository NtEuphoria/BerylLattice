# Plan03 Task2 independent review

Reviewed commit `c153e64d4d809c1209ec76bbf9e4b6733fc90b3a`, the exact task-2 review package, brief, implementation report, implementation and versioned contract, and the approved performance protocol at `/workspace/scratch/axiom-foundations-2026-10-15/performance/protocol.md`. No product files were changed. The reported 21 manifest checks (including optimized Python) and 37 state/manifest integration checks were not rerun unchanged.

**Spec compliance: changes required.** Exact matrices, primary comparison, content/stratum separation, approved input hashes, selector-before-pilot ordering, later policy/selection/measurement ordering, fixed balanced sampling, and strict frozen-manifest revalidation satisfy the requirements inspected. One disclosed-access role bypass remains.

**Code quality: changes required.** One P2 correctness finding; no other important finding established.

## P2 — Apply known-access rules to disclosed correctness receipts

Location: `axiom/research/experiment_manifest.py:461-475` in `validate_chronology`.

The function validates pilot, training, selection and held-out receipt chronology, but a `correctness` receipt receives only the common identity and known-stratum checks. Consequently it accepts a receipt explicitly disclosing access to the primary held-out input before candidate freeze, and even before dataset preregistration. This contradicts `_validate_spec` and the versioned contract: all non-pilot known accesses, including correctness, count toward contamination. The exception for unreported use does not apply: the disqualifying access is present in the supplied receipt tuple.

Independent reproduction using the existing declaration fixture and a temporary frozen manifest:

```python
rows = receipts(s)  # valid per-stratum pilot, selection, final measurement
early = replace(rows[-1], role='correctness',
    started_utc='2026-10-01T02:00:00Z',
    completed_utc='2026-10-01T02:30:00Z')
validate_chronology(f, (early,) + rows)
# ChronologyResult(eligible=True, reasons=())
```

The fixture freezes the candidate at `04:00Z`; the primary held-out workload is unchanged. Reporting the same workload and `02:00Z` time as `AccessRecord(f.primary_workload, 'correctness', ...)` in `known_accesses` correctly rejects freezing with `held-out content/shape appears in known tuning access history`. Moving the correctness receipt to September 1, before the October 1 preregistration, still returns eligible. As a control, changing that receipt's role to `training` correctly returns ineligible for relabeling held-out data.

Requested correction: reconcile supplied correctness receipts with the frozen access history and declared input/shape holdout rules. Reject disclosed pre-freeze/preregistration held-out accesses rather than allowing a role change to bypass the history policy. Preserve legitimate correctness acquisition/verification associated with final held-out measurement after selection. Add a targeted regression for the same actual held-out stratum reported as correctness before candidate freeze and before preregistration, with a valid later measurement chain present.

## Other independent evidence and scope

- Compared the six training and eight held-out shapes and both four-seed sets with protocol section 4; the constants match exactly. The primary filter requires `(2047,2049,65537)`, unconstrained cap and `ordinary_checked_call`, and can disambiguate multiple cache strata explicitly.
- Independently generated twelve LCG64 values for `(W,H,seed)=(3,2,65537)`, packed them with `struct.pack('<12i', ...)`, and obtained the same SHA-256 as `approved_input_sha256`. This checks actual bytes rather than a label hash. Code inspection confirms complete row-major stream generation, 32-bit little-endian encoding, bounded chunking and typed cache keys.
- Independently changed role, generator/version, cache label and cap: content identity stayed equal while stratum identity changed. Manifest validation verifies actual approved hashes for timing workloads and known non-correctness accesses. Correctness patterns explicitly depend on truthful input-hash declarations; acquiring their bytes and discovering unreported use remain outside this format.
- Independently checked the 32-block schedule: 16 AB and 16 BA orders, repeatable for seed 71 and changed by seed 72. The version, count, seed, order, warmup, input touch and initialization are frozen; session assumptions and reset evidence are declarations, not assertions that a PID establishes independence. The accepted 30 lower bound follows the controller ruling recorded in the implementation report; the source protocol normally starts at 32.
- Inspected per-stratum pilot/selection matching, pinned objective/selector/compiler/artifact identifiers, fixed threshold and fixed sample declaration. Selector design must precede baseline A/A pilot exposure; each final measurement needs a pilot before policy freeze and a completed selection afterward. No pooling of independent shape/seed/cache strata or changed threshold claim was found.
- Independently appended a newline to frozen canonical bytes; `validate_chronology` returned ineligible with `invalid frozen manifest: metadata must use canonical JSON`. Loading uses bounded canonical JSON and descriptor-relative no-follow reads; revalidation compares the loaded path, digest and typed declaration. Freeze checks the requested spec/digest after writing and reuses the descriptor-pinned immutable writer reviewed in Task1.

These findings concern declaration and chronology validation. No native measurement, independence proof, timestamp authenticity or performance claim was produced or inferred.

## Scoped re-review of disclosed-access correction

Reviewed `.superpowers/sdd/03/task-2-fix.diff`, its appended implementation-report evidence, and the corrected implementation. **Original P2: ADDRESSED. Spec compliance: approved. Code quality: approved.** These verdicts supersede the initial changes-required verdicts above. No new important breakage was found in the scoped correction. No product files were changed and the reported 24 normal/optimized tests were not rerun unchanged.

The fix shares the existing content/shape contamination predicate between manifest accesses and supplied receipts. It rejects disclosed accesses before preregistration and non-pilot held-out accesses starting by candidate freeze. Correctness work in that tuning window must finish by candidate freeze; later held-out correctness acquisition requires policy freeze and a completed selection for its own stratum. Baseline A/A pilot treatment and the original final measurement chain are retained. The versioned contract now documents these distinctions.

Independent targeted probes confirmed:

- Both original reproductions now return ineligible: primary held-out correctness at `02:00Z` before candidate freeze, and the same declared access before preregistration.
- A held-out correctness access starting exactly at candidate freeze is rejected. An access starting exactly when selection completes is rejected; starting one microsecond later is accepted with the valid later measurement chain.
- Correctness work on a training stratum inside the preregistered tuning window remains eligible, as does the original pilot/selection/held-out chain.
- A post-selection correctness acquisition with renamed generator/cache declarations cannot borrow the original stratum's selection receipt, despite equal content identity; it is rejected until its own stratum has a completed selection.

The appended report provides failing regressions before correction followed by 24 passing tests under normal and optimized Python. The independent probes above exercise the original finding, strict boundary behavior, legitimate acquisition, and stratum isolation without repeating that suite.

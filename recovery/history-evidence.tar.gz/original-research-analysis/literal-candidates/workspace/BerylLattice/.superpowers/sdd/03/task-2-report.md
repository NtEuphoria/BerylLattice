# Task 2 report — frozen datasets and chronology

Status: implementation complete; no commits made (controller owns integration).
Owned deliverables: axiom/research/experiment_manifest.py,
tests/test_manifest.py, protocol/experiment-v1.md.

## Result

Frozen typed records, strict serialization/loading, content-versus-stratum
identities, actual approved LCG input-stream hashes, exact six/four training and
eight/four held-out shape/seed cross-products, explicit input/shape holdout,
complete asserted training history with all known accesses retained, selector-
before-pilot and candidate/policy/selection/measurement chronology, one explicit
primary comparison, immutable threshold policy, and reproducible balanced sampling.
The public API was shared with the controller and receipt-admission implementer
before their dependent code. Workload content identity ignores generator/cache/
role labels; stratum identity includes those declarations. Native acquisition,
independence, authentic time attestation, undisclosed-use discovery, collection,
performance claims, and scalable semantic-oracle execution remain outside scope.

## Final verification

- Normal state+manifest integration: `PYTHONPATH=. python -m unittest tests.test_state tests.test_manifest -v` — 37 tests, OK, 11.347s.
- Optimized manifest: `PYTHONPATH=. python -O -m unittest tests.test_manifest -v` — 21 tests, OK, 8.341s.
- Earlier owned normal manifest run: 20 tests, OK; final integration includes all 21 current manifest cases.
- Project discovery initially used wrong package root and produced eight named import errors (full output below). Corrected discovery reached the exhaustive selector matrix and was stopped at the controller's explicit request to avoid duplicate work. The owned PID53513 ignored SIGINT; SIGTERM stopped it. The controller owns the one final combined project run. This stopped run is not a passing suite.
- Broad research discovery saw the concurrent Task3 RED `test_receipts` import error, `No module named receipt_admission`. State and manifest tests passed in that run. Final owned integration explicitly excludes concurrent in-flight RED work.

## Self-review and RED→GREEN fixes

1. Checked role/content/stratum separation and same data under renamed generator/cache labels. Both input-level and shape-level holdout are explicit; a changed label does not change content.
2. Checked actual LCG little-endian i32 byte identity and discovered `lru_cache` could return a cached integer key for a boolean argument before validation. Added failing regression, changed cache to typed keys, and observed green.
3. Checked prior selection history and discovered a false declared input digest in a known non-correctness access could evade input holdout. Added failing regression and actual stream verification for prior timing accesses.
4. Checked receipt roles and discovered that a reported held-out stratum could be relabeled training. Added failing regression and restricted training receipts to declared training strata.
5. Checked downstream serialization and discovered `ExperimentSpec.to_record()` returned tuple collections rejected by `from_record()`. Added failing direct-roundtrip test and emitted actual JSON arrays.
6. Checked auxiliary roles and discovered an extra pilot shape/seed could bypass exact v1 matrices. Added failing regression and restricted every timing-role workload to approved cells.
7. Checked filesystem mutation and reproduced a parent-directory swap creating an experiment file outside its owned root before loading rejected the symlink. Added failing regression; reused state-artifacts' reviewed descriptor-pinned `_write_directory`/`_write_immutable` internal primitives. No independent unsafe writer remains.
8. Checked freeze return identity and reproduced replacement of just-written bytes by a different valid declaration before loading. Added failing regression; freeze now compares both resulting digest and typed spec with the requested declaration.
9. Checked strict unknown fields, canonical JSON, fixed threshold/schedule tampering, freeze revalidation, missing history, reversed times, selector/objective/compiler/artifact changes and per-stratum pilot/selection prerequisites. Tests pass with Python assertions disabled.

No outstanding important self-review findings. Internal dependency on the state
writer's two private filesystem primitives is deliberate within this package;
changing their signatures requires updating both state and experiment writers.
Default LCG identity computation costs about eight seconds on first use for the
full frozen matrix; the bounded cache avoids recomputation within an interpreter.
The manifest validates declarations and supplied chronology, not truth of
unreported events, independence assumptions, or acquired native state.

## Rulings

- Accept fixed even sample counts 30..1024 because the controller's explicit task instruction specifies that interval. The source protocol normally starts at 32, retained by fixtures and docs. Cost if this is wrong: 30 would need rejection or a separately frozen protocol amendment.
- Generator/version strings are stratum/display metadata; v1 timing data is always the approved LCG64 stream. This keeps renamed generator labels from hiding contamination. A genuinely different generator requires a separate versioned contract. Cost if this is wrong: alternate timing generators require an explicit extension, not a label-only change.
- All known non-pilot accesses, including correctness, count for contamination. Retain accesses before preregistration and reject the run rather than silently remove them. Cost if this is wrong: an intentionally weaker holdout declaration would require explicit protocol revision.

## Complete command/output evidence

Each following section contains the complete saved output. Initial missing-module
RED is the plan's prescribed expected failure; subsequent review RED runs show
behavioral failures before fixes. The first implementation run also exposed
list/tuple JSON structural comparison errors; canonical-byte comparison corrected
them before the initial green below. No failed check is treated as success.

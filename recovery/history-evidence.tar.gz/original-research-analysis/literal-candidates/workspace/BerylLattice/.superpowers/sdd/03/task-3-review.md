# Independent Task 3 review

Specification verdict: **PASS**.

Code-quality verdict: **APPROVE WITH NIT**. No Critical or Important findings.

Reviewed the Task 3 brief, report and immutable review package against the current
receipt module, protocol, tests and relevant state/manifest dependencies. Verified
the external evaluator hash remains
`b368462fc46c3173650c8654765e283fc84fd1e86c7c6c11154d809367956593` and compared its exact
paid/resource keys, integer/sum/retained<=peak rules and chronology contract.

The required boundary is preserved: both admission entry points return native
`eligible=False`; `instrumentation_validated` is always false. Native collector,
scalable-oracle and larger-buffer gates remain explicit. Synthetic eligibility
requires a separately supplied pinned expected manifest and oracle sidecar; the
documentation correctly leaves independent fixture authorship as a caller trust
assumption. Raw observation consistency does not purport to validate physical
instrumentation. Required resource unavailability remains null and ineligible;
retained measured zero is distinct. RSS, arena capacity and allocator peak remain
separate diagnostics.

Full observed post-call input/output and metadata are compared to expected state;
input preservation additionally binds the frozen original input. Wrong agreement
between a baseline and candidate cannot substitute for the independent expected
fixture. Run/artifact/compiler/collector/acquisition identities, UTC windows,
sampling schedule/reset declarations, exact semantic stdout/events and combined
actual/expected closure and logical budgets are checked. Request-wide pair
chronology, independence and physical observation honesty are appropriately
documented as outside this single-receipt gate.

## Minor finding: one nested field remains mutable

`axiom/research/receipt_admission.py:82` declares `Observation.reason: str` but
does not enforce that type. `_observations` only checks its type for an
`inapplicable` cost (line 312). `MeasurementReceipt.from_record` therefore accepts
a JSON array as the `reason` of a measured observation, and a valid synthetic
fixture with that receipt still returns `synthetic_eligible=True`. The array can
then be mutated through the frozen receipt, contrary to the documented immutable,
typed receipt guarantee. This does not change the admitted costs, oracle pins or
native gates, so it is a nonblocking quality nit. Validate `reason` as a string
for every observation at construction/parsing or admission.

Targeted probe used the existing `ReceiptTests` fixture setup, changed only
`record['instrumentation']['paid'][0]['reason']` to `['mutable']`, round-tripped
through `MeasurementReceipt.from_record`, and called synthetic admission. Output:

```text
mutable_reason_accepted True
receipt_changed_after_admission ['mutable', 'changed after admission']
```

No reported unchanged 24/40/64-test suites were rerun. No implementation edits or
subagents were used. The nit above is the only additional probe finding.

## Scoped nit-fix rereview

Reviewed `task-3-fix.diff`, current `Observation.__post_init__`, the two added
regression tests and appended implementation report. The unconditional exact
`str` check applies through direct construction, `dataclasses.replace` and
`MeasurementReceipt.from_record` for every observation status/group. It closes
the mutable-reason finding without changing valid string serialization or the
existing nonempty reason requirement for inapplicable paid components. No new
breakage found in the scoped change.

The reported normal/optimized 26-test results were not repeated. An independent
small constructor probe additionally rejected `None`, integer, float, tuple and
a `str` subclass for each of measured/inapplicable/unavailable status (15 cases),
while accepting empty and nonempty exact strings.

Updated specification verdict: **PASS**. Updated code-quality verdict:
**APPROVE**. The sole prior nit is closed; no remaining findings.

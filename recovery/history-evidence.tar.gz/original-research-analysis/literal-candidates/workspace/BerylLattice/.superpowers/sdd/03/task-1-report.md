# Plan03 Task1 implementation report

Implemented complete-state artifacts in the four assigned files:

- `axiom/research/state_artifacts.py`
- `axiom/research/tests/__init__.py`
- `axiom/research/tests/test_state.py`
- `axiom/research/protocol/state-v1.md`

No compiler/generator/planner imports, external dependencies, native collection,
performance claims, commits, or subagents were introduced. Root owns commits and
independent review. Applied executing-plans, TDD, systematic-debugging for targeted
regressions, and verification-before-completion. Python runtime is 3.12.

## Downstream interface

`StateMetadata(logical_semantics_sha256: str, H: int, W: int,
original_input_sha256: str, initial_output_sha256: str,
status: str = "success", first_bad_index: int | None = None)` validates SHA-256
identifiers, positive explicit output shape, exact statuses and the failure-index
relationship. `invocation_sha256` is a derived property, not caller-authoritative:
SHA-256 of canonical JSON with exactly logical semantics, shape, original input,
and initial output identities. Failure index is a row-major scalar index into
`(H+1,W+1)` input; success requires null. `to_record()` emits complete manifest
metadata including the derived invocation identifier.

`write_state(input_after, output, metadata, directory, *, limits=ArtifactLimits())`
streams signed little-endian i32, checks precise iterable lengths and stores
immutable `chunks/<sha256>.i32` plus `state.json`. Default chunks are at most 1 MiB.
Repeated equal content at distinct offsets may use the same immutable chunk path.
The writer reuses existing bytes only after actual comparison; incompatible
existing content is rejected. No compression or synthetic-fill encoding exists.

`verify_state(manifest, limits=ArtifactLimits(), *, sidecars=(), closure_paths=())`
returns frozen `VerifiedState`; `ValidatedState` is an alias. Retained fields:
`root: Path`, `manifest_path: Path`, `manifest_sha256: str`,
`metadata: StateMetadata`, `chunks: tuple[StateChunk,...]`,
`closure: tuple[ClosureFile,...]`, `logical_bytes: int`, `limits: ArtifactLimits`.
Each `StateChunk` has `role, offset, byte_length, sha256, path`; offset is in bytes.
Each `ClosureFile` has `path: str` (normalized relative POSIX),
`resolved_path: Path`, `sha256: str`, `byte_length: int`.

`VerifiedState.revalidate()` hashes all previously accepted closure bytes and
checks identities again. `iter_bytes("input_after" | "output")` and
`iter_scalars(role)` revalidate before traversal and rehash every actual chunk
before exposing its bytes; no stale-hash shortcut is used. Symlink directory
ancestors swapped after verification are also rejected. All path components are
opened with `O_NOFOLLOW`; nonregular files are rejected without blocking on FIFOs.

`compare_state(a,b)` compares complete semantic metadata, revalidates closures and
compares actual streamed scalar values rather than equating digests. It returns
`StateComparison(equal, reason=None, role=None, index=None, coordinate=None,
left=None, right=None)`. First mismatch includes row/column coordinate using
`W+1` for post-call input and `W` for output. Successful comparison traverses all
logical state; an unequal comparison can stop at the first mismatch.

`AcquisitionMetadata(run_sha256, collector_sha256, plan_sha256,
emitted_kernel_sha256, binary_sha256, mode, started_utc, completed_utc)` uses
SHA-256 identity strings, modes `synthetic` or `native_observed`, strict UTC
seconds/fractional-second Z timestamps and nondecreasing windows.
`write_acquisition(manifest, metadata, *, name="acquisition.json", limits=...)`
and `verify_acquisition(path, state)` keep this separate from canonical semantic
state. Sidecars bind the exact manifest bytes and semantic invocation identifier.
Their full schema is in `protocol/state-v1.md`. Tests demonstrate two distinct run,
plan and emitted-kernel identities with equal semantic manifests and different
acquisition declarations.

Shared `canonical_json(value) -> bytes` uses ASCII/sorted keys/no whitespace;
`read_manifest(path, limits=ArtifactLimits())` rejects noncanonical JSON, duplicate
keys, floats/NaN, oversized integer tokens, excessive depth, bytes and decoded
items. The reader validates one JSON file and intentionally discovers no arbitrary
indirect reference schema; enclosing protocol modules must enumerate their own
complete closure.

## Budget and schema decisions

Defaults exactly preserve 1,048,576 chunk bytes, 16,777,216 per-file bytes,
268,435,456 aggregate bytes and 16,384 files. Additional defaults are
268,435,456 logical expanded bytes, 1,048,576 metadata bytes, depth 16, and 65,536
metadata items. Shape-derived expanded size is checked before state consumption;
writer metadata-envelope checks also occur before consuming a potentially large
iterable. Only bounded chunk buffers and bounded metadata are retained.

Budgeting includes the state manifest, every referenced actual chunk, explicit
sidecars and caller-supplied pilot/other closure paths. Same normalized path
counts once; equal bytes at distinct paths count twice, including hard links.
The independent logical bound prevents repeated-content reconstruction bypasses.
No path escape, symlink, malformed or reordered/overlapping/missing coverage,
wrong role/shape/status, or actual-byte/hash mismatch is accepted. Direct and
indirect enclosing protocol references must be expanded by their owning module;
its cross-state union must use `ClosureFile.resolved_path` and count actual bytes.

Ruling: first_bad_index is an integer row-major input index rather than a tuple,
per root's semantic contract clarification. Coordinates are derived from W+1;
if that contract changes, a versioned schema migration is necessary.

Ruling: strict canonical semantic JSON excludes acquisition/run/kernel/binary
identities. Physical plan changes cannot change semantic state identity by
metadata alone; provenance remains a separately budgeted and bound declaration.

Ruling: no task-local commit, root serializes commits and review, overriding the
brief's final commit step. No pending changes are hidden by a local commit.

## Trust boundary

The format cannot prove that a supplied iterable was observed native post-call
memory. `native_observed` is a declaration, not origin evidence. Original input
and initial output hashes cannot by themselves prove input preservation, true
first failure or unchanged failure output. Future admission must require a real
collector to bind actual dump paths/bytes to a completed invocation and compare
all observed state to independent original data/reference state, before allowing
blob sharing or admitting timing. Synthetic evidence retains synthetic provenance.
No native resource zeroes, measurement claims, or threshold changes are supplied.

## TDD and verification evidence

1. Initial test invocation failed with missing `state_artifacts` implementation,
   as required by the brief. Ten initial format tests then passed after fixing a
   test-only invalid custom-limit construction.
2. Added regression tests before fixes and observed RED for: writer consuming
   iterables before rejecting impossible metadata limits; accepting a date-only
   acquisition timestamp until an incidental TypeError; accepting a mutated
   extra/pilot closure in `verify_acquisition`; following a symlink introduced
   in a previously verified root ancestor. Root causes were addressed and each
   test returned GREEN. Added strict semantic-identity/shape tampering coverage.
3. `PYTHONPATH=. python -m unittest tests.test_state -v`, cwd
   `axiom/research`: **14/14 passed**, latest normal run 3.271 seconds.
4. `PYTHONPATH=. python -O -m unittest tests.test_state -v`: **14/14 passed**
   (optimized product validation remains active).
5. `python -m py_compile state_artifacts.py tests/test_state.py`: exit 0.
6. Full integration snapshot `PYTHONPATH=src:. python -m unittest discover -s tests -v`,
   cwd `axiom`: 89 tests, six expected actual-toolchain skips, one unrelated
   in-flight RED: `test_unsafe_dead_arithmetic_has_actual_witness` attempted JSON
   encoding of a greater-than-19-digit witness result and got
   `INTEGER_TOKEN_LIMIT at $.result`. Root/checker owner confirmed this was an
   intentional RED during their concurrent witness-serialization regression and
   subsequently fixed it with a decimal string. Root requested no further
   out-of-scope rerun; root owns final integration verification.

Primary-size synthetic test uses unique per-chunk scalar data and stores all
**33,570,812 actual chunk bytes before metadata**, not merely a small repeated
content file. Input is 16,793,600 bytes, output 16,777,212 bytes. The test hashes
and reconstructs every actual byte and checks every scalar in logical order;
no file exceeds 16 MiB. Its values intentionally exercise encoding independently
of the source range contract. This is **artifact-format validation only**, not
seed-65537 native execution or eligibility/performance evidence.

No deferred known product defect is recorded. Fresh independent review and
root-owned integration verification remain outside this worker's role.

## Independent review round1: writer confinement correction

Review `.superpowers/sdd/03/task-1-review.md` against immutable base `89f8eae`
identified P2: `_write_immutable` checked ancestors and then opened an absolute
path, allowing a concurrent directory-to-symlink swap to redirect creation before
final verification rejected the bundle. The same race affected absolute-path
bundle directory creation. This supersedes the earlier no-known-defect statement.

Added controlled filesystem regressions before changing product code. They
intercept the actual imminent OS creation call, rename a legitimate temporary
ancestor, replace it with a symlink to a separate temporary destination, and
check the actual destination remains empty. The wrapper delegates to the real OS
operation; assertions cover physical side effects, not mocked call signatures.

RED command (cwd `axiom/research`):

```text
PYTHONPATH=. python -m unittest tests.test_state.StateTests.test_write_rejects_swapped_directory_without_outside_file tests.test_state.StateTests.test_directory_creation_does_not_follow_swapped_ancestor -v
Ran 2 tests in 0.002s
FAILED (failures=2)
```

The first failure demonstrated a 16-byte content-addressed i32 file in the
symlink destination; the second demonstrated a newly created `bundle` directory
there. Both are the real reviewed defect and stayed within temporary probes.

Changed only state module/tests/protocol for the fix: `_write_directory` now
opens each absolute ancestor as a directory relative to the previous pinned
descriptor, always with `O_DIRECTORY | O_NOFOLLOW`. Missing directories are
created via descriptor-relative `os.mkdir`, then safely opened. Immutable files
are created from their basename with `dir_fd`, `O_EXCL | O_NOFOLLOW` under the
pinned parent. There is no absolute-path directory or file creation in these
write paths. Chunks, semantic manifests and acquisition sidecars all use the
corrected helper. Public API/schema is unchanged; the protocol now documents
write-side confinement.

GREEN targeted command: identical to RED above; `Ran 2 tests in 0.002s`, `OK`.
Final requested covering checks, cwd `axiom/research`:

```text
PYTHONPATH=. python -m unittest tests.test_state -v
Ran 16 tests in 2.944s
OK

PYTHONPATH=. python -O -m unittest tests.test_state -v
Ran 16 tests in 2.900s
OK
```

Both runs include the full unique 33,570,812-byte synthetic format roundtrip.
No broader suite was rerun, no commit or subagent was created. Root owns scoped
independent re-review of this correction against `89f8eae` and final integration.

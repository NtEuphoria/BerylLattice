# Plan03 Task1 independent review

Reviewed immutable commit `89f8eae45f5c3128378e641c5501af7dbe26041d` using the exact diff in `task-1-review-package.txt`, the task brief, implementation report, and current implementation. No product files were changed and the reported suite was not rerun unchanged.

**Spec compliance: changes required.** Complete encoding, coverage, comparison, closure accounting, semantic/acquisition separation and primary-size traversal satisfy the reviewed requirements, except writer path confinement under concurrent directory replacement.

**Code quality: changes required.** One P2 correctness finding; no other blocking finding established.

## P2 — Anchor immutable writes to safely opened directory descriptors

Location: `axiom/research/state_artifacts.py:378-389`, specifically the absolute-path `os.open` at line 382.

`_write_immutable` checks ancestors with `_root(target)` and subsequently opens the entire absolute target path. `O_NOFOLLOW` protects only the final component. A directory such as `chunks` can become a symlink between those operations, so writing a chunk creates bytes outside the artifact root. The final state verification eventually raises an exception, but the external write already occurred. The same helper writes manifests and acquisition sidecars, so the issue is not restricted to chunk content.

Independent deterministic reproduction: intercept the impending `os.open` for the first chunk, rename `bundle/chunks` to `bundle/original-chunks`, replace `bundle/chunks` with a symlink to a sibling `outside` directory, then perform the original open. Calling `write_state([1,2,3,4], [5], metadata, bundle)` creates one 16-byte content-addressed file in `outside` before raising `ValueError('symlink paths are forbidden')` on the next operation. Both directories are temporary; no files outside the temporary probe were touched.

Requested correction: open every write-directory component with descriptor-relative `O_DIRECTORY | O_NOFOLLOW`, as `_read_file` already does for reads, then create the final basename with `dir_fd` and `O_EXCL | O_NOFOLLOW`. Ensure directory creation does not reintroduce absolute-path ancestor traversal. Add a targeted regression which swaps an ancestor immediately before creation and asserts that no artifact appears in the symlink destination.

## Independent evidence

- Repeated all-zero content at distinct logical offsets verifies successfully. Comparing equal scalar sequences written with 8-byte versus 4-byte chunk partitions succeeds, confirming comparison does not depend on matching chunk hashes or boundaries.
- An output-only scalar mismatch reports role `output`, index `0`, coordinate `(0,0)`, and values `0` and `123` after equal input traversal.
- Two hard-linked paths containing six equal bytes add twelve aggregate bytes; repeating one path adds nothing. Reducing the complete closure quota by one byte rejects the artifact.
- Independently generated the primary synthetic shape `(H,W)=(2049,2047)` using increasing input and negative decreasing output scalars. Unique stored chunk bytes total **33,570,812**. Instrumented actual scalar yields while `compare_state(v,v)` traversed both operands: **8,396,800 input scalar yields** and **8,388,606 output scalar yields**, exactly twice each complete role length. This is complete artifact-format traversal, without a native execution or performance claim.
- Inspected exact role order, contiguous byte offsets, lengths, SHA-256 checks, strict metadata field sets, failure-index bounds, independent logical-byte limit, acquisition binding, and safe read traversal. No digest-only successful-comparison shortcut or content-hash-based aggregate deduplication was found.
- Existing report evidence covers normal/optimized unit checks and post-verification mutation tests; this review did not duplicate that suite. Read paths use descriptor-relative traversal and reject symlinks in ancestors. The confirmed finding concerns write paths.

Native origin remains an explicit future collector/admission obligation. The format correctly does not treat `native_observed` declarations, pre-call identities, or synthetic traversal as proof of native execution, preserved post-call input, resource observations, or eligibility.

## Scoped re-review of writer-confinement correction

Reviewed `.superpowers/sdd/03/task-1-fix.diff` and the updated implementation report. **Original P2: ADDRESSED. Spec compliance: approved. Code quality: approved.** These verdicts supersede the initial changes-required verdicts above. No new important breakage was found in the fix.

`_write_directory` now pins each ancestor using descriptor-relative `O_DIRECTORY | O_NOFOLLOW` opens; missing directories are created relative to those pinned descriptors and reopened safely. `_write_immutable` creates only the basename relative to the safely opened parent with `O_EXCL | O_NOFOLLOW`. Thus replacing an ancestor with a symlink cannot redirect either file or directory creation into its destination. The fix covers chunks, manifests, and acquisition sidecars without changing their schema or public API.

The updated report records both regressions failing before the fix and passing afterward, followed by 16 normal and 16 optimized tests. I did not repeat that unchanged suite. An additional independent probe exercised acquisition-sidecar creation: immediately before the final creation open, rename the entire verified bundle and replace its original path with a symlink to an empty temporary destination. The sidecar was created under the pinned original directory, the destination remained empty, and subsequent verification rejected the substituted root. The same probe confirmed normal nested directory creation and identical immutable-state reuse still work. No product files were changed during review.

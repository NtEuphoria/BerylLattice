# Plan03 Task4 independent review

Current status after scoped re-review of fix `d37a249`: **specification APPROVED; code quality APPROVED**. The initial P2 below is resolved. See the scoped re-review at the end; initial findings remain as historical evidence.

Reviewed owned files as committed in `d4bc5d154a62efd2a3d5df661d660a178b08c5b6`, against the task brief, Plan03, prototype contract, export-v1 documentation, actual receipt/state/manifest dependencies, and pinned evaluator source. The owned files were unchanged from that commit during review; later unrelated repository commits and working-tree changes were not reviewed or modified.

## Specification verdict: changes requested

One reproducible P2 mapping defect remains. The other inspected requirements are implemented: bounded direct/indirect closure, distinct-path accounting, logical-state accounting, exact evaluator SHA-256/Git blob pins, independent envelope-selected expected fixture, native denial, both ratified synthetic profiles, full held-out chronology, retained source/snapshot pre/post readmission, and supported fixed evaluator argv. The correctness-profile chronology exception and non-hermetic/read-only storage limitations are explicitly documented and were treated as approved scope.

### P2 — Bind evaluator independence method to the frozen sampling mode

Location: `axiom/research/evaluate_adapter.py:193-217` (especially the per-block mapping at lines 195-196 and identity mapping at lines 216-217).

The adapter maps order, sample index and session ID, but never maps `block.independence.method` or its reset evidence to `experiment.spec.sampling.session_mode`. Individual research receipt admission validates `fresh_owned_process` and rejects reset evidence in that mode, but does not enforce session uniqueness across receipts. The pinned evaluator delegates session uniqueness to its independently supplied `independence.method`; `verified_reset_equivalence` permits reused session IDs.

A consistent export can therefore retain a frozen `fresh_owned_process` experiment and `reset_evidence: null` on every research receipt while changing evaluator independence records to `verified_reset_equivalence` and reusing one session ID across every pilot/evaluation run. All ordinary hashes, metric mappings, oracle comparisons and chronology checks still pass. Real `admit_export` followed by real `evaluate` returns `synthetic_gate_pass` and claims 32 independent units. Native eligibility stays false, which limits impact but does not make this contradictory synthetic validation valid.

Exact reproduction: from `/workspace/BerylLattice/axiom/research`, run `PYTHONPATH=. python ../../.superpowers/sdd/03/task-4-review-independence.py`. The retained reproduction log is `.superpowers/sdd/03/task-4-review-independence.log`. The script:

1. Constructs the existing independently authored `Fixture(case, held_out=True)` without changing its frozen sampling plan.
2. Sets all 128 research receipt identity session IDs, raw identity session IDs, and evaluator measurement session IDs to `reused-session`, updating their references.
3. Changes each evaluator independence receipt method to `verified_reset_equivalence`, retaining its existing synthetic proof object and updating all block references.
4. Rewrites the pilot, recomputes its legitimate historical pinned-evaluator freeze, updates request/envelope hashes, and calls actual export admission and actual evaluator execution.
5. Prints the frozen mode, absent reset evidence and accepted result; cleans only its own temporary evidence.

Expected: reject the independence-method/frozen-mode mismatch (and reused fresh-process sessions). Actual: admission and evaluation succeed. This does not rely on forged admission objects, mutation races, modifying the pinned evaluator, or hostile same-UID behavior.

Requested correction: explicitly bind each block's evaluator independence method to the frozen sampling mode; enforce fresh-owned session uniqueness over both pilot and evaluation; for reset-contract mode, bind the external reset-equivalence evidence to the approved frozen/research reset evidence or an explicitly reviewed mapping. Add a negative control using consistent references and duplicate sessions, plus a positive control for any supported reset-contract mapping.

## Code-quality verdict: changes requested

The identified cross-schema omission needs correction and a regression test. The current tests have useful adversarial depth, but they do not cover this global sampling invariant; per-receipt checks plus the pinned evaluator cannot establish it unless their independence policies are joined explicitly. No additional blocking code-quality finding was established. No production files or tests were edited, and no commit was made.

## Validation performed

Executed from `axiom/research`:

```text
PYTHONPATH=. python -m unittest \
  tests.test_evaluate_adapter.AdapterTests.test_same_wrong_output_cannot_replace_independent_held_out_oracle \
  tests.test_evaluate_adapter.AdapterTests.test_fabricated_admission_is_freshly_revalidated \
  tests.test_evaluate_adapter.AdapterTests.test_post_execution_mutation_is_detected \
  tests.test_evaluate_adapter.AdapterTests.test_full_closure_quota_counts_equal_bytes_at_distinct_paths -v
```

Result: 4/4 PASS, 44.977 seconds. These independently exercise same-wrong-output rejection, fabricated/local admission rejection, post-execution mutation rejection, and byte/file/logical quota rejection.

The custom independence reproduction exercised both actual admission and the retained Python/evaluator subprocess and demonstrated the defect. Its final run completed with exit 0 and printed `ADMITTED: synthetic_gate_pass units: 32 native: False`. The first reproduction printed successful acceptance, then encountered a cleanup `PermissionError` because retained directories are read-only; cleanup was corrected and only that reproduction's retained root was removed. This cleanup issue did not cause the admission result.

The reported complete owned suite (16 tests) and isolated pinned evaluator analytical suite (18 tests) were inspected as implementation evidence, not rerun or claimed as independent reviewer execution. No native campaign was signaled, stopped, altered or used as review evidence. No cloud configuration change or dependency installation was needed. This review does not establish physical instrumentation, oracle authorship honesty, hermetic execution, or hostile same-UID immutability.

## Scoped fix re-review — d37a249a194291b8b1e4df8e85dc098f23c82d80

Specification verdict: **APPROVED**. Code-quality verdict: **APPROVED**. The original P2 is resolved; no additional blocking fix regression was found. This supersedes the initial changes-requested verdicts above.

Reviewed the exact fix package and current owned files (no difference from the fix commit). `evaluate_adapter.py:192-202` now derives the evaluator independence method from the frozen sampling mode and rejects a mismatch before processing measurements. Lines 225-227 enforce session uniqueness through one set shared across pilot and evaluation. Lines 228-232 require reset-contract evidence to match the exact resolved receipt path, receipt hash and frozen reset hash. Both receipts in every block are checked. Existing receipt admission still validates the complete sampling settings and reset evidence, while ordinary evaluator validation retains its exact schema and per-block identities. Documentation accurately describes these constraints and the remaining physical-independence assumption. No evaluator pin, CLI, native-eligibility boundary or oracle rule changed.

Reviewer-executed validation from `axiom/research`:

```text
PYTHONPATH=. python -m unittest \
  tests.test_evaluate_adapter.AdapterTests.test_frozen_fresh_sessions_cannot_claim_reset_equivalence \
  tests.test_evaluate_adapter.AdapterTests.test_fresh_session_uniqueness_spans_pilot_and_evaluation \
  tests.test_evaluate_adapter.AdapterTests.test_reset_contract_requires_exact_frozen_research_evidence \
  tests.test_evaluate_adapter.AdapterTests.test_approved_reset_contract_maps_and_preserves_synthetic_gate -v
```

Result: **4/4 PASS, 31.104 seconds, exit 0**. The positive reset-contract test executes actual retained evaluation, preserves `synthetic_gate_pass`/native false, and checks that the admitted closure contains the selected reset evidence hash. The negative controls test method mismatch, fresh-session reuse across phases, and substitute reset evidence with otherwise consistently updated references.

Also executed the original independent reproduction unchanged via `runpy.run_path('../../.superpowers/sdd/03/task-4-review-independence.py')`, catching and asserting the required `ValueError`. Result: **PASS, exit 0**; the original 128-run single-session export now rejects with `independence method differs from frozen session mode`. No production or test file was edited during re-review.

Scope limitation: this was a targeted re-review of the original finding and fix regressions, layered on the initial full inspection. The owner's complete 20-test suite was running separately and is not claimed as reviewer execution. Native campaigns and unrelated repository changes remained untouched.

# Plan03 Task3 implementation report

Scope: `axiom/research/receipt_admission.py`, `axiom/research/tests/test_receipts.py`,
`axiom/research/protocol/receipt-v1.md`. No commits, collector, large-buffer
backend, scalable Axiom oracle, generated performance result or adoption path.

## Outcome

Implemented frozen typed receipts, strict nested serialization/parsing, immutable
admission results, exact evaluator paid/resource names, retained per-run raw
observations, compiler/toolchain/environment/artifact/run binding, frozen workload
and experiment identities, checked-call scope/phase coverage, sample/order/reset
binding and UTC chronology. Resource diagnostics retain process RSS peak, logical
arena capacity and allocator peak separately; unavailable numbers are `null`.
Paid/resource values must match retained raw observations, including numeric type,
and raw keys map one-to-one to quantities. A scalar/version assertion never
validates measurement physics: `instrumentation_validated=False` in every result.

`admit_measurement(receipt, experiment)` remains unconditionally native-ineligible.
No JSON bit, collector/version string, nominal measured resource or synthetic
success can enable native admission. Every result retains the deferred reviewed
collector/instrumentation, independently reviewed scalable oracle and larger-buffer
gates, plus explicit hardware/OS/collector/history/sampling assumptions.

`admit_synthetic_fixture(..., fixture_oracle=...)` is the separately labeled
infrastructure test path. The explicit independently supplied anchor requires
expected manifest path, sidecar path, version and both SHA-256 pins. It is not
constructed from the receipt's self-claimed expected hash. Its fixture-author
trust is explicit, and it cannot become native evidence. `write_fixture_oracle`
only binds supplied literal expected values; it computes no Axiom oracle.

Both actual/expected complete manifests and acquisition/oracle sidecars are
traversed via the state-artifact API. Comparison reads every actual post-call
input/output scalar and verifies status/first failure plus full invocation
identity. Post-call input also must preserve the frozen original-input identity,
supplementing the full scalar comparison. Semantic events/stdout compare exact
retained bytes; instrumentation diagnostics are retained separately. Full combined
closure file/aggregate/count budgets and a separate expanded logical-state budget
include both actual and expected state. Equal bytes in distinct files count twice.

The literal expected fixture independently hand-works `[0,1,2,3]` as
`1+4+9+16=30`. Two observed states both returning 99 pass pair/format comparison
and fail the independent expected comparison. Controls additionally cover jointly
replaced expected-state+sidecar identities, missing actual state/input coverage,
postinput mutation, wrong status/semantics, acquisition/identity/sampling changes,
process timers, omitted phases/costs, fake zero/unavailable resources, raw boolean
vs integer confusion, double-counted raw costs, future acquisition, and closure
limits.

## Pinned contract read

`/workspace/beryl/tools/beryl-experiments/evaluate.py` SHA-256:
`b368462fc46c3173650c8654765e283fc84fd1e86c7c6c11154d809367956593`.
Read its exact `COSTS`, `RESOURCES`, identity, integer/sum/scope-adjacent chronology
and retained<=peak admission contract, plus its README and the approved Axiom
performance protocol/harness-gaps. The external evaluator was neither modified
nor invoked by this task. No threshold changes.

## RED -> GREEN evidence

All commands below were run from `/workspace/BerylLattice/axiom/research` with
`PYTHONPATH=.`; output logs live beside this report.

- `python -m unittest tests.test_receipts -v`: `task-3-red.log` ends
  `ModuleNotFoundError: No module named 'receipt_admission'`, `FAILED (errors=1)`.
  Before this intended missing-module RED, a mistaken test destination and an
  unmatched parenthesis were corrected; neither was treated as feature evidence.
- Initial full receipt implementation: `task-3-green.log`, 14 tests, `OK`.
- Pin/diagnostic/raw-identity hardening RED:
  `task-3-hardening-red.log` (new required oracle API missing), then
  `task-3-hardening-red-2.log` (2 failures: absent explicit diagnostics and changed
  compiler argv incorrectly accepted), and `task-3-hardening-red-3.log` (new raw
  fields rejected before support). `task-3-hardening-green.log`: 20 tests, `OK`.
- `task-3-selfreview-red.log`: 22 tests, 2 meaningful failures: candidate at
  baseline pair position accepted; raw `true` accepted as measured integer 1.
  `task-3-selfreview-green.log`: 22 tests, `OK` after strict JSON-typed comparison,
  position/artifact-role checks and explicit raw session/unit binding.
- `python -m unittest tests.test_receipts.ReceiptTests.test_future_acquisition_is_not_a_completed_measurement -v`:
  `task-3-future-red.log`, `FAILED (failures=1)` because 2099 acquisition was accepted.
  Added present-time UTC bound; `task-3-final-green.log`: 23 tests, `OK`.
- `python -m unittest tests.test_receipts.ReceiptTests.test_synthetic_fixture_full_state_pass_is_never_native -v`:
  `task-3-instrumentation-red.log`, missing `instrumentation_validated` field.
  Added permanently false result field; normal and optimized dependency suites
  initially passed 60 tests each.
- `python -m unittest tests.test_receipts.ReceiptTests.test_independent_fixture_cannot_redefine_input_preservation -v`:
  `task-3-preservation-red.log`, `FAILED (failures=1)`: samewrong actual+expected
  postinput could contradict their original immutable-input identity. Added the
  independent frozen-original-input check after full scalar comparison.

Final verification is recorded below after the last change.

## Rulings and limits

- Ruling: no native enable flag/registry is provided — reviewed collector,
  scalable oracle and larger-buffer gates are explicitly deferred by the brief
  and root instruction. Cost if wrong: a separately reviewed future implementation
  must introduce native admission; this change cannot accidentally open it.
- Ruling: explicit synthetic oracle pins supplied independently by the caller,
  instead of treating a measurement's expected hash as trusted — root approved
  this API. Fixture-author expected values/provenance remain an explicit test
  assumption. Cost if wrong: a fixture can be logically wrong despite consistent
  bytes; it still cannot establish native/performance evidence.
- Ruling: retain exact raw observation records under an explicitly synthetic or
  unreviewed-native consistency schema — this does not invent approved physical
  collector definitions. Cost if wrong: future reviewed instrumentation may need
  a separately versioned schema; current native admission remains unavailable.
- Ruling: parent requested no subagents, no commits and root-managed final project
  suite while other workers run. Only owned receipt and direct state/manifest
  dependency suites were run here; parent will run the combined project suite.

## Self-review

Reviewed owned code against every Task3 bullet and the exact external evaluator
contract, including wrong-pair output, full actual/expected closure, postinput
preservation, trusted oracle pins, scope, raw-vs-instrument distinction, unknown
numeric handling, frozen records, diagnostic scope, no-command execution and
native gate closure. Self-review found and fixed raw-key cost reuse, raw numeric
bool confusion, missing session/position identity binding, future acquisition and
postinput preservation against original identity, with RED/GREEN controls noted
above. No remaining Critical/Important findings in this authored pass. A fresh
review by the parent remains useful; self-review is not independent approval.

Cloud skills were loaded for executing-plans and TDD at task start. A later
verification-before-completion read was unavailable after cloud skills were
removed; completion claims rely on the fresh explicit test output below.

## Final verification and concurrent dependency changes

- Final normal owned+state run:
  `PYTHONPATH=. python -m unittest tests.test_receipts tests.test_state -v`
  (`task-3-final-owned-green.log`): 40 tests, `OK` (24 receipt controls).
- Fresh optimized full direct-dependency run:
  `PYTHONPATH=. python -O -m unittest tests.test_receipts tests.test_state tests.test_manifest -v`
  (`task-3-dependencies-optimized-green.log`): 64 tests, `OK`.
- Owned Python files compile with `python -m py_compile`; all three owned files
  have clean trailing whitespace and final newlines. These are untracked files,
  so `git diff --check` alone was not counted as an effective whitespace check.

An immediately preceding normal dependency run encountered Task2's intentionally
in-flight review regression tests before that worker applied its fixes. Preserved
log: `task-3-concurrent-manifest-red.log` (64 tests, six failures, log mtime
2026-10-16 00:07:14 UTC). All failures were from:
`test_correctness_receipt_labels_cannot_hide_content_or_shape_access`,
`test_disclosed_correctness_receipts_obey_holdout_and_preregistration` (three
cases), and `test_postfreeze_held_out_correctness_needs_completed_selection` (two
cases). No receipt/state tests failed. The subsequent optimized dependency run
passed 64/64; root confirmed Task2 fixes stable at `ef0c7f8` and requested no
further dependency reruns. The root will run the final combined project suite.
- Final focused optimized owned run:
  `PYTHONPATH=. python -O -m unittest tests.test_receipts -v`
  (`task-3-final-owned-optimized-green.log`): 24 tests, `OK`.

## Scoped review nit fix: immutable observation reasons

Independent review `task-3-review.md` approved the specification and reported one
quality nit: a measured observation's annotated string `reason` could instead be
a mutable JSON list, survive parsing, receive synthetic admission and then be
mutated through the otherwise frozen record. Root explicitly requested fixing
this nit before integration.

Added construction-time exact-string validation in `Observation.__post_init__`,
which covers parsing and direct construction for every observation group/status.
Reasons never accept null, booleans, arrays or objects. Valid strings, including
default empty reasons where permitted, keep identical serialization. The existing
nonempty-string rule for an inapplicable paid component still applies. Export
adapter owner confirmed fixtures use compatible default empty-string reasons.

Targeted RED command:
`PYTHONPATH=. python -m unittest tests.test_receipts.ReceiptTests.test_observation_reasons_reject_mutable_and_nonstring_values_for_all_variants tests.test_receipts.ReceiptTests.test_string_observation_reasons_roundtrip_and_preserve_synthetic_admission -v`.
`task-3-reason-red.log`: 2 tests, `FAILED (failures=15)` from list/bool/dict reasons
being accepted across measured paid/resources, inapplicable paid, and
measured/unavailable diagnostics. The valid-string roundtrip/admission test passed
before the fix. New rejection controls check both `from_record` and direct
`dataclasses.replace` construction; valid measured/inapplicable/unavailable
string reasons roundtrip unchanged.

After the fix, the owned normal command
`PYTHONPATH=. python -m unittest tests.test_receipts -v`
passed 26 tests (`task-3-reason-green.log`). No dependency/project suites were
repeated for this nit. No commits or subagents. The focused optimized result is
recorded below after completion. Native gates and physical-instrumentation status
remain unavailable; this change only enforces the documented string field type.

Focused optimized verification:
`PYTHONPATH=. python -O -m unittest tests.test_receipts -v`
passed 26 tests (`task-3-reason-optimized-green.log`). The verification skill became
available again during this scoped fix and was read before final handoff. All
changes are limited to the reason type check, its targeted rejection/roundtrip
controls, and the protocol clarification above.

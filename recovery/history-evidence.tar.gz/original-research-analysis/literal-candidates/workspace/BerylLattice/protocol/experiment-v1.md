# Axiom frozen experiment v1

This declaration format implements the 2026-10-15 performance protocol's frozen
workloads and chronology. It supplies no native measurement, scalable semantic
oracle, causal proof of independence, or performance result. It cannot discover
unreported accesses or independently attest the declared UTC times. Report all
known accesses, including accesses that make the run ineligible.

## Identity and exact data

`experiment_manifest.py` provides immutable `Workload`, `AccessRecord`,
`SamplingPlan`, `ExperimentSpec`, `Receipt` (also `ChronologyReceipt`),
`FrozenManifest`, and `ChronologyResult` records. Collections inside typed records
are tuples. Hashes are lowercase SHA-256; UTC times use an ISO timestamp with a
`Z` suffix and up to six fractional digits. Integer fields reject booleans.

`Workload.content_sha256` hashes canonical JSON containing logical semantics,
output shape `{W,H}`, and the complete original input hash. It excludes dataset
role, paths, generator labels, seed, cap, entry contract, output initialization,
and cache regime. `Workload.stratum_sha256` additionally binds generator/version,
seed, cap (`null` means unconstrained), entry contract, initial output hash, and
cache regime. Roles are correctness, training, pilot, selection, and held_out;
changing a role or stratum label cannot remove content contamination.

The approved training `(W,H)` values are `(32,32)`, `(128,128)`, `(512,512)`,
`(2048,2048)`, `(4096,64)`, `(64,4096)`, each with seeds 1, 2, 3, 4. Held-out shapes
are `(31,33)`, `(127,129)`, `(511,513)`, `(2047,2049)`, `(4093,67)`, `(67,4093)`,
`(8191,1)`, `(1,8191)`, each with seeds 65537, 65538, 65539, 65540. Every cell must
be declared. Extra cap/cache/operation strata may use these exact cells, but
duplicate role/stratum entries and extra timing shape/seed cells are rejected.
Correctness patterns remain separate.

The timing data algorithm is fixed regardless of display labels. Start with u64
state equal to seed; update `state = state*6364136223846793005 +
1442695040888963407 (mod 2^64)` for each of `(W+1)*(H+1)` row-major input elements
and emit `(state >> 32) & 1023`. `approved_input_sha256(W,H,seed)` computes the hash
of the actual little-endian i32 stream in bounded chunks. Freeze/load checks
input hashes against this stream for every timing workload and every known
non-correctness access. Renaming a generator does not change this algorithm.
Correctness-pattern content hashes must truthfully describe those actual inputs;
this format does not acquire their bytes. Generated input is expected data, never
observed post-call input or native acquisition evidence. The bounded Core array
admission profile remains separate from these larger generated dataset identities.

One primary stratum is exactly `(W,H,seed)=(2047,2049,65537)`, unconstrained cap,
`ordinary_checked_call`. An optional `primary_stratum_sha256` disambiguates
multiple declared cache strata. All other results are descriptive. All declared
workloads share the primary's logical semantics.

## Known accesses and freezes

`holdout_rule` must be `input` or `shape`. Input holdout rejects a known tuning
access with held-out content identity. Shape holdout additionally rejects every
known tuning access to any held-out output dimensions, even with different data,
generator names, contracts, caps, or cache regimes. Access purposes include
training, selection, tuning, correctness, and baseline A/A pilot. All non-pilot
accesses count for contamination; relabeling timing work as correctness does not
permit held-out content/shape use.

`training_history_complete` must explicitly be true and all training content must
have a declared training access. This is an assertion about reported knowledge,
not a discovery mechanism. Non-pilot tuning accesses must occur after dataset
preregistration and by candidate freeze. Training must finish by fixed-baseline
selection. Accesses with earlier timestamps are retained and cause rejection;
they must not be erased to make a run pass.

Required ordering is dataset preregistration <= selector-design freeze <= fixed
baseline selection <= candidate freeze < pilot-policy freeze. The objective,
selector design/coefficients/ties/filter/budgets/fallback, compiler configuration,
and selected baseline/candidate artifacts are committed through their identity
fields. The baseline policy remains the approved sum of equally weighted
per-training-cell median checked-call times, ties M, I, R. These declarations do
not compute training costs or prove that the baseline was selected correctly.

A known pilot exposure must be explicitly `baseline_aa=true`, after selector
design and fixed-baseline selection and before pilot-policy freeze. It is an
allowed calibration role; candidate feedback cannot be relabeled as baseline A/A.
The selector is frozen before any such exposure. Candidate and selector identity
checks prevent retuning between pilot, final artifact selection, and measurement.

`Receipt` binds one stratum, one actual UTC window, all five frozen identity
fields, one role, and the baseline-A/A flag. `validate_chronology(manifest,
receipts)` revalidates the manifest and checks every supplied record. Final
measurements require their own stratum's A/A pilot finishing before policy freeze
and exactly one selection receipt starting after both candidate and policy
freezes, finishing strictly before measurement. Measurements from independent
shape/seed/cache/operation strata cannot share one pooled receipt, pilot or
selection. Training receipts must reference declared training strata. Passing
chronology is only one admission prerequisite; complete state, instrumentation,
resource observations and receipt authenticity are separate gates.

The evaluator threshold is the fixed literal
`max(5%,pilot_p95_absolute_paired_variation)`. There is no configurable numeric
threshold, changed objective loophole, pooled interval, or multiplicity claim.

## Sampling

`SamplingPlan` fixes an even sample count from 30 through 1024 before candidate
measurement; the protocol's normal starting declaration is 32. Count and order
cannot change mid-run or stop when an interval first looks favorable. Each
shape/seed workload repeatedly uses the same complete input. Distinct seed cells
are separate strata, not interchangeable IID samples.

The versioned `sha256-sort-balanced-abba-v1` schedule starts with count/2 indexed
AB labels and count/2 indexed BA labels. Sort indices by the binary SHA-256 of
ASCII `version:randomization_seed:index`, ascending, and emit the indexed labels.
The exact orders are persisted and checked on loading, alongside the seed,
count, warmup, input-touch and output-initialization declarations.
`SamplingPlan.sha256` binds the plan and these orders.

Fresh samples require disjoint owned process sessions containing the checked
operation. Repetitions in a session are one sample. A PID is not evidence of an
independent session; record and assess the actual independence assumption and
reset protocol. Reusing sessions requires an externally established reset
contract whose evidence hash is mandatory. The manifest records these claims;
the collector/admission layer must bind actual sessions and retained drift/run
order diagnostics. Restart does not flush LLC or OS page cache. Validation warms
input; the timer must still include required preflight and scratch cleanup.

## Serialization and loading

`freeze_manifest(spec,directory)` validates and writes canonical ASCII JSON in
`experiment-<sha256>.json`, using exclusive creation. Existing identical bytes
may be reused; existing differing content fails. `load_manifest(path)` enforces
the bounded strict canonical-JSON reader from state-artifacts v1, rejects unknown
or missing fields at every record level, and recomputes primary, threshold,
schedule, approved data hashes and history constraints. `FrozenManifest.sha256`
is SHA-256 over the complete canonical envelope. Its `revalidate()` rereads and
compares the loaded declaration, detecting changed bytes or typed records.
Serialization helpers `Workload.to_record/from_record`,
`ExperimentSpec.to_record/from_record`, and `Receipt.to_record/from_record`
supply the same strict field shapes to downstream evidence validators. A
manifest's typed declarations and input identities carry no `native_observed`
claim and cannot turn synthetic evidence into native evidence.

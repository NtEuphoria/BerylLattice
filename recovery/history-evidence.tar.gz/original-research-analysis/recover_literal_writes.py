"""Recover literal writes using a deliberately tiny AST evaluator, never exec."""
import ast
import hashlib
import json
import pathlib
import re
import shlex
import sys

ROOT = pathlib.Path('/workspace/scratch/axiom-recovery')
OUT = ROOT / 'original-research-analysis'
files = {}
provenance = {}
gaps = []
events = []
agents = sys.argv[1:] or ['implement_o1_invocation_transport']

class Unknown(Exception): pass

def apply_hunks(source, patch):
    lines = source.splitlines(keepends=True)
    out, cursor, rows, i = [], 0, patch.splitlines(keepends=True), 0
    while i < len(rows):
        m = re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', rows[i])
        if not m:
            assert not rows[i].strip(), repr(rows[i])
            i += 1
            continue
        start, count, new_count = int(m.group(1))-1, int(m.group(2) or 1), int(m.group(4) or 1)
        assert start >= cursor
        out.extend(lines[cursor:start])
        i += 1
        old, new = [], []
        while i < len(rows) and not rows[i].startswith('@@ '):
            row = rows[i]
            if row.startswith(' '): old.append(row[1:]); new.append(row[1:])
            elif row.startswith('-'): old.append(row[1:])
            elif row.startswith('+'): new.append(row[1:])
            else: assert not row.strip(), repr(row)
            i += 1
        assert len(old) == count and len(new) == new_count
        assert lines[start:start+count] == old
        out.extend(new)
        cursor = start+count
    return ''.join(out+lines[cursor:])

def normalize(path, cwd):
    p = pathlib.PurePosixPath(path)
    if not p.is_absolute(): p = pathlib.PurePosixPath(cwd) / p
    assert '..' not in p.parts
    return str(p)

def write(path, text, event, append=False):
    if append:
        if path not in files: raise Unknown('append lacks base ' + path)
        text = files[path] + text
    files[path] = text
    provenance.setdefault(path, []).append(event)

def interpret(code, cwd, event):
    env = {}
    tree = ast.parse(code)
    def evaluate(n):
        if isinstance(n, ast.Constant) and (isinstance(n.value, (str, int)) or n.value is None): return n.value
        if isinstance(n, ast.Name) and n.id in env: return env[n.id]
        if isinstance(n, ast.BinOp) and isinstance(n.op, ast.Add): return evaluate(n.left) + evaluate(n.right)
        if isinstance(n, ast.BinOp) and isinstance(n.op, ast.Div): return str(pathlib.PurePosixPath(evaluate(n.left)) / evaluate(n.right))
        if isinstance(n, ast.Subscript) and isinstance(n.slice, ast.Slice):
            sl = n.slice
            return evaluate(n.value)[slice(evaluate(sl.lower) if sl.lower else None, evaluate(sl.upper) if sl.upper else None, evaluate(sl.step) if sl.step else None)]
        if isinstance(n, ast.Call):
            if isinstance(n.func, ast.Name) and n.func.id == 'Path': return normalize(evaluate(n.args[0]), cwd)
            if isinstance(n.func, ast.Name) and n.func.id == 'len' and len(n.args) == 1:
                value = evaluate(n.args[0])
                if not isinstance(value, str): raise Unknown('len of nonliteral string')
                return len(value)
            if isinstance(n.func, ast.Name) and n.func.id == 'open': return ('open', normalize(evaluate(n.args[0]), cwd), evaluate(n.args[1]) if len(n.args)>1 else 'r')
            if isinstance(n.func, ast.Attribute):
                obj = evaluate(n.func.value)
                args = [evaluate(a) for a in n.args]
                if n.func.attr in ('read_text', 'read'):
                    path = obj[1] if isinstance(obj, tuple) and obj[0] == 'open' else normalize(obj, cwd)
                    if path not in files: raise Unknown('read lacks base ' + path)
                    return files[path]
                if n.func.attr == 'replace' and isinstance(obj, str): return obj.replace(*args)
                if n.func.attr == 'index' and isinstance(obj, str): return obj.index(*args)
                if n.func.attr == 'write_text':
                    write(normalize(obj, cwd), args[0], event)
                    return len(args[0])
                if n.func.attr == 'write' and isinstance(obj, tuple) and obj[0] == 'open':
                    assert obj[2] in ('w', 'a')
                    write(obj[1], args[0], event, append=obj[2]=='a')
                    return len(args[0])
        raise Unknown(ast.unparse(n)[:200])
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom)): continue
        if isinstance(node, ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0], ast.Name):
            try: env[node.targets[0].id] = evaluate(node.value)
            except Unknown as exc:
                env.pop(node.targets[0].id, None)
                gaps.append({**event, 'statement': ast.unparse(node)[:300], 'reason': str(exc)})
        elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
            call = node.value
            if isinstance(call.func, ast.Attribute) and call.func.attr in ('write_text','write'):
                try: evaluate(call)
                except Unknown as exc: gaps.append({**event, 'statement': ast.unparse(node)[:300], 'reason': str(exc)})
        elif isinstance(node, ast.AugAssign) and isinstance(node.target, ast.Name) and isinstance(node.op, ast.Add):
            try: env[node.target.id] += evaluate(node.value)
            except (Unknown, KeyError) as exc: gaps.append({**event, 'statement': ast.unparse(node)[:300], 'reason': str(exc)})
        elif isinstance(node, (ast.Assert, ast.If)):
            # Historical guards are recorded, not executed. File mutations beneath
            # control flow are explicitly unsupported and cannot silently disappear.
            if any(isinstance(x, ast.Attribute) and x.attr in ('write','write_text') for x in ast.walk(node)):
                gaps.append({**event, 'statement': ast.unparse(node)[:300], 'reason': 'unsupported conditional write'})
        elif not isinstance(node, ast.Expr):
            gaps.append({**event, 'statement': ast.unparse(node)[:300], 'reason': 'unsupported statement'})

turns = []
for agent in agents:
    for page in sorted((ROOT/'history/agents').glob(agent+'-*.json')):
        obj = json.loads(page.read_text())
        for turn in obj.get('turns', []): turns.append((turn.get('startedAt', ''), page, turn))
for _, page, turn in sorted(turns, key=lambda x: (x[0], x[2]['id'])):
    for index, item in enumerate(turn['items']):
        event = {'source': str(page), 'turn': turn['id'], 'item_index': index, 'item_id': item.get('id'), 'method': 'static literal file mutation; no historical command execution'}
        if item['type'] == 'fileChange':
            for change in item['changes']:
                if change['kind']['type'] == 'add' and not change['diff'].get('truncated'):
                    write(change['path'], change['diff']['text'], event)
                elif change['kind']['type'] == 'update' and not change['diff'].get('truncated') and change['path'] in files:
                    try: write(change['path'], apply_hunks(files[change['path']], change['diff']['text']), event)
                    except AssertionError:
                        gaps.append({**event, 'reason': 'strict patch mismatch', 'path': change['path']})
                else:
                    gaps.append({**event, 'reason': 'fileChange update lacks base or truncated', 'path': change['path']})
            continue
        if item['type'] != 'commandExecution': continue
        parts = shlex.split(item.get('command',''))
        shell = parts[2] if len(parts)>2 and parts[1] in ('-lc','-c') else item.get('command','')
        cwd = item.get('cwd') or '/workspace/BerylLattice'
        lines = shell.splitlines(keepends=True)
        i = 0
        while i < len(lines):
            line = lines[i]
            if line.startswith('mv '):
                args = shlex.split(line.split(';', 1)[0])
                if len(args) == 3:
                    source, dest = (normalize(x, cwd) for x in args[1:])
                    if source in files:
                        write(dest, files.pop(source), {**event, 'method': 'literal historical rename; no shell execution'})
                    else: gaps.append({**event, 'reason': 'move lacks base '+source})
            match = re.search(r"\b(cat\s+(>>?)\s*([^\s]+)|python[0-9.]*\s+(?:-[^<]*)?)\s*<<\s*(['\"])(\w+)\4", line)
            if not match:
                i += 1
                continue
            delimiter = match.group(5)
            end = i + 1
            while end < len(lines) and lines[end].rstrip('\r\n') != delimiter: end += 1
            if end == len(lines):
                gaps.append({**event, 'reason': 'missing heredoc terminator', 'header': line})
                break
            body = ''.join(lines[i+1:end])
            if match.group(2):
                path = normalize(match.group(3).strip('"\''), cwd)
                try: write(path, body, event, append=match.group(2)=='>>')
                except Unknown as exc: gaps.append({**event, 'reason': str(exc)})
            else:
                try: interpret(body, cwd, event)
                except (SyntaxError, Unknown) as exc: gaps.append({**event, 'reason': str(exc)})
            i = end + 1

manifest = []
for path, content in sorted(files.items()):
    target = OUT / 'literal-candidates' / path.lstrip('/')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(content)
    manifest.append({'historical_path': path, 'candidate_file': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'provenance': {'method': 'statically reconstructed literal writes', 'events': provenance[path]}})
(OUT/'literal-candidates.json').write_text(json.dumps(manifest, indent=2)+'\n')
(OUT/'literal-gaps.json').write_text(json.dumps(gaps, indent=2)+'\n')
print(json.dumps({'agents':agents,'files':len(manifest),'gaps':gaps,'paths':[{'path':x['historical_path'],'sha256':x['sha256']} for x in manifest]},indent=2))

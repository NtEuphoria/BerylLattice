# Latest Axiom continuation recovery

These files were reconstructed from saved Codex history, without running any
historical command. Recovered code is not thereby newly approved or qualified.
The machine-readable `supplemental-candidates.json` records exact source item
IDs, the ordered transformations, and the saved candidate bytes.

## Exact recorded checkpoints

- O2 `source_oracle.py`: `a29677691160c2f9b19fa580f47429760ca647d9ff0d7340d66ea07a35dbcb8f`.
- O2 `test_source_oracle.py`: `8544cec5d9c7e7c10320150b1672cb7e0f62a2e341684d5986abb9387e37a49d`.
- O3 `oracle_receipt.py`: `0a6aba2b43ce10202b3d2b1311345420ae6f7fa2f2aa21bbc94f80d1e3cf43e4`.
- O3 `test_oracle_receipts.py`: `77b22683f5b900dc1f66d0a8e012c1afe0223efa1e98faf7002b7713b629b30b`.
- O3 `source-oracle-v1.md`: `a4921ae8c22541273c01db2236e6df56731f230b468de5708e6a03af2610e8ec`.

The O3 bytes match the committed historical `e68660c` checkpoint. That checkpoint
had two independent-review cleanup blockers; matching its bytes does not make it
an accepted integration. The later history contains both regression tests for
those blockers, but no completed implementation repair. Those regression tests
are saved separately under `o3-uncommitted-tests`, hash
`f4917612d5a2067d73b3dabb30f9f456e4ab30c8d79e65c9d6f94f5360cd5549`.

## Uncommitted A1 work

All four A1 source/test files match the final implementer dependency-hashes record
in `implement_bounded_source_names-001.json`, item 62. They are preserved under
`a1-uncommitted`, with `restore_eligible: false` to prevent an automatic selector
from treating unfinished work as the accepted baseline.

The historical differential report is also preserved. It records 32 unchanged
accepted outcomes and original AST/identity checks, 20 unchanged rejected
outcomes, and seven intentional rejected-diagnostic changes. This is historical
evidence, not a current rerun. Approval had not completed.

## Uncommitted P1 work

The graph, cost model, both test files, and obligation fixture were reconstructed
from all successful recorded source-write commands and subsequent string edits.
All four independently recorded intermediate graph/cost hashes match the
reconstruction. Later edits have complete history coverage, but no recorded final
hash was found. The final candidates are labelled `p1-uncommitted` and are not
eligible for automatic accepted-baseline restoration.

The obligation fixture matches the independently recorded final SHA256
`80b70708c656877d57e3ff190107abe2fc579c0c0a50acf0be25f1af5a337778`.
The appended `axiom/docs/loop-plan-v2.md` also matches the independently recorded
hash `1bc7323a0bd7b0d24773c4b0f162aacf983f77e22c92abb55c32707b57984278`.

## Method and limits

`recover_o2.py` and `recover_o3_p1.py` interpret a small, explicit data-only subset:
quoted heredoc bytes, Python string literals, concatenation, replacement, slicing,
literal finite loops, and virtual in-memory reads/writes. They do not execute
historical Python, shell commands, imports, tests, network actions, or file-copy
commands. Failed writes to the mistaken nested `axiom/axiom` location were
excluded. Recovered Python files parse successfully and all saved candidate
hashes were recomputed. Current functional testing belongs to the reconstructed
complete dependency tree, outside this isolated recovery analysis.

"""Reconstruct O2 bytes from a whitelisted data-only subset of command history.

No historical code is executed. String literals, concatenation, replace, and
in-memory pseudo-file reads/writes are interpreted. Exact recorded hashes gate
all exported candidates.
"""
import ast
import hashlib
import json
from pathlib import Path
import re
import shlex

BASE = Path('/workspace/scratch/axiom-recovery')
HISTORY = BASE/'history/agents/implement_source_oracle-001.json'
OUT = BASE/'latest-analysis'
items = json.loads(HISTORY.read_text())['turns'][0]['items']
files = {}
events = []
current = None

def shell_text(item):
    argv = shlex.split(item['command'])
    assert argv[:2] == ['/bin/bash', '-lc']
    return argv[2]

def export_event(path, text, method):
    files[path] = text
    events.append({'path': path, 'item_index': current, 'item_id': items[current]['id'],
                   'method': method, 'sha256': hashlib.sha256(text.encode()).hexdigest()})

def evaluate(node, names):
    if isinstance(node, ast.Constant) and isinstance(node.value, (str, int)):
        return node.value
    if isinstance(node, ast.Name):
        return names[node.id]
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        a, b = evaluate(node.left, names), evaluate(node.right, names)
        assert type(a) is str and type(b) is str
        return a + b
    if isinstance(node, ast.Call) and not node.keywords:
        if isinstance(node.func, ast.Name) and node.func.id == 'open':
            args = [evaluate(x, names) for x in node.args]
            assert len(args) in (1, 2) and (len(args) == 1 or args[1] == 'w')
            assert args[0] in ('research/source_oracle.py', 'research/tests/test_source_oracle.py')
            return ('file', *args)
        if isinstance(node.func, ast.Attribute):
            base = evaluate(node.func.value, names)
            args = [evaluate(x, names) for x in node.args]
            if node.func.attr == 'replace':
                assert type(base) is str and len(args) in (2, 3)
                assert type(args[0]) is str and type(args[1]) is str
                return base.replace(*args)
            if node.func.attr == 'read':
                assert type(base) is tuple and base[0] == 'file' and len(base) == 2 and not args
                return files[base[1]]
            if node.func.attr == 'write':
                assert type(base) is tuple and base[0] == 'file' and base[2] == 'w' and len(args) == 1
                assert type(args[0]) is str
                export_event(base[1], args[0], 'whitelisted_ast_string_transformation')
                return len(args[0])
    raise ValueError(ast.dump(node))

for current in (12, 16):
    text = shell_text(items[current])
    match = re.search(r"^cat > (\S+) <<'EOF'\n(.*?)\nEOF(?:\n|$)", text, re.S)
    assert match
    export_event(match[1], match[2]+'\n', 'quoted_cat_heredoc')

for current in (20, 24, 26, 31, 34, 48, 51):
    text = shell_text(items[current])
    code = text.split("<<'PY'\n", 1)[1].split('\nPY\n', 1)[0]
    names = {}
    for statement in ast.parse(code).body:
        if isinstance(statement, ast.Assign):
            assert len(statement.targets) == 1 and isinstance(statement.targets[0], ast.Name)
            names[statement.targets[0].id] = evaluate(statement.value, names)
        elif isinstance(statement, ast.Expr):
            evaluate(statement.value, names)
        else:
            raise ValueError(ast.dump(statement))

expected = {
    'research/source_oracle.py': 'a29677691160c2f9b19fa580f47429760ca647d9ff0d7340d66ea07a35dbcb8f',
    'research/tests/test_source_oracle.py': '8544cec5d9c7e7c10320150b1672cb7e0f62a2e341684d5986abb9387e37a49d',
}
manifest_path = OUT/'supplemental-candidates.json'
manifest = [entry for entry in json.loads(manifest_path.read_text())
            if entry['provenance'].get('method') != 'whitelisted_ast_replay'] if manifest_path.exists() else []
for path, text in files.items():
    raw = text.encode()
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == expected[path], (path, digest)
    destination = OUT/'verified-o2'/path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(raw)
    manifest.append({'historical_path': '/workspace/BerylLattice/axiom/'+path,
                     'candidate_file': str(destination), 'sha256': digest,
                     'provenance': {'source': str(HISTORY), 'method': 'whitelisted_ast_replay',
                                    'events': [x for x in events if x['path'] == path],
                                    'verification': 'Exact match to recorded historical SHA256 in item 59 and 68'}})
(OUT/'supplemental-candidates.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(manifest, indent=2))

"""Data-only reconstruction of selected source-writing history records.

Never evaluates historical Python or shell. Only whitelisted string operations,
finite literal loops, and virtual in-memory files are interpreted.
"""
import ast
import hashlib
import json
from pathlib import Path
import posixpath
import re
import shlex

BASE = Path('/workspace/scratch/axiom-recovery')
OUT = BASE/'latest-analysis'
manifest_path = OUT/'supplemental-candidates.json'
manifest = [x for x in json.loads(manifest_path.read_text()) if x['provenance']['method'] != 'data_only_string_replay']
files = {}
events = {}
current = {}
allowed = set()

def normalize(path):
    return posixpath.normpath(posixpath.join(current['cwd'], path))

def put(path, text, method):
    assert path in allowed and type(text) is str
    files[path] = text
    events.setdefault(path, []).append({**current, 'method': method, 'sha256': hashlib.sha256(text.encode()).hexdigest()})

def value(node, names):
    if isinstance(node, ast.Constant) and type(node.value) in (str, int, bool, type(None)):
        return node.value
    if isinstance(node, ast.Name):
        return names[node.id]
    if isinstance(node, ast.Tuple):
        return tuple(value(x, names) for x in node.elts)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        a, b = value(node.left, names), value(node.right, names)
        assert type(a) is type(b) and type(a) in (int, str)
        return a + b
    if isinstance(node, ast.Slice):
        return slice(*(None if x is None else value(x, names) for x in (node.lower,node.upper,node.step)))
    if isinstance(node, ast.Subscript):
        base, index = value(node.value, names), value(node.slice, names)
        assert type(base) is str and type(index) in (int, slice)
        return base[index]
    if isinstance(node, ast.Compare) and len(node.ops) == len(node.comparators) == 1:
        a, b = value(node.left, names), value(node.comparators[0], names)
        assert type(a) is str and type(b) is str
        if isinstance(node.ops[0], ast.NotIn): return a not in b
        if isinstance(node.ops[0], ast.In): return a in b
    if isinstance(node, ast.Call) and not node.keywords:
        args = [value(x, names) for x in node.args]
        if isinstance(node.func, ast.Name) and node.func.id == 'open':
            assert len(args) in (1, 2) and (len(args) == 1 or args[1] == 'w')
            path = normalize(args[0]); assert path in allowed
            return ('file', path, *args[1:])
        if isinstance(node.func, ast.Attribute):
            base = value(node.func.value, names)
            if node.func.attr in ('replace', 'index'):
                assert type(base) is str
                if node.func.attr == 'replace':
                    assert len(args) in (2,3) and type(args[0]) is type(args[1]) is str
                    return base.replace(*args)
                assert len(args) in (1,2,3) and type(args[0]) is str
                return base.index(*args)
            if node.func.attr == 'read':
                assert type(base) is tuple and base[0] == 'file' and len(base) == 2 and not args
                return files[base[1]]
            if node.func.attr == 'write':
                assert type(base) is tuple and base[0] == 'file' and base[2] == 'w' and len(args) == 1
                put(base[1], args[0], 'whitelisted_ast_string_transformation')
                return len(args[0])
    raise ValueError(ast.dump(node))

def statements(body, names):
    for node in body:
        if isinstance(node, ast.Assign):
            assert len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
            names[node.targets[0].id] = value(node.value, names)
        elif isinstance(node, ast.AugAssign):
            assert isinstance(node.target, ast.Name) and isinstance(node.op, ast.Add)
            old, new = names[node.target.id], value(node.value, names)
            assert type(old) is type(new) is str
            names[node.target.id] = old + new
        elif isinstance(node, ast.Expr):
            value(node.value, names)
        elif isinstance(node, ast.If):
            if value(node.test, names):
                raise ValueError('Historical string precondition failed')
            assert not node.orelse and len(node.body) == 1 and isinstance(node.body[0], ast.Raise)
        elif isinstance(node, ast.For):
            values = value(node.iter, names)
            assert type(values) is tuple and len(values) < 10 and isinstance(node.target, ast.Name) and not node.orelse
            for x in values:
                names[node.target.id] = x
                statements(node.body, names)
        else:
            raise ValueError(ast.dump(node))

def replay(history_name, indices, owned):
    global current, allowed
    history = BASE/'history/agents'/history_name
    items = json.loads(history.read_text())['turns'][0]['items']
    allowed.update(owned)
    for index in indices:
        item = items[index]
        assert item['type'] == 'commandExecution'
        argv = shlex.split(item['command']); assert argv[:2] == ['/bin/bash','-lc'] and len(argv)==3
        command = argv[2]
        current = {'source': str(history), 'item_index': index, 'item_id': item['id'], 'cwd': item['cwd']}
        if command.startswith("python - <<'PY'\n"):
            code = command.split("<<'PY'\n",1)[1].split('\nPY',1)[0]
            body = ast.parse(code).body
            if history_name == 'implement_oracle_qualification-001.json' and index == 14:
                # Remaining statements copy the already-written test to an old
                # archive. Only the preceding in-memory source edit is relevant.
                body = body[:8]
            try:
                statements(body, {})
            except Exception as exc:
                raise RuntimeError((history_name, index, exc)) from exc
            command = command.split('\nPY',1)[1]
        if 'cat ' in command:
            found = 0
            for match in re.finditer(r"cat\s+(>>?)\s+(\S+)\s+<<'([A-Z]+)'\n(.*?)\n\3(?:\n|$)", command, re.S):
                path = normalize(match[2])
                if path == '/workspace/BerylLattice/axiom/docs/loop-plan-v2.md':
                    # Generic strict-replay engine owns this existing document.
                    continue
                assert path in allowed, path
                text = match[4]+'\n'
                if match[1] == '>>': text = files[path]+text
                put(path, text, 'quoted_cat_heredoc'+('_append' if match[1]=='>>' else ''))
                found += 1
            assert found, index
        if history_name == 'implement_constructive_proofs-001.json' and index in (75,81,159):
            # This selected history command appends definitions, then edits the
            # preceding accounting function. Preserve that exact order.
            code = command.split("\npython - <<'PY'\n",1)[1].split('\nPY',1)[0]
            statements(ast.parse(code).body,{})

def export(paths, label, expected=None):
    for path in paths:
        text = files[path]; raw = text.encode(); digest = hashlib.sha256(raw).hexdigest()
        if expected: assert digest == expected[path], (path, digest)
        destination = OUT/label/path.removeprefix('/workspace/BerylLattice/')
        destination.parent.mkdir(parents=True, exist_ok=True); destination.write_bytes(raw)
        manifest.append({'historical_path':path,'candidate_file':str(destination),'sha256':digest,
                         'provenance': {'method':'data_only_string_replay','events':list(events[path]),
                                        'restore_eligible': bool(expected),
                                        'expected_sha256': expected[path] if expected else None,
                                        'verification':'Exact recorded SHA256 match' if expected else 'Complete ordered literal/string-transform history; historical final hash not yet located',
                                        'label': label}})
        print(label, path, digest, len(raw))
    manifest_path.write_text(json.dumps(manifest, indent=2)+'\n')

o3 = ['/workspace/BerylLattice/axiom/research/oracle_receipt.py', '/workspace/BerylLattice/axiom/research/tests/test_oracle_receipts.py']
protocol = '/workspace/BerylLattice/axiom/research/protocol/source-oracle-v1.md'
allowed.add(protocol)
protocol_seed_sha = 'e68b8137a01c227f05951eaff8f9071b2f15e5cdbdd5c11dbf132b195e0b3b05'
protocol_seed = BASE/'staging/objects'/protocol_seed_sha
seed_bytes = protocol_seed.read_bytes(); assert hashlib.sha256(seed_bytes).hexdigest() == protocol_seed_sha
current = {'source':str(protocol_seed),'item_id':None,'item_index':None,'cwd':'/workspace/BerylLattice'}
put(protocol,seed_bytes.decode(),'exact_verified_O2_protocol_seed')
replay('implement_oracle_qualification-002.json', [13,16,20,26,30,33,36,40,44,50,53,57,59,67,89,105], o3)
export(o3+[protocol], 'verified-o3-checkpoint', {
    o3[0]:'0a6aba2b43ce10202b3d2b1311345420ae6f7fa2f2aa21bbc94f80d1e3cf43e4',
    o3[1]:'77b22683f5b900dc1f66d0a8e012c1afe0223efa1e98faf7002b7713b629b30b',
    protocol:'a4921ae8c22541273c01db2236e6df56731f230b468de5708e6a03af2610e8ec'})
replay('implement_oracle_qualification-001.json', [14], o3)
export([o3[1]], 'o3-uncommitted-tests')
p1 = ['/workspace/BerylLattice/axiom/'+p for p in ['research/loop_proof_graph.py','research/loop_proof_cost.py','research/tests/test_loop_proof_graph.py','research/tests/test_loop_proof_cost.py','research/fixtures/loop_proof_obligations.json']]
replay('implement_constructive_proofs-001.json', [13,15,17,26,28,30,32,37,46,48,49,54,56,61,65,75,81,84,92,112,124,128,151,153,157,159,179,191,192], p1)
export(p1, 'p1-uncommitted')
manifest_path.write_text(json.dumps(manifest, indent=2)+'\n')

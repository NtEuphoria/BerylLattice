"""Restore three Core bridge files as literal data, never executing history."""
import ast
import hashlib
import json
from pathlib import Path
import re
import shlex
from replay_core_edits import replay

ROOT = Path('/workspace/scratch/axiom-recovery')
OUT = Path(__file__).parent
state = {}
events = {}
supplemental = []

def record(path, text, provenance):
    raw=text.encode();digest=hashlib.sha256(raw).hexdigest()
    destination=OUT/'objects'/digest;destination.write_bytes(raw)
    state[path]=text
    entry={'historical_path':path,'candidate_file':str(destination),'sha256':digest,'provenance':provenance}
    events.setdefault(path,[]).append(entry)
    return entry

def heredoc(name,index):
    history=ROOT/'history/agents'/name
    item=json.loads(history.read_text())['turns'][0]['items'][index]
    shell=shlex.split(item['command'])[-1]
    match=re.search(r"cat\s+(>>?)\s+(\S+)\s+<<'([A-Z]+)'\n(.*?)\n\3(?:\n|$)",shell,re.S)
    assert match
    path=str(Path(item['cwd'])/match[2])
    assert path.endswith(('core_toolchain.py','core_capsule.py','test_core_toolchain.py'))
    text=match[4]+'\n'
    if match[1]=='>>':text=state[path]+text
    record(path,text,{'source':str(history),'item_id':item['id'],'item_index':index,
                      'method':'quoted_literal_heredoc'+('_append' if match[1]=='>>' else ''),
                      'command_exit_code':item.get('exitCode'),
                      'note':'Nonzero trailing test exit does not erase the preceding successfully written source.'})

def edits(name,indices):
    for index in indices:
        for entry in replay('agents/'+name,index,state):
            events.setdefault(entry['historical_path'],[]).append(entry)

heredoc('impl_core_toolchain-002.json',10)
heredoc('impl_core_toolchain-002.json',13)
edits('impl_core_toolchain-002.json',[17,19,23,24,30,33,36,39,40])
edits('impl_core_toolchain-001.json',[9,11,17])
heredoc('impl_toolchain_loader-001.json',16)
edits('impl_toolchain_loader-001.json',[28,45])
heredoc('impl_core_cli-001.json',24)
edits('impl_core_cli-001.json',[32,39,45])
edits('impl_core_cli-001.json',[141])

# Independent review read the complete capsule before the later review fixes.
review=ROOT/'history/agents/review_core_cli-002.json'
item=json.loads(review.read_text())['turns'][0]['items'][5]
observed=(item.get('output') or {})
assert not observed.get('truncated')
capsule='/workspace/BerylLattice/axiom/src/axiom/core_capsule.py'
assert state[capsule]==observed['text'], 'Pre-fix capsule differs from independent complete source read'
capsule_readback={'source':str(review),'item_id':item['id'],'item_index':5,
                  'sha256':hashlib.sha256(observed['text'].encode()).hexdigest()}
edits('impl_core_cli-001.json',[105])

recorded_final = {
    '/workspace/BerylLattice/axiom/src/axiom/core_toolchain.py':'213504b9913a0f04bd5419149ce22c7505bbcd783164da32b5da8f3fea9993b0',
    capsule:'2f0965cee75456fc1e25947c05063ff5cb8e5c8d700012c041317d134e172c2b',
}
final_review=ROOT/'history/agents/review_final_implementation-001.json'
final_review_item=json.loads(final_review.read_text())['turns'][0]['items'][27]
assert not final_review_item['output'].get('truncated')
for digest in recorded_final.values():
    assert digest in final_review_item['output']['text']

for path,text in state.items():
    ast.parse(text)
    assert '[REDACTED_SECRET]' not in text
    digest=hashlib.sha256(text.encode()).hexdigest()
    if path in recorded_final: assert digest==recorded_final[path]
    target=OUT/'files'/Path(path).relative_to('/workspace/BerylLattice')
    target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
    supplemental.append({'historical_path':path,'candidate_file':str(target),'sha256':digest,
       'provenance':{'method':'complete_literal_write_and_restricted_string_edit_chain',
                     'restore_eligible':True,'events':events[path],
                     'expected_sha256':recorded_final.get(path),
                     'historical_hash_source':{'source':str(final_review),'item_id':final_review_item['id'],'item_index':27} if path in recorded_final else None,
                     'verification':'Exact match to final independent review retained hash; Python syntax checked' if path in recorded_final else 'Complete historical source-write coverage, subsequent review fixes retained, Python syntax checked',
                     'independent_capsule_readback':capsule_readback if path==capsule else None}})
    print(path,digest,len(text.encode()))
(OUT/'supplemental-candidates.json').write_text(json.dumps(supplemental,indent=2)+'\n')

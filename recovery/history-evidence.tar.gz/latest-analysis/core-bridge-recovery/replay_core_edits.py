"""Recover reviewed string edits by interpreting a tiny non-executable AST subset.

No historical Python or shell command is executed. File reads only use supplied
candidate bytes; writes only produce supplemental content-addressed objects.
"""
import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import shlex

BASE = Path(__file__).parent
HISTORY = Path('/workspace/scratch/axiom-recovery/history')
OBJECTS = BASE.parent / 'staging/objects'


def replay(source, item_index, state):
    data = json.loads((HISTORY / source).read_text())
    item = data['turns'][0]['items'][item_index]
    shell = shlex.split(item['command'])[-1]
    script = shell.split("<<'PY'\n", 1)[1].split('\nPY', 1)[0]
    tree = ast.parse(script)
    if source == 'agents/impl_core_cli-001.json' and item_index == 141:
        # First three non-import statements edit __main__.py, outside our scope.
        tree.body = tree.body[4:]
    if source == 'agents/impl_core_cli-001.json' and item_index == 32:
        tree.body = tree.body[:4]
    if source == 'agents/impl_core_toolchain-001.json' and item_index == 17:
        tree.body = tree.body[:5]
    names = {}
    writes = []
    bases = {}

    allowed = {'/workspace/BerylLattice/axiom/src/axiom/core_toolchain.py', '/workspace/BerylLattice/axiom/src/axiom/core_capsule.py', '/workspace/BerylLattice/axiom/tests/test_core_toolchain.py'}

    def path(value):
        p = PurePosixPath(value)
        result = str(p if p.is_absolute() else PurePosixPath(item['cwd']) / p)
        assert result in allowed, result
        return result

    def value(node):
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            return names[node.id]
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            left, right = value(node.left), value(node.right)
            assert type(left) == type(right) and isinstance(left, (str, bytes))
            return left + right
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == 'Path':
                assert len(node.args) == 1 and not node.keywords
                return value(node.args[0])
            if isinstance(node.func, ast.Attribute):
                func = node.func.attr
                args = [value(x) for x in node.args]
                assert not node.keywords
                if func in ('read_text', 'read'):
                    target = node.func.value
                    if isinstance(target, ast.Call):
                        assert isinstance(target.func, ast.Name) and target.func.id == 'open'
                        filename = path(value(target.args[0]))
                    else:
                        filename = path(value(target))
                    bases[filename] = hashlib.sha256(state[filename].encode()).hexdigest()
                    return state[filename]
                subject = value(node.func.value)
                assert isinstance(subject, str)
                if func == 'replace':
                    assert len(args) in (2, 3)
                    assert args[0] in subject, 'recorded replacement source missing'
                    return subject.replace(*args)
                if func == 'index':
                    return subject.index(*args)
        if isinstance(node, ast.Subscript):
            subject = value(node.value)
            if isinstance(node.slice, ast.Slice):
                return subject[slice(value(node.slice.lower) if node.slice.lower else None,
                                     value(node.slice.upper) if node.slice.upper else None,
                                     value(node.slice.step) if node.slice.step else None)]
        raise ValueError('unsupported expression: ' + ast.dump(node))

    for statement in tree.body:
        if isinstance(statement, (ast.Import, ast.ImportFrom)):
            continue
        if isinstance(statement, ast.Assign):
            assert len(statement.targets) == 1 and isinstance(statement.targets[0], ast.Name)
            names[statement.targets[0].id] = value(statement.value)
            continue
        if isinstance(statement, ast.If):
            test = statement.test
            assert isinstance(test, ast.Compare) and len(test.ops) == 1
            assert isinstance(test.ops[0], ast.NotIn)
            assert value(test.left) in value(test.comparators[0]), 'recorded guard failed'
            continue
        assert isinstance(statement, ast.Expr) and isinstance(statement.value, ast.Call)
        call = statement.value
        assert isinstance(call.func, ast.Attribute) and call.func.attr in ('write_text', 'write')
        target = call.func.value
        if isinstance(target, ast.Call):
            assert isinstance(target.func, ast.Name) and target.func.id == 'open'
            assert value(target.args[1]) == 'w'
            filename = path(value(target.args[0]))
        else:
            filename = path(value(target))
        assert len(call.args) == 1 and not call.keywords
        result = value(call.args[0])
        assert isinstance(result, str)
        writes.append((filename, result))

    records = []
    for filename, result in writes:
        state[filename] = result
        digest = hashlib.sha256(result.encode()).hexdigest()
        candidate = BASE / 'objects' / digest
        candidate.write_bytes(result.encode())
        records.append({'historical_path': filename, 'candidate_file': str(candidate),
                        'sha256': digest, 'provenance': {
                            'source': str(HISTORY / source), 'item_id': item['id'],
                            'method': 'restricted AST interpretation of recorded exact string edits; no historical code execution',
                            'base_sha256': bases.get(filename)}})
    return records



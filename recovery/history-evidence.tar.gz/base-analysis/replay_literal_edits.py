"""Recover reviewed string edits by interpreting a tiny non-executable AST subset.

No historical Python or shell command is executed. File reads only use supplied
candidate bytes; writes only produce supplemental content-addressed objects.
"""
import ast
import hashlib
import json
from pathlib import Path, PurePosixPath
import shlex
import re

BASE = Path(__file__).parent
HISTORY = BASE.parent / 'history'
OBJECTS = BASE.parent / 'staging/objects'


def replay(source, item_index, state, first_write_only=False, start_at_path=None):
    data = json.loads((HISTORY / source).read_text())
    item = data['turns'][0]['items'][item_index]
    shell = shlex.split(item['command'])[-1]
    match = re.search(r"python(?:3)? - <<'PY'\n", shell)
    assert match, 'no Python literal heredoc'
    script = shell[match.end():].split('\nPY', 1)[0]
    tree = ast.parse(script)
    names = {}
    writes = []
    bases = {}

    def path(value):
        p = PurePosixPath(value)
        return str(p if p.is_absolute() else PurePosixPath(item['cwd']) / p)

    def value(node):
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            return names[node.id]
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            left, right = value(node.left), value(node.right)
            assert type(left) == type(right) and isinstance(left, (str, bytes))
            return left + right
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id == 'Path':
                assert len(node.args) == 1 and not node.keywords
                return value(node.args[0])
            if isinstance(node.func, ast.Attribute):
                func = node.func.attr
                args = [value(x) for x in node.args]
                assert not node.keywords
                if func in ('read_text', 'read'):
                    target = node.func.value
                    if isinstance(target, ast.Call):
                        assert isinstance(target.func, ast.Name) and target.func.id == 'open'
                        filename = path(value(target.args[0]))
                    else:
                        filename = path(value(target))
                    bases[filename] = hashlib.sha256(state[filename].encode()).hexdigest()
                    return state[filename]
                subject = value(node.func.value)
                assert isinstance(subject, str)
                if func == 'replace':
                    assert len(args) in (2, 3)
                    assert args[0] in subject or args[0] == args[1], 'recorded replacement source missing'
                    return subject.replace(*args)
                if func == 'index':
                    return subject.index(*args)
        if isinstance(node, ast.Subscript):
            subject = value(node.value)
            if isinstance(node.slice, ast.Slice):
                return subject[slice(value(node.slice.lower) if node.slice.lower else None,
                                     value(node.slice.upper) if node.slice.upper else None,
                                     value(node.slice.step) if node.slice.step else None)]
        raise ValueError('unsupported expression: ' + ast.dump(node))

    statements = tree.body
    if start_at_path is not None:
        for position, statement in enumerate(statements):
            if not isinstance(statement, ast.Assign):
                continue
            try:
                if path(value(statement.value)) == start_at_path:
                    statements = statements[position:]
                    break
            except (ValueError, KeyError, TypeError, AssertionError):
                pass
        else:
            raise ValueError('requested literal file scope absent')
    for statement in statements:
        if isinstance(statement, (ast.Import, ast.ImportFrom)):
            continue
        if isinstance(statement, ast.Assign):
            assert len(statement.targets) == 1 and isinstance(statement.targets[0], ast.Name)
            names[statement.targets[0].id] = value(statement.value)
            continue
        if isinstance(statement, ast.AugAssign):
            assert isinstance(statement.target, ast.Name) and isinstance(statement.op, ast.Add)
            left, right = names[statement.target.id], value(statement.value)
            assert isinstance(left, str) and isinstance(right, str)
            names[statement.target.id] = left + right
            continue
        if isinstance(statement, ast.If):
            test = statement.test
            assert isinstance(test, ast.Compare) and len(test.ops) == 1
            assert isinstance(test.ops[0], ast.NotIn)
            assert value(test.left) in value(test.comparators[0]), 'recorded guard failed'
            continue
        assert isinstance(statement, ast.Expr) and isinstance(statement.value, ast.Call)
        call = statement.value
        assert isinstance(call.func, ast.Attribute) and call.func.attr in ('write_text', 'write')
        target = call.func.value
        if isinstance(target, ast.Call):
            assert isinstance(target.func, ast.Name) and target.func.id == 'open'
            assert value(target.args[1]) == 'w'
            filename = path(value(target.args[0]))
        else:
            filename = path(value(target))
        assert len(call.args) == 1 and not call.keywords
        result = value(call.args[0])
        assert isinstance(result, str)
        writes.append((filename, result))
        if first_write_only:
            break

    records = []
    for filename, result in writes:
        state[filename] = result
        digest = hashlib.sha256(result.encode()).hexdigest()
        candidate = BASE / 'objects' / digest
        candidate.write_bytes(result.encode())
        records.append({'historical_path': filename, 'candidate_file': str(candidate),
                        'sha256': digest, 'provenance': {
                            'source': str(HISTORY / source), 'item_id': item['id'],
                            'method': 'restricted AST interpretation of recorded exact string edits; no historical code execution',
                            'statement_scope_path': start_at_path,
                            'base_sha256': bases.get(filename)}})
    return records


if __name__ == '__main__':
    seeds = {
        '/workspace/BerylLattice/axiom/tests/test_frontend.py': 'c14bb66acfe482c0f599fac1d4fbd11703ff7e66e2604c48ad8bd8a2e1ba43f3',
        '/workspace/BerylLattice/axiom/src/axiom/codec.py': 'd15956b46fedfa1ef36525a26586e9be048b5265a05a463fcdbcb2fd53e7ec1a',
        '/workspace/BerylLattice/axiom/tests/test_codec.py': 'eecd2ba58e415016be6a06aad591b300c871c073a9ae67b2ee77ea553be90e7b',
    }
    state = {p: (OBJECTS / digest).read_text() for p, digest in seeds.items()}
    records = json.loads((BASE / 'supplemental-candidates.json').read_text())
    for source, indices in [('agents/impl_frontend-002.json', [18]),
                            ('agents/impl_frontend-001.json', [3]),
                            ('agents/impl_codec-001.json', [4, 6, 9, 11, 17, 19])]:
        for index in indices:
            records.extend(replay(source, index, state))
    (BASE / 'supplemental-candidates.json').write_text(json.dumps(records, indent=2) + '\n')
    for p, text in state.items():
        print(p, hashlib.sha256(text.encode()).hexdigest())

# Initial implementation recovery

This pass recovered recorded source bytes, exact literal string edits, quoted heredoc appends, and complete independent source observations. No historical shell/Python command was executed. `replay_literal_edits.py` interprets a deliberately restricted AST subset against supplied candidate bytes only.

Raw histories were fetched by the root agent. Child-agent `read_thread` calls hung and were terminated without saved results.

`supplemental-candidates.json` contains complete candidates with source/item provenance. It includes intermediate versions as well as final versions; the reconstruction engine and root's independently recorded hashes select final states. It is not a claim that every candidate is the latest revision.

Major recovered paths include frontend/model and their fixtures; codec/checker/selection and their tests; runner, supervisor, and runner tests; CLI and compile/loader/emitter tests; complete evidence replay/publication code and tests; planner conformance corrections; integration corpus/schema; and prototype/Core bridge documentation.

Independent historical Git blob prefixes verified final versions of frontend, runner, supervisor, frontend/runner/compile CLI tests, evidence and its tests, planner and its tests/interpreter/conformance controls, and both documentation files. The root separately recovered the final ten-file publisher SHA256 table. Final selection and codec sources independently match complete later reviewer observations. Integration corpus and schema also match complete independent observations; the schema additionally matches its recorded literal JSON generator.

Important recovery details:

- The original frontend heredoc contains four false-positive `[REDACTED_SECRET]` substitutions. Corresponding original lines were recovered from an independent recorded Git diff. Both the initial Git blob and accepted final SHA256 then matched.
- Some initial runner test/supervisor bytes preceded changes that were not reconstructable from their creation commands alone. Complete later chained `cat`/`sed` observations supplied their accepted baselines; the final review repairs then matched independently recorded Git blob prefixes.
- `test_core_observe.py` has three tests. Its original command exits 1 during intentional RED dependency import. The traceback explicitly imports the newly written test file and reads line 3, proving the file write succeeded before the absent implementation dependency failed. Its historical command exit remains 1 in provenance; the seed is flagged `confirmed_red_test_file_creation`, not represented as a successful test run.
- Prototype documentation seed `2f62687f...` matches accepted evidence review blob `beaf09b`; later root page-006 changes 498 and 501 still need ordered forward replay. Core bridge final seed `0ac36be5...` matches final review blob `411f772`.

All saved candidate bytes were SHA256-checked and all Python candidates were parsed without executing them. The root owns runnable-tree selection and current test execution. Historical counts and approvals are not presented as fresh validation.

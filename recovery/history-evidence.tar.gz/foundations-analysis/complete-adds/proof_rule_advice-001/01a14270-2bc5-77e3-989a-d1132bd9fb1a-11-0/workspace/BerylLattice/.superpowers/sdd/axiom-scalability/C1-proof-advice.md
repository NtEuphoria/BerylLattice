# C1 preparatory proof-rule advice

Status: preparatory advice, not independent approval of an implementation or a formal proof. Read against `task-C1-brief.md` and the shared `design.md` on 2026-10-16. No feasibility implementation was evaluated. Keep the gate `blocked` until the controller reviews the actual complete artifact identity.

## Assessment

The three schedules appear expressible by finite structural induction, affine bounds, exact source-expression substitution, rectangle operations, and two parity cases. This is a feasibility judgment conditional on the rules below being made explicit and checked. The difficult parts are state/effect conservation and the scope of induction hypotheses, not the numerical parity table. Bounds and values must be proved for arbitrary admissible loop indices and arbitrary admitted input values, not inferred from successful executions at selected dimensions.

The first unresolved obligation in the written brief is an operationally precise loop rule with an exact, non-forgettable output ledger and scratch invalidation. Without that rule, a prefix reset or stale row fact can pass otherwise correct local arithmetic tests. Quota fit also remains unmeasured.

## Minimal judgment and state rules

Use a judgment of the form `Gamma; State |- block => State'`, where `Gamma` contains typed lexical binders, affine constraints and scoped induction hypotheses. Keep these distinct state components:

- Scalar bindings: in-scope SSA identifier to an exact term DAG node, with a checked i32 value bound.
- Scratch facts: universally quantified initialized/value facts `forall x in R: S[f(x)] = t(x)`. Each fact includes its physical footprint, logical coordinates, layout and source expression; initialization cannot be inferred from native zeroing.
- Output ledger: an exact disjoint union of physical output cells already written, each with the established source value. This is state owned by the derivation, not an ordinary weakening-permitted proposition.
- Immutable input and fixed capacity/layout facts, established structurally rather than asserted by a certificate.

Suggested finite rules:

1. **Input read / constants / scalar operations.** Derive the literal source-coordinate load term or exact operation node. Require access bounds and checked-i32 safety for every executed operation, including dead work. Do not use final output equality as an overflow proof for intermediate or dead operations.
2. **Scratch read.** Instantiate an existing initialized/value fact at a checked member of its rectangle and physical map. Equality of logical producer coordinates alone does not establish physical membership.
3. **Scratch store.** Check bounds and the stored scalar term; invalidate every fact whose physical footprint might intersect the store, then establish the singleton fact. A disjointness proof may preserve a frame. Splitting before invalidation may retain a provably unaffected portion; conservatively discarding an entire scratch fact is sound. Never preserve an overlapping stale value merely because another fact describes the new value.
4. **Region split/join/extension.** Check exact half-open endpoints, coverage equality, compatible maps/value substitutions and required disjointness. Join adjacent pieces only when their union is exactly the claimed region. An initialized prefix plus its next singleton establishes the extended prefix. Empty rectangles require explicit well-formed semantics and do not license reads.
5. **Output store.** Check bounds, exact source value, and nonmembership in the current output ledger, then add exactly the stored singleton. No weakening rule applies to this ledger. Split/join changes its representation while preserving its exact union and multiplicity. Identical-value duplicate writes remain prohibited.
6. **Sequence.** Feed each resulting state to the next operation. Reusable pure lemmas are allowed in a DAG; state transitions cannot duplicate or discard the owned output history. Process every plan operation exactly once structurally, including operations not mentioned in a certificate.
7. **For induction.** For `for k in [L,U)`, establish `I(L)` from the actual incoming state; with fresh arbitrary `k`, assume `L <= k < U` and `I(k)`, check the actual body, and derive `I(k+1)`; conclude `I(U)`. The invariant must describe the complete output ledger, including incoming framed writes, and any needed scratch facts. Base and step must check ledger equality, not merely containment. Lexical scalar scope is enforced; inner SSA cannot appear in the outer postcondition. An empty loop derives its result from the incoming state, without pretending an unreachable body executed.

An induction hypothesis is a scoped parameter in the step subderivation, discharged by the loop rule. It must not be an unrestricted proof node that claims its own conclusion. An acyclic proof DAG can represent this binder without cyclic node references. Reject forward references, escaped hypotheses and substitution capture. Capture-avoiding substitution must also distinguish source indices, plan binders and quantified region variables despite alpha-renaming.

## Exact source expressions and bounds

For exposition, let `T(a,b)` mean the retained producer AST instantiated at `(a,b)`, and `E(r,c)` mean the retained output AST instantiated at `(r,c)` with producer applications expanded. These are abbreviations for reconstructed terms, not certificate axioms. For the admitted family:

`T(a,b) = Mul(Add(Input(a,b), Const(1)), Add(Input(a,b), Const(1)))`

`E(r,c) = Add(Add(Add(T(r,c), T(r,c+1)), T(r+1,c)), T(r+1,c+1))`.

Preserve operand order, association and each checked-i32 operation. Independent loads/definitions may be reordered, identifiers renamed and identical operand nodes shared, but algebraic reassociation of scalar expressions is not a permitted equality rule. Sharing the two `Add` term references does not remove the obligation to validate both executed definitions when the physical plan computes both.

Index algebra may be normalized independently. After shape specialization, prove inequalities over arbitrary binders using checked affine coefficient arithmetic and interval premises. A useful narrow implementation is endpoint elimination: bound an affine expression over an innermost interval by the appropriate endpoint according to the coefficient sign, substitute that endpoint and continue outward. Symbolic proof rectangles such as `[0,c)` introduce dependent endpoint premises even though physical loop bounds are constants; specify their permitted binding order. An alternative certificate can provide a finite nonnegative linear combination of established affine inequalities with an exact checked residual. If adopted, document that derivation explicitly as the meaning of the affine-bound rule; do not accept an unexplained solver result.

Neither option needs arbitrary polyhedral completeness. Reject unsupported affine goals as unknown. Ensure row-major injectivity is a derived property of the layout and coordinate bounds: `pitch*a+b = pitch*a'+b'` with `0 <= b,b' < pitch` implies both coordinates equal. Modulo-two maps are not globally injective in the logical row index.

Source bounds establish `T` in `[1,1048576]` and the three successive output additions within `[2,2097152]`, `[3,3145728]`, `[4,4194304]`. General plan operations need their own intervals. Mathematical address validity does not imply that a particular native evaluation of the address avoids overflow; retain native lowering as a separate gate.

## Hand-derived certificate outlines

### Inline

There are no scratch facts or scratch accesses. At outer entry `r`, the exact output ledger is `[0,r) x [0,W)`. At inner entry `c`, it is that rectangle disjointly joined with `[r,r+1) x [0,c)`. Derive each of four producer terms from actual input reads, prove their coordinates lie in `[0,H+1) x [0,W+1)`, construct the source-associated sum, and extend the inner prefix by `(r,c)`. Inner exit joins the full row; outer exit yields `[0,H) x [0,W)`. This also proves exactly-once writes. No inference may use an `inline` schedule tag.

### Materialize

Use pitch `W+1` and capacity `P=(H+1)*(W+1)`. Producer outer induction has initialized/value region `[0,a) x [0,W+1)`; its inner induction adds `[a,a+1) x [0,b)`. The store of `T(a,b)` extends that prefix, preserving all previous cells by row-major injectivity. The producer exit supplies the complete source-valued producer rectangle. The consumer uses the same output-prefix proof as inline; four scratch loads instantiate the producer fact. Consumer output stores cannot alter scratch. The certificate must connect producer exit to consumer entry through actual sequence state.

### Rows2

Use pitch `W+1`, capacity `2*(W+1)` and physical row `a mod 2`. For H>=1, capacity is at most P. Prove `0 <= b <= W` gives a valid address in each parity slot. Stage row zero with a column-prefix induction before the outer loop; no assumption about initial scratch contents is available.

At outer entry `r`, retain:

- `forall b in [0,W+1): S[(r mod 2)*(W+1)+b] = T(r,b)`;
- exact output ledger `[0,r) x [0,W)`;
- the immutable input facts.

Any other scratch facts may be forgotten here. During staging of logical row `r+1`, the inner invariant is the complete current-row fact plus `forall b in [0,j): S[((r+1) mod 2)*(W+1)+b] = T(r+1,b)`. For arbitrary `0 <= j < W+1`, derive source input bounds, establish the next singleton and join the prefix. Preserve the current row by disjoint physical row slots, and preserve the next-row prefix by column injectivity. If old facts about the target slot were retained, invalidate them on overwrite; do not infer new logical row values from old initialization alone.

Use exhaustive cases `r=2q+p`, `p in {0,1}` with the Euclidean quotient/remainder decomposition justified. In each case derive `r mod 2 = p` and `(r+1) mod 2 = 1-p`. Both mod arguments are nonnegative. The disjointness result holds for arbitrary q and arbitrary valid columns; evaluating rows 0 and 1 alone does not establish it. Cases must cover every permitted r; unreachable cases can be discharged by checked contradictions, never omitted on the generator's assertion.

At staging exit both complete rows are available. Consumer prefix induction uses exact ledger `[0,r) x [0,W)` disjointly joined with `[r,r+1) x [0,c)`, preserves both scratch rows, checks four fact instantiations at c/c+1, and constructs `E(r,c)`. At consumer exit, join output rows into `[0,r+1) x [0,W)`. Forget the old current-row fact; retain the newly staged row. Capture-avoiding substitution shows that this is precisely the current-row fact required by `I(r+1)`. Exit at r=H supplies the complete output ledger. The retained row-H scratch fact is harmless.

H=1 uses stage-zero plus one refill/consume iteration; W=1 still stages two producer columns and consumes one output column. These are direct instances of the same proofs, not special schedule branches. Rectangles/prefixes at zero and their first singleton require explicit controls.

## Feasibility controls and measurements

The research probe should represent and validate the obligations above, not contain a success bit for each named schedule. Hand-authored alpha-renamed examples and reordered independent definitions should produce the same rule conclusions. A column-major inline/materialize consumer is a useful alternate legal traversal: transpose the rectangle-prefix decomposition, leaving the rules unchanged. A positive-unit-step loop can also represent a reverse traversal through affine coordinates; admitting it requires checking its corresponding suffix invariant, not changing the rule based on a schedule name. Unsupported traversals can remain unknown.

At minimum, mutate a valid obligation graph to exercise these rejections:

- Reset/drop an output prefix, duplicate a same-value output store, hide an output write inside a staging loop, or omit a plan operation from the derivation.
- Read scratch before initialization; carry a stale target-slot value through refill; alias current and next slots; omit either parity case; use an unproved parity assertion.
- Assume a loop invariant without its base; let the step conclude I(k) instead of I(k+1); misuse an inner hypothesis after its scope; supply source/plan binders with colliding names.
- Skip the W-th producer column; read c+1 with only a prefix through c; introduce a rectangle gap or overlap; join facts with differing value expressions.
- Reassociate the output sum, substitute the wrong source coordinate, or add an overflowing dead scalar operation.

The same obligation graph shape for dimensions 32,128,512,2048 establishes non-enumeration only for those constructions. Pair that control with inspection showing all loops traverse bounded IR/proof/region/DAG structures rather than H, W or their product. Shape-dependent integer bit work may grow while structural graph size remains fixed. Avoid claiming flat work or time from equal node counts.

Measure encoded proof size, proof nodes, active facts, region pieces, parity cases, term nodes/depth and charged work separately for all three outlines. Report actual counts and the accounting definition. Inspect term substitution, hashing and comparison for expansion of shared trees; source-term DAG sharing alone is insufficient. Add zero/single/multiple trip structural controls, width/limit boundary controls and optimized-Python runs, with no correctness checks relying on `assert` statements that disappear under `-O`.

Exact operation metrics follow syntactic sums and multiplication by constant loop trip counts, including dead operations. This can be bounded without solving liveness. Do not fold the optional peak-transient-SSA property into the theorem until its distinct compositional rules are reviewed; it can remain deferred and unavailable.

## Alternatives and remaining decision

A restricted validator is a plausible first choice because the three outlines only need rectangle prefixes, simple affine bounds and finite parity partitions. A solver-certificate route would help establish more affine implications only if its complete proof objects are independently checked; a solver success flag would add a new trust assumption. A general polyhedral engine adds representation and proof complexity and does not itself solve scalar association, initialization, overwrite or output conservation.

Before recording `proceed`, the implementation/review must resolve: the exact stateful induction/ledger rule; scratch invalidation and scoped hypotheses; a documented bounded affine-bound derivation; source-derived DAG equality and all-operation arithmetic safety; a complete obligation inventory with negative controls; measured fit under unchanged quotas; and review bound to the finished artifact identity. This advice does not discharge those obligations and must not be used as the required independent review.

# C1 fix round 1 independent scoped review

Reviewer: `/root/review_c1_proof_feasibility`, original independent F1 reviewer.
Date: 2026-10-16 (UTC).
Reviewed commit: `00dd07949d6fa32437c53460cf6a340d8f85567e`.
Comparison base: `0e3c6b7d6a451cb74d6caa8666b817d3d56544d3`.

**Current gate: blocked. F1 remains open.** This review accepts the revision as
an accurate record of partial research progress and the remaining blocker. It
does not approve certificate quota fit or authorize C4–C11.

## Separate decisions

**Specification: PASS for this explicitly blocked follow-up.** The revision
preserves the four-file research scope and source-profile prefix, corrects the
scratch-peak convention, records F1 as the actual remaining obligation, and
retains unchanged quotas and independent gate authority. It does not claim to
complete the original positive feasibility requirement.

**Quality: PASS for accurate blocked reporting and arithmetic-accounting
experiments; positive feasibility remains unapproved.** The new appendix gives a
useful candidate inventory and identifies its unproved assumptions. The tests
are correctly described as accounting controls rather than proof validation.
No new correctness blocker was identified in this scoped change. My previous
assessment of the unchanged conditional rule/ledger argument remains unchanged.

## Exact reviewed identities

| Artifact | SHA-256 |
|---|---|
| `axiom/docs/loop-plan-v2.md` | `9bf2a154db56dcb82aed11cd867cfb482a18c7cabd5775b6b92f7f905e2989d3` |
| `axiom/research/loop_proof_feasibility.py` | `89d689c9e387aac115916febb35f8f386e2c7c2f870b1e0bddd562bdd4341247` |
| `axiom/research/tests/test_loop_proof_feasibility.py` | `dd20454681ea47973a727381f761bf02af1f496474699cb858c7342f4a1e373f` |

The three hashes were independently calculated and match the report and tracked
record. All four reviewed working-tree files have no differences from the exact
reviewed commit, although unrelated later commits have advanced HEAD. The
retained scoped diff exactly matches the requested base-to-revision diff. A
byte-prefix comparison confirms that the C2 text from
`958de943aeba6f8fd00dd983924499c6ca32a85c` remains intact.

I read the final fix report, scoped diff, changed files and retained RED/GREEN/
optimized logs. No product files were edited, tests repeated, commits created,
or subagents used. This review report is the only file I wrote.

## Findings and verified improvements

**F1 — remains open, gate blocker.** The 32/64/128 proof-row reservations and
associated payload, scope, state, substitution and algorithm allocations have
not been instantiated or proved sufficient. They are therefore assumptions of
a candidate accounting model, not established bounds on complete certificates.
The appendix, returned `expansion_completeness_established=False`, tracked
record and implementation report all disclose this accurately.

Independent arithmetic confirms the stated aggregate of 4,501 typed rows and
440,352 bytes, including the 4,096-byte header allowance. The table formulas are
consistent with the listed 20/13/31 primitive proof instances and 2/4/6 induction
instances. Rows2 correctly includes stage zero once and both refill/consume
parity subderivations, without counting duplicate physical code. These checks
establish the arithmetic of the proposal only. In particular, I have not
approved its per-row byte capacities or expansion completeness as a proof of
encoded-size fit.

Independent summation confirms 8,814,588 proposed work units. Even if every
reservation and algorithm allowance were justified, that upper estimate would
not certify compliance with 1,000,000. Conversely, an upper estimate exceeding a
limit is not a lower bound and does not prove that any complete implementation
or these schedules must exceed the limit. The revision explicitly preserves
both distinctions. Its 6,832,336-unit term category is a reasonable target for
a tighter derivation, since it charges multiplication interval work to every
reserved term, but no assumed reduction is accepted here.

**Scratch-peak clarification: resolved.** Materialize's previous complete rows,
current row prefix and newly stored singleton coexist before the join. The
receipt now reports three scratch facts, matching the sequential rule argument.
Rows2 likewise has three. The appendix distinguishes these active facts from
persistent proof-table region rows and conservatively budgets scratch and
ledger pieces separately. These remain hand-derived bounds, not instrumented
production peaks.

**Accounting controls: adequate for their stated limited purpose.** The added
test checks the enumerated primitive/loop counts, rows2 proof-row arithmetic,
corrected scratch peak, numerical failure of the work limit, and rejection of
each requested table/work omission and incorrect supplied totals. Explicit
runtime checks remain effective under `python -O`. The controls do not establish
that the original category list or row allocations are semantically complete.
In particular, the mandatory-work set and omission test cases are derived from
the implementation's category dictionary; deleting a category from that original
dictionary would not be detected by those omission controls alone. The current
documentation limits its claim to omissions from the proposed accounting, so
this is not an additional blocker for the deliberately incomplete submission.
The next complete audit should independently anchor its obligation/category
inventory and reconcile each item with actual graph rows and work.

The retained RED log records the missing accounting function and old unresolved
message. GREEN and optimized logs each show 11 completed passing tests without
skips. All three log hashes match the final implementation report. I inspected
these logs rather than rerunning the passing suite, and separately recalculated
the three published aggregate totals with simple arithmetic.

## Actionable remaining C1 task

Construct the complete scoped hand graphs, or supply a complete constructive
expansion proof, for all three schedules. Assign each physical operation and
base/step/exit premise a concrete row and typed reference; include source/value
terms, state and ledger equality, scratch invalidation, capture-free
substitutions, scope discharge and both parity cases. Reconcile the result with
an independently enumerated obligation inventory. Establish actual encoding
lengths or rigorous per-field and row-count bounds.

Then derive reachable term/affine/substitution instances and audit a specified
comparison/interning algorithm, charging all of its work, including source,
identity, state, coverage and bookkeeping costs. Separate operation-specific
costs where justified instead of applying worst multiplication costs everywhere;
retain charges for every physical operation even when semantic terms are shared.
Demonstrate the full bound across the admitted dimensions under every unchanged
quota. If it still does not establish fit, retain blocked with the precise
remaining obligation. This is bounded C1 research work and does not require a
production C3–C5 implementation, quota widening or a template acceptance shortcut.

The always-blocked provisional probe and identity-bound reviewed tracked gate
remain an acceptable separation under the controller ruling. No passing
accounting test or conditional byte estimate can activate proceed. This scoped
review approves the accuracy of the blocked record, not feasibility approval.

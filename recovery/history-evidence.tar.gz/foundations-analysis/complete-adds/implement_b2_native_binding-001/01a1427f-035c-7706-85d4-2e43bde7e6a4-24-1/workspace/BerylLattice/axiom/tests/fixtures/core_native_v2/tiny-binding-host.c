/* B2 seam probe only: explicit C lifetime, no B3 allocator or general worker.
 * All stencil computations below are in unchanged real emit-c output. */
#include "generated.c"
#include "binding.h"
#include <errno.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int32_t *input_owner;
    int32_t *output_owner;
    be_t_List_3ci32_3e input;
    be_t_List_3ci32_3e output;
    const char *events[10];
    size_t event_count;
    int32_t first_bad;
} tiny_invocation;

static void event(tiny_invocation *inv, const char *name) {
    if (inv->event_count >= 10) abort();
    inv->events[inv->event_count++] = name;
}

static int descriptors(const tiny_invocation *inv, const be_t_List_3ci32_3e *scratch,
                       int32_t *scratch_owner, int32_t scratch_cells) {
    return inv->input.data == inv->input_owner && inv->input.len == 6 && inv->input.cap == 6
        && inv->output.data == inv->output_owner && inv->output.len == 2 && inv->output.cap == 2
        && scratch->data == scratch_owner && scratch->len == scratch_cells
        && scratch->cap == scratch_cells;
}

/* Sole helper invocation site. There are no externally supplied pointers or
 * callbacks. main retains sole input/output ownership until acquisition. */
static int checked_invoke(tiny_invocation *inv) {
    int result = 0;
    int32_t *scratch_owner = NULL;
    be_t_List_3ci32_3e scratch = {NULL, 0, 0};
    if (!inv->input_owner || !inv->output_owner ||
        !descriptors(inv, &scratch, NULL, 0)) return 70;
    event(inv, "preflight");
    inv->first_bad = be_i_axiom_5fbuffer_5ffixture_2eax_5fpreflight(&inv->input);
    if (inv->first_bad < -1 || inv->first_bad >= 6) return 71;
    if (inv->first_bad != -1) {
        event(inv, "descriptors");
        return descriptors(inv, &scratch, NULL, 0) ? 0 : 72;
    }
    scratch_owner = malloc(6 * sizeof *scratch_owner);
    if (!scratch_owner) return 73;
    event(inv, "scratch_allocate");
    for (size_t i = 0; i < 6; ++i) scratch_owner[i] = 0;
    event(inv, "scratch_zero");
    scratch = (be_t_List_3ci32_3e){scratch_owner, 6, 6};
    event(inv, "body");
    be_i_axiom_5fbuffer_5ffixture_2eax_5fbody(&inv->input, &inv->output, &scratch);
    event(inv, "descriptors");
    if (!descriptors(inv, &scratch, scratch_owner, 6)) result = 72;
    /* Cleanup always uses the retained allocation, never the borrowed pointer. */
    free(scratch_owner);
    event(inv, "scratch_free");
    return result;
}

static int read_values(int32_t values[8]) {
    char buffer[256];
    if (!fgets(buffer, sizeof buffer, stdin)) return 0;
    char *cursor = buffer;
    for (size_t i = 0; i < 8; ++i) {
        char *end;
        errno = 0;
        intmax_t value = strtoimax(cursor, &end, 10);
        if (errno || end == cursor || value < INT32_MIN || value > INT32_MAX) return 0;
        values[i] = (int32_t)value;
        cursor = end;
    }
    while (*cursor == ' ' || *cursor == '\t' || *cursor == '\r' || *cursor == '\n') ++cursor;
    return *cursor == '\0' && fgetc(stdin) == EOF;
}

int main(int argc, char **argv) {
    if (argc != 2 || strcmp(argv[1], "invoke") != 0) return 64;
    int32_t values[8];
    if (!read_values(values)) return 65;
    tiny_invocation inv = {0};
    inv.input_owner = malloc(6 * sizeof *inv.input_owner);
    inv.output_owner = malloc(2 * sizeof *inv.output_owner);
    if (!inv.input_owner || !inv.output_owner) {
        free(inv.input_owner);
        free(inv.output_owner);
        return 66;
    }
    memcpy(inv.input_owner, values, 6 * sizeof *values);
    memcpy(inv.output_owner, values + 6, 2 * sizeof *values);
    inv.input = (be_t_List_3ci32_3e){inv.input_owner, 6, 6};
    inv.output = (be_t_List_3ci32_3e){inv.output_owner, 2, 2};
    int result = checked_invoke(&inv);
    if (result) {
        free(inv.input_owner);
        free(inv.output_owner);
        return result;
    }
    /* Complete acquisition after checked_invoke, before independent Python
     * comparison. No hashing or second input preflight inside checked_invoke. */
    int32_t acquired_input[6], acquired_output[2];
    memcpy(acquired_input, inv.input_owner, sizeof acquired_input);
    memcpy(acquired_output, inv.output_owner, sizeof acquired_output);
    event(&inv, "acquire");
    free(inv.input_owner);
    free(inv.output_owner);
    inv.input_owner = NULL;
    inv.output_owner = NULL;
    event(&inv, "input_output_free");
    printf("{\"status\":\"%s\",\"first_bad_index\":", inv.first_bad == -1
           ? "success" : "input_precondition_failed");
    if (inv.first_bad == -1) printf("null");
    else printf("%" PRId32, inv.first_bad);
    printf(",\"input\":[");
    for (size_t i = 0; i < 6; ++i) printf("%s%" PRId32, i ? "," : "", acquired_input[i]);
    printf("],\"output\":[");
    for (size_t i = 0; i < 2; ++i) printf("%s%" PRId32, i ? "," : "", acquired_output[i]);
    printf("],\"events\":[");
    for (size_t i = 0; i < inv.event_count; ++i) printf("%s\"%s\"", i ? "," : "", inv.events[i]);
    printf("]}\n");
    return 0;
}

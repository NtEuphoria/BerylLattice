"""Real emit-c/private ABI seam probe; no test-only callback adapter executes Core."""
from dataclasses import replace
import importlib
import importlib.util
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import unittest

from axiom.core_toolchain import load_toolchain


FIXTURES = Path(__file__).parent / 'fixtures/core_native_v2'
RECEIPT = Path('/workspace/scratch/cloud-onboarding-native-20261016/'
               'qualification-57lxdp8j/receipts/toolchain.json')
TYPE = 'be_t_List_3ci32_3e'
PREFLIGHT = 'be_i_axiom_5fbuffer_5ffixture_2eax_5fpreflight'
BODY = 'be_i_axiom_5fbuffer_5ffixture_2eax_5fbody'


def capture(argv, cwd, stem, *, input_bytes=None):
    """Retain exact bytes and argv even on failed/timeout processes."""
    try:
        result = subprocess.run([str(a) for a in argv], cwd=cwd, input=input_bytes,
                                capture_output=True, timeout=60)
        out, err, code, timeout = result.stdout, result.stderr, result.returncode, False
    except subprocess.TimeoutExpired as exc:
        out, err, code, timeout = exc.stdout or b'', exc.stderr or b'', None, True
    stem.with_suffix('.stdout').write_bytes(out)
    stem.with_suffix('.stderr').write_bytes(err)
    stem.with_suffix('.json').write_text(json.dumps({
        'argv': [str(a) for a in argv], 'cwd': str(cwd), 'returncode': code,
        'timed_out': timeout,
        'stdin_sha256': None if input_bytes is None else hashlib.sha256(input_bytes).hexdigest(),
    }, indent=2) + '\n')
    return code, out, err


class NativeBindingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        module_name = 'axiom.core_native_v2'
        cls.module = importlib.import_module(module_name) if importlib.util.find_spec(module_name) else None
        if cls.module is None:
            return  # Each test reports the intended missing binding assertion (RED).
        if not (os.environ.get('AXIOM_TEST_CORE') and os.environ.get('AXIOM_TEST_CLANG')):
            if os.environ.get('AXIOM_V2_REQUIRE_NATIVE') == '1':
                raise AssertionError('required native qualification needs explicit Core/Clang selectors')
            raise unittest.SkipTest('explicit qualified Core/Clang selectors not provided')
        cls.toolchain = load_toolchain(Path(os.environ.get('AXIOM_V2_TOOLCHAIN_RECEIPT', RECEIPT)))
        if Path(os.environ['AXIOM_TEST_CORE']).resolve() != cls.toolchain.source_repository:
            raise AssertionError('Core source selector differs from qualified original')
        if Path(os.environ['AXIOM_TEST_CLANG']).resolve() != cls.toolchain.clang:
            raise AssertionError('Clang selector differs from qualification')
        evidence_parent = Path(os.environ.get('AXIOM_V2_BINDING_EVIDENCE', '/tmp'))
        evidence_parent.mkdir(parents=True, exist_ok=True)
        cls.evidence = Path(tempfile.mkdtemp(prefix='axiom-B2-binding-', dir=evidence_parent))
        cls.semantic = cls.evidence / 'semantic'
        cls.qualification = cls.evidence / 'qualification'
        cls.semantic.mkdir()
        cls.qualification.mkdir()
        print('\nB2 evidence: ' + str(cls.evidence), flush=True)
        cls.source = FIXTURES / 'tiny-1x2.be'
        cls.source = cls.source.resolve()
        for name in ('tiny-1x2.be', 'tiny-1x2-cases.json'):
            shutil.copyfile(FIXTURES / name, cls.semantic / name)
        code, out, err = capture([cls.toolchain.compiler, 'emit-c', cls.source],
                                 cls.qualification, cls.qualification / 'emit-c')
        if code != 0:
            raise AssertionError('actual emit-c failed: ' + err.decode(errors='replace'))
        cls.generated = cls.qualification / 'generated.c'
        cls.generated.write_bytes(out)  # stdout bytes unchanged, including final newline.
        cls.manifest = cls.module._bind_fixture(cls.toolchain, (cls.source,), cls.generated)
        (cls.qualification / 'binding-manifest.json').write_text(cls.manifest.to_json())
        shutil.copyfile(RECEIPT, cls.qualification / 'original-toolchain-receipt.json')
        for name in ('beryl_rt.h', 'beryl_rt.c'):
            shutil.copyfile(cls.toolchain.snapshot / 'runtime' / name, cls.qualification / name)
        cls.assertions = cls.module._binding_assertions(cls.manifest)
        cls.host = (FIXTURES / 'tiny-binding-host.c').read_text()
        cls.good = cls.compile('qualified')
        if cls.good[0] != 0:
            raise AssertionError('private binding compile failed: ' + cls.good[2].decode(errors='replace'))

    @classmethod
    def compile(cls, name, *, generated=None, assertions=None, extra=''):
        directory = cls.qualification / name
        directory.mkdir()
        (directory / 'generated.c').write_bytes(cls.generated.read_bytes() if generated is None else generated)
        (directory / 'binding.h').write_text(cls.assertions if assertions is None else assertions)
        (directory / 'host.c').write_text(cls.host + extra)
        argv = [cls.toolchain.clang, '-std=c11', '-O0', '-fvisibility=hidden',
                '-Werror=incompatible-pointer-types', '-Werror=implicit-function-declaration',
                '-Werror=int-conversion', '-I', cls.qualification,
                directory / 'host.c', '-o', directory / 'worker']
        code, out, err = capture(argv, directory, directory / 'compile')
        return code, out, err, directory

    def setUp(self):
        self.assertIsNotNone(self.module, 'missing pinned private Core binding implementation')

    def test_emit_stdout_is_unchanged_and_manifest_revalidates(self):
        self.assertEqual(self.generated.read_bytes(), (self.qualification / 'emit-c.stdout').read_bytes())
        self.module._validate_binding(self.manifest, self.toolchain, (self.source,), self.generated)
        self.assertEqual(self.manifest.descriptor_typedef, TYPE)
        self.assertEqual(self.manifest.source_order, (str(self.source),))

    def test_all_complete_native_states_match_independent_hand_expectations(self):
        cases = json.loads((FIXTURES / 'tiny-1x2-cases.json').read_text())
        for case in cases:
            with self.subTest(case=case['name']):
                data = (' '.join(map(str, case['input'] + case['initial_output'])) + '\n').encode()
                code, out, err = capture([self.good[3] / 'worker', 'invoke'], self.qualification,
                                         self.semantic / ('run-' + case['name']), input_bytes=data)
                self.assertEqual(code, 0, err.decode(errors='replace'))
                state = json.loads(out)
                self.assertEqual(state['input'], case['input'])
                self.assertEqual(state['output'], case['final_output'])
                self.assertEqual(state['first_bad_index'], case['first_bad_index'])
                self.assertEqual(state['status'], case['status'])
                expected_events = ['preflight']
                if case['status'] == 'success':
                    expected_events += ['scratch_allocate', 'scratch_zero', 'body', 'descriptors', 'scratch_free']
                else:
                    expected_events += ['descriptors']
                self.assertEqual(state['events'], expected_events + ['acquire', 'input_output_free'])

    def test_worker_protocol_cannot_select_generated_helpers(self):
        for i, operation in enumerate(('ax_body', 'ax_preflight', BODY, PREFLIGHT, 'invoke extra')):
            code, out, _ = capture([self.good[3] / 'worker', operation], self.qualification,
                                   self.qualification / ('protocol-' + str(i)))
            self.assertEqual(code, 64)
            self.assertEqual(out, b'')

    def test_executable_helpers_have_hidden_visibility_and_no_dynamic_exports(self):
        worker = self.good[3] / 'worker'
        for kind, argv in [('symbols', ['/usr/bin/readelf', '-Ws', worker]),
                           ('dynamic', ['/usr/bin/nm', '-D', '--defined-only', worker])]:
            code, out, err = capture(argv, self.qualification, self.qualification / kind)
            self.assertEqual(code, 0, err.decode(errors='replace'))
            if kind == 'dynamic':
                self.assertNotIn(BODY.encode(), out)
                self.assertNotIn(PREFLIGHT.encode(), out)
            else:
                for symbol in (BODY, PREFLIGHT):
                    lines = [line for line in out.decode().splitlines() if line.endswith(' ' + symbol)]
                    self.assertEqual(len(lines), 1)
                    self.assertRegex(lines[0], r'LOCAL\s+DEFAULT|GLOBAL\s+HIDDEN')

    def reject_compile(self, name, **kwargs):
        code, _, err, directory = self.compile(name, **kwargs)
        self.assertNotEqual(code, 0, 'binding mutant unexpectedly compiled')
        self.assertFalse((directory / 'worker').exists())
        return err.decode(errors='replace')

    def test_wrong_symbol_fails_before_execution(self):
        err = self.reject_compile('wrong-symbol', assertions=self.assertions.replace(PREFLIGHT, PREFLIGHT + '_wrong'))
        self.assertIn('undeclared', err)

    def test_wrong_const_fails_before_execution(self):
        generated = self.generated.read_bytes().replace(
            ('const ' + TYPE + ' *restrict').encode(), (TYPE + ' *restrict').encode())
        err = self.reject_compile('wrong-const', generated=generated)
        self.assertIn('preflight signature', err)
        self.assertIn('body signature', err)

    def test_wrong_return_signature_fails_before_execution(self):
        generated = self.generated.read_bytes().replace(('void ' + BODY).encode(), ('int32_t ' + BODY).encode())
        err = self.reject_compile('wrong-signature', generated=generated)
        self.assertIn('body signature', err)

    def test_changed_typedef_layout_fails_before_execution(self):
        generated = self.generated.read_bytes().replace(b'int32_t len; int32_t cap;', b'int64_t len; int32_t cap;')
        err = self.reject_compile('wrong-layout', generated=generated)
        self.assertIn('len type', err)
        self.assertIn('descriptor size', err)

    def test_separately_declared_descriptor_is_incompatible(self):
        extra = ('\ntypedef struct { int32_t *data; int32_t len; int32_t cap; } lookalike;\n'
                 'int32_t incompatible(lookalike *p) { return ' + PREFLIGHT + '(p); }\n')
        self.assertIn('incompatible pointer', self.reject_compile('lookalike', extra=extra))

    def test_modified_generated_c_is_rejected_by_manifest(self):
        altered = self.qualification / 'altered-generated.c'
        altered.write_bytes(self.generated.read_bytes() + b'\n/* changed */\n')
        with self.assertRaisesRegex(self.module.NativeBindingUnavailable, 'binding identity'):
            self.module._validate_binding(self.manifest, self.toolchain, (self.source,), altered)

    def test_wrong_core_pin_is_rejected_before_binding(self):
        with self.assertRaisesRegex(self.module.NativeBindingUnavailable, 'Core pin'):
            self.module._bind_fixture(replace(self.toolchain, source_pin='0' * 40), (self.source,), self.generated)
        with self.assertRaisesRegex(self.module.NativeBindingUnavailable, 'binding identity'):
            self.module._validate_binding(replace(self.manifest, core_pin='0' * 40),
                                          self.toolchain, (self.source,), self.generated)


if __name__ == '__main__':
    unittest.main()

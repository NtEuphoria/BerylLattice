# Axiom scalability implementation record

This work implements the [reviewed scalability plan](superpowers/plans/2026-10-16-axiom-scalability/README.md).
Axiom remains the confidential 5GL research project; Core remains the separate
4GL language. This record distinguishes implemented boundaries from later
proof, execution, measurement and publication gates.

## Completed foundations

| Task | Implemented result | Verification and limits |
| --- | --- | --- |
| G0 | Preserved the plan and source inventories; verified recovery through a clean local bundle clone | Portable setup passed; existing toolchain receipt revalidated. Independent cloud-task restoration remains unverified. [Baseline record](reviews/axiom-scalability-baseline.md). |
| G1 | Reconciled shared ownership and dependency order before implementation | Independent preflight covered 46 task/gate entries and 438 shared-interface/file pairs. This is contract review, not proof or native qualification. |
| C2 | Explicit fixed-buffer source admission, retained original AST, separate source/family/specialization and policy identities | Commit `958de943aeba6f8fd00dd983924499c6ca32a85c`; 33 focused/frontend/reference tests and 21 optimized-Python checks passed. Independent specification and quality review passed with no findings. |

The [source-profile guide](../axiom/docs/loop-plan-v2.md) describes the new
`admit_source_v2` API. Its fixed dimensions are in `1..8192`, with at most
`2^23` input cells. Admission does not allocate those buffers or prove that a
physical plan is correct. Existing v1 source limits, identities, commands and
native performance admission remain unchanged.

## Open gates

B1 boundary contracts and hand fixtures are in progress. Real Core buffer
binding (B2), owned native lifetime handling (B3), compact proof feasibility
(C1), the production loop checker and the scalable source oracle are not yet
established. The first integrated target remains a checked 32×32 computation
through Core with complete independent result comparison, then the disclosed
2048×2048 training shape.

Native timing admission, performance results and paper readiness remain later
gates. No scalable native execution, speedup, general language capability or
machine-checked soundness theorem is claimed by the work recorded here.

## Execution rulings

1. Use the existing isolated cloud checkout on `work`; verify recovery in an
   ordinary scratch clone. Local restoration does not establish cloud
   publication or remote persistence.
2. Implement C2 before B1 executable contract tests. The native lane consumes
   the sole source-admission API.
3. Keep B1's observable ordering adapter explicitly test-only. B3 owns the
   production lifecycle; B2 supplies actual compiler/executable evidence.
4. Serialize shared source and document ownership. Every product task gets
   independent specification and quality review; focused tests precede broader
   integration checks.
5. Stage the native inventory dependency through O1's production-safe blob API,
   then B5's build inventory, then O4's complete store verification. Production
   code must not import the research verifier or future timing capability.
6. Assign the required straightforward scalar Core comparator to M5a, with
   B4/B5 boundary review. It is a separate experimental control, not a fourth
   generated portfolio plan.
7. Preserve the actual training, pilot, freeze and final-measurement chronology.
   Implemented admission machinery does not imply collected experiment evidence.

The detailed ledger, briefs, reports, review diffs and test logs live under
`.superpowers/sdd/axiom-scalability/`. Recovery archives retain them at
integration boundaries. The original prototype's completed evidence remains
in its separate [implementation record](implementation-record.md).

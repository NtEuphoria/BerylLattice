# Independent C1 proof/design gate review

Reviewer: controller-appointed independent agent `/root/review_c1_proof_feasibility`.
Decision date: 2026-10-16 (UTC).
Reviewed commit: `0e3c6b7d6a451cb74d6caa8666b817d3d56544d3`.
Owned-path baseline: `958de943aeba6f8fd00dd983924499c6ca32a85c`.

**Gate decision: blocked.** First unresolved obligation: a complete, auditable
representation and cost bound for all three hand certificates under the unchanged
proof-node, certificate-byte and deterministic-work quotas. The current event
trace measurements do not establish that bound. This is an unresolved feasibility
obligation, not a checked semantic counterexample.

## Separate verdicts

**Specification verdict: PASS as a fail-closed C1 research submission; NOT PASS
for the positive feasibility condition.** The four-file scope, preserved C2
section, research-only interface, bounded experiments, documented assumptions,
separate native/metric gates and pending independent approval follow the task.
The task expressly permits a blocked outcome. No authorization to start C4–C11
follows from this review. C2/C3 retain their independent review path.

**Quality/proof-argument verdict: written general rule argument acceptable at its
declared conditional, non-mechanized level; changes required before approval of
quota feasibility.** I found no unsound ledger-forgetting, scratch-frame or
induction inference in the written rules and hand derivations. Passing the
research tests does not implement or mechanically validate those general rules.

## Bound artifact identities

The following SHA-256 values were independently calculated from files with no
differences from the reviewed commit:

| Artifact | SHA-256 |
|---|---|
| `axiom/docs/loop-plan-v2.md` | `a75ecbe11348c3e8d0a8a79a62f553107ba437115a4b595c123df0f8d4168c0c` |
| `axiom/research/loop_proof_feasibility.py` | `f1719eb8bd95daf7c226b9fea1001c48114a9804e3caa9e305e1ab6a904f43a8` |
| `axiom/research/tests/test_loop_proof_feasibility.py` | `536383409330d566799bf20530e16ed777b3000943da64011a3cdf0d97b22868` |

I read the task brief, review instructions, final implementation report, retained
scoped diff, all four task artifacts, and retained test logs. The retained diff
exactly matches `git diff` of the specified identities restricted to the four C1
paths. The document starts with the byte-identical C2 baseline text. The commit
contains exactly the four named C1 paths. Concurrent unrelated work was excluded.
I did not implement or advise C1, change product files, commit, or delegate.

## Finding requiring resolution before proceed

**F1 — High, gate blocker: full certificate quota fit remains unestablished.**

Locations: `axiom/docs/loop-plan-v2.md:395–418`;
`axiom/research/loop_proof_feasibility.py:354–378`;
`docs/reviews/loop-proof-feasibility.md`, “Actual research evidence.”

The measured object contains event-kind strings, obligation labels and shape.
It does not encode proof premises, induction scopes and state linkage, typed
region/value facts, substitutions, physical-operation coverage or their full
references. Consequently, 8,399/9,781/11,845 trace bytes and 513/585/693 events
cannot bound certificate bytes or proof nodes. The work counter also expressly
omits affine assembly, source admission, key hashing and other mandatory work.
The complete proof's cost cannot be inferred from the substantial apparent
headroom in these partial counters. The report is candid about this limitation;
the problem is missing evidence, not falsely advertised production measurement.

The hand bounds need an explicit counting convention too. For example, the
materialize receipt reports two scratch facts, while the written producer step
preserves the completed prior rows and current-row prefix, adds a singleton,
then joins it. Under that sequential representation there are three facts before
the join. An atomic extension rule or a count restricted to invariant entry
states could produce two, but neither is a measured general peak. This is an
illustration of the missing representation/counting argument, not a semantic
failure or an assertion that the generous fact quota is exceeded.

Resolution need not implement C3–C5. Supply an explicit bounded research proof
representation or a fully specified encoding-size derivation for every premise
in each hand certificate. Account for operation coverage, nested base/step/exit
linkage, scoped assumptions, substitutions, region/value payloads, DAG references
and parity case replication. Give actual counts or justified conservative bounds
for every applicable quota, including complete charged work and intermediate
widths, over the admitted dimension envelope. Clearly distinguish measured
counts from analytical bounds. Then obtain another artifact-bound review. Merely
relabeling the event trace as a certificate would not resolve the finding.

## General proof assessment

The judgment separates scalar values, conservatively forgettable scratch facts,
and the complete owned output ledger. Stores invalidate possibly overlapping
scratch facts and retain only established disjoint frames. Exact physical
membership and source-value substitution are required for reads. Split/join
checks maps, endpoints and values. Output stores require a fresh singleton and
the exact source expression; all ledger transformations conserve union and
multiplicity. Sequence covers every actual operation, including dead operations,
and does not permit state transitions to fork owned history.

The loop rule checks the actual incoming ledger against the invariant base and
the complete body result against the successor. Its fresh arbitrary index and
locally discharged hypothesis support ordinary finite induction. Binder
identities, separate namespaces and the prohibition on escaped inner hypotheses
address capture. Empty-loop handling does not fabricate initialized reads.
These are adequate written premises for the conditional soundness argument;
their implementation remains a separate obligation.

The inline derivation uses the previous-row and current-column prefixes and
joins the actual singleton into complete output coverage. Materialize establishes
the full producer rectangle before its consumer and preserves the empty output
ledger during production. Rows2 explicitly stages row zero, preserves the
current row while refilling the other slot, consumes both complete rows and
retains exactly the newly staged row as the next outer invariant. Both parity
cases are affine identities in arbitrary quotient q, with a justified complete
Euclidean partition and nonnegative remainder arguments. H=1 and W=1 require no
extra inference. Physical row-major injectivity uses bounded columns and positive
pitch; it is not incorrectly applied to the globally noninjective modulo map.

The retained AST supplies ordered scalar terms, including producer substitution;
the candidate DAG is compared with that reconstruction. The documented interval
bounds establish each source add/multiply is safe. Rules require separate checks
for every physical operation and dead work. None of these claims relies on a
schedule label, native zeroing, scalar reassociation or successful sample runs.

## Executable evidence and its limits

The retained RED log shows the required missing-module failure. GREEN and
optimized-Python logs each show 10 tests completed successfully with no skips.
Their SHA-256 values match the implementation report. I inspected the same-code
logs as requested rather than repeating suites. Explicit runtime checks survive
optimization. Inspection confirms loops traverse bounded source/DAG/fact
structures, four producer coordinates or two parity cases, not H×W iterations.

The controls meaningfully exercise affine endpoints, source association, dead
overflow, rectangle extension/gaps/overlaps, output reset/duplicate rejection,
both parity cases, current-row framing, stale target invalidation, last-column
membership, and bounded work/width/DAG failures. The large-shape graph-shape
control measures the same event sequence; it does not validate a generic proof
DAG. `check_prefix` constructs its invariant and exit; `check_scratch` checks
geometry and value labels separately; materialize does not mechanically connect
a full producer state to its consumer. Those limitations are explicitly disclosed.
They are acceptable research/production boundaries, not passed production tests.

Generic invariant decoding, capture-free substitution, complete physical syntax
coverage, origin validation, hostile decoding and exact production metrics remain
C3–C5 work. Optional SSA liveness is correctly unavailable. Native compilation,
heap instrumentation, timing and complete acquisition/comparison remain separate.
No absent mechanized theorem is represented as completed formal verification.

## Gate mechanism decision

The always-blocked provisional `run_feasibility()` and authoritative reviewed
tracked record are an acceptable separation under the controller's explicit
ruling. The probe cannot approve itself. The tracked mechanism requires an
independent decision bound to the implementation commit and all three hashes,
then a reviewed controller update, and invalidates approval on artifact changes.
This is a procedural design gate, not a production eligibility API.

For this revision, record **blocked** with F1 as the first unresolved obligation.
The missing item is now precise quota evidence, not merely “review pending.”
This review does not authorize changing that decision to proceed.

# Loop plan v2: source profile and admission

This section specifies explicit scalable source admission only. Loop proof
feasibility is unestablished. Source admission does not establish plan
correctness, abstract storage bounds, native allocation, timing, or publication
eligibility; those are separate gates.

## Public source boundary

```python
admit_source_v2(source_bytes: bytes, *, profile: SourceProfileV2,
                limits: SourceLimitsV2) -> AdmittedLoopKernel
```

These records and the function live in `axiom.source_profiles`. Both keyword
arguments are required. Use `SourceProfileV2()` and `SourceLimitsV2()` to select
the supported configuration explicitly. V1 `parse_source` / `admit_source`, its
256-input-cell bound, canonical bytes, and hashes retain their existing behavior.

`SourceProfileV2` is immutable, with `version=2`,
`profile_id="axiom-stencil-fixed-buffer-v1"`, `max_height=8192`,
`max_width=8192`, `max_input_cells=2**23`, and
`index_semantics="checked-i32-row-major"`. Only these exact profile values are
supported; altered profile versions or semantics are rejected. Dimensions
follow the first and second shape declarations, independently of their names.

`SourceLimitsV2` is immutable, with `version=2`, `source_bytes=65536`, and
`expression_nodes=100000`. Quotas may be reduced to positive exact integers, but
cannot exceed these defaults. The existing parser also retains its ten-digit
integer-token and 32-level expression bounds. Boolean values do not qualify as
integers. Unknown versions and mutable configuration values are rejected with
`ValueError`. Source diagnostics use the existing `DiagnosticError` and byte
spans. Mutable source buffers and caller-created ASTs are not admitted.

## Supported fixed-buffer source semantics

```text
1 <= H,W <= 8192
P = (H+1)*(W+1) <= 2^23
O = H*W
input: i32[P], admitted values 0..1023
producer(r,c) = (input(r,c)+1) * (input(r,c)+1)
output(r,c) = ((producer(r,c)+producer(r,c+1))
                +producer(r+1,c))+producer(r+1,c+1)
```

H/W are fixed source parameters; values and host-owned buffers are runtime data.
The original parsed scalar tree governs computation. Admission compares the
exact supported normalized binary tree, ignoring parenthesis wrappers but not
association. Renaming bound symbols preserves semantics, including axes whose
names shadow tensor names. Changed grouping, ranges, tensor roles, or scalar
operations cannot be admitted as this canonical family. Structural validation
runs before profile recognition.

Every scalar node, including dead operations, uses checked i32 semantics.
Producer values are `1..1,048,576`; successive output sums are bounded by
`2,097,152`, `3,145,728`, and `4,194,304`. Mathematical index reasoning must
separately establish that generated i32 arithmetic and checked host byte
arithmetic fit their machine domains. These engineering dimension/cell limits
are neither a language theorem nor a native memory promise.

The source boundary semantics require row-major input preflight. Failure
identifies the first invalid input index and preserves the complete input and
original output. No scratch allocation, initialization, or body execution may
precede that decision. Success and input-precondition failure are the only
completed semantic states; invalid handles, native resource failure, traps,
timeout, cancellation, and missing acquisition need separate execution-failure
records. C2 binds these semantics in identity; it implements no execution path.

The execution profile additionally requires `0 <= scratch_capacity_cells <= P`,
including unused capacity and hand-authored plans. One complete semantic state
is strictly below 64 MiB, and reserved plan scratch is at most 32 MiB. These
execution requirements and actual memory/work/evidence budgets remain for the
later plan and execution gates.

## Retention and identities

`AdmittedLoopKernel` retains `source_bytes`, `source_digest`, the original
`source_module` AST, `height`, `width`, `input_interval`, original
`source_constraints`, their intersected workspace `cap`, `objective`, the
selected `profile`, and `version=2`. `input_cells` and `output_cells` are derived
properties. Its constructor uses the same fresh-byte admission boundary, so a
caller cannot construct an admission result by supplying asserted AST fields.
All retained structures are immutable parser-derived records.

Three distinct hashes serve distinct purposes:

* `source_digest` hashes the exact retained bytes, including names, spelling,
  comments, and formatting. The shared boundary name `source_sha256` is a
  read-only derived property.
* `family_digest` hashes canonical UTF-8 JSON with identity version
  `axiom-loop-family-v2`, the source-profile version/envelope/index semantics,
  alpha-normalized tensor types, roles, equations, input range, checked scalar
  arithmetic, and preflight boundary semantics. It excludes literal H/W and
  optimization preferences. Only the recognized canonical profile is hashed as
  this family. `family_semantics_sha256` is a derived property.
* `specialization_digest` hashes identity version
  `axiom-loop-specialization-v2`, the family hash, exact H/W, and the contract
  that dimensions are fixed while inputs and host buffers are runtime data.
  `specialization_semantics_sha256` is a derived property. A future proof must
  bind this specialization.

Canonical JSON uses sorted keys, compact separators, UTF-8, and no NaN values.
The v2 version domains differ from v1 semantic identities. Shape changes preserve
the family hash and change the specialization hash; spelling changes affect the
source hash alone. Shared boundary aliases are never separately mutable hashes.

Source constraints and objectives have separate versioned canonical identities:
`constraint_digest` binds `axiom-loop-source-constraints-v2` and the effective
source `plan_workspace_bytes` cap; `objective_digest` binds
`axiom-loop-source-objective-v2` and the parsed objective. Repeated source caps
intersect to their minimum. The original constraint declarations are retained;
their ordering/spelling remains bound by the exact source hash. Unknown source
properties/objectives and caps outside exact integer `0..2^31-1` are rejected.
Changing source caps or objective preserves the value-semantic hashes. Future
checking/replay must bind policy identities and independently intersect each
additional requested property with fresh source constraints.

Source ordering/path fingerprints, generated C, binaries, compiler pins, plans,
certificates, and execution instances require their own identities. None can
substitute for source, family, specialization, constraint, or objective identity.

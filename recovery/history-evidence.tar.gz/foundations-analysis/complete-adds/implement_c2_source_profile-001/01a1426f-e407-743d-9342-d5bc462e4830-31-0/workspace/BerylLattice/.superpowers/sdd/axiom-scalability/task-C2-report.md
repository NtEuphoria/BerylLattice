# C2 implementation report

Status: DONE

Base: `089e7f2` on existing isolated `/workspace/BerylLattice`, branch `work`.

Exact implementation commit: `958de943aeba6f8fd00dd983924499c6ca32a85c`
(`feat(axiom): add explicit fixed-buffer source profile`).

## Files and APIs

Only these task-owned product files were committed:

* `axiom/src/axiom/source_profiles.py`
* `axiom/tests/test_source_profiles.py`
* `axiom/docs/loop-plan-v2.md`

Public APIs: frozen `SourceProfileV2`, `SourceLimitsV2`, `AdmittedLoopKernel`,
and `admit_source_v2(source_bytes, *, profile, limits)`.

The explicit profile admits fixed source dimensions `1..8192` and at most
`2^23` input cells. It retains the existing parser's source-byte, expression-node,
integer-token and depth bounds, and uses its structural validation and exact
normalized scalar-tree comparison. No frontend/model/v1 code was modified.

The admitted record retains immutable exact bytes, their hash, original AST,
dimensions/domain, original constraints, intersected source cap and objective.
Both the public function and record constructor require fresh source bytes;
neither accepts a caller-provided AST as trusted admission.

Family and specialization hashes have distinct v2 canonical version domains;
family identity excludes literal dimensions and preferences. Constraint and
objective hashes have separate canonical domains. `source_sha256`,
`family_semantics_sha256`, and `specialization_semantics_sha256` are read-only
derived properties, not separately mutable hashes.

The new document contains only source-profile/admission material. It explicitly
leaves proof feasibility unestablished and describes later resource/execution
gates as requirements rather than implemented or verified capabilities.

## RED and GREEN evidence

All evidence paths below are under
`/workspace/BerylLattice/.superpowers/sdd/axiom-scalability/` and are retained as
local workflow artifacts, outside the product commit.

RED command, run from `axiom/` before production implementation:

```text
PYTHONPATH=src python -m unittest tests.test_source_profiles -v
```

Evidence: `task-C2-red.txt`, exit 1. Expected missing API failure:
`ModuleNotFoundError: No module named 'axiom.source_profiles'`.

GREEN commands, run from `axiom/`:

| Command | Evidence | Result |
| --- | --- | --- |
| `PYTHONPATH=src python -m unittest tests.test_source_profiles -v` | `task-C2-green.txt` | 9 passed |
| `PYTHONPATH=src python -O -m unittest tests.test_source_profiles -v` | `task-C2-optimized.txt` | 9 passed |
| `PYTHONPATH=src python -m unittest tests.test_frontend -v` | `task-C2-frontend.txt` | 12 passed |
| `PYTHONPATH=src python -m unittest tests.test_source_profiles tests.test_frontend tests.test_reference -v` | `task-C2-final.txt` | 33 passed |
| `PYTHONPATH=src python -O -m unittest tests.test_source_profiles tests.test_frontend -v` | `task-C2-final-optimized.txt` | 21 passed |

`git diff --cached --check` passed before committing. Working tree was clean
after the product commit.

## Self-review

* Namespace review: declaration-order shape roles preserved; alpha-renaming
  across module/shapes/tensors/axes and local axis shadowing of tensor names are
  covered. Swapping declaration roles without updating equations is rejected.
* Identity review: shape changes preserve family and change specialization;
  formatting and alpha-renaming alter exact source hash only. Changed scalar
  association, range, increment or selected profile cannot reuse admission.
  Source caps and objectives preserve value-semantic hashes but have their own
  distinct identities. Repeated constraints intersect to the minimum while
  retaining their original declarations.
* Integer-domain review: exact upper cell boundary `H=8191,W=1023` admitted;
  `H=8192,W=1022` admitted; `H=8192,W=1023` and either dimension 8193 rejected.
  Zero/negative/bool source dimensions fail. Bool/mutable/noninteger config,
  unsupported versions, raised parser quotas, invalid caps and unknown policies
  fail under normal Python and `-O`.
* Fresh-source review: parser invoked on bytes for every public admission;
  mutable byte buffers and supplied ASTs fail. No caller-supplied cap, height,
  digest or success receipt can bypass admission through the constructor.
* V1 review: no v1 file changes; all existing frontend and reference tests pass.
  Literal golden source/semantic hashes for `(5,7,64)`, `(5,7,0)` and `(1,1,64)`
  are now regression fixtures. V1 still rejects the same 32x32 source admitted
  by explicit v2. V2 family/specialization identities differ from v1 identities.
* Scope review: no checker, loop IR, code generation, runtime, native invocation,
  publication, external contact, worktree or subagent was introduced.

## Deviations and concerns

No task-requirement deviations or unresolved concerns. As instructed in the task
brief, focused/optimized/frontend/directly related reference verification was
used; unrelated exhaustive suites were not repeated. Shared frontend helpers
are imported privately without refactoring or modifying them. Later C1/Core
work must freshly admit bytes and implement its separate proof/execution gates.

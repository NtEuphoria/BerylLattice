# C2 independent review

Reviewed exact change `089e7f2..958de943aeba6f8fd00dd983924499c6ca32a85c`.
The checkout HEAD matched the implementation commit during review.

## Spec compliance verdict: PASS

No actionable spec deviations found in the C2 scope.

* Admission is explicit through the named v2 profile and required limits. Both
  the public function and `AdmittedLoopKernel` constructor parse fresh exact
  immutable bytes; neither accepts asserted AST, dimensions, cap, or digests.
* Exact configuration types and fields are validated again at admission.
  Booleans, unsupported versions/profile policies, mutable configuration values,
  and raised parser quotas are rejected. The existing bounded lexer/parser
  enforces immutable bytes, byte length, integer-token length, expression-node
  count, and expression depth without depending on assertions.
* Structural validation precedes exact normalized-family recognition. Original
  AST records and grouping remain retained; normalization preserves the binary
  tree while removing parenthesis wrappers. Declaration-order shape roles and
  separate tensor/axis name mappings avoid identifier-spelling dependencies.
* The dimension envelope, inclusive cell boundary, input domain, checked scalar
  semantics, and boundary preflight semantics match the brief. Source
  constraints derive from parsed bytes, retain original declarations, and
  intersect repeated workspace caps to their minimum.
* Source, family, specialization, constraint, and objective identities are
  distinct. Canonical digests have explicit v2 version domains. Family identity
  excludes fixed dimensions and preferences; specialization binds exact H/W.
  Shared serialization names are derived properties.
* The diff contains only the three owned files. V1 frontend/model/runtime code
  and native-unavailable behavior are untouched. Literal v1 hash fixtures are
  included in the new tests.
* Documentation explicitly leaves proof feasibility unestablished and separates
  admission from correctness, abstract storage, allocation, timing, execution,
  and publication. `checked-i32-row-major` identifies this source profile; the
  document separately requires mathematical index reasoning and machine-range
  proof for generated arithmetic. No logical plan-index API or lowering policy
  is introduced, so this does not redefine the later mathematical plan-index
  contract.

## Code quality verdict: PASS

No actionable correctness, maintainability, or regression findings found.
The implementation is small, uses frozen records and parser-derived immutable
nested values, and keeps v2 recognition and identities isolated from v1.
Reusing the existing private structural/normalization helpers is within the
brief's allowed scope and avoids changing existing behavior. Constructor
validation closes the ordinary caller-created admission-record bypass.

## Findings

None.

## Evidence reviewed

* `task-C2-brief.md`, `task-C2-report.md`, and `task-C2-review.diff`.
* Complete `source_profiles.py`, `test_source_profiles.py`, and
  `loop-plan-v2.md`; relevant `frontend.py`, immutable `model.py` records, and
  `tests/helpers.py` source fixtures.
* C1/B1/B2 integration requirements concerning mathematical plan indices and
  separate checked native lowering.
* Retained RED evidence reports the expected missing API error. GREEN evidence
  records 9 new tests passing; final evidence records 33 source-profile,
  frontend, and reference tests passing; optimized final evidence records 21
  source-profile/frontend tests passing. Reviewed normal/optimized test names
  and terminal counts; these are implementation-run results, not new review
  executions.
* Read-only `git diff --check` passed for the exact reviewed commit range.

## Limitations

No same-code passing suites were rerun. Static review found no concrete concern
requiring an additional targeted runtime probe. Runtime preflight, loop proofs,
native lowering, allocation qualification, and execution evidence are future
gates outside this source-admission-only change; this review establishes none
of those capabilities. No product files or commits were changed by review.

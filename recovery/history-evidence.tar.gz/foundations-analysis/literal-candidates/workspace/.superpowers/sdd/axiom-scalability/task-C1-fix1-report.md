# Task C1 fix round 1 report

Status: **BLOCKED**. F1 remains unresolved; no positive feasibility approval is requested.
Commit: `00dd07949d6fa32437c53460cf6a340d8f85567e`.
Message: `docs(axiom): record unresolved compact proof quota bound`.
Prior C1 commit: `0e3c6b7d6a451cb74d6caa8666b817d3d56544d3`.
C2 source baseline: `958de943aeba6f8fd00dd983924499c6ca32a85c`.

The controller opened this commit window after B2 and requested immediate release
for O1. The fix commit contains only the four C1-owned paths; the window has
been released. No subagents, worktrees, production IR/checker/planner changes,
quota increases, unrelated edits or publication occurred.

## Accepted review and changes

Read and accepted the complete independent `task-C1-review.md`. Its written
conditional induction assessment remains positive, while F1 requires complete
hand-certificate representation/cost evidence under unchanged quotas.

Corrected materialize's scratch peak from two to three facts at store-before-join.
The tracked gate now names F1 rather than merely saying initial review is pending.
The general C2 source-profile prefix remains byte-identical. Existing trace
measurements remain explicitly partial and are not relabeled as certificates.

Added `hand_certificate_bounds()` as a separate arithmetic audit of a proposed
typed encoding and conservative cost allocation. It enumerates actual written
primitive bodies, including both rows2 parity proof instances: 20/13/31 primitive
instances and 2/4/6 induction instances. The design appendix maps the proposed
tables to operation coverage, scoped nested base/step/exit state linkage,
substitutions, region/value payloads, DAG references and parity replication.
It separately discusses source constraints/AST visits, integer widths, active
facts, symbolic terms, storage and unchanged quota limits.

## Outcome and exact remaining obstacle

The proposed slot allocation has 4,501 typed rows and a **conditional** encoded
size of **440,352 bytes**. These are not proven certificate upper bounds:
per-operation/per-loop expansion capacities remain uninstantiated and unaudited.
The explicit field `expansion_completeness_established` is false. The calculation
must not be cited as quota feasibility or as a measured encoded certificate.

The corresponding conservative work attempt totals **8,814,588**, exceeding the
unchanged **1,000,000** quota. Its largest category is term keys/intervals/
comparison (6,832,336), because it charges worst interval multiplication to every
reserved term. It includes source admission/reconstruction, affine normalization,
substitution/capture, state/fact bookkeeping, proof coverage, scopes, origins,
metrics and identity bytes. It does not assume a generic DAG Cartesian product
or free memo lookups. Row/algorithm capacities themselves still require audit.
The overestimate is not a lower bound and does not prove the restricted design
infeasible.

Therefore this round **does not resolve F1**. The exact next research task is to
instantiate the complete scoped hand graphs, or prove their complete expansion,
then derive reachable distinct term/affine/substitution instances and a fully
charged comparison/memoization algorithm whose total, including source/identity/
state work, fits one million. Source reconstruction, every physical operation,
all state/effect premises, both parity cases and induction scope must remain
explicit. Do not widen quotas, accept a planner template, or substitute production
C3–C5 implementation for this missing research evidence. C4–C11 remain stopped.

## Tests and verification

From `/workspace/BerylLattice/axiom`:

`PYTHONPATH=src:research python -m unittest discover -s research/tests -p 'test_loop_proof_feasibility.py' -v`

RED: exit 1, missing accounting API and old unresolved-obligation message.
Final GREEN: exit 0, 11 tests passed, no skips.
Final optimized run: same command with `python -O`, exit 0, 11 tests passed,
no skips. The added audit rejects omission of every proposed table/work
category and incorrect claimed totals. It explicitly asserts that the resulting
work bound exceeds the quota and `fits_unchanged_quotas` is false. These tests
verify arithmetic accounting and fail-closed behavior, not semantic completeness
of an unbuilt proof graph. No unsupported control is reported as passing.

`git diff --check` passed. A direct byte-prefix comparison with the C2 source
baseline passed. Only the four intended paths were staged and committed.
No unrelated exhaustive suites were run.

## Gate mechanism

`run_feasibility()` returns blocked with F1 as first unresolved. The tracked
`docs/reviews/loop-proof-feasibility.md` retains blocked and accurately records
the independent review plus the incomplete fix. No test or accounting result
can activate proceed. A later independent reviewer must bind an actual complete
positive result to the exact implementation commit and three non-review hashes;
the controller then records that decision. Current follow-up review should
assess the outstanding obligations and next research task, not approve quota
feasibility on the conditional 440,352-byte figure.

## Exact artifact and log identities

| Path | Bytes | SHA-256 |
|---|---:|---|

# O1 implementation report

Status: implementation, scoped verification and scoped checkpoint commit complete;
independent review pending. Source baseline was
`cf01790ca3fa97e22e60a842427a3c582dec5a5b`; no worktree or subagents used.
Only the five O1-owned tracked source/test/protocol paths were created.
This report is the separately requested local coordination artifact.

## Exact interfaces and schemas

The full protocol is `axiom/research/protocol/invocation-v2.md`; it documents
every field, identity preimage, bound, file-safety assumption and I/O behavior.

`axiom.artifact_chunks_v2` exposes:

- Frozen `BlobLimits(chunk_bytes=1048576,max_file_bytes=16777216,max_files=16384,max_metadata_bytes=1048576,max_metadata_depth=16,max_metadata_items=65536)`; values may only tighten absolute ceilings.
- Frozen `BlobReference(manifest_path: Path, manifest_sha256: str, byte_length: int, sha256: str)`; `sha256` binds whole concatenated content, independently of manifest identity/layout.
- Frozen `ChunkReference(offset,byte_length,path,sha256)` and `VerifiedBlob(reference,limits,chunks)` metadata; bounded internal LRU is excluded from equality.
- `write_blob(blocks: Iterable[bytes], byte_length: int, directory: Path, *, limits: BlobLimits) -> BlobReference`.
- `verify_blob(reference: BlobReference, *, limits: BlobLimits) -> VerifiedBlob`.
- `VerifiedBlob.revalidate() -> None`, `iter_bytes() -> Iterator[bytes]`, `read_i32(index: int) -> int`, and properties `byte_length`, `sha256`, `cached_chunk_count`.
- `canonical_json(value) -> bytes` and bounded `read_manifest(path: Path, *, limits: BlobLimits) -> tuple[object,str]`.

Blob manifest fields are exactly `schema="axiom-blob-v2"`, `byte_length`,
`sha256`, and `chunks`. Chunk fields are exactly `offset`, `byte_length`,
`path`, `sha256`; contiguous exact coverage, unique normalized relative paths,
positive bounded lengths and actual content hashes are required. Empty arbitrary
byte blobs are supported. Generic chunks may divide scalar boundaries;
`read_i32` handles crossing but rejects a partially scalar-aligned blob.

`axiom.invocation_v2` exposes:

- Frozen `InvocationLimits(blobs=BlobLimits(), source_profile=SourceProfileV2(), source_limits=SourceLimitsV2())`.
- Frozen `InvocationManifest(source: BlobReference, source_sha256, family_semantics_sha256, specialization_semantics_sha256, source_profile: SourceProfileV2, H, W, input: BlobReference, initial_output: BlobReference, buffer_contract="axiom-core-buffer-host-v1")` with `invocation_sha256`.
- `write_invocation(source_bytes: bytes, input_blocks: Iterable[bytes], initial_output_blocks: Iterable[bytes], directory: Path, *, limits: InvocationLimits) -> Path`.
- `verify_invocation(manifest: Path, *, limits: InvocationLimits) -> VerifiedInvocation`.
- `VerifiedInvocation` exposes bound manifest path/digest/metadata/limits, exact retained source bytes and source VerifiedBlob, source/family/specialization identities, source profile, H/W, input/initial-output VerifiedBlob, buffer contract, invocation identity, `revalidate() -> None`, and `state_v1_invocation_sha256(logical_semantics_sha256=None)`.

Invocation manifest fields are exactly `schema="axiom-invocation-v2"`, `source`,
`source_sha256`, `family_semantics_sha256`, `specialization_semantics_sha256`,
`source_profile`, `H`, `W`, `input`, `initial_output`, `buffer_contract`, and
`invocation_sha256`. Embedded references have exactly `path`,
`manifest_sha256`, `byte_length`, `sha256`. All schemas use strict canonical
ASCII JSON, no duplicate/unknown fields or floating values; counts/lengths/
offsets/dimensions/versions reject bool. SHA-256 strings are lowercase exact64.

Invocation identity hashes canonical JSON with identity version
`axiom-exact-source-invocation-v2`, source content length/digest, source SHA,
family/specialization SHA, exact profile, H/W, input and initial-output content
length/digest, and required host contract. Paths, manifest hashes, chunking,
physical plan, run, and timing are excluded. Relocation/rechunking equivalence
is tested. Fresh retained source admission compares C2's three identities and
shape, so renamed source and forged source/family/specialization/extent bindings
cannot be substituted.

The explicit state-v1 mapping defaults logical semantics to the C2
specialization identity and uses exact content digests/H/W under the unchanged
state-v1 preimage. A test compares it with existing research `StateMetadata`;
production has no research imports and v1 admission/receipts remain unchanged.

The required `axiom-core-buffer-host-v1` contract was reconciled directly with
the controller. It is a host obligation, never a caller-provided proof of
pointer disjointness, generation, liveness or ownership. Shared content files
do not authorize aliased runtime buffers. No second host/allocator/schema was
introduced.

## Evidence: RED and GREEN

Commands run from `/workspace/BerylLattice/axiom`.

1. Initial intended RED before production files existed:

   `PYTHONPATH=src:research python -m unittest tests.test_artifact_chunks_v2 tests.test_invocation_v2 -v`

   Result: missing `axiom.artifact_chunks_v2`, exactly the missing O1 API,
   not a dependency/environment failure. Actual output retained at
   `/tmp/O1-red.log`.

2. Final focused normal command, same as RED: **12 tests PASS**;
   `/tmp/O1-green.log` (0.074s on recorded final normal run).

3. `PYTHONPATH=src:research python -O -m unittest tests.test_artifact_chunks_v2 tests.test_invocation_v2 -v`

   **12 tests PASS**; `/tmp/O1-optimized.log` (0.068s).

4. `PYTHONPATH=src:research python -m unittest tests.test_frontend research/tests/test_state.py -v`

   **28 tests PASS**; `/tmp/O1-v1.log` (3.322s).

5. `PYTHONPATH=src:research python -O -m unittest tests.test_frontend research/tests/test_state.py -v`

   **28 tests PASS**; `/tmp/O1-v1-optimized.log` (3.293s).

Product guards use explicit errors, with no assertions disappearing under -O.
No production research import exists. Scoped `git diff --check` is clean.

Focused coverage includes exact coverage/missing/overlap, exact integer domains,
negative/oversized offsets/indexes, little-endian signs/extrema, partial final
scalars and crossing generic chunks, mutable-file replacement after verification,
source/input/output/manifest replacement, invalid source/shape before iterator
consumption, duplicate keys/unknown schema/fields, predecode metadata byte/depth/
item bounds, missing/directory/FIFO files, leaf/ancestor symlinks and writer
symlink rejection, immutable name collisions, incomplete iterator prefix
retention with no accepted final manifest, cache capacity, source/family/
specialization bindings, state-v1 mapping, and re-chunk/path-independent identity.

H=2049/W=2047 and H=W=2048 checks are arithmetic-only. No new test generates or
executes historical primary/thin-shape or held-out input; disclosed 1x1 correctness
values include -1/1024 so source rejection data remains transportable. Required
existing state regression retains its own unchanged format-only primary-size
streaming test; O1 adds no new primary exposure or semantic execution.

## Resource and trust boundaries

Extent/profile admission precedes buffer iterator consumption; input/output are
exactly 4P/4O. No complete input or output is allocated in a reader. Full file
reads are bounded by configured chunk or metadata caps. The scalar LRU retains
at most two chunks (at most 2 MiB default), distinct from transient read/join
buffers, bounded metadata, source retention (at most 65,536 bytes) and the
caller-owned current write block. Writers retain at most a chunk-sized pending
buffer plus immutable flush bytes and bounded metadata.

Each scalar read safely reopens/stats its chunk, including cache hits; it hashes
actual complete chunk bytes on a cache miss or fingerprint change. This
reference implementation makes no throughput claim for millions of scalar
reads. `iter_bytes` first performs a complete revalidation scan, then rereads
and hashes every yielded actual chunk; consumers must exhaust it. Source
verification/readmission also entails repeated bounded source reads. O2/O5 must
account this acquisition/logical-read amplification; none is free deduplication.

Every full revalidation hashes actual bytes and compares immutable metadata.
Descriptor-relative NOFOLLOW traversal covers every ancestor and file, regular
file checks avoid FIFOs/devices, before/after device/inode/size/mtime/ctime checks
detect changing reads. Cache hits compare safely reopened fingerprints.
Stable files during a consuming operation remain an explicit assumption;
same-UID concurrent adversarial mutation is not made impossible by a dataclass,
mode0400 or fingerprint. Consumers must revalidate at the actual trust boundary.

Limits here apply to individual blobs/documents. Complete store/campaign unique
path accounting, semantic/qualification aggregates, failure quarantine, capture
reservation, logical work budgets and all state comparisons belong to enclosing
owners. Failed writes retain an incomplete prefix without a final accepted
manifest; caller policy owns cleanup/quarantine/reservation. Existing artifacts
are never overwritten or discarded. Native execution, oracle matches,
performance and successful acquisition are not claimed by O1.

## Self-review / deviations / commit

Self-review checked source-before-stream admission, strict counts and hashes,
C2/B1 identity compatibility, path safety, finite metadata ingestion, scalar
crossing, cache eviction before a third insertion, complete actual-byte
revalidation, immutable metadata, state-v1 equivalence and no research imports.

Tests replace mode0400 files via unlink/recreate when injecting mutations, so
mutation checks prove storage revalidation rather than write-permission failure.
`VerifiedInvocation` uses a frozen nonslotted dataclass to avoid Python 3.12's
frozen-slots property-assignment TypeError; its metadata remains immutable.
No requirements or v1 behavior were changed. No native gate is relevant to this
transport-only task. Independent spec/quality review is controller-owned and
pending after the scoped checkpoint commit.

Commit: `7e72feeed82648b059e6f9884a2ebc56cf0a27a0`, with actual parent
`00dd07949d6fa32437c53460cf6a340d8f85567e`, message
`feat(axiom): add bounded v2 invocation transport`. Exactly five O1-owned paths
were staged/committed; controller commit window released. This local coordination
report is outside the tracked scope.

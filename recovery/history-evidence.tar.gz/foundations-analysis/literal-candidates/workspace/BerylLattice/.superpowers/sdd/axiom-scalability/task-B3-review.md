# B3 independent lifecycle review

Overall verdict: **PASS**, scoped to the implemented private lifecycle and tiny native cases.

- Spec verdict: **PASS**.
- Code-quality / ABI verdict: **PASS**.
- Ownership / cleanup verdict: **PASS** under the documented trusted, synchronous, sole-owner implementation contract.

No blocking implementation defect was demonstrated. The controller corrected one nonblocking report precision issue during review; its resolution is recorded below. General allocation accounting, production admission/invocation, C12/native semantic lowering, timing and large execution remain unqualified.

## Reviewed identity and method

Exact range: `7e72feeed82648b059e6f9884a2ebc56cf0a27a0..9912ead6c330fb0f302e687aca577fecad005bc0`.

I verified that `task-B3-review.diff` is byte-identical to that Git diff and that all ten owned files match the commit. Read the brief/report, all five implementation files, both native test programs, Python lifecycle driver, B2 host retrofit and B2 test changes. Reviewed the retained emitted C, actual assertion header, command records, native stdout/stderr, LLVM, symbol outputs and inventories. The B2 binding helper itself is unchanged.

No product files, worktrees, commits, compiler rebuilds or native test reruns were made. Read-only verification rehashed retained files, compared exact sources and assertions, and reloaded the original qualified Toolchain. This review document is the sole written artifact. Concurrent O1/controller files are outside the reviewed change.

Verified evidence:

| Evidence directory beneath `/workspace/scratch/axiom-B3-native-lifecycle/` | Result |
| --- | --- |
| `axiom-B3-pj_wtn5v` | Exact final-source Python `-O` run: all 80 inventoried files rehashed; 5,137,345 indexed bytes |
| `axiom-B3-qphad034` | Normal run: all 80 files rehashed; 5,137,176 indexed bytes |
| `axiom-B2-binding-v5o86r0u` | Final retrofit: all 83 qualification and 26 semantic indexed files, modes and hashes verified |
| `axiom-B2-binding-26pi2kd1` | Normal retrofit: same inventory verification |

The normal B3 header differs from final source only by the two documented API comments about the compiled token and scratch caller contract. All final B3 native sources match the final-source evidence. Both B3 inventory file sets are exact and contain no symlinks. Build-input identities and recorded execution binary identities also match their retained bytes.

## ABI, private entry and state outcomes

Generated C and binding assertions in both B2 retrofit stores are byte-identical to the accepted original B2 artifacts. The emitted C is still exactly actual `emit-c` stdout. Loading the original receipt and reconstructing each of the four retained B2/B3 bindings reproduces its manifest and assertions. The live Toolchain still reports `known_pinned_baseline_failure`; this review does not relabel Core fully green.

`host_protocol.c:18-20,42` constructs the actual emitted `be_t_List_3ci32_3e`, with no cast from another descriptor. The unchanged B2 `_Generic` field/signature checks and offset/size/alignment assertions remain before the protocol include. Wrong symbol, removed const, changed return type, changed len/layout and lookalike-pointer controls still fail compilation with their intended diagnostics; no mutant executable remains. The retained hash/pin gates and declaration-rendering controls remain in the 13-test B2 suite.

The static checked entry is the sole helper invocation site. The B2 worker admits only `invoke`; all five helper-selection controls exit 64 with no stdout. Both emitted helpers remain `LOCAL DEFAULT` in retained symbols and absent from dynamic exports. Production-mode B2 compile arguments omit `AX_BUFFER_TESTING`; its LLVM contains no `ax_test_fail_at` or test-fault implementation. The test instrumentation is selected at compilation, never by accepted worker metadata. The protocol contains no runtime callback pointer or caller-selected alias.

Both retrofit stores retain all six complete input/output states, unchanged from B2: valid `[46,74]`, minimum `[4,4]`, maximum `[4194304,4194304]`; first/last/multiple-invalid cases preserve `[-99,77]` and report indices 0/5/1. Every complete acquired input equals its supplied input. Successful calls record one scratch allocation; rejected calls record zero; all have zero final scratch live bytes and zero operation-allocator body attempts. These are independent hand fixture comparisons, not the B1 callback adapter.

## Ownership and recoverable paths

`ax_shape_checked` bounds dimensions before multiplication, checks P and scratch counts, checks i32/size_t byte conversion and addition, and enforces the combined byte budget before allocation. The native arithmetic tests cover near-i32/SIZE_MAX/UINT64_MAX values without huge allocation, minimum/maximum admitted shapes and exact zero scratch.

The fixed registry owns original base pointers and records identity/generation, role, liveness, logical/reserved/initialized extent, requested bytes and alignment. A process-lifetime monotonic serial prevents handle resurrection on slot/host reuse and fails before wrap. Handles expose no data pointer. Lookup checks slot, liveness and both identity fields. Live malloc allocations are distinct; no relational comparison of unrelated pointers or offset view is used. Trusted records are not hostile wire metadata.

The checked entry validates specialization, shape fields, handle state, roles, exact counts/bytes/initialization/alignment, disjoint input/output identities and empty operation state before Core access. Scratch is allocated only after a successful preflight, fully zeroed before borrowing, and checked to have an identity distinct from input/output. The zero-scratch boundary makes no allocator request. This zero case is lifecycle-only; no inline Core kernel is thereby qualified.

Source rejection precedes scratch allocation/initialization/body. The test arms scratch failure while presenting invalid input and still observes source rejection, first invalid index and zero scratch attempts. Scratch OOM follows successful preflight and returns a resource status with unchanged output. Preparation OOM at either ordinal destroys partial setup. Unexpected preflight results and descriptor mutations are integrity failures, distinct from boundary/resource/semantic outcomes.

All recoverable checked-call paths converge on original-handle scratch cleanup, clear busy state and return. Borrowed descriptor corruption never supplies the pointer passed to free. Preparation destruction likewise walks original owner records. There is no Core defer/clear cleanup assumption. Complete acquisition is outside the checked entry; failure diagnostics cannot become a successful semantic receipt merely because acquisition succeeds.

Native tests exercise 120 alternating valid/rejected/OOM calls, 100 success/OOM calls against one live preparation, stale handles, wrong specialization, alias handles, incomplete initialization, hostile logical/shape lengths and five preflight/descriptor faults. The repeated calls and integrity controls compare every input/output cell. Scratch returns to baseline and owner counts balance on the exercised recoverable paths. The allocator tests also cover three failure ordinals, full poisoned-to-zero initialization and 1,000 reused generations.

## Sanitizer and allocation evidence

The original qualified Clang SHA256 remains `0a3c55936ac43954fbe4914e6e73b577ca9e35e75d89ef13d3e28c187f41ca1a`. No alternate compiler discovery occurs. Native lifecycle compile commands use that exact Clang with `-O1`, strict pointer/declaration/conversion errors, `-fno-builtin` and active C assertions. Python `-O` does not disable these C assertions. B2's production-mode seam retains `-O0`.

I independently rehashed all 363 actual sanitizer resource files and verified the exact file set, no symlinks and inventory SHA256 `4ed2d0c3bfa9c2c3507dc4b08dcf051a172c45fccca7e8f4ef8552c1a24b7b91` under `/workspace/scratch/axiom-scalability-execution-20261016/sanitizer-runtime-jtv4b5ih`. Actual compile receipts use that resource directory with combined address/undefined or standalone leak sanitizers. Run receipts retain ASAN/UBSAN/LSAN overrides and binary identities.

For both normal and final-source runs, allocator and host binaries exit zero with empty stderr in ordinary, combined ASan/UBSan and standalone LSan modes. Deliberate host-owner use-after-free, signed-overflow and omitted-cleanup controls each exit 23 with the intended diagnostic. These failing controls are detector witnesses, not successful semantic invocations or cleanup receipts.

Independent linker wrapping covers direct linked malloc/calloc/realloc/free/aligned_alloc/posix_memalign references in this executable. All five allocating-interface controls are exercised; injected malloc/free outside the operation allocator causes the expected assertion abort (-6). Ordinary calls observe one wrapped scratch malloc on success, none on source rejection/injected OOM, and none in the actual emitted body interval. An actual mmap/munmap control leaves wrapped counts unchanged. Consequently complete allocation accounting is explicitly **unqualified**: mmap, direct syscalls, shared-library internals, custom allocators and other interfaces/configurations/kernels are outside coverage. Balanced counts do not prove stable RSS or absence of allocator slack/reservation.

## Findings, precision and remaining limits

**Resolved nonblocking report precision:** The report initially said every normal/failure-return invocation acquires and compares full state. The individual boundary-metadata controls in `test_buffer_host_v2.c` assert boundary status and no scratch attempt, restore their deliberately damaged metadata and eventually destroy the host; they do not each reacquire state. Full comparisons are present for the 220 lifecycle calls, integrity controls and six B2 cases. The controller corrected `task-B3-report.md` during review to state this narrower scope, without source changes. This does not violate the no-Core-access boundary contract or conceal an accepted result.

The API is deliberately private and assumes zero-initialized, noncopied live registries, trusted preparation/acquisition arrays and exclusive synchronous access. It does not defend against arbitrary mutation of owner records or hostile same-process code. Compile-time instrumentation macros and fixture constants are trusted build inputs, not proof of source admission. The opaque token is not a build hash. B5/B6 must establish full specialization/artifact/invocation authority and preserve lifetime, acquisition and independent comparison obligations.

No C12/source/native semantics, large shape execution, production protocol/supervision, full transport, clocks or timing qualification follows from these tiny tests. B4/B5/B6/B7 and later gates remain necessary. Tool/runtime identity coverage is selected and path-sensitive, not hermetic SDK/linker/transitive closure or hostile same-UID immutability. The B3 local inventory is diagnostic output indexing, not an O1 artifact protocol.

Retained normal and Python `-O` focused logs each report 18 passing tests. The broad earlier suite is correctly reported as failed rather than green. Its B3 portable-size helper error is stale: final source explicitly passes `None` for the unintended source cap and both final focused runs include the passing test. The separate O1 import error is outside these ten files and is not a B3 defect. No unchanged expensive suite was rerun during review.

# B2 independent review

Spec verdict: PASS for the B2 tiny native binding seam.

Code-quality / ABI verdict: PASS within that scope. No blocking or nonblocking code defect demonstrated. B8 is not triggered by the observed evidence. This review does not qualify B3's production owned invocation or B5's general binding.

Reviewed immutable range: `0e3c6b7d6a451cb74d6caa8666b817d3d56544d3..cf01790ca3fa97e22e60a842427a3c582dec5a5b`. The saved `task-B2-review.diff` is byte-for-byte the Git diff for that range. All three changed files currently match the reviewed commit. Read the brief, implementation report, B1 hand source/cases, generated C, host, assertions, test implementation, selected existing Toolchain validation, and retained command/output evidence.

Only this review document was written. No product edits, commits, compiler rebuilds, native executions, or passing-suite reruns were performed. Verification consisted of read-only identity/inventory checks, independent arithmetic over the retained complete states, and loading/revalidating the existing qualified toolchain. Concurrent controller/research changes are outside this review.

## Spec evidence

The final normal evidence is `/workspace/scratch/axiom-B2-native-binding/axiom-B2-binding-w199uac8`; the Python optimized evidence is `/workspace/scratch/axiom-B2-native-binding/axiom-B2-binding-xpk439j7`.

For each directory I independently verified every inventoried file's size, SHA256 and mode, the exact actual file set, absence of symlinks, quota totals, and all execution-input identities. Each semantic store has 26 inventoried files and 9,344 bytes including its inventory; each qualification store has 78 files and 553,409 bytes including inventory. These match the implementation report. I loaded the original toolchain receipt through `load_toolchain`, regenerated the binding record from the current qualified tools/source/artifact, and compared it and the generated assertions with both retained stores: exact matches.

The retained `emit-c.json` records the qualified snapshot's actual `beryl.exe emit-c` invocation on the absolute B1 fixture path, exit zero and no timeout. Its 6,206 stdout bytes equal both `generated.c` and `qualified/generated.c`. The manifest hashes those exact bytes. The included generated code implements the hand source's first-invalid range scan and checked `(value + 1) * (value + 1)` producer followed by left-associated four-term sums. Host code does no substitute stencil computation. Native input and initial output values come from runtime transport, not source specialization.

Both stores retain the following complete outcomes; I independently recomputed the valid outputs from their six input values and independently located each first invalid input:

| Case | First bad index | Entire output | Entire input |
| --- | --- | --- | --- |
| valid | none | `[46, 74]` | unchanged |
| minimum | none | `[4, 4]` | unchanged |
| maximum | none | `[4194304, 4194304]` | unchanged |
| first-invalid | 0 | `[-99, 77]` | unchanged |
| last-invalid | 5 | `[-99, 77]` | unchanged |
| multiple-invalid | 1 | `[-99, 77]` | unchanged |

All twelve retained run records exit zero without timeout. Success events are preflight, scratch allocation, scratch initialization, body, descriptor checks, scratch free, complete acquisition, input/output free. Rejection events omit scratch and body. The source and LLVM control flow support those recorded events; events alone are not independent allocator measurements.

## ABI and lifetime review

The host includes the unchanged generated translation unit before its assertion header and directly declares `be_t_List_3ci32_3e` objects. Its compound literals initialize that actual type; they are not casts of a lookalike descriptor. `_Generic` checks `data`, `len`, `cap`, and both complete helper pointer signatures, including const input and mutable output/scratch descriptor pointers. `_Static_assert` checks byte/i32/pointer widths, offsets 0/8/12, size 16 and alignment 8 under the selected Linux/x86-64 C11 profile. Top-level parameter `restrict` does not hide a weakened pointee check.

Both retained compile invocations use the explicitly qualified Clang with C11, `-O0`, hidden visibility and errors for incompatible pointers, implicit functions and integer conversions. Negative translations fail with the intended diagnostics and contain no worker executable:

- Wrong symbol: undeclared identifier.
- Removed input const: both signature assertions fail.
- Changed body return type: body signature assertion fails.
- Changed len type/layout: len type, cap offset and descriptor size assertions fail.
- Separately declared structurally identical descriptor: incompatible-pointer error.

Modified-generated-C and wrong-pin guard records show identity rejection before execution; their hash/pin differences are real. The code also rejects manifest pin/signature misstatements during assertion rendering. ABI mutants intentionally bypass the identity gate only to exercise compilation failures; the qualified build takes both gates.

`checked_invoke` is static and is the sole source call site for both generated helpers. `main` admits only `argc == 2` and exact operation `invoke`. Five retained helper-selection attempts exit 64 without stdout. Retained readelf entries show both helper symbols `LOCAL DEFAULT`; `nm -D --defined-only` is empty. LLVM independently shows hidden generated helper definitions and an internal checked entry. This contains the executable's process interface; it does not isolate hostile code in the same address space or qualify a shared-library export policy.

Input/output are distinct live malloc allocations owned by `main`, initialized before entry, and never supplied as caller pointers. Separate live allocations also establish disjoint scratch. Preflight occurs before scratch allocation; successful scratch is completely initialized before borrowing. Descriptor pointer/length/capacity comparisons follow the body or rejection. Cleanup uses the retained scratch owner, not borrowed metadata. `main` frees input/output after checked-call errors and after copying the entire successful/rejected state. Tiny constant sizes make the C allocation sizes representable. No local owning Core List, push/clear invocation, callback, escaped reference or Core cleanup assumption appears in the fixture helpers. Generated C includes unused push/runtime code unchanged, so this review makes no general allocation-absence inference.

## Limits and downstream obligations

1. **Binding helper trust is intentionally narrower than provenance validation.** `core_native_v2.py:55-87` hashes the supplied source and generated file and checks subsequent equality. It does not independently establish that supplied C was emitted from supplied Core source; `_binding_assertions` establishes declarations, not semantics. The caller must obtain its Toolchain through `load_toolchain` and retain the real emission/build sequence. The reviewed test harness does so. Rebinding arbitrary initial C or constructing arbitrary Toolchain objects is outside this helper's contract. Do not promote `_bind_fixture` into a standalone production admission or proof-token API.
2. **Identity closure remains partial.** The receipt and selected tool/configuration/known-component identities are checked; this is not a complete SDK/linker/transitive dependency closure. Hashes and read-only modes discourage accidental changes but do not establish hostile same-UID immutability or eliminate check/use races. Paths remain identity-bearing; relocation is unqualified.
3. **Python `-O` is not native optimization qualification.** Both retained native compile commands use Clang `-O0`. The second run verifies that Python optimization does not remove the test's fail-closed checks. It makes no statement about optimized native generated code.
4. **Lifetime behavior is scoped.** OOM and descriptor-corruption paths are source-reviewed, not fault-injection-qualified here. Production generations/handles, full resource semantics, allocator integration, independent allocation/interposition observations, supervision and timing belong to later tasks. Current C const descriptor pointers alone do not make backing input memory const; sole host ownership, checked Core behavior and full postcomparison carry that obligation here.
5. **No inflated green claim.** The retained normal and Python `-O` logs each report 13 passing tests; the required-native missing-selector control is a setup error with zero executed tests, not positive qualification. Live loaded Toolchain status is `known_pinned_baseline_failure`, consistent with the report's two known Core failures. This seam does not establish large-shape execution, oracle qualification, timing, performance, allocation measurement or publication readiness.

The implementation report accurately distinguishes these boundaries. No observed failure requires B8, and no broader success is inferred from this B2 pass.

# B1 implementation report

Status: DONE

Base: `958de943aeba6f8fd00dd983924499c6ca32a85c` (accepted C2), existing
isolated `/workspace/BerylLattice`, branch `work`; no worktree or subagents.

Commit: `aaa6d2f2c87ff47ee15c7f4f0bc809a45846831c`
(`docs(axiom): define checked runtime buffer boundary`).

## Owned files and interfaces

Only five explicitly owned new paths were committed:

- `axiom/docs/core-buffer-contract-v1.md`
- `axiom/tests/test_core_buffer_contract_v2.py`
- `axiom/tests/support/buffer_contract_v2.py`
- `axiom/tests/fixtures/core_native_v2/tiny-1x2.be`
- `axiom/tests/fixtures/core_native_v2/tiny-1x2-cases.json`

No production interface was implemented or changed. The document fixes
`axiom-core-buffer-host-v1` expectations while preserving existing v1 behavior
and explicitly naming the v2 route. It consumes C2 admission, source constraints,
source/family/specialization identities and fixed engineering limits rather
than independently implementing AdmittedLoopKernel.

Test-only interfaces are `sizes(source_bytes, reserved_capacity, *, size_max)`,
`prepare(source_bytes, values, initial_output)`, `checked_call(invocation,
callbacks, *, scratch_capacity)` and `exercise_control(mutation)`. The fixture
prepares owned tiny buffers, performs real Python callback allocation/zeroing,
preflight, mutation, cleanup and acquisition, then compares with the existing
original-source-AST evaluator. All source parsing/binding occurs outside the
checked-call event interval. Scratch size checking inside that interval uses
the already freshly admitted source record, with no extra source parse or
input hashing/preflight scan. These are behavioral ordering specifications,
not production pointer/handle ownership, timings, allocation interception or
native execution evidence.

The hand-written Core fixture is independent of the loop emitter. Its two
ordinary private helpers implement row-major preflight and materialization for
H=1/W=2, P=6/Q=2/scratch=6. Reads and writes are separate statements, producer
source additions remain explicit, and both loops are integer ranges. Six
hand-worked cases specify valid/minimum/maximum/first-invalid/last-invalid/
multiple-invalid state, including distinct nonzero output canaries. The Python
fixture separately exercises zero-allocation inline boundary behavior; it does
not claim to compile an inline Core fixture. Tiny execution deliberately accepts
only capacities zero or six; arbitrary admitted shapes and all capacities in
0..P are covered by arithmetic-only size planning.

## Tests and retained evidence

Logs are retained locally under `.superpowers/sdd/axiom-scalability/`, outside
the product commit, matching the earlier C2 artifact policy.

| Command from `axiom/` | Log | Outcome |
|---|---|---|
| `PYTHONPATH=src python -m unittest tests.test_core_buffer_contract_v2 -v` before adapter implementation | `task-B1-red.txt` | exit 1; 12 intended missing-adapter assertion failures |
| same focused command during additional metadata/capacity/instrumentation TDD | `task-B1-red-refinement.txt` | exit 1; 3 metadata acceptance failures and 5 missing-feature errors, all corrected |
| `PYTHONPATH=src python -m unittest tests.test_core_buffer_contract_v2.BufferContractTests.test_failures_never_synthesize_completed_state_and_cleanup_original -v` | `task-B1-red-partial.txt` | exit 1; partial acquisition misclassified as comparison failure; corrected to acquisition failure before comparison |
| `PYTHONPATH=src python -m unittest tests.test_core_buffer_contract_v2 -v` final | `task-B1-green.txt` | exit 0; 14 tests passed |
| `PYTHONPATH=src python -O -m unittest tests.test_core_buffer_contract_v2 -v` final | `task-B1-optimized.txt` | exit 0; 14 tests passed |

Each of these commands was also executed independently, with exit 1 and its
concrete assertion retained (the normal/-O suite asserts these controls fail):

```text
PYTHONPATH=src python -c 'from tests.support.buffer_contract_v2 import exercise_control; exercise_control("scratch_before_preflight")'
PYTHONPATH=src python -c 'from tests.support.buffer_contract_v2 import exercise_control; exercise_control("caller_validation_bit")'
PYTHONPATH=src python -c 'from tests.support.buffer_contract_v2 import exercise_control; exercise_control("used_capacity")'
```

Their logs are respectively `task-B1-control-scratch-red.txt`,
`task-B1-control-validation-red.txt`, and `task-B1-control-capacity-red.txt`.
The controls allocate before rejection, bypass preflight and actually change
output, and reserve six cells while charging one. They do not search prose or
merely supply synthetic event lists. Assertions remain active under `-O`.

`git diff --cached --check` passed before the scoped commit. No unrelated suite,
native build, compiler edit, witness/campaign execution or large input
generation was performed. This follows the brief's focused-verification rule
and controller instruction rather than the generic skill's broader suite rule.

## Self-review and cross-contract checks

- Arithmetic: exact admitted upper P=8,388,608 at H=8191/W=1023; dimension maxima
  and invalid dimension/cell combinations; primary input/output byte counts
  16,793,600/16,777,212; square combined state 33,570,820; reserved capacity,
  source cap, bool/noninteger rejection and target-byte overflow.
- Entry: no caller validation-bit keyword; constructed admission cannot replace
  bytes. Exact metadata guards reject dead/wrong-generation handles, alias
  identities, wrong initialization/alignment, lengths/capacities, wrong
  specialization and bool/float metadata before Core callbacks.
- Order/state: one actual row-major preflight reads every valid cell and stops
  at the first invalid cell. Rejection preserves all input and both output
  canaries without allocation/body. Success observes allocate, zero, body,
  descriptor integrity, original-record cleanup and timer end, followed by
  complete acquisition and independent AST comparison.
- Failures: scratch OOM preserves output; descriptor corruption, source input
  mutation, body trap, failed/partial acquisition and output mismatch never
  return accepted completed state. Partial acquisition is rejected before the
  comparison callback; original scratch storage is cleaned up even after its
  borrowed descriptor is corrupted.
- Status separation: only success and input_precondition_failed are source
  semantic states. Fixture comparison_error is explicitly a local later-stage
  evidence label, not an added NativeRunV2 completion value.
- Core source review: actual pinned List field declaration and let/inout
  parameter lowering, whole-call receiver borrowing in ownership.c, mutating
  collection iteration restriction in storage.c, runtime checked access/i32
  arithmetic, and documented lack of automatic owning List cleanup.
- Contract review: plan 01 §§2.1–2.6/B1, plan 03 O1/O2/O5 and plan 04 M1/M2.
  Document binds exact helper signatures/expected LP64 layout, fail-closed
  _Generic/_Static_assert requirements for B2, complete acquisition, storage
  quotas, raw timing scope, allocation accounting and separate identity domains.
- Scope/preservation: no source_profiles/frontend/v1/runtime/compiler changes.
  Controller-owned planning README edits and untracked
  `docs/scalability-implementation-record.md` remain untouched/uncommitted by B1.

## Concerns and deviations

No unresolved implementation concerns or requirement deviations. Controller
independent review remains separate from this self-review. Expected C11 ABI
assumptions and Core fixture admission are requirements for B2 to qualify;
B1 makes no native build/execution, allocator, performance or publication claim.
All workflow evidence/report files remain local and ignored rather than being
added to the product commit.

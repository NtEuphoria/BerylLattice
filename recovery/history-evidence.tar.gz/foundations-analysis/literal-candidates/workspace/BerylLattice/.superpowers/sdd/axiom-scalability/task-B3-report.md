# B3 owned native buffer lifecycle

Status: implemented and scoped verification passed; independent controller review pending.
Commit: `9912ead6c330fb0f302e687aca577fecad005bc0`
(`feat(axiom): add owned native buffer lifecycle`).
Explicit ten-file staged diff and whitespace check passed. Controller authorized
committing the scoped green sources while the broad exhaustive suite finishes.
Parent: `7e72feeed82648b059e6f9884a2ebc56cf0a27a0`.
B1/B2 accepted dependency: `cf01790ca3fa97e22e60a842427a3c582dec5a5b`.

Work used `/workspace/BerylLattice`, branch `work`, without worktrees, subagents,
compiler rebuilds, alternative compiler search, Core changes, or public actions.
The brief's `/workspace/BerylLattice/work` meant the branch, not an existing
subdirectory. Concurrent C1/O1/controller edits were preserved.

## Exact scope and APIs

New production implementation files:

- `axiom/native/v2/operation_allocator.h`
- `axiom/native/v2/operation_allocator.c`
- `axiom/native/v2/buffer_host.h`
- `axiom/native/v2/buffer_host.c`
- `axiom/native/v2/host_protocol.c`

New tests:

- `axiom/tests/native/test_operation_allocator_v2.c`
- `axiom/tests/native/test_buffer_host_v2.c`
- `axiom/tests/test_buffer_host_v2.py`

Minimal B2 retrofit, requiring independent review:

- `axiom/tests/fixtures/core_native_v2/tiny-binding-host.c` now prepares owned
  handles, calls the shared private checked entry, acquires the complete state,
  and destroys owners. Its old allocation/checked-entry implementation is gone.
- `axiom/tests/test_core_native_binding_v2.py` copies the five native inputs,
  retains/revalidates their identities, includes the two implementation C files
  in the fixture translation unit (preserving the existing single-TU LLVM and
  assembly evidence), and checks scratch/body counters in all six case captures.

`core_native_v2.py` is unchanged. No B5 build API, B6 invoke API, O1 transport,
second worker, replacement Core implementation, or new qualification format was
introduced. The B2 helper remains a tiny private binding utility.

The following private C implementation API is frozen for B5/B6 consumption;
it is not an external wire API or arbitrary-pointer validator:

- `ax_i32_bytes`, `ax_size_add`, and `ax_shape_checked` perform checked arithmetic
  before narrowing or allocation. Shape validation enforces H/W in 1..8192,
  P <= 2^23, scratch <= P, exact i32 counts, and checked total requested byte cap.
- `ax_allocator` owns three fixed bookkeeping slots. `ax_allocate`, `ax_lookup`,
  `ax_initialize_copy`, `ax_initialize_zero`, `ax_release`, and
  `ax_allocator_destroy` manage whole i32 allocations. An `ax_handle` contains
  identity, generation and slot; it exposes no data pointer. Owner records are
  trusted private implementation state, never supplied by the process protocol.
- A process-lifetime monotonic serial supplies unique identities/generations
  across slot/host reuse and fails before wrap. There is no address-based identity,
  view, realloc, callback allocator, or relational comparison of unrelated pointers.
- Records retain role, liveness, original base, logical/reserved/initialized
  cells, requested bytes and required alignment. Length equals exact capacity.
  Requested live/peak bytes and alloc/free counts are recorded. `sizeof` the
  fixed registry is separate bookkeeping; malloc usable extent, allocator slack,
  allocator-internal reservation and RSS are **unknown**, not guessed zero.
- `ax_host_prepare` allocates/copies trusted internal input and initial-output
  arrays into separate owned allocations. A preparation OOM destroys partial
  setup. `ax_host_validate` checks the fixed shape, opaque nonzero compiled token,
  handle generation/liveness, roles, initialization, counts/bytes/alignment and
  disjoint allocation identities in constant space. The token is not a source
  hash or proof of admission: B5/B6 must validate full build/invocation identities.
- `ax_host_scratch` is internal after fixed-specialization validation. It allocates
  exact nonzero scratch through the separate operation registry and zeroes every
  cell. Zero scratch makes no allocator request and leaves an empty handle.
- `host_protocol.c` is intentionally included after unchanged generated C and
  the qualified binding assertions, not compiled as a separate translation unit.
  B5 supplies `AX_CORE_PREFLIGHT`, `AX_CORE_BODY`, `AX_FIXED_H`, `AX_FIXED_W`,
  `AX_FIXED_SCRATCH` and `AX_SPECIALIZATION`. Static `ax_checked_invoke` is the
  only helper invocation site. It constructs actual `be_t_List_3ci32_3e`
  descriptors directly; there is no lookalike cast, generated-C rewrite or parser.
- `ax_checked_invoke` validates metadata, performs one preflight, classifies
  unexpected status as integrity failure, rejects source values before scratch,
  allocates/initializes scratch after success, calls body, checks all descriptor
  pointer/length/capacity fields, and releases the original owner through one
  recoverable cleanup path. Input remains exclusively owned throughout.
- `ax_call` distinguishes success/source rejection/boundary/resource/integrity;
  it carries first-invalid, body execution/allocation counters and at most six
  constant-space event names. These are observational records, not clocks,
  independent allocator accounting, complete NativeRunV2 or semantic receipts.
- `ax_host_acquire` copies the entire input/output only after the checked entry;
  `ax_host_destroy` frees original owners without consulting borrowed descriptors.
  Internal acquisition may be used diagnostically after an integrity/resource
  failure; that never promotes it into an accepted complete observation.
- Fault injection (`ax_test_fail_at`, descriptor/preflight fault fields) is compiled
  only with `AX_BUFFER_TESTING`. The B2 production-mode fixture build omits that
  define and has no invocation metadata or protocol selector for faults.

B5/B6 must retain the same sole-owner synchronous contract, actual typedef and
signature/layout assertions, no callbacks/aliases, and full independent state
comparison. They own transport/status mapping, clocks, process supervision,
complete capture classification and actual production build/invoke authority.
The allocator registry is not thread-safe or a hostile same-process sandbox.

## Native tests and exact tool selection

`load_toolchain` loads and revalidates the original receipt:
`/workspace/scratch/cloud-onboarding-native-20261016/qualification-57lxdp8j/receipts/toolchain.json`.
Explicit selectors must equal that receipt's original Core repository and Clang.
No fallback `cc`/`clang` discovery occurs. Both selectors missing with
`AXIOM_V2_REQUIRE_NATIVE=1` is a setup failure, not a pass/skip.

Final command, from `axiom/` (normal omits `-O`):

```sh
AXIOM_TEST_CORE=/workspace/beryl \
AXIOM_TEST_CLANG=/workspace/scratch/cloud-onboarding-native-20261016/toolchain/usr/lib/llvm-19/bin/clang \
AXIOM_V2_REQUIRE_NATIVE=1 \
AXIOM_V2_SANITIZER_ROOT=/workspace/scratch/axiom-scalability-execution-20261016/sanitizer-runtime-jtv4b5ih \
AXIOM_V2_LIFECYCLE_EVIDENCE=/workspace/scratch/axiom-B3-native-lifecycle \
AXIOM_V2_BINDING_EVIDENCE=/workspace/scratch/axiom-B3-native-lifecycle \
PYTHONPATH=src python -O -m unittest \
  tests.test_buffer_host_v2 tests.test_core_native_binding_v2 -v
```

Normal: 18 tests pass (`task-B3-green.txt`). Python `-O`: 18 pass
(`task-B3-optimized.txt`). Python optimization does not imply native optimization:
B3 native tests use exact Clang `-O1`; the B2 fixture keeps its prior `-O0` recipe.
Both include strict incompatible-pointer/implicit-declaration/integer-conversion
errors; native controls retain exact argv/stdout/stderr/exits and binary identity.
The only native compile warning is the unchanged emitted unused List push helper;
no generated bytes were altered to remove it. Clean native executions have empty stderr.

C allocator assertions cover zero request refusal, near-i32 limits, UINT64_MAX,
SIZE_MAX checked addition, byte budgets, min/max admitted shape arithmetic without
large allocation, exact nonzero lengths/reservation/alignment, forced failure at
all three allocation ordinals, full zero initialization from a nonzero poison,
stale release/lookup, cross-registry lookup and 1,000 reused generations.

Each host binary exercises both preparation failure ordinals; 120 alternating
success/first-invalid/scratch-OOM calls; 100 success/OOM calls reusing the same
live preparation; stale handles; wrong specialization; alias handles; incomplete
initialization; hostile logical/shape lengths; invalid preflight status; and
four descriptor-corruption modes (scratch pointer/length, output capacity, input
pointer). Every normal/failure-return invocation acquires full input and output
and compares all cells to independent hand expectations. Source rejection wins
when scratch failure is armed and allocates no scratch. OOM preserves output,
including the prior successful output in the repeated-preparation test. Every
recoverable path returns scratch live state to baseline; final preparation
allocation/free counts balance. Descriptor corruption cleanup uses retained
owner metadata and does not free the corrupted borrowed pointer.

Zero scratch is verified at the native lifecycle allocation boundary and pure
shape checks. The real Core fixture remains materialized 1x2; this is **not**
a compiled inline-kernel semantic qualification. Larger sizes are arithmetic-only.
All six B2 real emitted fixture cases also retain complete JSON state and independent
Python comparisons, plus the existing ABI/symbol/manifest negative controls.

## Sanitizers and independent allocation controls

The original Clang prefix is unchanged. The explicitly selectable
`AXIOM_V2_SANITIZER_ROOT` defaults to the reviewed scratch package root; identical
bytes may be restored at another explicitly selected path. Resource flags use
its `prefix/usr/lib/llvm-19/lib/clang/19` subtree. Each sanitizer build/run checks
all 363 actual resource files, sizes and hashes, exact file set, no symlinks, and
inventory SHA256:
`4ed2d0c3bfa9c2c3507dc4b08dcf051a172c45fccca7e8f4ef8552c1a24b7b91`.
This binds the authenticated package and copied original headers from the separate
prerequisite report; it does not create another compiler configuration.

Actual allocator and host tests each pass combined ASan+UBSan and standalone LSan
with the reviewed options. Deliberate host-owner use-after-free, unchecked size
overflow and omitted cleanup controls each exit 23 with the intended diagnostic.
These deliberately failed processes are not semantic invocations/cleanup receipts.
Missing sanitizer-root control fails before build/run and is retained explicitly;
no unavailable sanitizer configuration is silently treated as a positive result.

Independent linker `--wrap` intercepts direct linked references to malloc, calloc,
realloc, free, aligned_alloc and posix_memalign with `-fno-builtin`. Positive controls
exercise all five allocating interfaces and free. A test-only malloc/free inside
the body observation interval, outside the operation allocator, makes the
interposition assertion fail (SIGABRT, -6); operation-allocator counters alone
would not reveal it. Ordinary fixture calls show one actual scratch malloc on
success, zero on rejection/injected OOM, and zero direct wrapped allocations in
the real emitted body. Operation allocator body attempts are separately zero.

Coverage is deliberately limited to these direct linked references in these tiny
executable configurations. An actual mmap/munmap control succeeds without affecting
wrapped counts, explicitly demonstrating an uncovered allocation path. Calls from
shared-library internals, direct syscalls, custom allocators, other interfaces,
other compilers and other emitted kernels are unqualified. **Complete allocation
accounting remains blocked.** B7 must repeat controls on emitted integration kernels
and review their reachable paths. Balanced counters do not establish stable RSS.

## Evidence, RED/GREEN and remaining obligations

Final exact-current-source proof evidence (Python `-O`):
`/workspace/scratch/axiom-B3-native-lifecycle/axiom-B3-pj_wtn5v`.
Its local read-only diagnostic inventory covers 80 files, 5,137,345 bytes before
the inventory file; all hashes and exact file set were rechecked. Every copied
native source matches current source bytes. The inventory is a test-output index,
not an O1 chunked artifact store or future production qualification authority.
Compiler/runtime transitive closure and hostile same-UID immutability remain
outside the inherited B2 qualification scope.

Final B2 retrofit evidence:
`/workspace/scratch/axiom-B3-native-lifecycle/axiom-B2-binding-v5o86r0u`.
Normal B3 evidence:
`/workspace/scratch/axiom-B3-native-lifecycle/axiom-B3-qphad034`.
The final header adds an API comment after that normal run; the final optimized
run's exact source inventory includes it. Behavior is unchanged.

Retained workspace logs:

- `task-B3-red.txt`: initial intended missing-implementation assertion.
- `task-B3-retrofit-red.txt`: six case subtest errors because the old fixture
  lacks operation allocator fields, before its retrofit.
- `task-B3-first-green.txt`: initial four native/portable tests passed.
- `task-B3-retrofit-green.txt`: initial 17 B2/B3 tests passed.
- `task-B3-controls.txt`: native controls passed, new portable size test failed
  because its helper default imposed a source cap; test corrected to explicit
  no-cap source before final verification.
- `task-B3-green.txt`, `task-B3-optimized.txt`: 18 tests each passed.
- `task-B3-required-native-red.txt`: expected selector failure, exit 5, zero
  native tests executed; not positive native evidence.
- `task-B3-sanitizer-unavailable-red.txt`: expected absent inventory failure,
  exit 1; not positive sanitizer evidence.
- `task-B3-full-suite.txt`: full documented production suite completed without
  native selectors: exit 1, 233 tests in 354.456s, errors=2, skipped=12. The two
  errors are the new B3 portable test using the helper's unintended default cap
  (corrected and passing in both final focused runs) and the concurrent O1
  `test_invocation_v2` import failure for `state_artifacts`. Every exhaustive
  planner/selection test passed. This broad run is not represented as green;
  the 12 skips are unavailable native cases without explicit selectors.
- `task-B3-full-suite-corrections.txt`: corrected portable tests pass; separately
  confirms concurrent O1 `test_invocation_v2` import error under documented
  `PYTHONPATH=src` (`state_artifacts` missing). Routed to O1 owner/controller;
  no O1 file is part of this B3 commit.

The qualified Core receipt continues to report its two known pinned Core IR unit
failures; no compiler rebuild or new claim of a fully green Core baseline was made.
The current host tests have no demonstrated memory defect. This task does not
establish general allocation coverage, native production invocation, full artifact
transport, large execution, oracle admission, timing, performance or publication.
Independent review and later B5/B6/B7/O5/M2 gates remain mandatory.

Final Git source identity: all ten B3 paths match commit `9912ead6c330fb0f302e687aca577fecad005bc0`; concurrent modified O1/controller files are outside that commit. Commit window released to controller/O1. No unresolved B3 test failure remains; the recorded O1 integration failure is owned and being repaired separately.

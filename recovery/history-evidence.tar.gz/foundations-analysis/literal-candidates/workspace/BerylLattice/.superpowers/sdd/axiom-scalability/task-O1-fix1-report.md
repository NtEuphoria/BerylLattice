# O1 fix1: ordinary discovery and exact typed-record revalidation

Status: both integration/reviewer defects fixed in owned files, focused GREEN,
scoped checkpoint committed; independent re-review pending.

## Reproduced defects and concrete fixes

Ordinary product discovery documents `PYTHONPATH=src`, but O1's test-only
state-v1 mapping import used top-level `state_artifacts`, relying on research
being separately added. The owned test now imports
`research.state_artifacts.StateMetadata` through the repository namespace.
No sys.path manipulation or production research imports were introduced; the
same assertion compares production mapping against actual existing StateMetadata.

Reviewer P2 was independently reproduced before the fix. A forged
`ChunkReference(offset=0.0,byte_length=4.0,...)` compared equal to the actual
integer record and passed `VerifiedBlob.revalidate`; `read_i32` could raise
TypeError at a float slice. Boolean zero had the same equality issue. Forged
`VerifiedInvocation` input metadata and mutable `source_bytes=bytearray(...)`
also passed fresh-object equality checks.

Revalidation now explicitly checks exact field/container types before fresh
actual-byte verification and equality comparison:

- Blob references require their exact immutable record type, an absolute Path,
  exact integer byte length and exact lowercase hash strings, without mutating
  caller metadata during validation.
- Blob metadata requires an exact tuple of exact ChunkReference records; each
  offset/length is an exact bounded int, path/hash validates, and full contiguous
  coverage/unique paths/counts are checked. Nested BlobLimits revalidate exact
  integer domains. Cache container/capacity also validates.
- Scalar reads validate reference/limits/tuple and every probed/used chunk before
  offset arithmetic, comparison or slicing, raising ValueError for forged
  float/bool records. Binary search remains logarithmic; no full chunk-table
  scan is introduced per scalar read.
- Invocation revalidation validates nested InvocationLimits, exact immutable
  source bytes, exact manifest type/fields, exact VerifiedBlob types and metadata,
  and consistency of each blob's selected limits. The required host contract
  requires an exact string. Only then does it freshly verify all actual storage,
  readmit source and compare captured fields/content.

No accepted schema or identity preimage changed. No declarations or hashes
replace actual file acquisition. Production modules still import no research.
Protocol documentation now explicitly describes in-memory type revalidation.

## RED / GREEN evidence

Commands run from `/workspace/BerylLattice/axiom`.

1. Import RED:
   `PYTHONPATH=src python -m unittest tests.test_invocation_v2 -v`
   failed with expected `ModuleNotFoundError: No module named 'state_artifacts'`;
   `/tmp/O1-fix1-red.log`.

2. Typed-record RED:
   `PYTHONPATH=src python -m unittest tests.test_artifact_chunks_v2.BlobTests.test_revalidation_rejects_forged_typed_metadata tests.test_invocation_v2.InvocationTests.test_invocation_revalidation_rejects_forged_typed_records -v`
   failed on the intended boundary assertions (6 failures, 1 TypeError);
   `/tmp/O1-fix1-typed-red.log`.

3. Focused normal GREEN:
   `PYTHONPATH=src python -m unittest tests.test_artifact_chunks_v2 tests.test_invocation_v2 -v`
   **14 tests PASS**; `/tmp/O1-fix1-green.log`.

4. Focused optimized GREEN:
   `PYTHONPATH=src python -O -m unittest tests.test_artifact_chunks_v2 tests.test_invocation_v2 -v`
   **14 tests PASS**; `/tmp/O1-fix1-optimized.log`.

5. Explicit mapping regression:
   `PYTHONPATH=src python -m unittest tests.test_invocation_v2.InvocationTests.test_invocation_exact_source_and_family_bindings -v`
   **1 test PASS**; `/tmp/O1-fix1-mapping.log` (also part of both focused suites).

6. Directly affected v1/frontend regression:
   `PYTHONPATH=src python -m unittest tests.test_frontend research/tests/test_state.py -v`
   **28 tests PASS**; `/tmp/O1-fix1-v1.log`.

7. Optimized directly affected regression:
   `PYTHONPATH=src:research python -O -m unittest tests.test_frontend research/tests/test_state.py -v`
   **28 tests PASS**; `/tmp/O1-fix1-v1-optimized.log`.

New tests use dataclasses.replace and object.__new__/object.__setattr__ to forge
records with float/bool chunk offsets/lengths, mutable chunk containers, wrong
chunk types, forged nested limits and mutable retained source bytes. Assertions
require ValueError at revalidation/read boundaries, preserving normal/-O guards.
No new source inputs/shapes beyond the disclosed 1x1 case were used.

Scoped `git diff --check` passes. The scoped diff touches only five O1-owned
paths: two production modules, two tests, and protocol documentation. Full
existing source/input/output mutation revalidation and byte-comparison tests
continue to pass. Cache capacity, stable-file assumptions and I/O amplification
remain documented and unchanged, with bounded field validation added to scalar
reads.

Commit: `64da9e296f6c82f11ce5410c1421677fc6fc990f`, actual parent
`9912ead6c330fb0f302e687aca577fecad005bc0`, message
`fix(axiom): validate exact v2 transport record types`. Exactly five O1-owned
paths committed after controller window grant; window released immediately.
Final focused normal/-O runs each passed 14 tests (0.078s). The local coordination
report is ignored and outside tracked ownership. Independent reviewer will
re-review the actual scoped fix checkpoint; no approval is presumed.

import hashlib
import json
import pathlib
import re

ROOT = pathlib.Path('/workspace/scratch/axiom-recovery')
OUT = ROOT / 'foundations-analysis'
OWNED = re.compile(r'implement_c2|review_c2|implement_b1|review_b1|implement_c1|review_c1|implement_b2|review_b2|implement_b3|implement_o1|review_o1|review_scalability_foundations|proof_rule_advice|scalability_preflight|prepare_sanitizer_runtime')
sources = [ROOT / 'history' / 'page-002.json'] + [p for p in sorted((ROOT / 'history' / 'agents').glob('*.json')) if OWNED.search(p.name)]
changes = []
commands = []
hashes = []
pages = []
subagents = {}
for p in sources:
    d = json.loads(p.read_text())
    pages.append({'path': str(p), 'page': d.get('page'), 'thread': d.get('thread'), 'turn_count': len(d.get('turns', []))})
    for t in d.get('turns', []):
        for i, item in enumerate(t.get('items', [])):
            provenance = {'page': str(p), 'turn': t['id'], 'turn_started_at': t.get('startedAt'), 'item_index': i, 'item_id': item.get('id')}
            if item.get('type') == 'fileChange':
                for n, change in enumerate(item.get('changes', [])):
                    text = change.get('diff', {}).get('text', '')
                    rec = {**provenance, 'change_index': n, 'status': item.get('status'), **change, 'text_sha256': hashlib.sha256(text.encode()).hexdigest()}
                    changes.append(rec)
                    if change.get('kind', {}).get('type') == 'add' and not change.get('diff', {}).get('truncated'):
                        dest = OUT / 'complete-adds' / p.stem / (t['id'] + '-' + str(i) + '-' + str(n)) / change['path'].lstrip('/')
                        dest.parent.mkdir(parents=True, exist_ok=True)
                        dest.write_text(text)
                        rec['candidate_path'] = str(dest)
            if item.get('type') == 'commandExecution':
                command = item.get('command', '')
                output = item.get('output', {})
                commands.append({**provenance, 'command': command, 'cwd': item.get('cwd'), 'status': item.get('status'), 'exit_code': item.get('exitCode'), 'output': output, 'possible_source_write': bool(re.search(r'write_text|write_bytes|cat\s+[^\n]*>|apply_patch|tee\s', command)), 'possible_source_read': bool(re.search(r'\bcat\b|\bsed\b|read_text|read_bytes|git show', command))})
                for match in re.finditer(r'\b[0-9a-f]{64}\b', str(output.get('text', ''))):
                    hashes.append({**provenance, 'sha256': match.group(), 'context': output.get('text', '')[max(0, match.start()-200):match.end()+200]})
            if item.get('type') == 'subAgentActivity':
                subagents[item.get('agentThreadId')] = item.get('agentPath')
OUT.mkdir(exist_ok=True)
for name, data in [('changes.json', changes), ('commands.json', commands), ('hashes.json', hashes), ('pages.json', pages), ('nested-agents.json', subagents)]:
    (OUT / name).write_text(json.dumps(data, indent=2) + '\n')
summary = {'pages': len(pages), 'file_changes': len(changes), 'complete_adds': sum('candidate_path' in x for x in changes), 'truncated_changes': sum(x.get('diff', {}).get('truncated', False) for x in changes), 'commands': len(commands), 'possible_source_writes': sum(x['possible_source_write'] for x in commands), 'sha256_occurrences': len(hashes), 'pending_pagination': [x['path'] for x in pages if x.get('page', {}).get('hasMore')], 'paths': sorted(set(x['path'] for x in changes))}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))

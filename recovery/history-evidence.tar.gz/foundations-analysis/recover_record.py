import ast
import hashlib
import json
import pathlib
import re
import shlex

ROOT = pathlib.Path('/workspace/scratch/axiom-recovery')
OUT = ROOT / 'foundations-analysis'
SOURCE = ROOT / 'history/page-002.json'
TARGET = '/workspace/BerylLattice/docs/scalability-implementation-record.md'

def apply_hunks(source, patch):
    lines = source.splitlines(keepends=True)
    out = []
    cursor = 0
    rows = patch.splitlines(keepends=True)
    i = 0
    while i < len(rows):
        m = re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', rows[i])
        if not m:
            assert not rows[i].strip(), repr(rows[i])
            i += 1
            continue
        old_start = int(m.group(1)) - 1
        old_count = int(m.group(2) or 1)
        new_count = int(m.group(4) or 1)
        assert old_start >= cursor
        out.extend(lines[cursor:old_start])
        i += 1
        old, new = [], []
        while i < len(rows) and not rows[i].startswith('@@ '):
            row = rows[i]
            if row.startswith(' '):
                old.append(row[1:]); new.append(row[1:])
            elif row.startswith('-'):
                old.append(row[1:])
            elif row.startswith('+'):
                new.append(row[1:])
            else:
                assert not row.strip(), repr(row)
            i += 1
        assert len(old) == old_count, (len(old), old_count)
        assert len(new) == new_count, (len(new), new_count)
        assert lines[old_start:old_start+old_count] == old, ''.join(old)
        out.extend(new)
        cursor = old_start + old_count
    out.extend(lines[cursor:])
    return ''.join(out)

current = None
events = []
for turn in json.loads(SOURCE.read_text())['turns']:
    for index, item in enumerate(turn['items']):
        if item['type'] == 'fileChange':
            for change in item['changes']:
                if change['path'] != TARGET:
                    continue
                assert not change['diff'].get('truncated')
                if change['kind']['type'] == 'add':
                    current = change['diff']['text']
                else:
                    current = apply_hunks(current, change['diff']['text'])
                events.append({'item_index': index, 'item_id': item.get('id'), 'method': 'strict ' + change['kind']['type']})
        elif item['type'] == 'commandExecution' and index in (157, 216, 413) and turn['id'] == '01a14266-ccd6-7738-b9af-25e05eecc45e':
            shell = shlex.split(item['command'])[2]
            code = shell.split("<<'PY'\n", 1)[1].rsplit('\nPY', 1)[0]
            tree = ast.parse(code)
            values = {}
            def evaluate(node):
                if isinstance(node, ast.Constant) and isinstance(node.value, str):
                    return node.value
                if isinstance(node, ast.Name):
                    return values[node.id]
                if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
                    return evaluate(node.left) + evaluate(node.right)
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                    if node.func.attr == 'read_text':
                        assert isinstance(node.func.value, ast.Name) and node.func.value.id == 'p'
                        return current
                    if node.func.attr == 'replace':
                        value = evaluate(node.func.value)
                        old, new = [evaluate(a) for a in node.args]
                        assert value.count(old) == 1, (index, old, value.count(old))
                        return value.replace(old, new)
                raise ValueError(ast.dump(node))
            for node in tree.body:
                if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id in ('s', 'needle'):
                    values[node.targets[0].id] = evaluate(node.value)
            current = values['s']
            events.append({'item_index': index, 'item_id': item.get('id'), 'method': 'statically evaluated exact literal replacements; no historical code executed'})
assert current is not None
destination = OUT / 'scalability-implementation-record-foundation.md'
destination.write_text(current)
sha = hashlib.sha256(destination.read_bytes()).hexdigest()
candidate = {'historical_path': TARGET, 'candidate_file': str(destination), 'sha256': sha, 'provenance': {'source': str(SOURCE), 'method': 'complete add, strict patch hunks and three statically evaluated literal-replacement commands', 'events': events, 'historical_boundary': 'end of scalability foundations turn 01a14266-ccd6-7738-b9af-25e05eecc45e; before continuation updates'}}
(OUT / 'supplemental-candidates.json').write_text(json.dumps([candidate], indent=2) + '\n')
print(json.dumps(candidate, indent=2))

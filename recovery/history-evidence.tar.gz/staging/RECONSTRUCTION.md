# Historical byte reconstruction

Read `candidate-index.json` as the authoritative index; `candidate-manifest.tsv` gives one row per historical path and byte candidate, with source evidence. Content resides at `objects/<sha256>`. Objects not referenced in the index may be leftovers from previous runs and are not accepted complete candidates.

This reconstruction engine does not execute historical commands or Python code. Independent supplemental seed methods are recorded separately; generated fixtures do not claim original byte identity without a recorded digest. Sources are complete file additions, complete observed single-file `cat` output, literal quoted shell heredocs, literal Python `Path.write_text` arguments, and strict forward/reverse unified-hunk applications to recovered matching bytes. Literal writes are candidates: conditional execution and current/latest version are not asserted. Patch line counts, exact positions, context and removal bytes must match. Each patch operation is used at most once in an ancestry, preventing repeated append-only hunk application. Deletion events never destroy earlier versions. Incomplete records remain separately labelled fragments; they are not complete-file candidates.

Selection is separate from byte recovery. The selector withholds conflicting latest versions across threads. Any restore_eligible:false provenance vetoes its exact path and digest, even when another source is eligible. Controller-excluded unfinished paths, unsuccessful literal-write commands and Python syntax failures are quarantined from the exported baseline. Tool redaction placeholders are incomplete fragments, never complete candidates. Exact recorded SHA256 or independently logged Git blob-prefix checks are preferred; the index distinguishes those forms of evidence.

Export restores regular-file bytes, not symlinks or Git metadata. Executable permissions are restored only when explicit historical mode evidence is recorded in the manifest; other files use 0644. A preliminary tree and final tree have separate names. Fresh exports are built separately before replacing their named tree; earlier trees are retained under `*-previous-*` and are not current outputs.

The index preserves input source hashes, reconstruction script hash, original history file/item/change references, candidate hashes, replay bases, unresolved patches and truncated fragments. Cross-thread chronology, whether any version was committed, and which candidate was latest require independent evidence. A matching supplied SHA256 identifies exact bytes only.

Rerun: `python /workspace/scratch/axiom-recovery/reconstruct.py`. Existing history files are read, and outputs remain within staging. This does not restore repositories, Git commits, toolchains or build dependencies.

Current pass:

```json
{
  "history_files": 168,
  "paths": 313,
  "fragments": 19,
  "truncated_command_outputs": 364,
  "versions": 650,
  "patches": 150,
  "unapplied_patches": 38,
  "issues": 18,
  "rounds": 6,
  "known_hash_matches": {
    "frontend": [
      "/workspace/BerylLattice/axiom/src/axiom/frontend.py"
    ],
    "model": [
      "/workspace/BerylLattice/axiom/src/axiom/model.py"
    ],
    "source_oracle": [
      "/workspace/BerylLattice/axiom/research/source_oracle.py"
    ]
  }
}
```

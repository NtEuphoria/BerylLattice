# Research and documentation recovery report

Recovery is data-only. Historical shell and Python programs were parsed as text; no historical commands were executed. Every candidate below has complete original bytes from recorded adds/updates, reads or copy operations. Fragments were joined only on exact text, and assembled large documents were admitted only after matching independently recorded historical hashes.

| Historical path | Bytes | SHA256 | Evidence |
|---|---:|---|---|
| `/workspace/BerylLattice/docs/superpowers/plans/2026-10-16-axiom-scalability/design.md` | 24592 | `11b07794c565bd32003e8f4b9289bed7907c303bff39b6164b520736d4cd4234` | exact-overlap-fragment-assembly-historical-hash-verified |
| `/workspace/BerylLattice/docs/superpowers/plans/2026-10-16-axiom-scalability/03-independent-oracle-and-evidence.md` | 34785 | `49c7b368b99d99e8c27a1812b1b1fec4624ba3cb1bec9e226157d352458a012a` | exact-overlap-fragment-assembly-historical-hash-verified |
| `/workspace/BerylLattice/docs/reviews/2026-10-16-prototype.md` | 10072 | `a4b5a03b5b7fe86977013eb199624923cdbf4f4a57e926a76c6045ba82654dbd` | literal-source-destination-file-copy |
| `/workspace/BerylLattice/docs/reviews/axiom-scalability-foundations.md` | 10573 | `30075af3893be6c7e081a80523df24242836b1188b9e44b17423d648bcaf90a6` | literal-source-destination-file-copy |
| `/workspace/BerylLattice/docs/superpowers/plans/2026-10-16-axiom-bounded-source-admission.md` | 12328 | `61b11fc862cc9d59e0f2fefd625eda5c29d0b2e8bf5fbc7bc087a7c8b72b2655` | existing-candidate-independent-historical-hash-selection |
| `/workspace/BerylLattice/docs/superpowers/plans/2026-10-16-axiom-proof-oracle-continuation.md` | 18167 | `4014e1f9b1b707d1c165f30c4c786eeb57932570b416cecd028c419bb72d251d` | existing-candidate-independent-historical-hash-selection |
| `/workspace/BerylLattice/docs/superpowers/specs/2026-10-16-axiom-proof-oracle-continuation-design.md` | 10586 | `e61cf3915e07265eacb8ccc6da6db219860e6e251556f1963a8213e3e19db474` | existing-candidate-independent-historical-hash-selection |
| `/workspace/BerylLattice/docs/superpowers/plans/2026-10-16-axiom-scalability/review-architecture.md` | 10602 | `6a1026faa1e436e73ff6702d96a1c234463437928a9c53dc5d9de4652d78a807` | complete-chronological-fileChange-chain-and-full-observed-read-match |
| `/workspace/BerylLattice/docs/implementation-record.md` | 12193 | `5693c2f74ee5d1305c44dae2e650b43eb255ca5a4c28be176dbfaa0b9262fdf5` | complete-chronological-fileChange-chain-and-full-observed-read-match |
| `/workspace/scratch/axiom-foundations-2026-10-15/axiom-v0-design.md` | 20187 | `af3c0ee5d49e96f882ff215345fa2ae0b6c7e412a3aa90c9328e9cb2f79c1454` | existing-candidate-independent-historical-hash-selection |
| `/workspace/scratch/axiom-foundations-2026-10-15/performance/protocol.md` | 24087 | `252ce30a5d8df97302ac70e4993433cde68dd3d97e73c8bffa5ec15623abe975` | existing-candidate-independent-historical-hash-selection |
| `/workspace/scratch/axiom-foundations-2026-10-15/performance/harness-gaps.md` | 9011 | `2b3745ec446edffe8149474ddebd3b2360fe0a560345e5f8f053e261bd2e17ce` | existing-candidate-independent-historical-hash-selection |

## Remaining gaps

The large scalability master README and subsystem plans 01, 02, 04 and 05 are not yet completely recovered. Their initial additions exceed the history API 20,000-character output limit. Recovered suffixes and update hunks do not currently cover all missing text with sufficient version certainty. No missing prose was invented. All observed fragments, line positions, provenance and original history remain retained.

The checker plan has a recorded Git blob identity b0861456192a967b8f270aae03aa1b30b481e8de, but no assembled candidate matches it; missing coverage includes the C6/C7 region around lines 187–203. This is an explicit gap, not a recovered document.

Additional original foundation/research docs with truncated additions (including semantics contract, Core interface, search validation and some refinement reviews) remain represented by original history fragments unless another recovery lane completes them.

Latest scratch document recommendations are in latest-scratch-recommendations.json. Prototype contract and resource-contract research have later full reads from non-overlapping later turns. Research-program has a final strict root patch after its initial complete add; a prior-reader turn overlaps the root turn, so latest selection should inspect the known patch chronology.

supplemental-candidates.json is the machine-readable handoff. Its provenance records link original source JSON and item IDs; fragments.json retains all observed fragments for the seven scalability plans. Exact SHA256 checks above were rerun after writing candidates. No original Git commit history, historical review approval, or test success is claimed by this recovery.

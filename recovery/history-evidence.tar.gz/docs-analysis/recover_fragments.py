import pathlib,json,re,shlex,importlib.util,hashlib,collections
BASE=pathlib.Path('/workspace/scratch/axiom-recovery'); OUT=BASE/'docs-analysis'
spec=importlib.util.spec_from_file_location('engine',BASE/'reconstruct.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
ROOT='/workspace/BerylLattice/docs/superpowers/plans/2026-10-16-axiom-scalability/'
NAMES=['README.md','design.md','01-core-buffer-and-native-build.md','02-compact-plans-and-checker.md','03-independent-oracle-and-evidence.md','04-native-measurement-and-experiments.md','05-research-and-publication.md']
frags=collections.defaultdict(list);patches=collections.defaultdict(list); records={}
def add(path,text,prov,start=None,eof=False,prefix=False):
 if path not in [ROOT+n for n in NAMES] or not text:return
 lines=text.splitlines(keepends=True)
 if not lines[-1].endswith('\n'):lines.pop() # incomplete observation last line
 if not lines:return
 key=(tuple(lines),eof,prefix)
 if any(f['key']==key for f in frags[path]):return
 frags[path].append({'lines':lines,'key':key,'provenance':prov,'start':start,'eof':eof,'prefix':prefix})
for p in sorted((BASE/'history').rglob('*.json')):
 d=json.loads(p.read_text())
 if not isinstance(d,dict):continue
 for t in d.get('turns',[]):
  for ix,i in enumerate(t.get('items',[])):
   prov={'source':str(p),'item_id':i.get('id'),'turn_id':t.get('id'),'item_index':ix,'turn_startedAt':t.get('startedAt')}
   records[i.get('id')]=(i,prov)
   if i.get('type')=='fileChange':
    for c in i.get('changes',[]):
     path=c['path'];df=c['diff'];txt=df['text']
     if c['kind']['type']=='add':add(path,txt,prov,start=1,eof=not df.get('truncated'),prefix=True)
     elif not df.get('truncated'):
      try:hs=e.parse_patch(txt)
      except ValueError:continue
      patches[path].append((hs,prov))
      for h in hs:
       add(path,''.join(h['before']),{**prov,'hunk':'before','hunk_old':h['old']},start=h['old'])
       add(path,''.join(h['after']),{**prov,'hunk':'after','hunk_new':h['new']},start=h['new'])
   if i.get('type')!='commandExecution' or i.get('exitCode')!=0:continue
   script=e.unwrap(i['command']); text=i.get('output',{}).get('text','');trunc=i.get('output',{}).get('truncated',True)
   if '\n' in script:continue
   # Parse only prefix read commands, whose outputs begin at a known offset.
   chunks=re.split(r'\s*(?:&&|;)\s*(?=(?:sed|cat|nl|rg|git|tail|head)\b)',script)
   remaining=text.splitlines(keepends=True)
   for ci,chunk in enumerate(chunks):
    try:a=shlex.split(chunk)
    except ValueError:break
    if len(a)>=2 and a[0]=='cat' and all(not x.startswith('-') for x in a[1:]) and '|' not in a:
     for path in a[1:]:
      path=e.pathof(path,i.get('cwd'));# if first file incomplete, no safe delimiter for next
      add(path,''.join(remaining),{**prov,'command_fragment':chunk},start=1,eof=not trunc and len(a)==2 and len(chunks)==1,prefix=True)
      break
     break
    elif len(a)==4 and a[:2]==['sed','-n']:
     m=re.fullmatch(r'(\d+),(\d+)p',a[2])
     if not m:break
     lo,hi=map(int,m.groups());n=hi-lo+1;path=e.pathof(a[3],i.get('cwd'))
     observed=remaining[:n]
     add(path,''.join(observed),{**prov,'command_fragment':chunk},start=lo,eof=not trunc and len(remaining)<n and ci==len(chunks)-1,prefix=lo==1)
     if len(remaining)<n:break
     remaining=remaining[n:]
    elif a[:2]==['nl','-ba'] and len(a)>=3:
     path=e.pathof(a[2],i.get('cwd'));numbered=[];lo=None;last=None
     for line in remaining:
      m=re.match(r'^\s*(\d+)\t(.*\n)$',line)
      if not m:break
      n=int(m[1]);body=m[2]
      if last is not None and n!=last+1:
       add(path,''.join(numbered),{**prov,'command_fragment':chunk},start=lo,prefix=lo==1)
       numbered=[];lo=None
      if lo is None:lo=n
      numbered.append(body);last=n
     add(path,''.join(numbered),{**prov,'command_fragment':chunk},start=lo,eof=not trunc and len(chunks)==1 and ('|' not in a or (len(a)>4 and a[-2].endswith('p'))),prefix=lo==1)
     break
    else:break
# Manually justified finite extraction with an observed doc boundary, avoiding guessed line counts.
i,prov=records['exec-475a6a2b-1172-47d1-a380-913dd1395654'];s=i['output']['text'];marker='## Native checked entry'
# First file ends before the following design excerpt; source wc below used instead of content guessing.
# Pull wc evidence into report only.
(OUT/'fragments.json').write_text(json.dumps({p:[{k:v for k,v in f.items() if k!='key'} for f in fs] for p,fs in frags.items()},indent=2))
print({pathlib.Path(p).name:len(fs) for p,fs in frags.items()})
# Build exact-line overlap graph: no replacement or invented text. Accept a complete assembly only with recorded hash later.
expected={ROOT+'design.md':('sha256','11b07794c565bd32003e8f4b9289bed7907c303bff39b6164b520736d4cd4234'),ROOT+'03-independent-oracle-and-evidence.md':('sha256','49c7b368b99d99e8c27a1812b1b1fec4624ba3cb1bec9e226157d352458a012a'),ROOT+'02-compact-plans-and-checker.md':('gitblob','b0861456192a967b8f270aae03aa1b30b481e8de')}
verified=[]; stats={}
for path in expected:
 fs=frags[path];type_,target=expected[path]
 q=collections.deque();seen=set();completed={};maxlines=1000
 def push(lines,trace,eof=False):
  text=''.join(lines);h=hashlib.sha256(text.encode()).hexdigest()
  if h in seen:return
  seen.add(h)
  if len(seen)>20000:return
  q.append((lines,trace,eof))
 for n,f in enumerate(fs):
  if f['prefix']:push(f['lines'],[{'fragment':n}],f['eof'])
 while q:
  lines,trace,terminal=q.popleft();data=''.join(lines).encode()
  if path.endswith('03-independent-oracle-and-evidence.md') and len(data)>=34785 and hashlib.sha256(data[:34785]).hexdigest()==target: data=data[:34785]
  digest=hashlib.sha256(data).hexdigest() if type_=='sha256' else hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  if digest==target:
   h=hashlib.sha256(data).hexdigest();fp=OUT/(pathlib.Path(path).stem+'-'+h+'.md');fp.write_bytes(data)
   verified.append({'historical_path':path,'candidate_file':str(fp),'sha256':h,'provenance':{'source':str(OUT/'fragments.json'),'method':'exact-overlap-fragment-assembly-historical-hash-verified','expected_sha256':h,'historical_verification':{'kind':type_,'expected':target},'trace':trace,'fragments':[f['provenance'] for f in fs]}})
   print('VERIFIED',path,h,len(data));break
  # Join on nontrivial exact-line overlap ending at current prefix; only extend, never erase/replace.
  for n,f in enumerate(fs):
   fl=f['lines'];maxov=min(len(lines),len(fl))
   for ov in range(maxov,1,-1):
    if len(''.join(fl[:ov]))<100:continue
    if lines[-ov:]==fl[:ov] and len(fl)>ov:
     push(lines+fl[ov:],trace+[{'fragment':n,'overlap_lines':ov}],f['eof']);break
  # Apply complete patch if all hunks fall inside known prefix; keeps suffix unchanged by strict replay.
  for n,(hs,prov) in enumerate(patches[path]):
   for reverse in (False,):
    out=e.apply(''.join(lines),hs,reverse)
    if out is not None and out!=''.join(lines):push(out.splitlines(keepends=True),trace+[{'patch':prov,'reverse':reverse}],terminal)
   for hi,h in enumerate(hs):
    before=''.join(h['before']);after=''.join(h['after']);whole=''.join(lines)
    if len(before)>100 and whole.count(before)==1:
     out=whole.replace(before,after)
     if out!=whole:push(out.splitlines(keepends=True),trace+[{'patch':prov,'single_hunk':hi,'method':'unique-exact-before-context'}],terminal)
 stats[path]={'states':len(seen),'verified':any(v['historical_path']==path for v in verified),'max_lines':max([len(f['lines']) for f in fs],default=0)}
 print('STATS',pathlib.Path(path).name,stats[path])
(OUT/'supplemental-candidates.json').write_text(json.dumps(verified,indent=2))
(OUT/'fragment-recovery-stats.json').write_text(json.dumps(stats,indent=2))

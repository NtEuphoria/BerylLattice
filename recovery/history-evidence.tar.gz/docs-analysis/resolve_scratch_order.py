import pathlib,json,hashlib,importlib.util
base=pathlib.Path('/workspace/scratch/axiom-recovery');out=base/'docs-analysis'
spec=importlib.util.spec_from_file_location('e',base/'reconstruct.py');e=importlib.util.module_from_spec(spec);spec.loader.exec_module(e)
targets=['/workspace/scratch/axiom-program-2026-10-15/prototype-contract.md','/workspace/scratch/axiom-program-2026-10-15/research-program.md']
allitems=[]
for p in (base/'history').rglob('*.json'):
 d=json.loads(p.read_text())
 if not isinstance(d,dict):continue
 for t in d.get('turns',[]):
  for n,i in enumerate(t.get('items',[])):
   if i['type']=='fileChange':
    for c in i['changes']:
     if c['path'] in targets:allitems.append((t['startedAt'],n,c,{'source':str(p),'item_id':i['id'],'item_index':n,'turn_startedAt':t['startedAt']}))
c=[]
for path in targets:
 seq=sorted(x for x in allitems if x[2]['path']==path);text=None;trace=[]
 for _,_,change,prov in seq:
  assert not change['diff']['truncated'],path
  if change['kind']['type']=='add':
   assert text is None,path
   text=change['diff']['text'];trace.append({**prov,'method':'fileChange-add'})
  else:
   hs=e.parse_patch(change['diff']['text']);new=e.apply(text,hs);assert new is not None, (path,prov)
   text=new;trace.append({**prov,'method':'strict-forward-fileChange-hunks'})
 data=text.encode();h=hashlib.sha256(data).hexdigest();fp=out/(pathlib.Path(path).stem+'-'+h+'.md');fp.write_bytes(data)
 c.append({'historical_path':path,'candidate_file':str(fp),'sha256':h,'provenance':{**trace[-1],'method':'complete-chronological-fileChange-chain','trace':trace,'verification':'Full recorded add followed by every recorded fileChange in same-author chronology; all hunks matched strict positions and contexts. Separate command mutations require checking.'}})
 print(path,len(data),h,len(trace))
(out/'ordered-scratch-candidates.json').write_text(json.dumps(c,indent=2))

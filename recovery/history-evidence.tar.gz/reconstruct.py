#!/usr/bin/env python3
"""Recover candidate bytes from history without executing historical commands.
All output remains in staging. Timeline and latest-version selection are deliberately unresolved.
"""
import argparse, ast, collections, csv, hashlib, json, pathlib, posixpath, re, shlex, tempfile, uuid
ROOT=pathlib.Path(__file__).parent
OUT=ROOT/'staging'; OBJECTS=OUT/'objects'
KNOWN={'frontend':'2b6f291ce350fa32c1a09e64a0de425a3d02e9633535b13949fac1a8063afa71','model':'dd45837debec9302a19d194d1fe8805176c902164f4432fc5391bcc274b96408','source_oracle':'a29677691160c2f9b19fa580f47429760ca647d9ff0d7340d66ea07a35dbcb8f'}
candidates=collections.defaultdict(dict); issues=[]; fragments=[]; truncated_outputs=[]; updates=[]; events=[]; stats=collections.Counter(); seen=set(); sources=[]
def pathof(p,cwd):
 if not isinstance(p,str) or not p or '\0' in p:return None
 return posixpath.normpath(p if p.startswith('/') else posixpath.join(cwd or '/workspace/BerylLattice',p))
def add(p,text,prov,operations=()):
 failures=[record for record in prov.get('literal_write_failures',[]) if record['path']==p]
 if failures:prov={**prov,'explicit_creation_failed':True,'creation_failure_evidence':failures}
 if not p or not p.startswith(('/workspace/','/tmp/')) or not isinstance(text,(str,bytes)):return
 data=text if isinstance(text,bytes) else text.encode('utf-8'); h=hashlib.sha256(data).hexdigest()
 if re.search(rb'\[(?:REDACTED|SECRET_REDACTED)[^\]\r\n]*\]|<(?:REDACTED|SECRET_REDACTED)[^>\r\n]*>',data,re.I):
  (OBJECTS/h).write_bytes(data)
  fragment={**prov,'path':p,'sha256':h,'bytes':len(data),'warning':'REDACTED TOOL PLACEHOLDER: incomplete evidence, never restore-ready'}
  if fragment not in fragments:fragments.append(fragment)
  return
 if h not in candidates[p]:
  candidates[p][h]={'sha256':h,'bytes':len(data),'provenance':[],'used_patch_operations':list(operations)}; (OBJECTS/h).write_bytes(data)
 entry=candidates[p][h]
 if len(operations)<len(entry['used_patch_operations']):entry['used_patch_operations']=list(operations)
 if prov not in entry['provenance']:entry['provenance'].append(prov)
 return h

def walk(x, context=None):
 context=dict(context or {})
 if isinstance(x,dict):
  if 'startedAt' in x and isinstance(x.get('items'),list):
   context.update({'turn_id':x.get('id'),'turn_startedAt':x.get('startedAt'),'turn_completedAt':x.get('completedAt')})
  if x.get('type') in ('fileChange','commandExecution'):yield x,context
  for key,v in x.items():
   if key=='items' and isinstance(v,list):
    for index,item in enumerate(v):yield from walk(item,{**context,'item_index':index})
   else:yield from walk(v,context)
 elif isinstance(x,list):
  for v in x:yield from walk(v,context)

def unwrap(cmd):
 try:
  args=shlex.split(cmd)
  if len(args)==3 and args[0] in ('bash','/bin/bash','sh','/bin/sh') and args[1] in ('-lc','-c'):return args[2]
 except ValueError:pass
 return cmd

def literal(node):
 try:return ast.literal_eval(node)
 except (ValueError,TypeError,SyntaxError):return None

def python_writes(body,cwd,prov):
 try:tree=ast.parse(body)
 except SyntaxError:return
 bindings=collections.defaultdict(set)
 for node in ast.walk(tree):
  if isinstance(node,ast.Assign):
   for target in node.targets:
    if isinstance(target,ast.Name):
     v=node.value; resolved=None
     if isinstance(v,ast.Call) and isinstance(v.func,ast.Name) and v.func.id=='Path' and len(v.args)==1:resolved=pathof(literal(v.args[0]),cwd)
     bindings[target.id].add(resolved)
  elif isinstance(node,(ast.For,ast.comprehension)) and isinstance(node.target,ast.Name):bindings[node.target.id].add(None)
  elif isinstance(node,ast.arg):bindings[node.arg].add(None)
 paths={key:next(iter(values)) for key,values in bindings.items() if len(values)==1 and None not in values}
 # Literal candidates only; conditional execution is not asserted.
 for node in ast.walk(tree):
  if not (isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=='write_text' and len(node.args)>=1):continue
  text=literal(node.args[0]); receiver=node.func.value; p=None
  if isinstance(receiver,ast.Name):p=paths.get(receiver.id)
  elif isinstance(receiver,ast.Call) and isinstance(receiver.func,ast.Name) and receiver.func.id=='Path' and len(receiver.args)==1:
   p=pathof(literal(receiver.args[0]),cwd)
  if p and isinstance(text,str):add(p,text,{**prov,'method':'python-literal-write-candidate','line':node.lineno,'execution_not_asserted':True})

def shell_write_failures(command_item,cwd):
 output=command_item.get('output',{})
 text=output.get('text','') if isinstance(output,dict) else ''
 failures=[]
 for line in text.splitlines():
  match=re.match(r'^[^:\n]*sh:\s+(?:line\s+\d+:\s+)?(.+?):\s+(No such file or directory|Permission denied|Read-only file system|Is a directory|Not a directory|File exists)\s*$',line)
  if match:
   target=match[1].strip().strip("'\"");resolved=pathof(target,cwd)
   if resolved:failures.append({'path':resolved,'diagnostic':line,'reason':match[2]})
 return failures

def commands(item,prov):
 prov={**prov,'command_exitCode':item.get('exitCode'),'command_status':item.get('status')}
 cmd=unwrap(item.get('command','')); cwd=item.get('cwd') or '/workspace/BerylLattice'
 prov={**prov,'literal_write_failures':shell_write_failures(item,cwd)}
 output=item.get('output',{})
 if isinstance(output,dict) and output.get('truncated'):
  truncated_outputs.append({**prov,'originalChars':output.get('originalChars'),'observed_chars':len(output.get('text','')),'note':'Truncated command observation preserved only in raw source; not accepted as full-file bytes.'})
 # Complete, quoted delimiter heredocs only: no parameter/command expansion.
 lines=cmd.splitlines(keepends=True); i=0
 while i<len(lines):
  header=lines[i].rstrip('\r\n'); match=re.search(r"<<\s*(['\"])([A-Za-z0-9_]+)\1",header)
  if not match:i+=1;continue
  end=i+1
  while end<len(lines) and lines[end].rstrip('\r\n')!=match[2]:end+=1
  if end==len(lines):issues.append({**prov,'reason':'unterminated quoted heredoc','line':i+1});break
  body=''.join(lines[i+1:end]); prefix=header[:match.start()]+header[match.end():]
  # Avoid inferring effects of complex shell expressions; only literal cat writes.
  cm=re.fullmatch(r'\s*cat\s*>\s*([^;&|]+)\s*',prefix)
  if cm:
   try:
    args=shlex.split(cm[1]); p=pathof(args[0],cwd) if len(args)==1 and not re.search(r'[$`*?\[\]{}]',args[0]) else None
   except ValueError:p=None
   if p:add(p,body,{**prov,'method':'literal-quoted-cat-heredoc','line':i+1})
  if re.search(r'(?:^|[;&])\s*(?:python3?|python[0-9.]+)\s+-\s*$',prefix):python_writes(body,cwd,prov)
  i=end+1
 # A single full-file cat observation has explicit file-to-output identity.
 try:args=shlex.split(cmd)
 except ValueError:return
 output=item.get('output',{})
 if len(args)==2 and args[0]=='cat' and not args[1].startswith('-') and not any(c in args[1] for c in '$`*?;|&<>'):
  if item.get('exitCode')==0 and isinstance(output,dict) and output.get('truncated') is False:
   add(pathof(args[1],cwd),output.get('text'),{**prov,'method':'single-cat-observed-output'})

HUNK=re.compile(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*$')
def parse_patch(s):
 hunks=[]; current=None
 for line in s.splitlines(keepends=True):
  m=HUNK.match(line.rstrip('\r\n'))
  if m:
   current={'old':int(m[1]),'new':int(m[3]),'oldn':int(m[2] or 1),'newn':int(m[4] or 1),'before':[],'after':[]};hunks.append(current);continue
  if current is None:
   if line.strip():raise ValueError('text outside hunk')
   continue
  if line.startswith('\\ No newline at end of file'):
   if current.get('last') in (' ','-') and current['before']:current['before'][-1]=current['before'][-1].rstrip('\n')
   if current.get('last') in (' ','+') and current['after']:current['after'][-1]=current['after'][-1].rstrip('\n')
   continue
  if not line or line[0] not in ' +-':raise ValueError('invalid hunk line')
  current['last']=line[0]
  if line[0] in ' -':current['before'].append(line[1:])
  if line[0] in ' +':current['after'].append(line[1:])
 if not hunks:raise ValueError('no hunks')
 for h in hunks:
  if len(h['before'])!=h['oldn'] or len(h['after'])!=h['newn']:raise ValueError('hunk count mismatch')
 return hunks

def apply(data,hunks,reverse=False):
 lines=data.splitlines(keepends=True); offset=0
 for h in hunks:
  before=h['after'] if reverse else h['before'];after=h['before'] if reverse else h['after'];start=h['new'] if reverse else h['old']; n=h['newn'] if reverse else h['oldn']
  at=(start if n==0 else start-1)+offset
  if at<0 or lines[at:at+len(before)]!=before:return None
  lines[at:at+len(before)]=after;offset+=len(after)-len(before)
 return ''.join(lines)

def select_candidates(report, export=False,tree_name='recovered-tree'):
 paths=report['paths'];memo={};known=set(KNOWN.values())
 def eligible(prov):
  if prov.get('restore_eligible') is False or prov.get('explicit_creation_failed'):return False
  if 'command_exitCode' in prov and (prov['command_exitCode']!=0 or prov.get('command_status')!='completed') and not prov.get('engine_validated_red_test_creation'):return False
  return True
 tree=pathlib.Path(tempfile.mkdtemp(prefix='.recovered-tree-build-',dir=OUT)) if export else OUT/tree_name
 def order(prov):
  timestamp=prov.get('turn_startedAt');index=prov.get('item_index')
  return (timestamp,index) if isinstance(timestamp,(int,float)) and isinstance(index,int) else None
 def routes(path,digest,active=frozenset()):
  key=(path,digest)
  if key in memo:return memo[key]
  if key in active:return {}
  entry=paths.get(path,{}).get(digest); result={}
  if not entry:return result
  for prov in entry['provenance']:
   if not eligible(prov):continue
   method=prov.get('method','');thread=prov.get('thread_id');end=order(prov)
   if not thread or end is None:continue
   if method=='strict-reverse-hunk-replay':continue
   if method=='strict-forward-hunk-replay':
    base=routes(prov['base_path'],prov['base_sha256'],active|{key})
    if thread not in base or base[thread]>=end:continue
   if end>result.get(thread,(-1,-1)):result[thread]=end
  memo[key]=result;return result
 selected=[];ambiguous=[];quarantined=[]
 unfinished_names={'loop_proof_graph.py','loop_proof_cost.py','loop_proof_obligations.json','fixtureloop_proof_obligations.json','test_loop_proof_graph.py','test_loop_proof_cost.py','source_names_v2.py','test_source_names_v2.py'}
 for path,versions in sorted(paths.items()):
  if not path.startswith(('/workspace/','/tmp/')):continue
  restore_versions={}
  for digest,entry in versions.items():
   reasons=[]
   if posixpath.basename(path) in unfinished_names and path.startswith('/workspace/BerylLattice/axiom/'):
    reasons.append('controller excludes this newly introduced unfinished path from baseline; all byte candidates retained')
   if any(prov.get('restore_eligible') is False for prov in entry['provenance']):
    reasons.append('restore_eligible:false veto for this exact path and digest; other provenance cannot override it')
   if not any(eligible(prov) for prov in entry['provenance']):
    reasons.append('no successful restore-eligible source evidence')
    if any(prov.get('explicit_creation_failed') for prov in entry['provenance']):reasons.append('historical shell explicitly reports failure to create this target; combined exit status cannot establish write success')
   data=(OBJECTS/digest).read_bytes()
   if path.endswith('.py'):
    try:ast.parse(data,filename=path)
    except (SyntaxError,ValueError,UnicodeDecodeError) as error:reasons.append('Python syntax integrity failure: '+str(error))
   if reasons:quarantined.append({'historical_path':path,'sha256':digest,'reasons':reasons});continue
   restore_versions[digest]=entry
  versions=restore_versions
  if not versions:continue
  verified=[]
  for digest,entry in versions.items():
   if digest in known or any(p.get('expected_sha256')==digest or str(p.get('verification','')).startswith('Exact match to recorded historical SHA256') or p.get('historical_git_blob_prefix') or p.get('independent_full_observation') for p in entry['provenance'] if eligible(p)):verified.append(digest)
  controller_choices=[digest for digest,entry in versions.items() if any(prov.get('controller_selected') and eligible(prov) for prov in entry['provenance'])]
  reason=None;chosen=None
  if len(controller_choices)==1:
   chosen=controller_choices[0];reason='controller explicitly selected final complete chronological patch chain; no independently recorded final digest claimed'
  elif len(verified)==1:
   chosen=verified[0];reason='independently verified historical bytes; see provenance for recorded SHA256, logged Git blob-prefix or complete-observation evidence'
  elif len(verified)>1:
   ambiguous.append({'historical_path':path,'candidate_hashes':verified,'reason':'multiple independently recorded historical versions; latest unresolved'});continue
  elif len(versions)==1:chosen=next(iter(versions));reason='only complete-byte candidate recovered; latest not independently established'
  else:
   per_thread={}
   for digest in versions:
    for thread,end in routes(path,digest).items():
     if thread not in per_thread or end>per_thread[thread]['order']:per_thread[thread]={'order':end,'hashes':[digest]}
     elif end==per_thread[thread]['order']:per_thread[thread]['hashes'].append(digest)
   latest=set(h for record in per_thread.values() for h in record['hashes'])
   if len(latest)==1:chosen=next(iter(latest));reason='unambiguous latest direct evidence or chronologically coherent forward patch chain; thread-local order'
   else:
    ambiguous.append({'historical_path':path,'candidate_hashes':sorted(latest or versions),'thread_latest':per_thread,'reason':'conflicting thread-local latest evidence or no chronological route'});continue
  entry=versions[chosen];relative=path.lstrip('/');destination=tree/relative
  record={'historical_path':path,'sha256':chosen,'bytes':entry['bytes'],'reason':reason,'tree_relative_path':relative,'provenance':entry['provenance'],'other_candidate_hashes':sorted(set(versions)-{chosen}),'mode_octal':'0644'}
  if path=='/workspace/BerylLattice/tools/setup-cloud.sh':
   record['mode_octal']='0755';record['mode_provenance']=[{'source':'history/page-006.json','item_id':'exec-bad7a5cd-4b0e-4f3e-bd7f-a8ef7d956d5c','evidence':'historical create-mode 100755 output verified by controller'},{'source':'history/agents/impl_cloud_setup-001.json','item_id':'exec-6931198d-f3e0-4aac-bbfe-5d9b5cefd5c8','evidence':'historical chmod755 command verified by controller'}]
  selected.append(record)
  if export:
   destination.parent.mkdir(parents=True,exist_ok=True);data=(OBJECTS/chosen).read_bytes()
   if hashlib.sha256(data).hexdigest()!=chosen:raise ValueError('candidate byte corruption')
   destination.write_bytes(data);destination.chmod(int(record['mode_octal'],8))
 if export:
  target=OUT/tree_name
  if target.exists():target.rename(OUT/(tree_name+'-previous-'+uuid.uuid4().hex))
  tree.rename(target)
 result={'schema':'axiom-recovered-tree-selection-v1','exported':export,'tree_root':str(OUT/tree_name) if export else None,'caution':'This is an incomplete recovered tree, not restored Git history or an assurance of latest state. Ambiguous candidates are withheld. Known-hash preference can select an older verified checkpoint over later unverified bytes.','selected':selected,'ambiguous':ambiguous,'quarantined':quarantined}
 (OUT/('selection-manifest.json' if tree_name=='recovered-tree' else tree_name+'-manifest.json')).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
 return result

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--export',action='store_true');parser.add_argument('--export-tree-name',default='recovered-tree');args=parser.parse_args()
 if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]*',args.export_tree_name):raise ValueError('export tree name must be one safe relative name')
 metadata={};items_by_id={}
 OBJECTS.mkdir(parents=True,exist_ok=True)
 for source in sorted((ROOT/'history').rglob('*.json')):
  try:
   source_bytes=source.read_bytes();doc=json.loads(source_bytes);sources.append({'path':str(source.relative_to(ROOT)),'sha256':hashlib.sha256(source_bytes).hexdigest(),'bytes':len(source_bytes)})
  except Exception as e:issues.append({'source':str(source),'reason':'invalid history JSON: '+str(e)});continue
  for item,context in walk(doc,{'thread_id':doc.get('thread',{}).get('id')}):
   metadata[item.get('id')]=context;items_by_id[item.get('id')]=item
   # Duplicate pages retain one original source reference; source records are immutable files.
   key=(item.get('id'),hashlib.sha256(json.dumps(item,sort_keys=True).encode()).hexdigest())
   if key in seen:continue
   seen.add(key);stats[item['type']]+=1
   prov={**context,'source':str(source.relative_to(ROOT)),'item_id':item.get('id'),'status':item.get('status')}
   if item['type']=='commandExecution':commands(item,prov);continue
   for num,change in enumerate(item.get('changes',[])):
    p=pathof(change.get('path'),'/workspace/BerylLattice'); diff=change.get('diff') or {};kind=change.get('kind') or {}; kind=kind if isinstance(kind,dict) else {'type':kind}; evidence={**prov,'change_index':num}
    if diff.get('truncated') is not False:
     fragment=diff.get('text','').encode('utf-8');digest=hashlib.sha256(fragment).hexdigest();(OBJECTS/digest).write_bytes(fragment)
     fragments.append({**evidence,'path':p,'sha256':digest,'bytes':len(fragment),'originalChars':diff.get('originalChars'),'kind':kind,'warning':'INCOMPLETE EVIDENCE; never a complete-file candidate'})
     issues.append({**evidence,'path':p,'reason':'truncated or completeness unspecified'});continue
    if item.get('status')!='completed':issues.append({**evidence,'path':p,'reason':'file change not completed'});continue
    typ=kind.get('type');text=diff.get('text','')
    if typ=='add':add(p,text,{**evidence,'method':'fileChange-add'})
    elif typ=='update':
     try:hunks=parse_patch(text)
     except ValueError as e:issues.append({**evidence,'path':p,'reason':'patch parse: '+str(e)});continue
     updates.append({'path':p,'target':pathof(kind.get('move_path'),posixpath.dirname(p)) or p,'hunks':hunks,'operation':hashlib.sha256((p+'\0'+str(kind.get('move_path'))+'\0'+text).encode()).hexdigest(),'prov':evidence,'applied':set()})
    else:events.append({**evidence,'path':p,'kind':kind,'note':'Deletion/unknown operation retained as event; no candidates removed.'})
 # Optional independently verified complete byte seeds from other recovery analysts.
 for manifest in sorted(ROOT.rglob('supplemental-candidates.json')):
  if manifest.relative_to(ROOT).parts[0] in ('staging','history'):continue
  try:
   manifest_bytes=manifest.read_bytes();records=json.loads(manifest_bytes)
   sources.append({'path':str(manifest.relative_to(ROOT)),'sha256':hashlib.sha256(manifest_bytes).hexdigest(),'bytes':len(manifest_bytes),'kind':'supplemental-seed-manifest'})
   if not isinstance(records,list):raise ValueError('manifest must be a list')
   for rec in records:
    saved=pathlib.Path(rec['candidate_file']).resolve()
    if not saved.is_relative_to(ROOT.resolve()):raise ValueError('seed path outside recovery directory')
    data=saved.read_bytes();digest=hashlib.sha256(data).hexdigest()
    if digest!=rec['sha256']:raise ValueError('supplemental seed SHA256 mismatch: '+str(saved))
    text=data;p=pathof(rec['historical_path'],'/workspace/BerylLattice')
    seed_prov=dict(rec.get('provenance',{}))
    if rec.get('expected_sha256'):
     if rec['expected_sha256']!=digest:raise ValueError('supplement historical expected SHA256 mismatch')
     seed_prov['expected_sha256']=rec['expected_sha256']
    if isinstance(rec.get('verification'),dict):
     verification=rec['verification'];blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
     if verification.get('git_blob_sha1') and verification['git_blob_sha1']!=blob:raise ValueError('supplement Git blob hash mismatch')
     prefix=re.search(r'prefix ([0-9a-f]{7,40})',verification.get('method',''))
     if prefix and blob.startswith(prefix[1]):seed_prov['historical_git_blob_prefix']=prefix[1];seed_prov['computed_git_blob_sha1']=blob
     seed_prov['independent_verification']=verification
    observation_refs=list(seed_prov.get('independent_observed_matches',[]))
    if seed_prov.get('independent_full_observation') and seed_prov.get('item_id'):observation_refs.append({'item_id':seed_prov['item_id'],'source':seed_prov.get('source')})
    if observation_refs:
     validated=[]
     for reference in observation_refs:
      observed=items_by_id.get(reference.get('item_id'),{}).get('output',{})
      if isinstance(observed,dict) and observed.get('truncated') is False and data in observed.get('text','').encode('utf-8'):validated.append(reference)
     seed_prov['independent_full_observation']=bool(validated)
     seed_prov['engine_validated_full_observations']=validated
    if seed_prov.get('confirmed_red_test_file_creation'):
     original=items_by_id.get(seed_prov.get('item_id'),{});observation=original.get('output',{}).get('text','')
     literal_match=any(evidence.get('item_id')==seed_prov.get('item_id') and evidence.get('method')=='literal-quoted-cat-heredoc' for evidence in candidates.get(rec['historical_path'],{}).get(digest,{}).get('provenance',[]))
     if (literal_match and original.get('status') in ('completed','failed') and original.get('exitCode')==1 and rec['historical_path'] in observation and 'line 3' in observation and 'ModuleNotFoundError' in observation and 'axiom.core_observe' in observation):
      seed_prov['engine_validated_red_test_creation']=True
      seed_prov['restore_exception']='Exact new test path/line read in RED import traceback confirms heredoc write; combined command exit1 retained.'
    last_item=seed_prov.get('item_id') or next((event.get('item_id') for event in reversed(seed_prov.get('events',[])) if event.get('item_id')),None)
    add(p,text,{**metadata.get(last_item,{}),**seed_prov,'seed_manifest':str(manifest.relative_to(ROOT)),'seed_file':str(saved),'method':'independent-complete-seed','source_method':rec.get('provenance',{}).get('method')})
  except Exception as e:issues.append({'source':str(manifest),'reason':'supplement ingestion: '+str(e)})
 # Controller-confirmed final supervisor: validate independently logged Git target.
 supervisor_path='/workspace/BerylLattice/axiom/src/axiom/_core_supervisor.py'
 supervisor_digest='65a2bc27ed62972dad2239d9df832b049b9feb094ce513867776a85dfdd7a631'
 supervisor_item='exec-24c916e3-e792-477f-bf33-b6fefeb385dd'
 if supervisor_digest in candidates[supervisor_path]:
  data=(OBJECTS/supervisor_digest).read_bytes();blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
  observed=items_by_id.get(supervisor_item,{}).get('output',{}).get('text','')
  if blob.startswith('4c29e96') and 'index 68a35c9..4c29e96' in observed:
   add(supervisor_path,data,{**metadata.get(supervisor_item,{}),'source':'history/agents/review_core_runner-001.json','item_id':supervisor_item,'method':'controller-confirmed-final-with-logged-Git-blob-prefix','historical_git_blob_prefix':'4c29e96','computed_git_blob_sha1':blob,'restore_eligible':True})
 rounds=0
 while True:
  added=0;rounds+=1
  for patch in updates:
   for reverse in (False,True):
    src=patch['target'] if reverse else patch['path'];dst=patch['path'] if reverse else patch['target']
    for h in list(candidates[src]):
     signature=(reverse,h)
     lineage=candidates[src][h]['used_patch_operations']
     if patch['operation'] in lineage:continue
     if signature in patch['applied']:continue
     patch['applied'].add(signature)
     try:text=(OBJECTS/h).read_bytes().decode('utf-8')
     except UnicodeDecodeError:continue
     result=apply(text,patch['hunks'],reverse)
     if result is None:continue
     before=len(candidates[dst]);newhash=add(dst,result,{**patch['prov'],'method':'strict-reverse-hunk-replay' if reverse else 'strict-forward-hunk-replay','base_sha256':h,'base_path':src},operations=(*lineage,patch['operation']))
     added+=len(candidates[dst])-before
     patch.setdefault('success',set()).add((reverse,h,newhash))
  if not added:break
  if rounds>=100:issues.append({'reason':'iteration limit reached'});break
 # Controller explicitly selected the analyst's complete final correspondence chain.
 correspondence_path='/workspace/BerylLattice/axiom/tests/integration/test_core_correspondence.py'
 correspondence_digest='cca8ba87be27d9395137ea37348c78696f0f8a7c2e75d6857c6be4ec256fb719'
 correspondence_items=['exec-c6dc85e7-e706-41cb-9f62-6096f3eb2b88','exec-af9ea7bb-7b8a-44d4-a1a2-10cda4a77b93','exec-b3d92dab-b5b3-4c26-b68c-4cce0cb2648d','exec-1bec3d8a-00b8-4bf5-b0a6-760b3a73cb77','exec-9ee98aad-5bd7-4093-98d9-5b5ec3152329']
 if correspondence_digest in candidates[correspondence_path] and all(items_by_id.get(item,{}).get('status')=='completed' for item in correspondence_items):
  add(correspondence_path,(OBJECTS/correspondence_digest).read_bytes(),{**metadata.get(correspondence_items[-1],{}),'source':'history/agents/impl_core_correspondence-001.json','item_id':correspondence_items[-1],'method':'controller-selected-complete-five-patch-chain','controller_selected':True,'historical_patch_items':correspondence_items,'restore_eligible':True,'limitation':'Controller explicitly selected exact final reconstructed bytes; no independent final historical digest claimed.'})
 report={'schema':'axiom-history-candidates-v1','caution':'Candidates preserve historical byte evidence. Cross-thread timeline/latest version unresolved; replay applicability is not proof a version was committed. reconstruct.py does not execute historical shell/Python; supplemental methods are separately recorded in provenance.','stats':dict(stats),'rounds':rounds,'sources':sources,'reconstruct_script_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'paths':{p:v for p,v in sorted(candidates.items()) if v},'fragments':fragments,'truncated_command_outputs':truncated_outputs,'issues':issues,'events':events,'patches':[{'path':p['path'],'target':p['target'],'provenance':p['prov'],'successful_applications':[list(s) for s in sorted(p.get('success',set()))],'tested_bases':len(p['applied']),'blocker':None if p.get('success') else 'No recovered candidate matches complete hunk positions and old bytes.'} for p in updates]}
 report['known_hash_matches']={name:[p for p,versions in candidates.items() if h in versions] for name,h in KNOWN.items()}
 with (OUT/'candidate-manifest.tsv').open('w',newline='') as stream:
  writer=csv.writer(stream,delimiter='\t');writer.writerow(['historical_path','sha256','bytes','object_path','source_evidence'])
  for historical_path,versions in sorted(candidates.items()):
   for digest,entry in sorted(versions.items()):
    writer.writerow([historical_path,digest,entry['bytes'],str(OBJECTS/digest),json.dumps(entry['provenance'],sort_keys=True)])
 (OUT/'candidate-index.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 summary={'history_files':len(sources),'paths':sum(bool(v) for v in candidates.values()),'fragments':len(fragments),'truncated_command_outputs':len(truncated_outputs),'versions':sum(len(v) for v in candidates.values()),'patches':len(updates),'unapplied_patches':sum(not p.get('success') for p in updates),'issues':len(issues),'rounds':rounds,'known_hash_matches':report['known_hash_matches']}
 (OUT/'reconstruction-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 (OUT/'RECONSTRUCTION.md').write_text('''# Historical byte reconstruction

Read `candidate-index.json` as the authoritative index; `candidate-manifest.tsv` gives one row per historical path and byte candidate, with source evidence. Content resides at `objects/<sha256>`. Objects not referenced in the index may be leftovers from previous runs and are not accepted complete candidates.

This reconstruction engine does not execute historical commands or Python code. Independent supplemental seed methods are recorded separately; generated fixtures do not claim original byte identity without a recorded digest. Sources are complete file additions, complete observed single-file `cat` output, literal quoted shell heredocs, literal Python `Path.write_text` arguments, and strict forward/reverse unified-hunk applications to recovered matching bytes. Literal writes are candidates: conditional execution and current/latest version are not asserted. Patch line counts, exact positions, context and removal bytes must match. Each patch operation is used at most once in an ancestry, preventing repeated append-only hunk application. Deletion events never destroy earlier versions. Incomplete records remain separately labelled fragments; they are not complete-file candidates.

Selection is separate from byte recovery. The selector withholds conflicting latest versions across threads. Any restore_eligible:false provenance vetoes its exact path and digest, even when another source is eligible. Controller-excluded unfinished paths, unsuccessful literal-write commands and Python syntax failures are quarantined from the exported baseline. Tool redaction placeholders are incomplete fragments, never complete candidates. Exact recorded SHA256 or independently logged Git blob-prefix checks are preferred; the index distinguishes those forms of evidence.

Export restores regular-file bytes, not symlinks or Git metadata. Executable permissions are restored only when explicit historical mode evidence is recorded in the manifest; other files use 0644. A preliminary tree and final tree have separate names. Fresh exports are built separately before replacing their named tree; earlier trees are retained under `*-previous-*` and are not current outputs.

The index preserves input source hashes, reconstruction script hash, original history file/item/change references, candidate hashes, replay bases, unresolved patches and truncated fragments. Cross-thread chronology, whether any version was committed, and which candidate was latest require independent evidence. A matching supplied SHA256 identifies exact bytes only.

Rerun: `python /workspace/scratch/axiom-recovery/reconstruct.py`. Existing history files are read, and outputs remain within staging. This does not restore repositories, Git commits, toolchains or build dependencies.

Current pass:

```json
'''+json.dumps(summary,indent=2)+'\n```\n')
 selection=select_candidates(report,args.export,args.export_tree_name)
 summary['selection']={key:len(value) for key,value in selection.items() if isinstance(value,list)}
 selected_paths={entry['historical_path'] for entry in selection['selected']}
 observed_paths=set(report['paths'])|{fragment['path'] for fragment in fragments if fragment.get('path')}|{patch['path'] for patch in updates}|{patch['target'] for patch in updates}
 gaps={'schema':'axiom-recovery-gaps-v1','unrecovered_complete_file_paths':sorted(observed_paths-set(report['paths'])),'ambiguous_withheld':selection['ambiguous'],'candidate_paths_withheld':sorted(set(report['paths'])-selected_paths),'incomplete_records':fragments,'unapplied_patch_records':[patch for patch in report['patches'] if patch['blocker']],'regenerated_selected_seeds':[entry for entry in selection['selected'] if any(re.search(r'regenerat|recipe',str(prov),re.I) for prov in entry['provenance'])],'caution':'Absence of complete bytes in this reconstruction does not establish permanent data loss. Missing native Core checkout/toolchains and build validation are managed separately by the controller.'}
 (OUT/'recovery-gaps.json').write_text(json.dumps(gaps,indent=2,sort_keys=True)+'\n')
 (OUT/'reconstruction-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(json.dumps(summary,indent=2))
if __name__=='__main__':main()

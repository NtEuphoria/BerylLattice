"""Recreate fixture bytes from reviewed, retained literal recipes.

No historical shell or arbitrary Python is evaluated. JSON rows are read with
ast.literal_eval; the staged fixture calls the recovered independent test helper.
"""
import ast
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'root-analysis' / 'fixtures'
VALIDATE = ROOT / 'validation' / 'frontend-check'
OUT.mkdir(parents=True, exist_ok=True)
rows = []

def save(relative, data, source, item, method):
    target = OUT / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    rows.append({'historical_path': '/workspace/BerylLattice/axiom/' + relative,
                 'candidate_file': str(target), 'sha256': hashlib.sha256(data).hexdigest(),
                 'provenance': {'source': source, 'item_id': item, 'method': method,
                                'historical_hash_available': False, 'restore_eligible': True}})
    dest = VALIDATE / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)

source = 'history/agents/impl_core_emit-001.json'
index = json.loads((ROOT/'root-analysis/fixture-command-index.json').read_text())
entry = next(x for x in index if x['command_path'].endswith('impl_core_emit-001-21.sh.txt'))
cmd = (ROOT/'root-analysis/impl_core_emit-001-21.sh.txt').read_text()
marker = "cat > axiom/tests/fixtures/core_emit/minimal.ax <<'EOF'\n"
data = cmd.split(marker, 1)[1].split('\nEOF\n', 1)[0] + '\n'
save('tests/fixtures/core_emit/minimal.ax', data.encode(), source,
     entry['item_id'], 'complete quoted heredoc extracted without execution')

def op(opcode, dst=None, operands=(), index=None, value=None, origins=()):
    return dict(opcode=opcode, dst=dst, operands=list(operands), index=index,
                value=value, origins=list(origins))

ops = [op('const', dst=0, value=1, origins=(0,))]
for i in range(4):
    n = 1 + 3*i
    ops.extend([op('input_load', dst=n, index=i), op('add', dst=n+1, operands=(n,0)),
                op('mul', dst=n+2, operands=(n+1,n+1))])
ops.extend([op('add',dst=13,operands=(3,6)),op('add',dst=14,operands=(13,9)),
            op('add',dst=15,operands=(14,12)),op('output_store',operands=(15,),index=0)])
obj = dict(format_version=1, semantic_digest='a'*64, plan_id='manual inline 1x1',
           scratch_capacity_cells=0, operations=ops)
entry = next(x for x in index if x['command_path'].endswith('impl_codec-002-12.sh.txt'))
for name, data in [('inline-1x1.json', json.dumps(obj,sort_keys=True,separators=(',',':')).encode()),
                   ('duplicate-key.json', b'{"format_version":1,"format_version":1}'),
                   ('overlong-integer.json', b'{"scratch_capacity_cells":123456789012345678901234567890}')]:
    save('tests/fixtures/plans/'+name,data,'history/agents/impl_codec-002.json',entry['item_id'],
         'deterministic JSON/literal bytes recreated from complete historical recipe')

cmd = (ROOT/'root-analysis/impl_checker-001-10.sh.txt').read_text()
body = cmd.split("python - <<'PY'\n",1)[1].split('\nPY\n',1)[0]
parsed = ast.parse(body)
literal_rows = ast.literal_eval(next(n.value for n in parsed.body if isinstance(n,ast.Assign)
                                     and any(isinstance(t,ast.Name) and t.id=='rows' for t in n.targets)))
obj = dict(format_version=1,semantic_digest='a'*64,plan_id='hand-authored inline 1x1',
           scratch_capacity_cells=0,operations=[dict(opcode=o,dst=d,operands=a,index=i,value=v,origins=[])
                                               for o,d,a,i,v in literal_rows])
entry = next(x for x in index if x['command_path'].endswith('impl_checker-001-10.sh.txt'))
save('tests/fixtures/plans/checker/manual-inline-1x1.json',(json.dumps(obj,indent=2)+'\n').encode(),
     'history/agents/impl_checker-001.json',entry['item_id'],
     'literal rows recovered with ast.literal_eval; original JSON serialization reproduced')
obj = {'format_version':1,'semantic_digest':'a'*64,'plan_id':'manual uninitialized scratch negative',
       'scratch_capacity_cells':1,'operations':[{'opcode':'scratch_load','dst':0,'operands':[],
                                                'index':0,'value':None,'origins':[]}]}
entry = next(x for x in index if x['command_path'].endswith('impl_checker-001-26.sh.txt'))
save('tests/fixtures/plans/checker/manual-uninitialized-scratch.json',
     (json.dumps(obj,indent=2)+'\n').encode(),'history/agents/impl_checker-001.json',entry['item_id'],
     'deterministic JSON fixture recreated from complete historical recipe')

# Import only recovered, inspected fixture-helper and serialization modules.
for record in json.loads((ROOT/'base-analysis/supplemental-candidates.json').read_text()):
    relative = record['historical_path'].removeprefix('/workspace/BerylLattice/axiom/')
    if relative in ('src/axiom/codec.py','src/axiom/checker.py','tests/test_checker.py'):
        data = Path(record['candidate_file']).read_bytes()
        assert hashlib.sha256(data).hexdigest() == record['sha256']
        (VALIDATE/relative).write_bytes(data)
data = (ROOT/'staging/preliminary-recovered-tree/workspace/BerylLattice/axiom/src/axiom/plan_format.py').read_bytes()
(VALIDATE/'src/axiom/plan_format.py').write_bytes(data)
sys.path[:0] = [str(VALIDATE/'src'), str(VALIDATE)]
from tests.test_checker import kernel, staged
from axiom.codec import encode_plan
save('tests/fixtures/plans/checker/manual-ssa-staged-5x7.json',encode_plan(staged(kernel(5,7,0))),
     'history/agents/impl_checker-001.json',entry['item_id'],
     'deterministic fixture regenerated by recovered independent test helper and strict codec')
entry = next(x for x in index if x['command_path'].endswith('impl_core_correspondence-001-15.sh.txt'))
save('tests/integration/__init__.py',b'','history/agents/impl_core_correspondence-001.json',entry['item_id'],
     'recorded touch of absent package initializer before RED tests')
(ROOT/'root-analysis/supplemental-candidates.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'fixtures':len(rows),'output':str(OUT)}))

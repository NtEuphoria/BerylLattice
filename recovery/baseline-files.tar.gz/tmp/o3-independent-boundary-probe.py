import sys
sys.dont_write_bytecode=True
from pathlib import Path
import collections, hashlib, json, unittest
from dataclasses import replace
from unittest.mock import patch
sys.path.insert(0,str(Path.cwd()/'research/tests'))
import test_oracle_receipts as f
from research import oracle_receipt as o
from research import source_oracle as oracle
from research import state_artifacts as state

class IndependentBoundaryTests(unittest.TestCase):
    setUpClass=classmethod(f.SelectedQualificationTests.setUpClass.__func__)
    tearDownClass=classmethod(f.SelectedQualificationTests.tearDownClass.__func__)
    setUp=f.SelectedQualificationTests.setUp
    select=f.SelectedQualificationTests.select
    completed=f.SelectedQualificationTests.completed
    candidate=f.SelectedQualificationTests.candidate
    verified=f.SelectedQualificationTests.verified

    def test_qualification_exact_aggregate_before_any_bulk_read(self):
        files=[p for p in self.subject.rglob('*') if p.is_file()]
        amount=sum(p.stat().st_size for p in files)
        q=self.select(limits=o.OracleQualificationLimits(max_qualification_bytes=amount,max_files=len(files)))
        q.revalidate(); q.close()
        for limits in [o.OracleQualificationLimits(max_qualification_bytes=amount-1),o.OracleQualificationLimits(max_files=len(files)-1)]:
            with patch.object(o._Ledger,'verify_blob',side_effect=AssertionError('bulk payload read before preflight rejection')):
                with self.assertRaises(ValueError): self.select(limits=limits)

    def test_actual_live_source_mutation_is_rejected(self):
        q=self.select()
        path=Path(oracle.__file__)
        before=path.read_bytes()
        try:
            path.write_bytes(before+b'\n')
            with self.assertRaisesRegex(ValueError,'length|live bytes'): q.revalidate()
        finally: path.write_bytes(before)
        q.revalidate()

    def test_new_repository_bytecode_cannot_escape_inventory(self):
        q=self.select()
        cached=Path(oracle.__cached__)
        self.assertFalse(cached.exists())
        cached.parent.mkdir(exist_ok=True)
        try:
            cached.write_bytes(b'unapproved-bytecode-control')
            with self.assertRaisesRegex(ValueError,'inventory'): q.revalidate()
        finally: cached.unlink()
        q.revalidate()

    def test_valid_comparison_traverses_every_scalar_in_both_states(self):
        q=self.select()
        src,inv,result=self.completed(f.source(2,3),list(range(12)),[101]*6,chunk_bytes=8)
        claim=o.produce_oracle_receipt(result,q,self.root/'claim')
        counts=collections.Counter()
        real=state.VerifiedState.iter_scalars
        def counted(obj,role):
            for value in real(obj,role):
                counts[(str(obj.manifest_path),role)]+=1
                yield value
        with patch.object(state.VerifiedState,'iter_scalars',counted):
            with patch.object(o,'evaluate_source_state',wraps=o.evaluate_source_state) as evaluate:
                handle=o.verify_oracle_receipt(claim.manifest_path,src,inv,q,limits=oracle.OracleLimits(state_limits=state.ArtifactLimits(chunk_bytes=8)))
                self.addCleanup(handle.close)
                self.assertEqual(evaluate.call_count,1)
        self.assertEqual(sorted(counts.values()),[6,6,12,12])
        self.assertEqual(len({p for p,r in counts}),2)

    def test_recomputed_wrong_first_invalid_index_is_not_truth(self):
        q=self.select()
        src,inv,result=self.completed(f.source(1,2),[0,-1,2,3,-2,5],[87,-94],chunk_bytes=4)
        original=state.verify_state(result.state_manifest)
        wrong_meta=replace(original.metadata,first_bad_index=4)
        wrong=state.write_state([0,-1,2,3,-2,5],[87,-94],wrong_meta,self.root/'wrong',limits=state.ArtifactLimits(chunk_bytes=4))
        false_result=replace(result,state_manifest=wrong,first_bad_index=4)
        claim=o.produce_oracle_receipt(false_result,q,self.root/'claim')
        with patch.object(o,'evaluate_source_state',wraps=o.evaluate_source_state) as evaluate:
            with self.assertRaisesRegex(ValueError,'candidate state'):
                o.verify_oracle_receipt(claim.manifest_path,src,inv,q,limits=oracle.OracleLimits())
            self.assertEqual(evaluate.call_count,1)
        self.assertFalse(any((self.root/'scratch-1').iterdir()))

    def test_recomputed_false_semantic_rejection_is_not_truth(self):
        q=self.select()
        src,inv,result=self.completed()
        original=state.verify_state(result.state_manifest)
        wrong_meta=replace(original.metadata,status='input_precondition_failed',first_bad_index=0)
        wrong=state.write_state([0,1,2,3],[777],wrong_meta,self.root/'wrong')
        false_result=replace(result,state_manifest=wrong,status='input_precondition_failed',first_bad_index=0)
        claim=o.produce_oracle_receipt(false_result,q,self.root/'claim')
        with self.assertRaisesRegex(ValueError,'candidate state'):
            o.verify_oracle_receipt(claim.manifest_path,src,inv,q,limits=oracle.OracleLimits())
        self.assertFalse(any((self.root/'scratch-1').iterdir()))

    def test_combined_temporary_exact_boundary_and_reduced_o2_allowance(self):
        q=self.select()
        src,inv,_,claim=self.candidate(q)
        overhead=claim.manifest_path.stat().st_size
        exact=16+20+1_048_576+overhead
        with patch.object(o,'evaluate_source_state',side_effect=AssertionError('execution before temporary preflight')):
            with self.assertRaisesRegex(ValueError,'temporary'):
                o.verify_oracle_receipt(claim.manifest_path,src,inv,q,limits=oracle.OracleLimits(max_temporary_bytes=exact-1))
        real=o.evaluate_source_state
        seen=[]
        def evaluate(*args,**kwargs):
            seen.append(kwargs['limits'].max_temporary_bytes)
            return real(*args,**kwargs)
        with patch.object(o,'evaluate_source_state',evaluate):
            handle=o.verify_oracle_receipt(claim.manifest_path,src,inv,q,limits=oracle.OracleLimits(max_temporary_bytes=exact))
            self.addCleanup(handle.close)
        self.assertEqual(seen,[exact-overhead])

    def test_candidate_joint_byte_and_file_limits_precede_payload_verification(self):
        q=self.select()
        src,inv,_,claim=self.candidate(q)
        data=json.loads(claim.manifest_path.read_bytes())
        actual=state.verify_state(claim.manifest_path.parent/data['expected_state']['path'])
        candidate_bytes=claim.manifest_path.stat().st_size+sum(x.byte_length for x in actual.closure)
        candidate_files=1+len(actual.closure)
        exact_bytes=candidate_bytes+20+1_048_576
        exact_files=candidate_files+3
        q.close()
        for limit in [state.ArtifactLimits(max_aggregate_bytes=exact_bytes-1),state.ArtifactLimits(max_files=exact_files-1)]:
            q=self.select(limits=o.OracleQualificationLimits(semantic_limits=limit))
            with patch.object(o,'verify_state',side_effect=AssertionError('candidate payload before aggregate preflight')):
                with self.assertRaises(ValueError):
                    o.verify_oracle_receipt(claim.manifest_path,src,inv,q,limits=oracle.OracleLimits())
            q.close()
        q=self.select(limits=o.OracleQualificationLimits(semantic_limits=state.ArtifactLimits(max_aggregate_bytes=exact_bytes,max_files=exact_files)))
        handle=o.verify_oracle_receipt(claim.manifest_path,src,inv,q,limits=oracle.OracleLimits())
        self.addCleanup(handle.close)

    def test_duplicate_json_and_noncanonical_encoding_reject_before_execution(self):
        q=self.select()
        src,inv,_,claim=self.candidate(q)
        raw=claim.manifest_path.read_bytes()
        invalid=[raw+b'\n',b'{"schema":"x",'+raw[1:]]
        with patch.object(o,'evaluate_source_state',side_effect=AssertionError('invalid metadata executed')):
            for value in invalid:
                claim.manifest_path.write_bytes(value)
                with self.assertRaises(ValueError):
                    o.verify_oracle_receipt(claim.manifest_path,src,inv,q,limits=oracle.OracleLimits())
        claim.manifest_path.write_bytes(raw)

if __name__=='__main__': unittest.main(verbosity=2)

from pathlib import Path
from itertools import combinations
from collections import defaultdict
import hashlib
root=Path('/workspace/BerylLattice')
plan=root/'docs/superpowers/plans/2026-10-16-axiom-scalability'
output=root/'.superpowers/sdd/axiom-scalability/preflight.md'
tasks={
'G0':('README G0','Recovery/source inventory and portable restoration','Consistent; actual restoration receipt, selected revision and explicit known Core failures are prerequisites. A scratch clone is allowed; no new worktree.'),
'G1':('README gates/design','Reviewed source/IR/ABI/status/identity ownership','Needs rulings P1–P5 below before affected implementation; freeze public contracts without pretending C1 proof or B2 binding already passed.'),
'I1':('README I1','Explicit v2 plan/check/replay/compile CLI','Consistent; depends C2/C9/C10/B4/B5. Compile success is not execution. Root README update waits G3; portable CLI work need not wait G3.'),
'B1':('01 B1','Boundary arithmetic/status contract and hand fixtures','P1/P2: C2 owns executable admission. Observable ordering tests need a named test-only adapter/fixture, not a second production adapter.'),
'B2':('01 B2','Actual pinned emit-c/type/signature/native seam','Consistent after prior correction: tiny explicit allocation, no B3 allocator dependency. Requires real qualified toolchain; test skips cannot pass G2a.'),
'B3':('01 B3','Owned C buffers/allocator/lifecycle','Consistent; B2 descriptor first, then retrofit its tiny fixture through operation allocator. P3: serial fixture/host ownership handoff.'),
'B4':('01 B4','Fresh-checked Core emission','Consistent; needs C2–C5 and B1/B2. NativeLoweringUnsupported preserves valid mathematical result; negative modulo and high empty-loop controls fit grammar.'),
'B5':('01 B5','NativeQualification and qualified build closure','P4: use O1 production transport; own build inventory before O4 consumes real inventory. No production import of research/evidence_stores.py.'),
'B6':('01 B6','Owned invocation and complete raw capture','Consistent; O1 transport and B3/B5 required. Completion means fully acquired success/rejection, not oracle agreement. Shared module serial after B5.'),
'B7':('01 B7','Native integration review/focused controls','Consistent; consume the one O6 118-call campaign. Separate small debug/optimized/sanitizer/interposition controls; do not rerun large matrix gratuitously.'),
'B8':('01 B8','Conditional narrow Core fix','Consistent only after demonstrated B2–B6 failure. Separate reviewed Core pin/profile; existing cloud-checkout ruling supersedes generic worktree instruction. Not an early default task.'),
'C1':('02 C1','Hand-derived proof feasibility and rule vocabulary','Consistent; research-only proceed requires independent proof review. Blocked stops C4–C11, while C2/C3 independent infrastructure can proceed.'),
'C2':('02 C2','Registered source admission and exact identities','Consistent; may precede C1 completion. Preserve v1, AST grouping, source cap intersection, family/specialization separation, and registered maxima. Must precede B1 executable profile tests.'),
'C3':('02 C3','Immutable IR/proof/constraints/codecs/quotas','Consistent; no trusted decoded facts. C1 may revise proposed quotas explicitly; shared docs serialize with C1/C2. Scalar/index separation prevents storage escape.'),
'C4':('02 C4','Bounded independently checked region/affine rules','Consistent; only C1-approved rules, C3 typed input, deterministic precharge and width limits; false premises never facts; conserve output effects.'),
'C5':('02 C5','Actual-plan induction checker and complete metrics','Consistent; consumes C2/C3/C4 only. Failed proof is unknown absent independently validated counterexample; term DAG must never expand exponentially.'),
'C6':('02 C6','Independent small interpreter/manual fixtures/v1 bridge','Consistent; manual specialization precedes C8. SSA control required; two-column buffer conditional. Exact corpus/pattern count is frozen at execution, not implied by 955 shapes.'),
'C7':('02 C7','Optional abstract-storage analysis/promotion','Consistent conditional task. Diagnostic_only/deferred is allowed. Promotion changes C2/C5 schema and C9/C10 identities serially; no automatic native bound.'),
'C8':('02 C8','Three untrusted compact generators','Consistent; consumes C1/C2/C3/C5/C6; checker must remain unchanged by plan names. Production bridge extends C6-owned tests serially.'),
'C9':('02 C9','Deterministic charged selection','Consistent; C8 production/C5 checker. Frozen order differs from lexicographic rank. Complete metrics and matching incumbent survive later exhaustion.'),
'C10':('02 C10','Exact attempt writing/fresh replay','Consistent; requires C9/C5; manifest-last safe publication, exact bytes and caps. Owns no CLI; I1 is consumer.'),
'C11':('02 C11','Proof scaling probe and Core handoff','Consistent; completes C2–C10 (C7 conditionally), no per-output state. Required disclosed shapes are diagnostics/G3 evidence, not fresh holdout.'),
'O1':('03 O1','Bounded low-level blobs and verified invocation','Consistent; C2 admission plus B1/B6 host schema review. Production-safe modules own transport; two-chunk reader cache. Paths/typed objects require revalidation.'),
'O2':('03 O2','Original-AST streaming source oracle','Consistent; O1/C2 only, no checker/planner/emitter imports. Full preflight before equations, finite work/cache, only completed source results publish expected state.'),
'O3':('03 O3','Qualified oracle receipt/independent anchor','Consistent; O2 result and exact implementation/Python/dependency identity. Rehashing substituted expected bytes does not authorize an anchor.'),
'O4':('03 O4','Semantic/qualification store closure verification','P4: synthetic store controls can precede B5, real inventory acceptance follows B5. Retains NativeQualification, does not manufacture it.'),
'O5':('03 O5','Full per-run comparison and post-comparison CAS','Consistent; B6 raw capture/O1/O3/O4. All observed/expected bytes and input preservation traversed, counters include repeated closure rereads; no expected-to-observed substitution.'),
'O6':('03 O6','One frozen large correctness campaign','Consistent; C checks/emission/B5/B6/O1–O5. 102 ordinary +16 faults=118, one production configuration; no M2 performance dependency.'),
'M1':('04 M1','Checked-phase/resource/campaign contracts','Consistent; actual contiguous paid partition and exact full-span equality. Copies may be absent with retained reason; preparation copies remain outside timer under B6 contract.'),
'M2':('04 M2','Live instrument controls and reviewed capability','Consistent; B-owned host fixtures, M1/O4. NativeCapability differs from B5 NativeQualification. Missing allocation path/phase leaves performance unavailable.'),
'M3':('04 M3','Owned collector/append-only outcomes','Consistent staged bootstrap: M5a precedes real training; M6a implementation can precede data. O6/M2 required before timing admission; serial measurement worker.'),
'M4':('04 M4','Exposure ledger and actual experiment history','Consistent; may run early without data execution. Historical primary stays descriptive; independent entropy/custody required for future confirmatory scope.'),
'M5a':('04 M5 first phase','Frozen analytic policy/common portfolio/build/edit jobs','P5: required straightforward scalar Core control has no assigned source producer. Rest consistent: precedes M3, exact five-job median binary and deterministic edit.'),
'M5b':('04 M5 second phase','Best fixed baseline from admitted complete training','Consistent; consumes M6a VerifiedTrainingSet after M3. Equal cell medians, M/I/R ties, group identity and unchanged required keyset; no future-history dependency.'),
'M6a':('04 M6 first phase','Independent run/training admission','Consistent; consumes M1–M4/M5a/O3–O5, never M5b. Controls permit implementation before real training; complete type only after full actual keyset.'),
'M6b':('04 M6 second phase','Separate pilot and final request admission','Consistent staged interfaces: pilot requires baseline/candidate history, final requires completed experiment. Does not require future policy/final event for pilot.'),
'M7':('04 M7','Current-clock pilot freeze and final analytical export','Consistent; pilot freeze before selection/measurement; final export reuses original seal. External qualification identity does not imply evaluator traversed qualification bytes.'),
'M8':('04 M8','Execute staged campaigns and report all outcomes','Consistent; implementation readiness may precede data. Runtime sequence follows M5a→M3→M6a→M5b→pilot/M6b→M7 freeze→selection/final→M6b→M7 analysis. Quota amendment reviewed before launch.'),
'R1':('05 R1','Auditable source ledger and literature gaps','Consistent; missing full texts stay unavailable, bounded search, no negative competitor claims from missing evidence. Does not block engineering.'),
'R2':('05 R2','Contribution comparison/decision','Consistent; R1 and preliminary compact/storage design; engineering-only is legitimate. No invented theorem/novelty from labels.'),
'R3':('05 R3','Frozen hypotheses/baselines/falsifiers','Consistent; prospective research collection requires this review; disclosed implementation diagnostics are separately labeled. C7 deferral narrows H3 rather than forcing promotion.'),
'R4':('05 R4','Research checker/storage experiment drivers','Consistent; consumes compact/oracle interfaces/R3 and complements C11. No duplicate core checker or relabeling diagnostics as heldout evidence.'),
'R5':('05 R5','Soundness/trusted-base/mechanization decision','Consistent; independent mathematical review required; C7 property theorem conditional on promotion. Mechanization separate scope, not prerequisite implied for G3.'),
'R6':('05 R6','Private incremental technical report/claim ledger','Consistent; skeleton may precede R1–R3 completion; strongest claims wait supporting results. Preserve historical/proposed/measured distinctions.'),
'R7':('05 R7','Qualified native/close-system comparisons','Consistent; consumes M8/O6 qualification/protocol evidence. External baselines only after semantics/feasibility review; no duplicate collector. P5 affects scalar control.'),
'R8':('05 R8','Readiness and concrete private disclosure package','Consistent; next-family decision is not implementation authorization for extra families. Public disclosure remains separately authorized; engineering G3 need not wait G4/G6.')
}
interfaces=[]
def iface(name,prod,cons,rule): interfaces.append((name,set(prod.split()),set(cons.split()),rule))
iface('recovery receipt','G0','G1 B1 B2 C1 C2 O1 R1','G0 before product implementation; current pins reconciled explicitly')
iface('shared frozen source/IR/ABI/status ownership','G1','B1 C1 C2 C3 O1 M1 M4','Normative design governs; task owners implement, not competing schemas')
iface('source_profiles.AdmittedLoopKernel/admit_source_v2','C2','B1 B4 C3 C5 C6 C7 C8 C9 C10 C11 O1 O2 I1','C2 sole producer; fresh bytes at trust boundaries; P1 timing')
iface('boundary/fixture ABI','B1','B2 B3 B4 B6 O1 M1','P2 fixture adapter only; private entry and status convention fixed')
iface('confirmed generated type/signature seam','B2','B3 B4 B5 B8','Actual unchanged emit-c and pinned type; B8 conditional, not assumed')
iface('owned lifecycle/allocator/host phase hooks','B3','B5 B6 B7 B8 M1 M2','Single native host owner; M2 requests fixtures through B3; serialize edits')
iface('CoreEmissionV2','B4','B5 B7 B8 O6 I1 M5a','Fresh checker result plus separately bounded machine lowering; no case constants')
iface('NativeQualification/NativeBuildV2 inventory','B5','B6 B7 B8 O4 O6 I1 M2 M3 M5a M6a','P4 production blob transport then real inventory; build qualification is not measurement capability')
iface('NativeRunV2/complete raw capture','B6','B7 B8 O5 O6 M3 M6a','Complete means source result plus full acquisition only; O5 independent comparison')
iface('conditional revised Core pin','B8','B2 B3 B4 B5 B6 B7','Only reproduced seam failure; requalify affected pin/receipts separately')
iface('C1 approved rules/quotas/hand derivations','C1','C3 C4 C5 C6 C8 C11 R2 R5','C4–C11 blocked on failed feasibility; C2/C3 independent infrastructure may proceed')
iface('LoopPlan/LoopCandidate/LoopLimits/ConstraintRequestV2 codec','C3','C4 C5 C6 C7 C8 C9 C10 C11 B4 I1','Canonical immutable bounded artifact; decoded certificate does not grant proof')
iface('checked region facts/ProofBudget','C4','C5 R5','No serialized trusted fact; output conservation and exact precharge')
iface('LoopCheckResult/check_loop_plan','C5','B4 C6 C7 C8 C9 C10 C11 I1 M5a R4 R5','Eligibility complete+verified+valid+satisfied; unknown is not invalid')
iface('manual fixtures/concrete small observations/v1 bridge','C6','C8 C11 B7 R3 R4 R5','Interpreter independent of proof/generation; C8 extends bridge serially')
iface('abstract storage result/promotion decision','C7','C2 C5 C9 C10 C11 M5a R2 R3 R4 R5 R6','Conditional promotion; diagnostic/deferred cannot enter hard constraints')
iface('three untrusted production candidates/order','C8','C9 C11 O6 M5a','inline/materialize/rows2 frozen generation; opaque checker labels')
iface('LoopSearchResult/ranking','C9','C10 C11 I1 M5a','Exact full lexicographic metrics, cap intersection and charged matching incumbent')
iface('retained attempt/replay manifest','C10','I1 M5a','Fresh replay; exact bytes/version/caps; manifest last')
iface('proof scaling evidence','C11','B7 R4 R5 R6','No buffers/per-output expansion; proof-only result does not establish native execution')
iface('BlobReference/VerifiedBlob/VerifiedInvocation','O1','B5 B6 O2 O3 O4 O5 O6 M1 M3','Low-level production-safe transport, revalidate changed files; no research imports in native API')
iface('OracleResult/source AST execution','O2','O3 O6 R4','Original AST evaluator, no plan/native helpers; work exhaustion has no expected state')
iface('VerifiedOracle/qualified expected anchor','O3','O4 O5 O6 M2 M3 M6a M6b','Independent selected oracle; typed receipt not permanent authority')
iface('VerifiedEvidenceStores/qualification closure','O4','O5 O6 M2 M3 M6a M6b M7','Both roots fully traverse; inventory may not be truncated to fit')
iface('ComparisonReceipt/CAS/work counters','O5','O6 M1 M3 M6a M6b M7','Full per-run traversal before sharing; identities/counters survive CAS')
iface('one 118-call G3 campaign','O6','B7 I1 M3 M8 R6 R7 R8','O6 runs once; B7 independent review and distinct focused config controls')
iface('CheckedCallContract/CampaignSpec/reservations','M1','M2 M3 M5a M6a M6b M8','Full contiguous timing span and numerical cumulative I/O reservations')
iface('CollectorQualification/NativeCapability','M2','M3 M5a M6a M6b M7 M8 R7','Reviewed independent registry and real live controls; no self-reported eligibility')
iface('CollectedRun/CampaignOutcome','M3','M6a M6b M8','Append all failures and exact run schedule; each invocation captures')
iface('ExposureLedger/ExperimentHistoryV2','M4','M5a M5b M6a M6b M7 M8 R3 R7','Actual stage prefix only; historical primary never becomes fresh')
iface('FrozenSelector/CommonFixedPortfolio/build-edit metrics','M5a','M3 M5b M6a M6b M8 R3 R7','Freeze before training; median-job executable exact; P5 scalar control ownership')
iface('VerifiedTrainingRun/VerifiedTrainingSet','M6a','M5b M6b M8','No baseline prerequisite; all required training keys before complete set')
iface('FixedBaselineReceipt/candidate freeze','M5b','M6b M7 M8','Select from admitted complete data; fixed policy has specialized binary inventory')
iface('NativePilotAdmission/NativeRequestAdmission','M6b','M7 M8','Separate stage types; pilot needs no future final freeze')
iface('FrozenPilotV2/NativeEvaluationRun','M7','M5b M6b M8 R7','Current-clock seal precedes final selection; final admission uses actual complete history')
iface('ExperimentReport/native study evidence','M8','R6 R7 R8','Every required cell/failure retained; no automatic adoption')
iface('source ledger/reading support','R1','R2 R6 R8','Missing paper unavailable; claim evidence classes preserved')
iface('contribution decision','R2','R3 R5 R6 R8','One primary and at most one secondary hypothesis; narrow/null allowed')
iface('frozen research protocol/hypotheses','R3','R4 R6 R7','Prospective research only after freeze; diagnostics remain diagnostics')
iface('research scaling/storage rows','R4','R6 R8','Raw complete outcome reconstruction, no hidden expansion')
iface('soundness/trusted components','R5','R6 R7 R8','Assumptions and implementation/model/native boundaries explicit')
iface('private report/claim ledger','R6','R8','No results-bearing unsupported claims; disclosure private')
iface('native/competitor study','R7','R8','Qualified matched scope; null/unavailable legitimate')
shared=[
('axiom/src/axiom/core_native_v2.py','B2 B5 B6','B2 minimal helpers → B5 qualification/build → B6 invocation, serialized'),
('axiom/tests/fixtures/core_native_v2/','B1 B2 B3 B4 B7','B1 manual fixtures; B2 binding; B3 allocator retrofit; B4 emitted fixtures; B7 integration additions, serialized'),
('axiom/native/v2 host/protocol/allocator','B3 B6 M2','B3 owns lifecycle; B6 protocol integration; M2 controls remain B-owned, no research duplicate'),
('axiom/docs/core-native-v2.md','B5 B7','B5 build contract then B7 correspondence evidence'),
('axiom/docs/loop-plan-v2.md','C1 C2 C3 C4 C5 C8 C9 C10 C11','Serial shared document edits; C1 rules/quotas before consumers freeze'),
('axiom/tests/fixtures/loops/','C3 C5 C6','C3 README/schema; C5 certificate fixtures; C6 manual controls; distinct names and serial schema change'),
('axiom/tests/test_loop_v1_bridge.py','C6 C8','C6 manual bridge first; C8 production-candidate entry added serially'),
('C2/C5 source/checker promotion files','C2 C5 C7','Only after C7 independent promotion; update contracts/replay consumers serially'),
('research/protocol/source-oracle-v1.md','O2 O3','O2 semantics then O3 receipt/qualification extension'),
('research/protocol/native-acquisition-v2.md','O5 O6','O5 transport/accounting then O6 campaign rules'),
('research/training_selection.py and tests/protocol','M5a M5b','Same owner or serial handoff; early policy/jobs then actual baseline'),
('research/native_receipt_admission.py and tests/protocol','M6a M6b','Common verifier and training first; pilot/final second')]
pairs=defaultdict(list)
for name,producers,consumers,rule in interfaces:
 for a,b in combinations(sorted(producers|consumers,key=lambda t:list(tasks).index(t)),2):
  def role(t): return 'produce/update' if t in producers else 'consume'
  pairs[(a,b)].append(f'`{name}`: {a} {role(a)}, {b} {role(b)}. {rule}.')
for path,members,rule in shared:
 for a,b in combinations(sorted(members.split(),key=lambda t:list(tasks).index(t)),2):
  pairs[(a,b)].append(f'Shared file `{path}`: {rule}.')
lines=['# Axiom scalability implementation preflight','',
'Status: CONDITIONAL PROCEED for early implementation after G0/G1; five concrete sequencing/ownership rulings remain to be recorded by the integration lead. No inherent source/IR/native semantic contradiction was established. This is a document-contract review, not proof feasibility, native qualification, test execution or product approval.',
'', 'Scope: independently read normative design.md, README including G0/I1, and every B1–B8, C1–C11, O1–O6, M1–M8 (including M5a/b and M6a/b), R1–R8 task. Prior review reports were read only after the primary task review. Historical planning-only authority is superseded by the current implementation instruction. Existing isolated checkout is sufficient. Only this report was written; no plans/product files changed, no commit or subagent created.',
'', '## Exact unresolved integration rulings', '',
'| ID | Evidence / conflict | Recommended ruling | Affected gate |',
'| --- | --- | --- | --- |',
'| P1 | 01/B1 depends on “shared profile definition” and forbids implementing AdmittedLoopKernel; 02/C2 is its sole implementation owner. The master parallel graph does not explicitly place C2 before B1 executable tests. | C2 implements/reviews admission first; B1 may draft prose/manual fixtures in parallel, but its executable profile acceptance consumes C2. C1 and C2 can proceed independently after G0/G1. Never copy source admission into the native lane. | Before B1 completion/B2. |',
'| P2 | 01/B1 requires event-observable rejection of an adapter allocating scratch before preflight, but owns only docs/tests/fixtures; B3 owns the actual lifecycle and depends on B1/B2. | B1 owns a tiny explicitly test-only event fixture adapter with deliberate ordering mutations; B2 observes its actual tiny Core/native seam; B3 separately proves the production lifecycle. Alternatively defer the production-order assertion to B3, retaining B1 contract tests. Do not claim B1 alone verified a production host. | Before B1 acceptance. |',
'| P3 | Shared edit ownership spans core_native_v2.py (B2/B5/B6), B2 fixture replacement by B3, loop-plan-v2.md (many C tasks), C6 bridge extension by C8, C2/C5 optional C7 promotion, and B-owned host fixtures requested by M2. | Use serial owner handoffs shown in pair matrix; one implementation owner at a time in current ledger satisfies collision protection. Before C7 promotion, update producer and all cap/rank/replay consumers together. Research never implements another host. | Before relevant task starts; not a block to C1/C2. |',
'| P4 | B5 depends on “shared safe artifact-store APIs”; O4 depends on actual B5 inventory, and O4 implementation is in research while production must not import research. Wording leaves a bootstrap/import ambiguity. | Freeze O1 low-level blob API first. B5 owns NativeQualification and its production inventory/build closure using O1; O4 develops synthetic store controls early and consumes/revalidates the actual B5 inventory afterward. A B5 production call must not depend on O4 research imports or future NativeCapability. | Before B5/O4 integration; not G2a. |',
'| P5 | design.md requires straightforward checked scalar Core alongside three fixed plans; 04/M5a and 05/R3/R7 repeat it, but no task names its source producer/owned fixture and build mode. | Assign M5a the small independent scalar Core control source/build-mode adapter, with B4/B5 review of the same checked boundary and toolchain; retain all comparison identities/costs. It is a control, not a fourth C8 portfolio ID. Freeze its files before measurement work. | Before required measurement/comparison collection; not G3. |',
'', 'These are implementation handoff gaps, not requests for new user approval. The integration lead can record the above bounded rulings within existing authorization. No speculative container, compiler, solver, symbolic-shape, learned-selector or mechanization extension is needed.',
'', '## Early gates and dependency interpretation', '',
'- G0 restoration/source inventory is a real prerequisite; a saved cloud draft or existing bundle alone is not a fresh restoration receipt. Known Core failures remain explicitly classified.',
'- G1 freezes public ownership/contracts. C1 independently proves restricted proof feasibility; B2 independently qualifies native seam. Neither can be inferred from prior planning PASS.',
'- C1 blocked stops C4–C11. C2/C3 may remain useful infrastructure. B2 no longer depends on B3 allocator; the former cycle is resolved in current text.',
'- After C2, B1→B2→B3 and C3→C4→C5 can progress with separate reviewed boundaries. B4 waits fresh checker + native seam. O1→O2/O3 can progress without native execution.',
'- B5 uses O1 and its own build inventory; O4 final actual-store qualification follows that inventory. B6 then O5/O6 complete actual correspondence. B7 consumes O6’s single 118-call campaign and adds distinct small configuration controls.',
'- G3 does not require M2 performance capability. G4 means qualified instrument/admission machinery readiness; it cannot mean already having final experiment receipts. The detailed M5a→M3→M6a→M5b→pilot→M6b/M7 freeze→final selection/collection→M6b final→M7 analysis sequence governs actual evidence.',
'- M8’s dependency on implementations M1–M7 is not a dependency on their future runtime data. M6a controls may be implemented before collection; a real VerifiedTrainingSet only follows complete actual training.',
'- R3 gates prospective research collection, not the explicitly disclosed C1/C11/O6 implementation diagnostics. C7 deferral narrows storage claims. External entropy/custody/literature availability and disclosure are later distinct gates.',
'', '## Task self-consistency matrix', '', '| Task | Section | Produce / owned acceptance | Self-consistency and execution constraint |','| --- | --- | --- | --- |']
for key,(section,product,note) in tasks.items(): lines.append(f'| {key} | {section} | {product} | {note} |')
lines += ['', '## Shared file and interface pair matrix', '',
'Each unordered pair below appears once. It includes producer–consumer pairs and co-consumers sharing a public interface, plus all explicitly shared owned files identified in the task text. A co-consumer row requires the same owner-defined meaning, not an invented direct dependency. “Produce/update” includes C7’s conditional contract promotion. Pure transitive access is represented by the nearest declared API rather than making every task depend on all internal helpers. Generic review/log conventions do not create shared product ownership.', '',
'| Task pair | Produce/consume contract, shared ownership and conflict disposition |','| --- | --- |']
for (a,b),notes in sorted(pairs.items(),key=lambda x:(list(tasks).index(x[0][0]),list(tasks).index(x[0][1]))):
 lines.append(f'| {a} / {b} | '+ '<br>'.join(notes).replace('|',' / ')+' |')
lines += ['', '## Retained source identities', '', '| Document | SHA-256 |','| --- | --- |']
for f in [plan/'design.md',plan/'README.md',*sorted(plan.glob('0*.md'))]: lines.append(f'| {f.name} | `{hashlib.sha256(f.read_bytes()).hexdigest()}` |')
lines += ['',f'Coverage: {len(tasks)} task/gate rows and {len(pairs)} distinct shared-file/interface pair rows. All six requested task documents and normative design were read. Documentation review only; no implementation tests executed.']
output.parent.mkdir(parents=True,exist_ok=True)
output.write_text('\n'.join(lines)+'\n')
print(output)
print(f'{len(tasks)} task/gate rows; {len(pairs)} pair rows; {output.stat().st_size} bytes')

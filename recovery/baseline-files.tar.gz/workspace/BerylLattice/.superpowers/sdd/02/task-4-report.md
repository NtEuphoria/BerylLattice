# Plan02 Task4 correspondence campaign — execution in progress

Owned files: `axiom/tests/integration/{__init__.py,corpus.py,case-schema.json,test_core_correspondence.py,test_core_mutations.py}`. No Core edits, limit increases, throughput claims or commits.

## Implemented contracts

- Mandatory 108 cases: six exact requested shapes; zero/max/alternating/ramp/four corner impulses/two fixed seeds; -1 and 1024 at first/middle/last; two invalid-element patterns proving first failure. All three plans, five lane/configurations = 1,620 required unique cells.
- Independent oracle exclusively `reference.evaluate_source` on original source bytes; compares status, every input and every output for reference and native, retaining sentinel output on rejection.
- Nightly explicitly requires `AXIOM_CORE_NIGHTLY=1`: 48 H5/W7 impulses plus (7,7)/(9,9), four extra seeds = 88 cases, 1,320 cells. It is not run by default and was not executed in this task.
- Three byte-consistent faulty-emitter controls alter a neighbor, blank the final store, or return 46 instead of the last invalid index 47. Recomputed source/kernel/case/mapping hashes pass bundle identity. Actual controls require successful Core lanes agreeing with one another, yet independent-oracle semantic mismatch.
- Versioned manifest root contains exact UTF-8 sources, SHA256 hashes, inputs/sentinels, all three plan IDs and explicit lane/release configurations. JSON schema is tracked; full manifests/receipts remain outside git.
- Missing prerequisites visibly skip as native unavailable and never write a completion receipt. Completion requires the exact unique case/plan/lane/release keyset; duplicate successes cannot fill absent cells.
- Future native matrix calls use joined thread pools with explicit `AXIOM_CORE_WORKERS=1..4` (default4), private runner directories, locked append records and stable final ordering. The already running sequential corpus was not interrupted.

## Red/green evidence

1. Before orchestration: `PYTHONPATH=src python -m unittest discover -s tests/integration -v` failed because the integration start directory was not importable. After only creating the package it reported zero tests and exit5; no false native pass.
2. Initial correspondence tests failed on missing corpus helper; helper implementation made corpus contracts pass with explicit native skips.
3. Duplicate success rows test first failed because no assertion was raised; exact required-keyset validation made it pass.
4. Explicit worker-limit test first failed on absent helper; bounded parser implementation made it pass.
5. Final portable commands `PYTHONPATH=src python -m unittest discover -s tests/integration -v` and `PYTHONPATH=src python -O -m unittest discover -s tests/integration -v`: each 12 tests, 9 passed / 3 visibly skipped. Logs `/workspace/scratch/axiom-task4-portable.log` and `...-portable-optimized.log`.

## Actual native runs in progress

- Core source `/workspace/beryl`, clean exact pin `0a678b4ae6d41190c4f5a8bf063caba05759d20d`.
- Selected Clang `/workspace/scratch/axiom-toolchain-setup/toolchain/usr/lib/llvm-19/bin/clang`.
- Full quick run: `AXIOM_CORE_SOURCE=/workspace/beryl AXIOM_CLANG=/workspace/scratch/axiom-toolchain-setup/toolchain/usr/lib/llvm-19/bin/clang AXIOM_CORE_EVIDENCE_DIR=/workspace/scratch/axiom-task4-evidence PYTHONPATH=src python -m unittest tests.integration.test_core_correspondence.ActualCorrespondenceTests.test_quick_mandatory_corpus_all_plans_all_lanes_and_native_o2 -v`.
- Full quick evidence `/workspace/scratch/axiom-task4-evidence/axiom-correspondence-8yl13dg7`; live complete observations and exact argv/hashes at `lane-matrix.jsonl`; self-contained `quick-manifest.json`; actual log `/workspace/scratch/axiom-task4-actual.log`. Final count pending.
- 45 actual mutation controls: same configuration with evidence parent `/workspace/scratch/axiom-task4-mutation-evidence`, test `tests.integration.test_core_mutations.MutationControls.test_independent_oracle_rejects_all_rehashed_faults_when_core_lanes_agree`; live evidence `/workspace/scratch/axiom-task4-mutation-evidence/axiom-correspondence-cjtpu04i`; log `/workspace/scratch/axiom-task4-mutations.log`. Final count pending.
- Parallel smoke: `Campaign.from_environment().run_matrix` on H5/W7 coordinate ramp, all three plans and all five configurations, evidence `/workspace/scratch/axiom-task4-parallel-evidence/axiom-correspondence-8ea7s5p2`; log `/workspace/scratch/axiom-task4-parallel.log`. Final count pending.

## Rulings and limits

Ruling: use sources without a workspace-cap requirement for correspondence — all three intended physical plans must be exercised; all normal Axiom and fixed Core limits remain enforced — if wrong, add a separate cap-admission corpus, without relabeling plan rejection as semantic conformance.

Ruling: perform independently scoped integration testing before the combined Plan01 CLI gate finishes, as explicitly directed by the parent — this establishes technical evidence only; final milestone acceptance waits for the combined prerequisite gate — if wrong, repeat after the combined gate.

No broad unrelated suite was run, as directed. Known pinned Core ownership-fixture unit failures remain explicitly classified by toolchain qualification. Transitive SDK/linker/dynamic-library identity remains incomplete. Nightly is unexecuted. Full quick acceptance and final milestone remain pending actual completion, combined Plan01 CLI gate, and independent review.

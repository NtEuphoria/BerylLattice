# Authorized implementation task

The user explicitly requested implementation of all three reviewed plans. Earlier planning-only restrictions no longer block implementation. Work in /workspace/BerylLattice.

# Axiom Core Bridge Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Produce actual Core programs from checked Axiom plans and compare their complete observations with the independent Axiom source evaluator.

**Architecture:** A source emitter consumes immutable checked plan bytes, generates an ordinary `.be` kernel plus isolated witness, and retains byte-level provenance. A process adapter invokes the pinned Core compiler through existing admission. Production AST and experimental IR differential paths remain separate result lanes.

**Tech Stack:** Plan01 Python package, Beryl commit `0a678b4ae6d41190c4f5a8bf063caba05759d20d`, C11/Clang, existing Core CLI, standard-library subprocess and hashing.

**Spec:** [Prototype contract](../../../prototype-contract.md), [Core interface](../../../../axiom-foundations-2026-10-15/core-interface/interface-decision.md), [observer contract](../../../../axiom-foundations-2026-10-15/core-interface/observer-contract.md).

## Global Constraints

- Plan01 must pass first. All source/plan bytes are rechecked before emission; an externally supplied success record is insufficient.
- Existing complete Core frontend admission is mandatory. Do not directly populate typed AST or call IR C emission to bypass gates.
- H5/W7: input48/output35; return -1 success or first invalid input index; output is separate and initialized.
- Every input and output scalar plus status is observed. Different plan source offsets are not compared as if they were identical Core events.
- IR keeps 256 cells per aggregate, 64-KiB declared-storage estimate and fixed native execution budgets.
- No throughput claim, new native ABI, raw-pointer interface, Core limit increase or benchmark-collector repair in this plan.
- Record compiler/Clang binaries, known toolchain components and exact argv; unobserved SDK/linker dependencies remain explicit limits. Missing Clang is unavailable, not a passed test.

## Review Focus

- A compiler path containing spaces: argument lists preserve it and receipts capture the actual executable; Task1/3.
- Input failure at the last element: all output remains sentinel-valued and first invalid index is exact; Task2/4.
- A source generator defect shared by both Core lanes: independent Axiom observations catch it; Task4.
- Unsupported Core lowering or process timeout: unavailable/error stays distinct from semantic mismatch; Task3.
- Old schema-4 experimental helper docs: do not apply them as commands for current schema5; Task1.

## File map and shared interfaces

Paths relative to future `/workspace/BerylLattice/axiom/`:

```text
src/axiom/core_toolchain.py    identity/preflight and isolated Core build receipts
src/axiom/core_emit.py         source and provenance generation
src/axiom/core_runner.py       process isolation, output capture, result classification
src/axiom/core_observe.py      complete scalar observation decoding
tests/test_core_*.py           unit/protocol/negative controls
tests/integration/             actual compiler correspondence cases
docs/core-bridge.md            supported commands, limitations and receipts
```

Result records live in the owning module. `Toolchain` holds absolute compiler/Clang paths and hashes, Core source identity, version stdout and build receipts. `NativeRun` holds lane, argv, outer returncode, Core-reported subprocess status/code, stage/whole-run timeout and cleanup status, stdout/stderr paths/hashes, result/job paths and classification. Core folds native signals into 128+signal, which is ambiguous with an ordinary exit code; an exact native signal is unavailable unless separately observed. `Observation` holds status, input tuple and output tuple. Failed/partial runs retain diagnostics without advertising conformance.


### Task 1: Toolchain preflight and reproducible isolated build

**Files:** Create `core_toolchain.py`, `tests/test_core_toolchain.py`, `docs/core-bridge.md`.

**Interfaces:** `inspect_toolchain(core_source: Path, clang: Path) -> ToolchainPreflight`; `build_core(snapshot: Path, clang: Path, output: Path) -> Toolchain`. No default search that silently selects a different Clang. Use a disposable copy of the pinned source outside the existing checkout, with inventories before/after; no extra Git worktree is needed. Record expected build-generated headers separately.

- [ ] Test missing executable, nonzero version probe, different source commit, dirty source inventory, paths with spaces and unsuccessful compile/run. Failures must be unavailable/error, with no success receipt.
- [ ] Run `PYTHONPATH=src python -m unittest tests.test_core_toolchain -v`; confirm missing implementation failure.
- [ ] Implement identity capture and isolated build using the existing `scripts/build.sh --debug` and `scripts/test.sh`. Both scripts name `clang`; expose the selected executable as `clang` in a private PATH directory and record the resolved target. Do not change global alternatives or edit Core scripts.
- [ ] At execution time obtain a normal supported Clang installation if absent; record exact version/binary and source of installation. No exact package build is invented in this plan. Native results remain unavailable until the tool exists and its C11 compile/run preflight succeeds.
- [ ] In the isolated snapshot, run `bash scripts/build.sh --debug`, then `bash scripts/test.sh`, with the private PATH. Expected: actual compiler version probe/build and unit suite succeed. Record generated runtime-header changes; any source difference outside expected regeneration blocks pinning the build as the inspected commit until reconciled.
- [ ] Qualify the requested native-evidence flags with an actual tiny witness: C11 compilation alone does not prove LLVM IR, assembly and driver-job captures work. Distinguish binary-byte hashes from Core's path-sensitive loaded-source fingerprints; do not demand equal source-manifest hashes across arbitrary output directories.
- [ ] Verify current schema5 source, not the historical schema4 `tools/beryl-ir-experiments/README.md` protocol. Commit only Axiom toolchain adapter/tests/docs as `feat(axiom): pin and probe the Core toolchain`.


# Plan02 Task4 independent review

Reviewed commit `10f7029abc75f8931eb8b4423d39d646c6670403`, the Task4 brief/report/review package, current owned files, the source evaluator and runner admission/observation contracts, and retained native evidence. No production/test code was edited, no suite/native campaign was rerun, and the ongoing corpus process was not signalled or otherwise changed.

## Verdict

**Specification/code verdict: APPROVE. Quality verdict: APPROVE. No blocking code findings.**

**Native milestone/evidence verdict: PENDING.** The complete 1,620-cell quick campaign has not finished at this review snapshot. Approval of the implementation does not certify native conformance or satisfy the combined Plan01 prerequisite gate. Final acceptance requires the exact full case/plan/lane/release keyset, all matched, successful test termination and its completion receipt; missing/unavailable/skipped/error cells cannot qualify.

## Coverage and independence

- `corpus.py:58` explicitly defines 18 cases for each of the six required shapes: zeros, maximums, alternating extremes, coordinate ramp, four corner impulses, two fixed random seeds, both invalid values at first/middle/last, and two distinct two-invalid patterns. The original evaluator checks first failure and unchanged complete sentinel output. Every case uses all three physical plans and reference/debug AST/debug IR/O2 AST/O2 IR configurations.
- `corpus.py:104` derives the expected numeric observation exclusively by parsing the original Axiom source and calling `reference.evaluate_source`. That evaluator interprets retained source equations using its own expression traversal; it does not consume the physical plan, Core source, emitter calculations, or native agreement. `Campaign.check` compares the full immutable status/input/output observation. Runner admission requires complete reference/native scalar framing and successful admitted lanes before a row can become matched.
- The manifest embeds exact original UTF-8 source bytes, their SHA256, concrete inputs and distinct output sentinels, all plan IDs and lane/release configurations. I independently verified all 108 source hashes in each retained manifest. No source arithmetic is copied into an expected-output producer. Removing the optional workspace cap permits the intended plans without raising normal Axiom/Core limits.
- Nightly is an explicit opt-in, deliberately sampled 88-case corpus: all 48 H5/W7 impulse positions plus larger shapes and additional fixed seeds. It remains unexecuted and is not represented as passing.

## Mutation controls and retained actual execution

`test_core_mutations.py:12` makes actual same-length Core semantic changes and recomputes kernel/source/case/mapping identities; fresh bundle admission accepts those byte-consistent artifacts. The actual controls require `CorpusMismatch`, successful Core lane execution, and reference/native agreement, rather than accepting infrastructure failures as rejection.

I independently read all 45 retained mutation rows under `/workspace/scratch/axiom-task4-mutation-evidence/axiom-correspondence-cjtpu04i`: exactly 15 per mutation, all 45 underlying runs successful and all 45 classified semantic mismatch; all 36 native observations agree with their Core reference observation. Retained witness and reference/native stdout bytes match their recorded hashes. Representative observed defects are:

- Wrong neighbor: first ramp output 2121 instead of independent expected 2118.
- Dropped final store: output index34 remains sentinel -700034 instead of 87398.
- Shifted failure index: returned46 instead of47 for the last invalid input, with the independent expected rejection state.

The actual mutation test log reports one test passed in125.302s. These controls demonstrate a shared emitter defect can pass both Core lanes and byte-identity checking while failing the independent oracle.

## Matrix integrity and concurrency

`Campaign.complete` (`corpus.py:255`) checks both the exact unique keyset and row count, excludes mutation rows, and requires every classification matched. Duplicate successes cannot fill missing cells. Native prerequisite absence is an explicit `SkipTest` stating it does not establish conformance; portable green status cannot create the completion receipt.

The bounded worker path parses only1..4 workers, builds immutable bundles sequentially, creates private runner directories, locks append records, joins the pool before reporting errors, and sorts/replaces the published matrix only after workers join. Ordinary worker errors remain failed results. Retained parallel H5/W7 ramp evidence under `/workspace/scratch/axiom-task4-parallel-evidence/axiom-correspondence-8ea7s5p2` contains15 unique matched cells across all plans/configurations. I checked the actual compile argv for all12 native cells: debug uses-O0 and release uses-O2. Its receipt records the required Core pin `0a678b4ae6d41190c4f5a8bf063caba05759d20d` and preserves the known pinned baseline unit failure and incomplete transitive toolchain identity limitations.

## Verification evidence and remaining gate

Both retained portable logs report12 tests:9 passed and3 explicit skips, under normal and Python-O execution. I inspected these logs instead of repeating the unchanged suite.

At the independent live snapshot, `/workspace/scratch/axiom-task4-evidence/axiom-correspondence-8yl13dg7/lane-matrix.jsonl` contained518 unique successful/matched cells and no `quick-complete.json`. This is progress evidence only; the count will change while the already-running sequential sweep continues. The45 mutation and15 parallel cells are separate supporting evidence and cannot substitute for absent mandatory quick cells. Combined Plan01 CLI qualification remains an external pending acceptance gate. No nightly or throughput claim is approved.

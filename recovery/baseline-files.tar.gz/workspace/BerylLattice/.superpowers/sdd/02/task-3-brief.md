# Authorized implementation task

The user explicitly requested implementation of all three reviewed plans. Earlier planning-only restrictions no longer block implementation. Work in /workspace/BerylLattice.

# Axiom Core Bridge Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Produce actual Core programs from checked Axiom plans and compare their complete observations with the independent Axiom source evaluator.

**Architecture:** A source emitter consumes immutable checked plan bytes, generates an ordinary `.be` kernel plus isolated witness, and retains byte-level provenance. A process adapter invokes the pinned Core compiler through existing admission. Production AST and experimental IR differential paths remain separate result lanes.

**Tech Stack:** Plan01 Python package, Beryl commit `0a678b4ae6d41190c4f5a8bf063caba05759d20d`, C11/Clang, existing Core CLI, standard-library subprocess and hashing.

**Spec:** [Prototype contract](../../../prototype-contract.md), [Core interface](../../../../axiom-foundations-2026-10-15/core-interface/interface-decision.md), [observer contract](../../../../axiom-foundations-2026-10-15/core-interface/observer-contract.md).

## Global Constraints

- Plan01 must pass first. All source/plan bytes are rechecked before emission; an externally supplied success record is insufficient.
- Existing complete Core frontend admission is mandatory. Do not directly populate typed AST or call IR C emission to bypass gates.
- H5/W7: input48/output35; return -1 success or first invalid input index; output is separate and initialized.
- Every input and output scalar plus status is observed. Different plan source offsets are not compared as if they were identical Core events.
- IR keeps 256 cells per aggregate, 64-KiB declared-storage estimate and fixed native execution budgets.
- No throughput claim, new native ABI, raw-pointer interface, Core limit increase or benchmark-collector repair in this plan.
- Record compiler/Clang binaries, known toolchain components and exact argv; unobserved SDK/linker dependencies remain explicit limits. Missing Clang is unavailable, not a passed test.

## Review Focus

- A compiler path containing spaces: argument lists preserve it and receipts capture the actual executable; Task1/3.
- Input failure at the last element: all output remains sentinel-valued and first invalid index is exact; Task2/4.
- A source generator defect shared by both Core lanes: independent Axiom observations catch it; Task4.
- Unsupported Core lowering or process timeout: unavailable/error stays distinct from semantic mismatch; Task3.
- Old schema-4 experimental helper docs: do not apply them as commands for current schema5; Task1.

## File map and shared interfaces

Paths relative to future `/workspace/BerylLattice/axiom/`:

```text
src/axiom/core_toolchain.py    identity/preflight and isolated Core build receipts
src/axiom/core_emit.py         source and provenance generation
src/axiom/core_runner.py       process isolation, output capture, result classification
src/axiom/core_observe.py      complete scalar observation decoding
tests/test_core_*.py           unit/protocol/negative controls
tests/integration/             actual compiler correspondence cases
docs/core-bridge.md            supported commands, limitations and receipts
```

Result records live in the owning module. `Toolchain` holds absolute compiler/Clang paths and hashes, Core source identity, version stdout and build receipts. `NativeRun` holds lane, argv, outer returncode, Core-reported subprocess status/code, stage/whole-run timeout and cleanup status, stdout/stderr paths/hashes, result/job paths and classification. Core folds native signals into 128+signal, which is ambiguous with an ordinary exit code; an exact native signal is unavailable unless separately observed. `Observation` holds status, input tuple and output tuple. Failed/partial runs retain diagnostics without advertising conformance.


### Task 3: Isolated process runner and observation parser

**Files:** Create `core_runner.py`, `core_observe.py`, `tests/test_core_runner.py`, `tests/test_core_observe.py`.

**Interfaces:** `run_core(bundle: CoreBundle, toolchain: Toolchain, lane: Literal['reference','ast','ir'], directory: Path, release: bool=False, pipeline_timeout_ms: int=1200000) -> NativeRun`; `decode_observation(stdout: bytes, kernel: AdmittedKernel) -> Observation`. Per-stage Core timeout remains120000ms; the independent whole-pipeline default is1200000ms. Record both; neither is a performance measurement.

- [ ] Use fake executables to test argv, spaces, timeout, malformed/partial output and missing files. The cleanup control must spawn a child in a distinct process group, as Core does. Send cooperative SIGTERM to Core first; on a bounded grace timeout, use a verified platform ownership mechanism (such as an owned cgroup) to terminate all nested groups. Killing only the outer process group is insufficient. If forced cleanup cannot be verified, return infrastructure error and do not claim process isolation. Select and demonstrate that mechanism on the target environment before accepting the runner.
- [ ] Parse exactly `1+(H+1)*(W+1)+H*W` signed-i32 scalar lines followed by `ok  1 test, 0 assertions\n`, with no extra payload, and cross-check report test counts. Use retained `reference.stdout.log` and `differential.stdout.log`; the outer CLI may include diagnostics. Reject omitted/extra/out-of-range values and altered summary.
- [ ] Run the owned tests and observe missing runner/parser failure.
- [ ] Implement argv-based calls with a dedicated working directory per invocation; Core creates `.beryl-cache` relative to it. Retain only newly created jobs belonging to that invocation, never the newest job in a shared cache. Pin source-inspected stdout/report framing against the first real smoke run.
- [ ] Use these source-verified command forms, substituting explicit paths:

```text
beryl test --backend reference --lowering ast --timeout-ms 120000 witness.be
beryl test --backend differential --lowering ast --opt off --clang CLANG --save-native-evidence --timeout-ms 120000 witness.be
beryl test --backend differential --lowering ir --opt off --clang CLANG --save-native-evidence --timeout-ms 120000 witness.be
```

- [ ] Require lane-specific success. Reference: completed successful reference execution and one test; `compared=false` is normal. Differential: additionally completed native success, report status success, compared true, requested/selected lowering agreement, and schema5 admitted profile for IR. Test `compared=true,status=failure` as rejection. Compare Axiom observations independently only after lane admission. `--release` is the optional O2 lane; `--opt off` does not disable Clang optimization. No invented CLI flags.
- [ ] Run tests and commit as `feat(axiom): retain complete Core correspondence evidence`.


# Task 5 retained toolchain loader report

Owned implementation: `axiom/src/axiom/core_toolchain.py`; owned tests: `axiom/tests/test_core_toolchain_load.py`.

## API and behavior

`load_toolchain(receipt: Path) -> Toolchain` restores frozen dataclasses, absolute Paths, immutable nested inventories, command receipts, file identities and observed Clang invocation tuples. Errors surface as `ToolchainError`.

The loader accepts the existing exact unversioned Toolchain writer record (without silently accepting missing/new fields) and the pinned Core native schema-1 receipt formats. It rejects duplicate JSON keys, nonfinite values, unexpected/missing fields, invalid scalar types including bool-as-int, invalid hashes/paths/modes, other Core pins and fabricated compiler versions. The pinned compiler version is `beryl 0.1.0-dev\n`, as defined by the pinned `src/driver/main.c`.

The loader independently validates retained build/unit/native receipt files against the embedded command records; validates their fixed expected argv/cwd, preflight C11/version records, known component identities derived from the retained ldd result, observed build/unit Clang capture, all eight required native artifacts, native process exits and schema versions, output hashes, native witness source bytes and complete 42 output, Clang configuration, binary/source/snapshot identities and current component lookup targets. It runs no command taken from JSON. Existing `revalidate_identity()` checks all byte-bound runtime artifacts. The source check invokes only the existing fixed Git inspection commands.

`known_pinned_baseline_failure` remains the exact retained unit result, including exit 1, both diagnosed fixture failures and the 2/10814/583 summary. A success label cannot replace evidence validation.

An exported receipt copy is accepted only when the recorded original receipt remains present and its bytes exactly match the supplied copy. Every bound original runtime path remains required; this does not relocate/rewrite a toolchain. Paths containing spaces are retained exactly as individual argv strings.

This is retained local qualification and identity checking, not cryptographic attestation against someone rewriting all local records. Recorded preflight observations remain trusted local observations; transient preflight probe files no longer exist. Existing SDK/linker/dynamic dependency completeness limitations remain explicit in Toolchain.identity_limits and the loader docstring.

## RED / GREEN evidence

Initial command from repository root:

`PYTHONPATH=axiom/src python -m unittest discover -s axiom/tests -p test_core_toolchain_load.py -v`

RED: positive behavior failed with `AssertionError: False is not true : missing strict load_toolchain API`; other calls errored with the same missing API. Implemented loader only after this failure.

Copy-binding regression command from `axiom/`:

`PYTHONPATH=src python -m unittest tests.test_core_toolchain_load.LoadToolchainTests.test_modified_copy_cannot_claim_original_receipt_binding -v`

RED: `AssertionError: ToolchainError not raised`. `read_text()` normalized CRLF, permitting a byte-altered copy to compare equal. Changed copy binding to compare `read_bytes()`.

Pinned-version regression command from `axiom/`:

`PYTHONPATH=src python -m unittest tests.test_core_toolchain_load.LoadToolchainTests.test_compiler_version_must_match_pinned_source -v`

RED: `AssertionError: ToolchainError not raised`. Tightened the compiler version check to the known pinned source version.

Final GREEN commands from `axiom/`:

- `PYTHONPATH=src python -m unittest tests.test_core_toolchain_load -v`: **11 tests, 12.770s, OK**.
- `PYTHONPATH=src python -O -m unittest tests.test_core_toolchain_load -v`: **11 tests, 11.861s, OK**.
- `git diff --check -- axiom/src/axiom/core_toolchain.py axiom/tests/test_core_toolchain_load.py` from repository root: clean.

The tests include the actual retained receipt at `/workspace/scratch/axiom-toolchain-task1-review1/output with spaces/toolchain.json`, 24 top-record mutation cases, 11 native-result/evidence mutations, standalone malformed-record checks, exact/altered exported copies, added configuration discovery and changed component symlink lookup with the old target still intact. Receipt-read substitution avoids mutating shared real qualification files. Actual binaries are hashed/read; no compiler rebuild or benchmark was needed. Nine retained tests plus the baseline mutation method require the existing retained receipt; malformed receipt parsing remains runnable without native tools.

Two exploratory invocations used an incorrect module/file path and failed before edits/tests; reran with the correct `axiom/` working directory. These were invocation mistakes, not suppressed product failures.

## Self-review

No CLI, capsule, main, docs, pinned source, original qualification files, or other worker-owned files changed. No commits or subagents created. Existing writer schema and public dataclass fields remain unchanged. CLI owner was given the API and copy-binding contract early. No `assert`-dependent validation is used, and optimized-mode tests pass.

A full suite was deliberately left to the root agent's combined immutable snapshot and final package verification, per root coordination instruction. Owned normal/optimized runs contain no failures or skips in this environment. Retained identity qualification does not claim Axiom semantic conformance.

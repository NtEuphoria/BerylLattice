# Plan02 Task3 independent review

Spec compliance: **CHANGES REQUIRED**. Code quality: **CHANGES REQUIRED**.

Reviewed the task brief/report/review package and current runner, supervisor, observer, emitter boundary, owned tests, and pinned Core reference-driver report implementation. Existing 16-test normal/optimized results and real three-lane smoke were inspected as reported evidence; unchanged suites were not rerun.

## P1 — Caller interruption kills the cleanup supervisor and orphans Core

Location: `axiom/src/axiom/core_runner.py:270-271`.

`subprocess.run()` kills its child on `KeyboardInterrupt` (its broad exception handler calls `process.kill()`). Here that child is the subreaper responsible for all descendant ownership and the independent deadline. Consequently interrupting the caller kills the supervisor before its cleanup protocol completes. Core runs in a separate session and survives, reparented to PID 1, with no remaining supervisor deadline or cleanup receipt. The supervisor's own SIGINT handler does not fix this: Python's interrupt wait is approximately 250ms, shorter than the supervisor's 500ms cooperative grace plus forced cleanup.

Confirmed with two isolated probes, without signalling corpus processes:

- Targeted SIGINT to a caller executing `run_core`: caller caught `KeyboardInterrupt`, while fake Core remained sleeping with PPID 1 and no receipt.
- Ordinary group SIGINT to an exclusively review-created caller/supervisor session, with fake Core ignoring SIGTERM: after 800ms the caller had caught `KeyboardInterrupt`, Core remained in state `S` with PPID 1, and no `supervisor-result.json` existed. Evidence: `/tmp/task3-group-cancel-review-thai6p7m/probe-result.json`. The probe Core was then killed through a pidfd opened while it was known to be owned; no unrelated process was signalled.

Use an explicitly managed `Popen` lifecycle that forwards cancellation cooperatively to the supervisor and waits for its bounded ownership cleanup before propagating interruption. Do not invoke a helper that automatically SIGKILLs the subreaper on caller exceptions. Add regression controls for both caller-only and caller-group SIGINT with a distinct-session descendant that needs forced cleanup, checking its disappearance and the retained cleanup receipt.

## Otherwise verified

The ordinary deadline path uses a dedicated, verified Linux subreaper; proc ancestry plus pidfds avoids process-group escape and PID-reuse redirection. It gives Core SIGTERM first, stops/kills owned descendants, follows orphan reparenting, and requires ECHILD before claiming cleanup. Native exit code 139 is retained without inventing a signal. Invocation directories and job selection are private; retained paths must resolve inside the invocation. Source/plan/case metadata are freshly checked, hashes bind the actual witness, and the runner intentionally permits a consistently hashed faulty emitter to reach Task4's independent oracle. Lane admission rejects failed reports, inconsistent lowering/counts, unsupported IR schema, incomplete scalar streams, and unequal retained native/reference stdout. No additional blocking issue was established in these paths.

## Scoped re-review after cancellation fix

Updated spec compliance: **APPROVED**. Updated code quality: **APPROVED**. The P1 above is **resolved**; it remains recorded as review history.

Reviewed `task-3-fix.diff`, the current explicit `Popen` lifecycle, supervisor signal initialization, appended implementation report, and retained 17/17 normal and optimized logs. The four caller-only/group × single/repeated SIGINT regressions establish cleanup completion and receipt retention before interruption propagation. The supervisor now has its own session and is cooperatively cancelled; the caller no longer uses the `subprocess.run()` exception path that killed the ownership process. Cleanup waits preserve a fixed deadline and report failure without destroying the surviving owner.

Three additional scoped probes passed: (1) normal invocation from a worker thread preserved its signal mask and verified cleanup; (2) a preexisting blocked, pending SIGINT remained blocked and pending after normal completion; (3) a main-thread invocation with another unblocked live thread propagated SIGINT only after retaining a verified forced-cleanup receipt (`timed_out=false`). No process-wide handler replacement was introduced, and the original caller-thread mask is restored in `finally`. These probes used only their own temporary fake compiler invocations; unchanged suites and actual corpus lanes were not rerun.

No new important regression was established in the scoped fix.

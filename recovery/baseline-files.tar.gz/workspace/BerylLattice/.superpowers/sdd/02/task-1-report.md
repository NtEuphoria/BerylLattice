# Plan02 Task1 implementation report

Owned files: `axiom/src/axiom/core_toolchain.py`,
`axiom/tests/test_core_toolchain.py`, and the Task1 section of
`axiom/docs/core-bridge.md`. No commit created; parent serializes commits.

## API

- `inspect_toolchain(core_source: Path, clang: Path) -> ToolchainPreflight`:
  `status` is `available`, `unavailable`, or `error`; `.available` is a property.
  Captures version/C11 actual compile/run receipts and selected executable,
  configuration, observed linked components, source pin and inventory identity.
- `prepare_snapshot(source: Path, destination: Path) -> Path`: clean exact pinned
  Git source copied into a new destination outside the checkout. Actual file
  bytes are compared to pinned Git blob object IDs independently of Git status;
  executable modes are verified. Resolves parent symlinks before enforcing the
  outside-checkout rule. No Git checkout or worktree command runs.
- `build_core(snapshot: Path, clang: Path, output: Path) -> Toolchain`: both output
  and snapshot must be newly allocated; snapshot must have `prepare_snapshot`'s
  marker. Rechecks source and inventories, fixed debug/unit script argv under
  private clang PATH, real compiler version, then Core AST native/evidence probe.
  Partial build/unit/native JSON diagnostics survive failure. Failed operations
  raise `ToolchainError` with `.receipts`; no success `toolchain.json` is written.
- `Toolchain.revalidate_identity()` rejects changes to compiler, Clang, config,
  known components, original source, snapshot, and native qualification artifacts.

`Toolchain` fields for runner consumption: `compiler: Path`, `clang: Path`,
`compiler_sha256`, `clang_sha256`, `clang_config: tuple[FileIdentity,...]`,
`clang_components: tuple[FileIdentity,...]`, `source_pin`,
`source_inventory_sha256`, `compiler_version`, `clang_version`,
`build_receipt`, `unit_receipt`, `native_receipt`, `unit_status`, `receipt_path`.
`CommandReceipt` contains `argv`, `cwd`, `returncode`, `stdout`, `stderr`,
`timed_out`, and `error`. `FileIdentity` contains `path`, `sha256`, and `size`.
No receipt-provided argv or metadata is executed.

## Tests and evidence

The required test-first run failed with missing `axiom.core_toolchain` before
implementation. Portable negative tests cover missing executable, nonzero
version probe, version-only pseudo-driver, compile success without an output
executable, unsuccessful runtime, different Git commit, and unmarked snapshot.
Actual selected-toolchain cases additionally cover dirty and extra snapshot
files, a pinned Git source whose dirty bytes are hidden by assume-unchanged,
symlink-parent escape, a selected driver that can run C11 but cannot build Core,
real C11 capability, and full build/native qualification with compiler/config
identity tamper controls. The hidden-dirty-source and symlink-escape regressions
were individually observed RED then GREEN. Actual source remains unmodified.

Current test logs:

- `task-1-tests.log`: 13/13 earlier selected-toolchain run, before final additional
  symlink-escape test and linked-library recording.
- `task-1-full-suite.log`: final complete Axiom suite including all 14 Task1 cases
  using explicitly selected real Core/Clang; completion result appended below.
- `task-1-optimized-tests.log`: Python `-O`, all 7 portable negative tests pass.
- `task-1-retained-build.log`: retained real build and identity summary.

Retained adapter-produced evidence:
`/workspace/scratch/axiom-toolchain-task1/receipts/toolchain.json`.
Built compiler:
`/workspace/scratch/axiom-toolchain-task1/snapshot/build/beryl.exe`, SHA256
`1df7134aa2d3712564a0bfebef6c39d02cda97d5df05cdbe45157b902383f7f6`.
Clang is the explicitly selected rootlessly installed Debian Clang 19.1.7 at
`/workspace/scratch/axiom-toolchain-setup/toolchain/usr/lib/llvm-19/bin/clang`,
SHA256 `0a3c55936ac43954fbe4914e6e73b577ca9e35e75d89ef13d3e28c187f41ca1a`.
Its adjacent `clang.cfg` contains exactly `-lm\n`, SHA256
`bc3624e157ba6656818d5f16c70efcd0c5414ffc8f354dce80aa76d639f9587f`.
The retained receipt records 17 observed dynamic libraries/loader identities.
No tracked source differences resulted from generated runtime-header rebuild.
Compiler hashes may differ across snapshot paths because debug builds embed
paths; Core loaded-source fingerprints are also path-sensitive and are not
binary hashes.

The real C11 witness printed `42`; Core native witness printed `42` and produced
successful nonempty LLVM IR, assembly, driver-job and result artifacts, whose
hashes and process statuses are checked. Pinned source is
`0a678b4ae6d41190c4f5a8bf063caba05759d20d`, with current IR schema5 verified from
source. The existing original checkout's Git status remains empty.

## Rulings and limits

The plan's initial all-green Core unit expectation conflicts with the actual
pinned defect and the parent's explicit ruling. The adapter allows only the
exact two named FAIL lines, exact 2/10814/583 summary, exit1 and BE0401 diagnosis
for `IR: initialized SET destination remains readable during later scalar
capture`. `unit_status='known_pinned_baseline_failure'` retains full stdout,
stderr and exit1. Any other failure blocks qualification. This is a pinned
frontend/test contract mismatch at `replace(set n,n)`, reproduced independently
in the original setup evidence; no Core source fix or assertion disabling was
performed. It is not a passing Core unit suite or Axiom conformance evidence.

Known selected binary/configuration/component bytes are bound; complete
transitive SDK/linker identity remains explicitly unclaimed. Package provenance
and installation evidence remain in the existing verified setup report and
receipt under `/workspace/scratch/axiom-toolchain-setup`. No saved environment
draft changes or external messages were made by this implementation task.

# Plan02 Task5 implementation report (native full campaign pending)

Owned files: `axiom/src/axiom/core_capsule.py`, `axiom/src/axiom/__main__.py`,
`axiom/tests/test_compile_cli.py`, `axiom/docs/core-bridge.md`.
The separate receipt loader helper owns `core_toolchain.py` and
`tests/test_core_toolchain_load.py`; its detailed report is
`task-5-loader-report.md` in this workspace.

## Implementation and rulings

- Added explicit `witness SOURCE --plan PLAN --case CASE_JSON --clang PATH
  --core SOURCE_CHECKOUT --out DIR`, optional exact lane/release flags.
  `--core` chooses the pinned source checkout; witness builds/qualifies an
  isolated compiler through existing preflight/snapshot/build APIs.
- Added `conformance --manifest PATH --toolchain RECEIPT --out DIR`, with
  optional `--workers 1..4` (default4). Production strictly consumes embedded
  UTF-8 source and SHA-256, exact shape/input/initial output, explicit plan IDs
  and lanes; it imports no test modules or generators.
- All source/plan bytes are freshly checked before emission. The fixed plan
  never falls back. Source emission, build status, conformance status, kernel
  source and fixed-case witness source remain distinct dimensions/kinds.
- The independent source evaluator supplies complete status/input/output
  observations. Every present Core reference/native stream is separately
  compared against it, including preserved sentinels and first bad indices.
- Ruling (approved by controller): retained private `/tmp/axiom-core-capsule-*`
  working directories isolate compiler/path-based runner writes from user
  `--out` ancestry. Pinned-dirfd publication exports immutable files and
  publishes manifest last after complete hash checks. The manifest records
  original/copy mappings and external retained toolchain references. Runtime
  metadata retains original absolute paths; moving the export does not relocate
  a qualified compiler. Cost: originals must remain present for receipt reuse.
- Queued conformance futures are cancelled on any exception/interruption,
  then active owned runs are joined. No accepted capsule is published from
  an interrupted matrix. Worker count and fixed stage/pipeline budgets are
  retained in execution-config.json.
- No evidence.py edits, Core limit changes, raw-pointer ABI, throughput claim,
  general compile command, or production import of corpus fixtures.

## RED/GREEN record

Commands below run from `/workspace/BerylLattice/axiom`, `PYTHONPATH=src`.

1. Wrote six boundary/CLI tests before commands existed. Initial
   `python -m unittest tests.test_compile_cli -v` showed 8 assertion failures
   across six tests: absent witness/conformance parser branches, missing case
   semantics, stale source-origin detection and expected infrastructure status.
   An initial wrong working-directory heredoc attempt failed to create the
   test file and was corrected before the real RED run.
2. Implemented the coordinator/parser, then six tests passed. A stale-source
   test originally appended a harmless newline, which legitimately preserves
   semantic equivalence and origin offsets; it was corrected to prepend a
   newline, exercising a truly stale origin mapping. No source digest binding
   stronger than the existing plan format was invented.
3. Publication original/copy mapping test RED (`KeyError: original_path`),
   then added exact original mapping and final reference verification: 12
   owned tests GREEN including symlink and changed-ancestor interruption.
4. Worker cancellation test RED (missing `_run_tasks`), then explicit
   cancel-and-join helper: 13 owned tests GREEN.
5. Worker bound test RED (unrecognized `--workers`, rather than rejected
   out-of-bound choice), then bounded CLI option and recorded worker config:
   14 owned tests GREEN.
6. Added retained compiler-failure-after-valid-plan coverage, exercising
   source/build/conformance dimensions and exact diagnostics/plan retention.
   Current portable combined command:
   `python -m unittest tests.test_compile_cli tests.test_cli -v`.
   Last completed earlier combined run: 21/21 GREEN (14 new +7 existing).
   Final 22-test run is in progress at report creation; see portable-tests.log.

## Actual native evidence

All retained evidence lives in `/workspace/scratch/axiom-task5-cli/`.

- `python -m axiom witness source.ax --plan plan.json --case case.json
  --clang /workspace/scratch/axiom-toolchain-setup/toolchain/usr/lib/llvm-19/bin/clang
  --core /workspace/beryl --out .../witness-capsule`: exit0, matched1/1.
  Exact saved rows2-v1 H1/W1 plan, independent expected output30, production
  AST/debug lane. Fresh build/qualified runtime:
  `/tmp/axiom-core-capsule-45gmg2oj`.
- Replayed the exact same source/plan/case through a second fresh witness build
  with `--lane ir --release --out .../replay-capsule`: exit0, matched1/1.
  Runtime `/tmp/axiom-core-capsule-wj5mr_bq`.
- `replay-identity-comparison.json`: all six retained deterministic artifacts
  byte-identical across those independent runs: source.ax, plan.json,
  case.json, kernel.be, witness.be, emission.json. Native binary identity is
  intentionally not inferred from deterministic source identity.
- Full fresh production CLI campaign launched (session46780):
  `python -m axiom conformance --manifest .../quick-manifest.json
   --toolchain '/workspace/scratch/axiom-toolchain-task1-review1/output with spaces/toolchain.json'
   --out .../full-capsule --workers 3`.
  Manifest is explicit108cases ×3plans ×5lanes =1620 observations.
  Working root `/tmp/axiom-core-capsule-qffsp0_8`; result redirected to
  `full-result.json`. **Still running; no full-campaign success claimed.**

## Self-review

- Verified source/plan/case bytes captured before qualification and fresh
  checker/emitter/runner gates preserved; immutable bundles, no selector call.
- Checked production imports: no test fixture or generator imports.
- Checked complete expected/actual observations include status and all inputs
  and outputs, and shared erroneous Core output is classified mismatch even
  when Core lanes agree.
- Checked every exported artifact has a relative path/hash/size/original path;
  each original and export is revalidated before immutable manifest publication.
  External known toolchain dependencies are explicitly listed and hash-checked.
- Exercised output interruption, symlinked ancestor, swapped ancestor,
  existing immutable manifest and cancellation of queued work.
- Error/unavailable/timeout/compiler/native/mismatch runner classifications
  stay in the matrix; only complete independent matches increment matched.
- Native trusted-base limits and retained-path dependence documented.
- Remaining gates: controller's Plan01 combined suite, independent Task5 review,
  and completion/verification of full1620 CLI matrix. No commits made by worker.

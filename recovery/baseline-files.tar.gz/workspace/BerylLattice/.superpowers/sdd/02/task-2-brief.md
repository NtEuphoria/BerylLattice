# Authorized implementation task

The user explicitly requested implementation of all three reviewed plans. Earlier planning-only restrictions no longer block implementation. Work in /workspace/BerylLattice.

# Axiom Core Bridge Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Produce actual Core programs from checked Axiom plans and compare their complete observations with the independent Axiom source evaluator.

**Architecture:** A source emitter consumes immutable checked plan bytes, generates an ordinary `.be` kernel plus isolated witness, and retains byte-level provenance. A process adapter invokes the pinned Core compiler through existing admission. Production AST and experimental IR differential paths remain separate result lanes.

**Tech Stack:** Plan01 Python package, Beryl commit `0a678b4ae6d41190c4f5a8bf063caba05759d20d`, C11/Clang, existing Core CLI, standard-library subprocess and hashing.

**Spec:** [Prototype contract](../../../prototype-contract.md), [Core interface](../../../../axiom-foundations-2026-10-15/core-interface/interface-decision.md), [observer contract](../../../../axiom-foundations-2026-10-15/core-interface/observer-contract.md).

## Global Constraints

- Plan01 must pass first. All source/plan bytes are rechecked before emission; an externally supplied success record is insufficient.
- Existing complete Core frontend admission is mandatory. Do not directly populate typed AST or call IR C emission to bypass gates.
- H5/W7: input48/output35; return -1 success or first invalid input index; output is separate and initialized.
- Every input and output scalar plus status is observed. Different plan source offsets are not compared as if they were identical Core events.
- IR keeps 256 cells per aggregate, 64-KiB declared-storage estimate and fixed native execution budgets.
- No throughput claim, new native ABI, raw-pointer interface, Core limit increase or benchmark-collector repair in this plan.
- Record compiler/Clang binaries, known toolchain components and exact argv; unobserved SDK/linker dependencies remain explicit limits. Missing Clang is unavailable, not a passed test.

## Review Focus

- A compiler path containing spaces: argument lists preserve it and receipts capture the actual executable; Task1/3.
- Input failure at the last element: all output remains sentinel-valued and first invalid index is exact; Task2/4.
- A source generator defect shared by both Core lanes: independent Axiom observations catch it; Task4.
- Unsupported Core lowering or process timeout: unavailable/error stays distinct from semantic mismatch; Task3.
- Old schema-4 experimental helper docs: do not apply them as commands for current schema5; Task1.

## File map and shared interfaces

Paths relative to future `/workspace/BerylLattice/axiom/`:

```text
src/axiom/core_toolchain.py    identity/preflight and isolated Core build receipts
src/axiom/core_emit.py         source and provenance generation
src/axiom/core_runner.py       process isolation, output capture, result classification
src/axiom/core_observe.py      complete scalar observation decoding
tests/test_core_*.py           unit/protocol/negative controls
tests/integration/             actual compiler correspondence cases
docs/core-bridge.md            supported commands, limitations and receipts
```

Result records live in the owning module. `Toolchain` holds absolute compiler/Clang paths and hashes, Core source identity, version stdout and build receipts. `NativeRun` holds lane, argv, outer returncode, Core-reported subprocess status/code, stage/whole-run timeout and cleanup status, stdout/stderr paths/hashes, result/job paths and classification. Core folds native signals into 128+signal, which is ambiguous with an ordinary exit code; an exact native signal is unavailable unless separately observed. `Observation` holds status, input tuple and output tuple. Failed/partial runs retain diagnostics without advertising conformance.


### Task 2: Core source emission and provenance

**Files:** Create `core_emit.py`, `tests/test_core_emit.py`.

**Interfaces:** `emit_core(source: bytes, plan_bytes: bytes, limits: Limits, data: tuple[int,...], initial_output: tuple[int,...]) -> CoreBundle`. It parses/admit/checks exact bytes internally. CoreBundle has artifact_kind `core_witness_source`, source bytes/hash, mapping entries, logical/plan/emitter identities, exact case identity and observation layout. A kernel-only artifact is distinct (`core_kernel_source`) and has no native executable-entry claim. Fixed-case binaries are `core_witness_executable`, never a reusable Axiom ABI.

- [ ] Write source-inspection tests asserting the H5/W7 signature, -1 success, returned first invalid index, complete preflight preceding stores/computation, whole-array scratch initialization, checked arithmetic and deterministic scalar observation order.
- [ ] Pin one minimal complete hand-reviewed witness source and expected scalar observation before implementing the emitter. A literal-input witness is for correspondence; do not reuse it as a runtime performance workload that might be constant folded.
- [ ] Write stale/tampered plan, source-span bounds and unknown-operation tests. Every mapping references actual generated byte ranges and valid Axiom origins; synthetic wrapper/initialization operations have explicit roles.
- [ ] Run `PYTHONPATH=src python -m unittest tests.test_core_emit -v`; observe missing emitter failure.
- [ ] Implement direct translation of each validated unrolled operation into named scalar Core statements. Generate static element accesses and no extra calls/effects. Initialize arrays according to existing Core syntax and admission. Emit a standalone test block with runtime function call, status, all input and output values printed in fixed order.
- [ ] Check generated bytes are stable and mappings support repeated origins. Test canonical source→plan→source identities even if plan names are altered. Commit as `feat(axiom): lower checked plans through Core source`.


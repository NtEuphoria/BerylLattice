# Plan02 Task1 independent review

Reviewed commit `10bcf3b30bf87f92cc518a13c238d69e0660b745` against the brief,
implementation report, review package, current implementation/tests/docs and
retained build receipts. No implementation edits, complete-suite reruns or
build reruns were performed.

**Spec compliance: changes requested. Code quality: changes requested.** Two
medium evidence/identity issues should be resolved before using these receipts
as the retained toolchain contract for later tasks.

1. **Known component resolution is not revalidated**
   (`axiom/src/axiom/core_toolchain.py:107`, `:123`, `:257`). `ldd` lookup paths
   are resolved to their current targets by `_identity`, and only those resolved
   target paths survive in `clang_components`. `revalidate_identity()` hashes
   those old targets without checking what the selected Clang would load now.
   Retargeting a dependency symlink while retaining its old target therefore
   passes validation even though a previously observed dependency changes.
   A cheap targeted probe reconstructed the actual retained Toolchain, appended
   an identity observed through a temporary `libdep.so -> libA.so` link, changed
   the link to different `libB.so` bytes, and observed successful revalidation.
   This is relevant to the actual installation's versioned-library links. Keep
   dependency lookup paths plus resolved identities and re-observe the selected
   driver's component resolution at revalidation (or explicitly reject changed
   resolution). Add a targeted regression. The documented limit on unobserved
   SDK/linker dependencies does not address changes to already observed ones.

2. **Actual Core build/test Clang argv are absent from retained receipts**
   (`axiom/src/axiom/core_toolchain.py:329`, `:331`, `:342`). The build and unit
   receipts record only `bash scripts/build.sh --debug` and
   `bash scripts/test.sh`. The pinned scripts invoke Clang through
   `compile_once_run` with an expanded source list and a randomly allocated
   candidate output path, but do not print or persist that argv. The retained
   `build.json` contains only the final `built build/beryl.exe` message; the
   selected binary hash and unchanged scripts do not supply the missing actual
   invocation record. Capture underlying Clang calls in the private PATH
   adapter, preserving argument boundaries and the selected executable target,
   without editing Core scripts. Include failed invocations too. This fulfills
   the brief's explicit compiler/Clang exact-argv requirement.

The remaining inspected contracts are implemented coherently: actual tracked
bytes are compared to pinned Git blobs independently of status; executable
modes are checked; snapshots copy that inventory outside the checkout; parent
symlinks are resolved; fresh outputs and before/after snapshot inventories are
enforced; expected runtime-header regeneration is isolated; version-only and
compile-only drivers cannot pass C11 qualification; failures keep command
diagnostics and cannot write a success receipt. Subprocess argv lists preserve
spaces, including the real isolated compiler/snapshot/output test paths.
The selected Clang configuration is hashed and re-enumerated, and loaded
configuration paths reported by native driver evidence are checked against the
bound candidates. Current schema5 is checked directly in pinned source.

The retained actual witness prints `42`, with successful nonempty LLVM IR,
assembly and driver-job captures and checked native result statuses/artifact
hashes. This establishes toolchain capability qualification only. It does not
establish Axiom H5/W7 observation equality, IR conformance, throughput, a new
ABI, or complete SDK/linker identity. AST qualification uses ordinary Core CLI
admission; Core source and limits are unchanged.

The full Axiom log records 90/90 passing tests, including 14 Task1 cases; this
review inspected that existing evidence without rerunning it. The underlying
pinned Core unit suite remains **failed**, with two checks out of 10814 across
583 cases in the named SET/BE0401 fixture. The narrow baseline recognizer keeps
exit 1 and `known_pinned_baseline_failure`, matching the parent's recorded
exception, while other recognized failure patterns block qualification. The
docs and report correctly avoid claiming that Core suite passed or that the
native probe proves Axiom conformance.

## Scoped re-review after round1 fixes

**Finding 1: resolved. Finding 2: resolved. Spec compliance: pass within the
reviewed Task1 scope and recorded baseline exception. Code quality: pass.**
These verdicts supersede the initial changes-requested verdicts above.

Reviewed `task-1-fix.diff`, the updated implementation/report/tests/docs, the
three scoped verification logs, and the new retained receipt at
`/workspace/scratch/axiom-toolchain-task1-review1/output with spaces/toolchain.json`.
No builds or suites were rerun. No new important breakage was found in the fix
scope.

The first fix retains lexical dependency lookup paths alongside resolved file
identities and follows the lookup path again during revalidation. A retargeted
symlink now differs from its recorded resolved identity even when its old target
remains. The new regression exercises this exact case. Independently inspected
all 17 actual retained component lookup targets and hashes against their current
files; they match. This closes the reported known-component symlink gap without
claiming complete loader/SDK/linker dependency identity.

The second fix records actual nested Clang argv immediately before exec using
the private PATH adapter and preserves the explicitly selected executable.
The shell forwards `"$@"`; Python passes a list to `os.execv`, preserving spaces
and argument boundaries. Failed compile attempts retain the same capture log.
The successful retained JSONL records exactly match `Toolchain.clang_invocations`:
67 build tokens and 88 unit tokens, with the proper source lists, stage, cwd,
selected binary hash, and actual random output candidates, both of which exist.
Capture helper/wrapper/log hashes are included among the retained artifacts;
independent byte checks passed for those and all native qualification artifacts.
Invocation records correctly avoid claiming a separately observed child exit
status; outer script receipts retain the observed outcomes.

Existing scoped logs show 15 normal tests, 8 portable optimized tests and
2 targeted optimized regressions passing. The original Core checkout remains
clean at the exact required pin. The new native receipt still reports exit 0
and prints `42`; the underlying Core suite still retains exit 1 and
`known_pinned_baseline_failure`. Qualification remains distinct from Axiom
conformance, and the original documented limitations remain applicable.

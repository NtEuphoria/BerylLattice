# Plan02 Task3 — isolated Core runner and exact observer

Implemented `axiom/src/axiom/core_runner.py`, `core_observe.py`, private `_core_supervisor.py`, and owned tests `test_core_runner.py`, `test_core_observe.py`. No Core edits, commits, ABI changes, resource-limit increases, or throughput claims.

## Interfaces and retained evidence

- Frozen `Observation(status, input, output)`; `decode_observation(bytes, AdmittedKernel)` accepts canonical signed-i32 lines followed by exactly `ok  1 test, 0 assertions\n`. It requires every scalar, including all 48 input and 35 output cells for H5/W7. `ObservationError` is a `ValueError`.
- `run_core(bundle, toolchain, lane, directory, release=False, pipeline_timeout_ms=1200000)` returns frozen `NativeRun`. Stage timeout remains 120000ms. Each call creates its own new private cwd and cache; only new jobs below that cwd are retained.
- NativeRun includes exact argv/cwd, outer returncode, Core reference/native statuses and native exit code, both deadline fields and timeout outcomes, cleanup mechanism/verification, outer stdout/stderr paths and hashes, top-level result path/bytes/hash, all new job paths, reference/native observation paths/hashes, compiler/Clang/source digests, and immutable relative-path/artifact-hash tuples. Reports remain immutable bytes, not mutable dicts. Core's 128+signal folding remains an exit code; native_signal stays None.
- Classifications: success, unavailable, timeout, error, infrastructure_error. Runner success only admits Core execution/protocol; independent Axiom correspondence is downstream.
- Bundle source and plan are freshly reparsed/admitted/decoded/checked under default Limits; exact/logical metadata, case identity, kernel prefix/hash, mapping identity/bounds and complete i32 boundary tuples are checked. It intentionally does not regenerate and equate Core emitter output: a consistently faulty emitter must reach the independent oracle.

## Process lifecycle mechanism

A dedicated Python supervisor enables and verifies Linux PR_SET_CHILD_SUBREAPER, confirms proc ancestry and pidfd support, and launches Core in a fresh session. The user's parent Python process never changes subreaper/signal semantics. On the independent pipeline deadline it sends SIGTERM to Core first and allows 500ms for Core's own cancellation. Forced cleanup discovers only descendants by `/proc` ancestry, binds each signal to a pidfd, rechecks ownership after acquiring the handle, stops descendants to limit concurrent forks, kills them, follows children reparented to the subreaper, and reaps until the kernel reports ECHILD. Cleanup has a further 3s bound. Unverified/unsupported cleanup returns infrastructure_error, never successful isolation.

This is compiler process lifecycle isolation, not a hostile-code sandbox. Proc/pidfd support is required. The tested mechanism does not rely on killing the outer process group, and does not signal unrelated processes.

## RED/GREEN and controls

1. New observer tests failed with missing `axiom.core_observe` before implementation; new runner tests likewise failed with missing `axiom.core_runner`.
2. Initial implementation passed 10 owned tests, including detached grandchild cleanup (child/grandchild use distinct sessions/process groups; intermediate exits before timeout).
3. Added source/plan/case/mapping/receipt forgery tests: 12 subcases failed by incorrectly returning success. Fresh checking and exact source-receipt binding changed these to rejection.
4. Self-review found malformed JSON report values could introduce mutable dict/list values into a frozen NativeRun. A reproducer failed (`native_status == {}`); type-safe diagnostic retention fixed it, preserving raw report bytes.
5. Additional controls establish unrelated process survival, no stale shared-cache reuse, successful outer exit with residual background child cleanup, missing reports, code139 preserved without invented signal, path-with-spaces argv, partial/out-of-range/extra payload rejection, altered summary/counts, failed compared=true report, schema4 IR rejection, stage versus pipeline timeouts, and missing native logs.

Final owned commands:

- `PYTHONPATH=axiom/src:axiom python -m unittest tests.test_core_observe tests.test_core_runner` → **16/16 PASS**, `.superpowers/sdd/02/task-3-owned-tests.log`.
- Same command with `python -O` → **16/16 PASS**, `.superpowers/sdd/02/task-3-owned-optimized-tests.log`.
- `git diff --check` → clean (new files additionally read in self-review).

A broad suite was started before root asked workers to avoid duplicate exhaustive selection runs. It had already completed: 134 tests, 7 skips, **one observed unowned failure** `test_selection.SelectionTests.test_every_admitted_shape_and_cap_boundary_against_analytic_portfolio` (`AssertionError: 2 != 3`). Log: `.superpowers/sdd/02/task-3-suite.log`. Root was informed; no broad rerun was performed. This is not reported as a green full suite. Root owns final combined verification after concurrent task changes settle.

## Source inspection and actual protocol smoke

Inspected pinned Core `src/driver/reference_driver.c`, `build.c`, `identity.c`, `main.c` and observer contract. Confirmed report schema1, IR profile schema5, backend/lowering fields, reference/native status names, counts, exact source fingerprint representation, reference output/events hashes, nested native-job structure, and the retained stdout filenames. Outer CLI diagnostic text is never decoded as observations.

Actual selected Core: `/workspace/scratch/axiom-toolchain-task1/snapshot/build/beryl.exe`.
Actual selected Clang: `/workspace/scratch/axiom-toolchain-setup/toolchain/usr/lib/llvm-19/bin/clang`.
Toolchain reconstructed from retained task1 receipt and `revalidate_identity()` called normally (no bypass).

Minimal hand-reviewed emitter witness, data `(0,1,2,3)`, output initial `(-99,)`, expected scalar stream `-1,0,1,2,3,30` plus exact Core summary:

- reference: success, `/workspace/scratch/axiom-runner-smoke/core-reference-pxtcl7nq`;
- AST differential: success, `/workspace/scratch/axiom-runner-smoke/core-ast-rqorz2hg`;
- IR differential: success, `/workspace/scratch/axiom-runner-smoke/core-ir-gxnd0hcb`.

All three had cleanup_verified=True and passed report/lane admission and complete scalar framing. Source/plan/metadata checks were enabled. Exact reports are retained in those private cwd paths and `.superpowers/sdd/02/task-3-smoke.log`. Smoke driver: `/workspace/scratch/axiom-runner-smoke.py`.

These are targeted syntax/protocol smokes, not the final Plan02 semantic conformance matrix. The Plan01 full CLI gate remains root's prerequisite for that matrix.

## Rulings and limits

- Root explicitly prohibited worker commits despite the brief's generic commit step; no commits made.
- Linux subreaper + proc ancestry + pidfds is the demonstrated platform ownership mechanism instead of assuming cgroup availability. Unsupported platforms fail closed.
- Kernel/parser/plan checker use default Limits because run_core has no limits parameter in its authorized API. A bundle requiring larger custom checker budgets is rejected rather than trusted.
- Mapping checks establish byte identity and bounds, not semantic correctness of generated Core; semantic correctness belongs to the independent observation comparison.
- Exact compiler/Clang identities and all generated job artifacts are retained. Toolchain's existing explicit transitive SDK/linker identity limits remain applicable.

Self-review completed: checked process ownership/races, PID reuse protection, subreaper scope, orphan reaping, status/code ambiguity, fresh cwd/report selection, boolean-vs-integer report counts, frozen public records, separate timeout clocks, strict scalar framing, failure diagnostics, and consistent faulty-emitter passage to the oracle. No remaining owned blocker identified.

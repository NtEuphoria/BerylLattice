# Independent cloud setup review

Reviewed commit `a63c052ac5b0eb344c2a29c77f4661f0d34c9970` on 2026-10-16 UTC.
Scope: `tools/setup-cloud.sh` and `docs/cloud-environment.md` only. Their working
copies match the reviewed commit. Read the implementation report, prior trusted
`/workspace/scratch/axiom-toolchain-setup/REPORT.md`, and the public Core toolchain
APIs called by the script. No production files, commits, environment configuration,
or Core sources were changed. No native build was repeated.

## Specification verdict: PASS

The default setup performs the advertised small standard-library Axiom check.
Native setup enforces the exact Core commit and clean checkout, requires the
pinned Clang executable/configuration identities before selected-driver execution,
and rejects additional configuration candidates. The public API independently
validates tracked source bytes and builds an isolated disposable snapshot.

The bootstrap uses isolated APT configuration, an explicit Debian signing
keyring, HTTPS certificate/hostname verification, and authenticated repository
metadata. All six pinned package hashes and package/version/architecture values
are checked before extraction. It never installs into the system dpkg database.
Existing private installations are reused or rejected without overwriting them;
each qualification gets a new evidence directory. A prefix inside Core is
rejected before creating directories.

Both existing native qualification receipts retain actual build/unit/native
command evidence. They independently load and revalidate successfully. The unit
exit remains 1 with `known_pinned_baseline_failure`; the script and documentation
explicitly describe the known two failed checks and do not claim a passing suite.
The exact pattern classifier belongs to the pre-existing public API and unexpected
unit failures block the qualification path.

Documentation accurately distinguishes default portable checking from optional
native qualification, identifies image prerequisites and unavailable-version
failure behavior, and limits transitive toolchain identity claims. It explicitly
states that local files/commits do not prove restoration and that publication
and fresh-task restoration are not performed by this procedure.

## Code-quality verdict: PASS

No blocking or actionable correctness findings in the reviewed scope. Severity:
none. No defect reproduction is applicable. The small Bash wrapper delegates
argument handling and file operations to Python, avoiding shell interpolation of
user paths. Failures after evidence allocation retain diagnostics, and partial
installations fail closed with documented recovery via a new prefix. The native
workflow uses public APIs rather than duplicating build or receipt contracts.

## Independent verification

- `bash -n tools/setup-cloud.sh`: exit 0.
- `bash tools/setup-cloud.sh`: exit 0; Python 3.12.14, admitted stencil, height 5,
  width 7, semantic digest
  `17692e7e1022cc35edf4d6f0e4f0a42fdd8252f836e5b01f933854236198ac26`.
- Negative CLI check `--clang /usr/bin/false` without `--native`: exit 2,
  `--clang requires --native`.
- `--native --core /workspace/BerylLattice --prefix PREFIX`: exit 1 with pin
  mismatch, and PREFIX was not created.
- `--native --prefix PREFIX --clang /usr/bin/false`: exit 1 with pinned binary
  hash rejection, before preflight or selected-driver execution.
- `--native --prefix /workspace/beryl/review-forbidden`: exit 1; the Core child
  directory was not created.
- Verified explicit Clang plus `CLANG_CONFIG_FILE_USER_DIR` containing an extra
  `.cfg`: exit 1 with unexpected configuration candidate rejection.
- Existing `PREFIX/toolchain` containing only a sentinel: exit 1 without
  bootstrap or extraction; sentinel content and complete toolchain-directory
  inventory were unchanged.
- Loaded and independently called `revalidate_identity()` on both
  `/workspace/scratch/cloud-onboarding-native-20261016/qualification-57lxdp8j/receipts/toolchain.json`
  (`bootstrap-signed-apt`) and
  `/workspace/scratch/cloud-onboarding-native-20261016/qualification-nmu16_9d/receipts/toolchain.json`
  (`reuse-explicit`). Both passed, preserving unit exit 1 and known failure status.
- Recomputed the hashes of all six retained downloaded packages, compared their
  set to the script's pins, and independently checked `dpkg-deb -f` identities.
  All passed.
- Independently verified the retained Debian `InRelease` signature with installed
  `/usr/bin/sqv` and `/usr/share/keyrings/debian-archive-keyring.gpg`: exit 0.
  An initial optional `gpgv` attempt found that executable unavailable; sqv is
  available on this Debian image and completed the verification.
- `/workspace/beryl` still reports HEAD
  `0a678b4ae6d41190c4f5a8bf063caba05759d20d` and empty
  `git status --porcelain --untracked-files=all`.

Negative-test artifacts and the independently authenticated Release text are in
`/workspace/scratch/cloud-setup-review-_oamuj__/`.

## Remaining limits

Fresh signed bootstrap and explicit reuse execution are supported by the retained
implementation receipts, independently revalidated here. This review did not
rerun expensive native builds, separately execute `reuse-private`, test a fresh
cloud task, or publish the local commit. The script remains dependent on this
Debian development image's documented host support and on availability of its
pinned Debian packages. These limits are disclosed and do not contradict the
reviewed setup contract. Root retains ownership of the environment draft and any
publication/restoration follow-up.

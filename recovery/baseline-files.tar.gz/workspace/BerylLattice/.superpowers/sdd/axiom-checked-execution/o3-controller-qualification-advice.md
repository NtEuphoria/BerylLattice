# O3 controller qualification workflow advice

Date: 2026-10-16. Author: `/root/audit_source_work`, read-only adviser.
Inspected the O3 plan, protocol, `oracle_receipt.py` API, required tests and
existing execution logs at HEAD `e68660c8a1c12f50f8f42b2e5206a7cac5ea0164`.
The A1/A3 dependency repair is still a separate prerequisite. No tests, archive,
inventory capture, qualification artifacts, approval, commits or subagents were
created here. This document is orchestration advice, not an independent review
or an approved policy.

The diagnostic advice correction is separately recorded in
`source-admission-repair-advice.md`: DiagnosticError exposes `.message`.

## Prerequisite: freeze the integrated subject, not today's working tree

Finish and independently accept the source-name adapter and the O3 dependency
inventory update, then choose one immutable integrated commit. Existing O3/O2
implementation reviews remain historical to their own commits. An O3 code
review is not the later review of a qualification subject plus its execution
evidence. Do not create an approval root while that subject is still changing.

The known A3 item is necessary: `_REPOSITORY_MODULES` must include the accepted
new `axiom.source_names_v2` dependency. `_qualification_data` compares inventory
paths/roles for **exact equality** with `_runtime_paths`, so adding the helper
only to a JSON inventory is insufficient, and omitting it would be incomplete.
The controller has already assigned this code change to the O3 owner. This
advice does not propose editing it from the qualification script.

## Minimal staged orchestration

### 1. Create and identify a cache-free Git archive

Use a new dedicated directory outside the working checkout. Resolve the selected
commit once, retain the full commit and archive SHA-256 in controller evidence,
and extract an archive of that commit. Do not copy a live checkout or attach its
ignored caches. A minimal shell outline, with controller-supplied absolute paths,
is:

```sh
git -C "$repository_checkout" rev-parse --verify "$qualification_commit^{commit}"
git -C "$repository_checkout" archive --format=tar --output="$subject_tar" "$qualification_commit"
mkdir "$subject_directory"
tar -xf "$subject_tar" -C "$subject_directory"
```

`qualification_commit` must already be the fixed full hash chosen for the run;
do not use a moving HEAD between these commands. Inspect the archive paths for
symlinks, `__pycache__`, `.pyc`/`.pyo`, and unanticipated import files. If tracked
caches exist, resolve the source/cache policy explicitly rather than silently
deleting tracked subject content. Normal ignored caches are absent from a Git
archive. A1's accepted helper must be committed or it will be missing here.

Set the repository live root to the extracted `axiom/` directory, not the outer
repository root, when using the existing logical names
`repository/research/...` and `repository/src/axiom/...`. Keep artifact closure,
test logs, controller scripts and scratch outside this source live root unless
their presence is explicitly part of the selected subject/evidence.

Retain a byte inventory of the extracted implementation and evidence sources.
Check it again after the runs. Make the subject stable; do not modify it to
repair a failed test and then attach the old qualification digest.

### 2. Establish the actual interpreter and reproducible import prelude

Use the resolved current executable and exact CPython major/minor/micro, not a
`python` label or nominal `sysconfig` libpython path. Inspect actual paths with
the selected interpreter. Use a trusted fresh process, disable bytecode writes
before repository imports, and install only the approved source roots before
importing the fixed O3 entrypoint. A controller may use `-I -S -B` with an
explicit reviewed bootstrap; `-I` ignores PYTHONPATH, so supplying PYTHONPATH
alone does not configure such a process.

Use a consistent module naming convention (`research.oracle_receipt` and its
package dependencies, or the supported top-level form). Do not import both
forms in one controller process: that creates distinct module/issuer tables
and can turn a handle into a foreign object for another copy of the API.

Freeze a small, reviewed import/preflight prelude for inventory capture and live
qualification. Exercise disclosed tiny O2 success and precondition-failure paths
without granting qualification to discover lazy imports/mapped libraries.
The prelude itself is evidence and must not import the reference evaluator into
the execution dependency path. If a test harness needs additional stdlib native
libraries, identify that difference explicitly. Do not treat test-only repository
comparators as oracle execution imports.

### 3. Prepare the subject document before required qualification test runs

Use the actual `oracle_receipt._runtime_paths()` observation from the selected
trusted process as the implementation's required-path observation, and review
it rather than substituting the old `o3-runtime-observation.json`. It covers:

* the actual resolved executable;
* the complete non-site/non-dist installed stdlib, including existing permitted
  source, bytecode and extension binaries;
* actual executable-file mappings from `/proc/self/maps`, with device/inode
  agreement and no unresolved/deleted/anonymous executable mappings;
* every fixed loaded implementation module origin and permitted existing cache.

The observation is **not** approval. Map each path under explicit nonsymlink
`OracleLiveRoot('repository'|'python'|'system', absolute_directory)` values.
Record actual logical paths sorted uniquely. Do not invent a separate libpython
entry if no such file is mapped. Avoid overlapping root mappings and normalize
symlinked system/interpreter targets before choosing stable roots.

The selector requires exact runtime path/role equality. An inventory is not an
allowlist superset: extra unmapped runtime-library entries also fail. A new
import which maps another file after capture can fail subsequent selection or
revalidation. Preload the reviewed required dependencies consistently, then
compare the actual path/role set after each run and before live selection. If
the fixed runtime set changes, stabilize it and create a new qualification
subject, then rerun the required six tests against that subject. Do not edit the
already referenced subject in place or retrofit old logs to a new hash.

Retain every runtime/implementation file with O1 `write_blob`, in <=1 MiB
chunks, using complete bytes and actual lengths. The interpreter may exceed the
16 MiB per-retained-file limit: its **chunks** satisfy that limit; a single
30 MiB retained executable file would not. Validate all metadata/chunk/file and
aggregate limits, including duplicate retained paths, before review. Do not
blindly copy the roughly 975-file/22 MiB old stdlib observation as current truth.

Write canonical trusted-base and qualification documents using the exact
schemas. Freeze their bytes and the qualification digest Q. The subject binds
entrypoint, runtime assumption, exact SourceProfileV2, exact descriptive version
tags, actual interpreter and sorted inventory. It does not yet contain tests,
review or approval, avoiding a self-hash cycle.

### 4. Run the three real required suites in both modes

Run six fresh processes against the archived sources and selected interpreter:

| command_id | Test file | Modes |
|---|---|---|
| `o3` | `research/tests/test_oracle_receipts.py` | normal, optimized |
| `source_oracle` | `research/tests/test_source_oracle.py` | normal, optimized |
| `synthetic_receipts` | `research/tests/test_receipts.py` | normal, optimized |

The ordinary unittest invocation from archived `axiom/` should explicitly set
the research top-level directory. For each file, the corresponding commands are:

```sh
env PYTHONPATH=src:research PYTHONDONTWRITEBYTECODE=1 \
  "$runtime_python" -B -m unittest discover -s research/tests -t research -p "$suite_file" -v
env PYTHONPATH=src:research PYTHONDONTWRITEBYTECODE=1 \
  "$runtime_python" -O -B -m unittest discover -s research/tests -t research -p "$suite_file" -v
```

Here `suite_file` is exactly one of the three basenames above and cwd is the
archived `axiom/`, never the live checkout. This is an execution outline, not a
claim that these commands were run by this advice. A trusted controller harness
may instead establish the same import paths explicitly and invoke unittest;
retain that harness and its actual argv/cwd as evidence. If using the ordinary
runner, inspect/trust its site-hook/environment startup under the documented
runtime assumption rather than describing it as `-I -S` isolation.

**Real existing trap:** from `axiom/`, discovery without `-t research` can import
`axiom/tests` as package `tests`, while `test_receipts.py` needs
`research/tests/test_manifest.py` via `from tests.test_manifest import ...`.
The retained `o3-synthetic-normal.log` contains this `_FailedTest` import error;
later research-root runs passed. Starting in archived `axiom/research/` with
`PYTHONPATH=../src:.` is another valid remedy, but record the actual command/cwd.
Use fresh processes so a previously loaded wrong `tests` package cannot persist.

**Bytecode trap:** `-B` stops writing in that process only and never prevents
reading existing caches. `test_source_oracle.py` has a child launched as
`[sys.executable, '-c', ...]` without `-B`. Inherit
`PYTHONDONTWRITEBYTECODE=1` as well so that child cannot add caches to the frozen
source/runtime trees. O3's fresh-process test does supply `-B` and propagates
`-O`; the O2 import-only child currently uses its own normal-mode invocation.
Report the actual coverage; do not assert all child commands use `-O`.

Capture complete stdout/stderr, exact argv/cwd/environment policy, exit status
and actual unittest outcomes. A structured TextTestResult-producing controller
runner can avoid guessing counts; preserve its code as a test input. Check
`tests=passed+failed+errors+skipped`, nonzero passed, no failed/errors and zero
exit status; O3 required tests must not be skipped. Do not let a `tee` pipeline
replace the test exit code with the logger's exit code. Unexpected successes,
expected failures or subtest accounting require explicit interpretation because
the current evidence schema has no separate fields for them.

Existing log counts (31 O3, 29 O2, 26 synthetic in earlier checkpoints) are
historical observations, not expected constants to write into the new evidence.
Tests may change during dependency reconciliation. Count what actually ran.

### 5. Pin the complete test-input closure and real logs

At minimum the inspected three suites use:

* their three test source files;
* `research/tests/test_manifest.py`, imported by synthetic receipt tests, and
  `research/tests/__init__.py` for the chosen package runner;
* `research/experiment_manifest.py` and `research/receipt_admission.py` as
  synthetic-test comparators/helpers;
* `src/axiom/reference.py` as the O2 comparison oracle;
* `tests/fixtures/inputs/boundary_cases.json`;
* `research/protocol/source-oracle-v1.md` and the reviewed controller runner/
  inventory/qualification scripts, disclosed as applicable evidence inputs.

This is a starting closure, not permission to stop there. Reconcile imports,
fixture opens, subprocess inline code (already pinned inside test source),
dynamic helper paths and any additional protocol/fixture inputs in the frozen
tests. Shared execution dependencies are already in the qualification subject;
they still must be the exact bytes the tests imported. Do not misclassify
`axiom.reference` or synthetic receipt helpers as oracle execution dependencies.

The unit fixture's hard-coded `inputs` list omits package init/controller-runner
details and its asserted test/review records are intentionally synthetic. It is
not the authority for a complete real evidence closure. In particular, never
call `synthetic_approval()` to manufacture the real qualification record or copy
its fictitious `tests=1`, `argv=['synthetic-only']`, reviewer and approval fields.

Write the canonical test-evidence document with Q, unique sorted input BlobRefs,
and the six actual run records/log BlobRefs. Its hash is T. The selector verifies
retained test input blobs, but only implementation/runtime inventory entries are
rehashed against live files at selection. Therefore **the controller and reviewer
must establish that the retained evidence inputs are what the runs actually
used**; merely pointing at a same-named live test path is insufficient.

### 6. Independent qualification review, then controller root selection

Give a fresh independent reviewer the immutable Q subject, T evidence, complete
retained inputs/logs, import/cache/runtime policy, actual mapped-file inventory,
and the final accepted dependency checkpoint. The review must cover exact bytes,
not merely the implementation commit message or test summary. A review decision
must bind Q and T and retain the actual independent review text as a BlobRef.
Only an actual approved review with no unresolved findings supports the schema's
`decision='approved'` and empty list. Do not write those values prospectively.

After that review, assemble the approval document linking qualification, tests
and review DocumentRefs. Its SHA-256 is A. The external controller independently
records/selects A from its review workflow. Receipt contents, synthetic fixtures
and locally consistent hashes cannot select the approved root. Do not embed A
as a product default or produce a general auto-approval writer.

Keep the acyclic sequence explicit: inventory/trusted base -> Q -> six runs/T ->
independent review -> approval/A -> controller selection. Late subject or test
input changes invalidate the affected subsequent stages. A failed review has no
production approval output; continue the authorized repair instead of relabeling
findings as resolved.

### 7. Exercise the selected root through the public live API

In a new trusted controller process with the same approved roots/import prelude,
select explicitly:

```python
q = select_oracle_qualification(
    approval_manifest,
    approved_root_sha256=controller_selected_A,
    live_roots=approved_live_roots,
    scratch_directory=absent_owned_scratch_path,
    limits=OracleQualificationLimits(),
)
```

The scratch parent must exist and the leaf must **not** exist; selection creates
it exclusively. The live roots must point to actual loaded implementation and
runtime files, not just retained blob copies. Hash identity does not authorize
importing the live checkout instead of the archive.

Use disclosed tiny success and input-precondition-failure invocations. Build a
real `VerifiedInvocation` using `write_invocation`/`verify_invocation`, run O2
to produce a candidate completed state, and copy its claim using
`produce_oracle_receipt`. That producer grants no execution authority. Call
`verify_oracle_receipt(receipt.manifest_path, exact_source_bytes, invocation, q,
limits=OracleLimits(...))`: it independently executes O2 and compares every
candidate state scalar. Only the returned live VerifiedOracle is an admitted
anchor under this policy.

Check source/family/specialization/invocation/state-invocation identities, status,
first-bad index, and preserved input/original output for the failure case. Run
handle and qualification `revalidate()`. Test wrong controller digest and copied/
forged handles as rejections. Tamper tests must use disposable artifact copies
or separately imported disposable live archives, never alter the approved
archive/runtime or immutable approved evidence to manufacture a control.

Do not monkeypatch the evaluator in the actual qualified live session merely to
count executions: honest loaded code is an explicit assumption. The separately
pinned unit controls already instrument execution-versus-revalidation behavior.
The public verifier's one fresh execution and later no-AST-execution revalidation
can be reviewed from code and those controls. A fresh process cannot deserialize
handle authority: it must select A and verify the receipt again.

Close child handles then q, or use context managers. Only one qualification may
be live process-wide, with at most sixteen child handles and shared aggregate
semantic retention limits. A second selection while the first is live is a
capacity failure, not evidence that A is invalid. A failed cleanup can leave
cleanup debt that blocks a new selection; investigate/retry owned cleanup rather
than clearing issuer tables. The handle's independently generated anchor is
owned scratch and may be removed at close; serialized paths or copied dataclasses
cannot preserve live authority.

### 8. Retain the controller outcome without overstating it

Retain exact Q/T/A, review record, source/runtime commit and inventory bindings,
six logs and counts, closure byte/file totals, live-control logs and cleanup
outcome. State which controls used synthetic policies and which used the actual
controller-selected root. Do not describe the old observation JSON or a passed
unit suite as qualification.

Successful O3 qualification establishes this reviewed expected-state instrument
under its trusted-runtime assumptions. It does not establish C1 proof acceptance,
native admission, O4/O5/O6 campaign evidence, performance, or physical instrument
qualification. Those gates remain separately controlled.

# Source name-work and shared byte-budget advice

Date: 2026-10-16. Author: `/root/audit_source_work`, independent read-only adviser.
This is not gate acceptance. Inspected the unchanged C2/frontend at baseline
`2e827dacf2b6ece9640df7abdf43a74892d9fc9f` and the live, changing research
`loop_proof_cost.py` / `loop_proof_graph.py`. Only this advice file was written.
No product edits, tests, commits, or subagents. Small arithmetic scripts enumerated
the 511 subsets of nine roles; they did not execute or validate a proof checker.

## Result and its exact limitation

A role comparison multigraph gives a useful finite byte-coupled bound. For
**one-time source-name resolution**, the conservative graph below has 270
candidate character comparisons. Under a documented model which compares each
candidate key at most once per logical map access, with immutable string hashes
cached once per lexical occurrence, its name-byte density is `37/4`. Adding four
certificate/table traversals per source-axis spelling raises the density to
`119/12`. This is the result of an exact 511-subset maximum, not a measured
canonical-spelling extrapolation.

With the source variable categories identified below, their joint bound is
`131*B/12 <= 715,434 2/3`, leaving roughly 284,565 units for **all remaining
fixed/source/proof costs**. This is a conditional useful envelope, not a claim
that the whole source phase or proof fits. The four axis-name traversal count
must agree with the final serialization/accounting paths.

There is an important unresolved distinction: Python dict/set lookup is not a
linear candidate scan. A fixed allowance of 128 *structural* probes does not
automatically pay for repeated comparisons of long string keys. The graph is
an audit of logical map candidates, not yet a deterministic upper bound on every
actual CPython string-equality call. Pin/audit that implementation, implement
the specified bounded comparison algorithm, or retain the gap explicitly.
Do not use this report to relabel semantic name work as decoder work.

## Nine roles and disjoint source-byte budget

Roles in table order are H, W, input I, producer P, output O, producer axes p0/p1,
and output axes o0/o1. Their identifier spelling lengths are L_i. The exact
source token multiplicities are:

```
m = (4, 4, 3, 5, 1, 3, 3, 5, 5)
I = 4(L_H+L_W) + 3L_I + 5L_P + L_O
    + 3(L_p0+L_p1) + 5(L_o0+L_o1)
```

For example, each shape name occurs once in its declaration, once in an input
dimension, and once in each producer/output axis upper bound. The output tensor
name appears only in its declaration. Each producer axis appears once as a
binder and in two producer read indices; each output axis appears in four reads.
Two different roles can have identical text where the source permits shadowing;
the occurrence multiplicities still hold. The five declaration names are
distinct, and the two axes in any single equation are distinct.

Let C be the number of repeated cap constraints, D their total decimal digits,
and G retained group wrappers. Then, without double-counting source bytes,

```
I + 2G + 31C + D <= B <= 65536
D >= C
therefore I + 2G + 32C <= B.
```

Uncounted module name, type spelling, keywords, numeric literals, punctuation,
comments, whitespace and optional objective consume further bytes, so omitting
them is conservative. The role names exclude the constraint-property tokens,
which are already included in 31C+D. No source spelling restriction is needed.

The prior uniform `16*(length+1)` per role occurrence cannot establish a full
source envelope: a single accepted long output name can consume nearly all B
while appearing once. Its logical comparisons are against shorter other names,
which the uniform reservation fails to exploit.

## Independent call-site expansion

Read `_validate`, `_constant`, `_interval`, `_validate_scalar`, `_profile`, and
`source_profiles._admit` together. Successful fixed-profile admission enforces
declaration dependency order H,W,I,P,O, ignoring interspersed constraints.

| Site | Logical accesses and candidate sets |
|---|---|
| Declaration uniqueness | membership plus insertion against earlier global declarations |
| Declaration value maps | shape insertion into up to two shapes, tensor insertion into up to three tensors |
| Shape references | six source references, each membership plus lookup in shapes |
| Dimension extraction | **two further** shape lookups for H/W after validation |
| Axis declaration | membership plus insertion in each two-axis map |
| Tensor extent construction | two lookups of each axis (`axes[name][0]` and `[1]`) |
| Source read validation | two accesses per read (membership and get), two producer reads, four output reads |
| Source index validation | two accesses per axis occurrence in its local axis map |
| Profile shape maps | construction of the two-shape map |
| Profile tensor maps | input map, one-entry producer/output temporaries, and their updates |
| Profile axis maps | **temporary two-axis dict construction**, then update into a copy of the shape map |
| Profile normalization | six shape refs, six tensor read refs and twelve axis refs |
| One-time source resolution | two local axis maps, twelve axis occurrences resolved once, six read names resolved once |

Dictionary copies can reuse keys/hash fields without comparing source spelling;
they still have bounded structural work. When axis names shadow shape names,
updating a map can replace an earlier key. Keeping both logical roles in the
candidate superset below overcounts safely. Zero-candidate insertions still need
structural/hash treatment even though they add no character-comparison edge.

The live `_name_schedule` initially omitted six comparison candidates:

1. `_admit`'s `height, width = (shapes[decl.name] ...)`: two lookups with two
   shape candidates each, adding H-H, H-W, W-H, W-W.
2. `_profile`'s temporary axis dictionary comprehension: second-axis insertion
   can compare against first-axis once in each equation, adding p0-p1 and o0-o1.

These were sent to the implementer. Empty-key temporary insertions also need
structural treatment. A fixed global allowance must be reconciled with those
actual calls rather than silently omitting them.

## Complete conservative character-comparison graph

An edge weight counts comparisons and is symmetric in its two name lengths.
Self-edges are intentional: an AST occurrence and the declaration key can be
different string objects with the same spelling. The graph covers validation,
profile normalization, H/W extraction, and one resolution of retained scalar
and index names. Subsequent reconstruction must actually use numeric slots.

| Role pair | Weight | Role pair | Weight |
|---|---:|---|---:|
| H-H | 10 | W-W | 10 |
| H-W | 24 | I-I | 8 |
| H-I | 2 | I-P | 22 |
| H-P | 2 | I-O | 6 |
| H-O | 2 | P-P | 16 |
| H-p0 | 3 | P-O | 8 |
| H-p1 | 3 | p0-p0 | 10 |
| H-o0 | 5 | p0-p1 | 25 |
| H-o1 | 5 | p1-p1 | 10 |
| W-I | 2 | o0-o0 | 18 |
| W-P | 2 | o0-o1 | 41 |
| W-O | 2 | o1-o1 | 18 |
| W-p0 | 3 | W-p1 | 3 |
| W-o0 | 5 | W-o1 | 5 |

Weights sum to 270. A complete comparison costs a structural/length check plus
at most `min(L_i,L_j)` character examinations. Length inequality can skip all
character work when exact immutable ASCII-string equality is specified. Using
the min even when lengths differ is conservative and avoids relying on that
optimization. A mismatching prefix never costs more than this bound.

With repeated string lookup during each producer expansion instead, the graph
has 314 candidates. Relative to the table above, add I-I:8, p0-p0:8, p1-p1:8,
p0-p1:20. Thus the one-time resolver removes a concrete set of 44 repeated
string-comparison candidates. Merely changing the accounting multiplier without
changing the reconstruction algorithm would not justify that reduction.

## Exact finite density calculation

For any nonempty subset S of the nine roles, define

```
m(S) = sum of source multiplicities in S
e(S) = sum of graph weights whose two endpoints are in S
a(S) = number of the four source-axis roles in S
q(S) = [e(S) + m(S) + 4a(S)] / m(S).
```

The m(S) term charges one hash byte per lexical name byte; the 4a(S) term is the
separately stated four axis-name traversals. Enumerating the 511 masks with exact
integer cross-multiplication yields maximum `238/24 = 119/12`, attained by
S={H,W,p0,p1,o0,o1}. Without the four traversal term, the maximum is `222/24 =
37/4`, attained by the same subset. These maxima use the corrected 270-edge
graph; the provisional producer-axis-only 59/6 bound is too small.

This proves a bound for arbitrary nonnegative integer lengths, not only equal
lengths. At each byte depth k define S_k={i:L_i>=k}. Then

```
min(L_i,L_j) = sum_k 1[i,j in S_k]
I = sum_k m(S_k)
sum_edges e_ij*min(L_i,L_j) + I + 4*sum_axes L_i
    = sum_k [e(S_k)+m(S_k)+4a(S_k)]
    <= (119/12)*I.
```

This layer decomposition is the auditable proof behind the finite cases. All
length/hash and candidate comparison structural constants are additional fixed
costs; they are not in the length-dependent inequality.

## Combining source variables instead of independent maxima

The current `_source_work` has these conservative variable terms besides names:

* Raw source identity input contributes B.
* Cap validation/intersection contributes at most 96C: three integer comparisons
  per constraint, each one structural unit plus at most 31 bit units. The first
  constraint actually omits intersection, so this overcounts safely.
* Constraint property comparisons occur twice: parser cap recognition and v2
  admission. Each compares 20 bytes plus a structural unit, contributing 42C.
* Declaration dispatch and origin indexing add two more units per constraint.
  Thus a conservative combined term is 140C.
* Validation, normalization and origins contribute 3G. A T/E reconstruction
  traverses the producer once directly and four times inside E; no group is
  visited more than five times. If each recorded visit costs at most three
  units (one visit plus two replacements), this contributes at most 15G.
  Hence 18G covers these specific source group categories.

Let q=119/12. Since q>=9 and q>=140/32,

```
B + qI + 18G + 140C
 <= B + q(I+2G+32C)
 <= (1+q)B
 <= (131/12)*65536
 = 715434 + 2/3.
```

This bound is intentionally a little loose about digit lengths and group depth;
it needs neither the simultaneous maxima C=2048 and G=1674 nor a source-wide
maximum identifier length. It leaves fixed grammar/name-probe work, canonical
identity bytes, fixed source reconstruction visits, all proof work, and any
other group/name passes to be added explicitly. If an extra origin or source
visit walk is introduced, update the coefficients before claiming the bound.

## Runtime hash assumptions and the outstanding implementation gap

The one-hash-per-token bound is valid under a pinned immutable-string model
which caches a successful hash in the string object. Parsed identifiers are
ASCII-decoded token strings reused in AST fields; ordinary references to them
do not create new spelling objects. Even if equal spelling appears in separate
tokens, summing all lexical occurrence bytes already charges each object once.
If that model is CPython, name/version its implementation and audit the Unicode
hash caching contract. Do not silently assume the cache, PyPy equivalence, or
average collision resistance. Hashing can use a documented byte primitive,
just as source identity hashing does; its CPU operations are another matter.

Without cached hashing, charge the query spelling at every hashing access.
For the original repeated-expansion map schedule an independent no-cache query
vector is `(14,14,10,17,5,27,27,23,23)`; direct tensor equality is separate and
does not hash. This is much larger than lexical multiplicities. One-time numeric
resolution reduces it but does not erase validation/profile map accesses.

More importantly, an actual CPython hash table can revisit an occupied slot
during perturb probing. At capacity 8, an illustrative perturb hash 32 begins
at slots 0,2,3,0,...; the repeated slot can invoke equality again. Therefore
`number of resident keys <= k` does not prove `number of equality calls <= k`.
Charging 128 structural probes while charging long-character equality only once
per resident candidate leaves that repetition unaccounted. Small-table resizing
also needs explicit structural treatment, although it need not recompare all
string payloads when unique-key invariants are preserved.

Possible explicit resolutions are: a deterministic linear candidate scan; a
comparison cache keyed by immutable token/declaration identities with charged
lookup and first comparison; a trie of bytes; or a conservative pinned-runtime
probe/equality bound. Each must match the algorithm whose source reservation is
being claimed. The uninstrumented C2 implementation cannot be called free merely
because a cheaper reference algorithm exists. Resolving names once is a sound
optimization of reconstruction, but does not itself change C2's map behavior.

Keep accepted-source and rejected-source reservations separate as in the first
audit. This name graph assumes actual acceptance and does not cover arbitrarily
many pre-rejection declarations. No source restrictions, v1 changes, quota
increase, or complete-work acceptance follows from this advice.

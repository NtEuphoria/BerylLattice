# O3 independent specification and quality review checklist

Reviewer: `/root/review_oracle_qualification`.
Prepared before opening the live O3 implementation, tests or protocol extension.
Status: **CHECKLIST READY; IMPLEMENTATION REVIEW NOT STARTED; NO ACCEPTANCE.**

This is an independent obligation list derived from immutable requirements. It
is not an implementation design, advice to its author, a test result, a selected
qualification or an approval root. The controller must provide an immutable O3
checkpoint and its actual dependency/evidence inventory before full review.

## Requirement subjects

| Commit | Path | SHA-256 |
| --- | --- | --- |
| `a5a05b174c924fc65abf7a30041931a73c1871a1` | `docs/superpowers/plans/2026-10-16-axiom-oracle-qualification.md` | `a92bc2219bb0a875b68946d815515174ef8f82d4b7cb6ae5bcb9e5390a9c4a19` |
| Same | `docs/superpowers/plans/2026-10-16-axiom-scalability/03-independent-oracle-and-evidence.md`, global constraints and O2/O3 | `49c7b368b99d99e8c27a1812b1b1fec4624ba3cb1bec9e226157d352458a012a` |
| Same | `docs/superpowers/plans/2026-10-16-axiom-scalability/design.md`, common trust/identity/resource boundaries | `11b07794c565bd32003e8f4b9289bed7907c303bff39b6164b520736d4cd4234` |
| Same | `docs/superpowers/specs/2026-10-16-axiom-proof-oracle-continuation-design.md` | `e61cf3915e07265eacb8ccc6da6db219860e6e251556f1963a8213e3e19db474` |
| `eeb8f2c8e247d42abc73c6727ddfed57ab99a1d9` | `axiom/research/protocol/source-oracle-v1.md`, accepted O2 prefix | `e68b8137a01c227f05951eaff8f9071b2f15e5cdbdd5c11dbf132b195e0b3b05` |
| `d7e22c857ccf681cc94af9a1bfdf98282899b02c` | `docs/reviews/axiom-source-oracle.md` | `c7cae8342a7e7ac6c919b6584c3b7fb890e4553e3dddc183ad448cb3d8778dda` |

The refined O3 plan controls its additional operational choices. Accepted O2
remains unchanged by this task. A later separately reviewed C2 repair would be
a new dependency subject: inspect its exact change/review and reassess affected
O2/O3 claims; do not silently inherit approval from the older dependency hash.

## A. Scope, API and independent authority

- [ ] **A1** Only the three assigned O3 files change; O2's original protocol
  prefix, implementation, C2/O1/state primitives and v1 synthetic behavior stay
  intact, except separately identified and reviewed dependency changes.
- [ ] **A2** The exact selector, producer and verifier signatures are preserved.
  Public frozen records, `OracleReceipt`, caller-created `OracleResult` and
  caller-created state/invocation/qualification records do not grant authority.
- [ ] **A3** The selector requires the controller's explicit approval digest.
  No default, receipt-selected digest, embedded approved hash, self-approval
  builder or fallback path can manufacture qualification. Temporary test
  fixtures neither persist nor activate production approval.
- [ ] **A4** The producer copies a completed claim without O2 execution or
  verified-handle issuance. The verifier derives its anchor from one fresh O2
  execution of the exact admitted invocation, then compares the candidate.
- [ ] **A5** Production imports contain only the fixed accepted source oracle,
  permitted model/profile/invocation/blob/state dependencies and standard
  library. No reference evaluator, planner, checker, selector, emitter, native
  computation or receipt-provided executable/import/policy/callback executes.
  The caller's cancellation control remains explicitly trusted.
- [ ] **A6** All guards survive optimized Python; none depends on assertions.
  Qualification does not claim process isolation, cryptographic attestation,
  machine-checked correctness, native admission or measurement qualification.

## B. Closed schemas and approval evidence

- [ ] **B1** Every supported document is strict canonical JSON with exact
  schemas/keys/types; duplicate, missing or unknown keys reject. Reject bools
  as integers, malformed lowercase digests, unsafe/absolute relative paths,
  empty components and traversal. Each field/list/string is bounded.
- [ ] **B2** Document and blob references have their distinct closed layouts,
  exact lengths and complete-byte hashes. Paths resolve beneath the declared
  artifact root rather than cwd. Dispatch traverses only known reference roles;
  unsupported versions, cycles or unexpected nested reference types reject.
- [ ] **B3** Approval links exactly qualification, test evidence and review.
  Test evidence pins the qualification; review pins qualification and test
  evidence. All cross-links are checked against actual canonical bytes.
  Inventory -> tests -> review -> approval is acyclic and has no self-hash.
- [ ] **B4** Qualification pins the fixed entrypoint, runtime assumption,
  exact `SourceProfileV2`, actual agreed version spellings, CPython version,
  executable logical path, complete ordered inventory and trusted-base document.
- [ ] **B5** Inventory roles and test-input roles are separately closed;
  logical paths are normalized, ordered and unique. Exactly one interpreter
  entry exists. Evidence-only helpers cannot become executable imports.
- [ ] **B6** Test evidence retains actual test sources, helpers, fixtures,
  comparators, protocol and logs. Required `o3`, `source_oracle` and
  `synthetic_receipts` runs exist in both normal and optimized modes, with
  consistent exact counts, nonzero execution, zero failure/error/exit status
  and no skipped required O3 tests. `argv` is descriptive and never executed.
- [ ] **B7** Review is approved with zero unresolved findings and retains its
  real independent record. Verify that actual logs/review support their
  assertions about the pinned subject; fabricated count/reviewer strings and
  internally consistent locally recomputed hashes are not independent approval.
- [ ] **B8** Trusted-base text names shared parser/model/profile/state,
  Python/runtime/OS, trusted controller/reviewer, loaded-code honesty, stable
  files and absence of hostile same-UID races. Merely containing these strings
  does not establish review or remove operational validation obligations.

## C. Actual runtime and complete inventory

- [ ] **C1** Selected live roots are exact typed normalized absolute existing
  nonsymlink directories. Every inventory entry maps to the actual live file
  beneath its selected root, with descriptor-relative safe traversal and full
  comparison to the retained blob. Root aliases/overlap cannot bypass closure
  accounting or choose unapproved executable/module bytes.
- [ ] **C2** The actual resolved `sys.executable` file, not merely its version
  or a nominal sysconfig path, is bound. Large executables use bounded chunks;
  corrupting their final chunk fails.
- [ ] **C3** Inventory contains every actual O2/O3 execution module plus all
  additional accepted helpers. Loaded repository module origins must agree with
  selected live bytes. An omitted/replaced origin or path substitution rejects.
- [ ] **C4** Complete non-site/non-dist stdlib inventory includes permitted
  source, extension binaries and existing bytecode. Traversal cannot silently
  skip an unresolved symlink/entry. Further bytecode writes are disabled before
  capture. `-B` alone is not treated as prevention of cached-code execution.
- [ ] **C5** Every loaded implementation dependency's permitted existing
  `__cached__` file is inventoried, or trusted fresh repository roots demonstrably
  lack such caches. Source hashes do not substitute for this cache policy.
- [ ] **C6** Actual mapped executable-file dependencies are classified and
  bound after exercised success/failure imports; omission or newly used unmapped
  inventory entries fails selection/revalidation. Do not invent libpython from
  sysconfig. Kernel/vDSO and builtin/frozen modules are stated assumptions;
  unresolved mapping/origin classification leaves qualification unavailable.
- [ ] **C7** Revalidation rehashes actual live bytes and origin/executable
  bindings, not only retained inventory blobs. Honest already-loaded code is
  still assumed; hashes are not claimed to detect in-memory monkeypatching.

## D. Independent byte/file ledgers and pre-read limits

- [ ] **D1** Exact positive integer limits reject booleans and can only tighten:
  qualification 512 MiB, semantic 256 MiB, temporary 256 MiB, file 16 MiB,
  chunk 1 MiB, 16,384 files, metadata 1 MiB/depth 16/65,536 items, one live
  qualification and at most sixteen live oracle handles.
- [ ] **D2** Independent qualification/semantic path ledgers fully traverse
  known closures, including metadata. A shared retained path counts once;
  separate retained paths count separately even if content hashes agree.
  Forged declared totals, split references and duplicate logical names cannot
  suppress accounting.
- [ ] **D3** Safe stat/reference bounds charge prospective bytes/files before
  reading additional payload. Metadata itself is charged before its bounded
  read, with actual length/hash checked afterward. Instrument readers to show
  zero bulk reads when the relevant preflight budget is insufficient.
- [ ] **D4** Candidate state closure gets O3's bounded metadata/reference/stat
  precharge before `verify_state`; that dependency checks aggregate limits too
  late to provide O3's pre-read guard by itself. Revalidation must not trust an
  externally supplied empty or shortened `VerifiedState.closure`.
- [ ] **D5** Producer computes actual closure/file/per-file/metadata totals
  and exact canonical receipt bytes before destination creation or copying.
  Complete copy plus receipt fits semantic and temporary limits without credit
  for a future hardlink or omitted last chunk.
- [ ] **D6** Verifier charges candidate closure, all still-live independent
  anchors and the prospective anchor together. Shape reservations use
  `P=(H+1)*(W+1)`, `O=H*W`, `I=4P`, `S=4(P+O)`, both rounded-up chunk counts,
  manifest file and selected maximum manifest bytes, before O2 acquisition.
- [ ] **D7** Operation peak reservation is `I + S + max_manifest + O3_private`
  plus any existing temporary payload. The state manifest is counted once.
  Selected O3 and caller O2 temporary bounds both apply, and O2 receives only
  the remaining allowance after O3-owned temporary reservation. No independent
  fresh 256 MiB sub-budget may defeat the combined bound.
- [ ] **D8** Exact state metadata/per-file admission remains delegated to
  O2's accepted public pre-write contract; no unreviewed private helper or
  unchecked copied projection is treated as authoritative. Tight conservative
  rejection is allowed; transient excess is not.
- [ ] **D9** Slots/storage are reserved before execution and released on all
  failures and closes. Multiple handles cannot multiply semantic allowance.
  Cleanup refusal remains explicit and cannot silently turn retained bytes into
  unaccounted free capacity. Counters do not claim RSS, physical disk blocks,
  assured free space or full O5 campaign I/O accounting.

## E. Producer claims, safe copying and publication

- [ ] **E1** Revalidate exact result type, complete/incomplete relationships,
  every identity/counter type and a freshly parsed complete state. Only success
  and input-precondition failure may serialize; malformed or incomplete results
  leave no destination. State shape/status derive from actual state metadata.
- [ ] **E2** Copy the full closure with exclusive descriptor-relative
  NOFOLLOW writes into owned pending storage, preserving normalized paths.
  No hardlinks to caller-controlled files. Original removal/mutation cannot
  silently change the copy; the last state chunk is retained and verified.
- [ ] **E3** Existing destination/ancestor files remain untouched. Failure
  at final-chunk write, copied-state verification, source-state revalidation or
  final qualification check removes only owned incomplete staging.
- [ ] **E4** Copied state is freshly verified; original state and qualification
  are revalidated immediately before atomic publication. Allocate any returned
  record before the commit point as needed; a post-publication fallible step
  must not report an incomplete operation while leaving a published receipt.
- [ ] **E5** A fully self-consistent wrong candidate can serialize as a claim
  but has no verified authority. Its later rejection must rest on independently
  executed truth, not on a private O2-result registry or producer provenance.

## F. Fresh source execution and complete binding

- [ ] **F1** Validate the live qualification, strict receipt, exact source,
  C2 admission, public O1 invocation and matching profile/dimensions/identities
  before authoritative execution. A forged typed invocation or later mutation
  of its actual input/initial-output closure fails.
- [ ] **F2** Keep exact source, family, specialization, v2 invocation and
  state-v1 invocation identities distinct. State semantics uses specialization;
  state-v1 invocation comes from the public mapping. Renamed/grouped source may
  have equal states but cannot borrow exact-source receipts. H/W changes affect
  specialization/invocation while retaining the admitted family identity.
- [ ] **F3** Once admitted through preflight, call the fixed O2 evaluator
  once into a qualification-owned fresh child. The receipt supplies no executable
  destination or state anchor. Premature failures do not call O2 unnecessarily.
- [ ] **F4** Only a completed fresh O2 result may proceed. Work, resource,
  unsupported-source, invalid-invocation, cancellation, timeout, allocation and
  I/O failures issue no handle and release owned staging/reservations.
- [ ] **F5** Freshly parse/verify the generated anchor, then compare every
  candidate input/output scalar and complete status/earliest-bad-index metadata.
  Equal hashes never skip actual comparison. Include final chunks, preserved
  input and nonzero rejection canaries in controls.
- [ ] **F6** A candidate with changed state bytes and all locally recomputed
  digests/claims fails against the independent anchor. Test wrong initial output,
  last scalar, input preservation, status and earliest-invalid index separately.
- [ ] **F7** Immediately before issuance revalidate qualification, original
  invocation, candidate receipt/state and independent anchor, then perform the
  final cancellation/deadline poll. Late mutation or registration failure leaves
  no live handle. Prepare handle/issuer record before authority commit; no later
  fallible validation can relabel successful registration as failure.

## G. Exact-identity handles, lifetimes and reentrancy

- [ ] **G1** Handles are opaque, issuer-created, identity-based (`eq=False`),
  with no public success constructor. A bounded strong issuer table requires
  `record.handle is handle`, not equal field values, digest, token or recycled id.
  Exact type and current issuance are checked before using public fields.
- [ ] **G2** Private records retain original immutable pins, actual paths,
  qualification association and authoritative state metadata. Public properties
  cannot redefine any of them, even through copied/forged/altered records.
- [ ] **G3** Revalidation freshly reads actual receipt, invocation, full
  expected state, qualification and live code against original pins, without
  rerunning the AST. Repeat consumers do not turn serialized hashes into
  re-created authority. `expected_state` belongs to the independent anchor.
- [ ] **G4** Copy/deepcopy, dataclass lookalikes, object construction, altered
  public fields, unknown identity, pickle round trips, and reconstruction in a
  new process cannot recreate issuance. A new-process receipt verification must
  explicitly select qualification and execute O2 afresh.
- [ ] **G5** `close()` invalidates before cleanup, is idempotent for an issued
  closed handle, releases its slot, and parent close invalidates all children.
  Cleanup errors stay visible without reviving authority; already absent owned
  paths are harmless. Closing forged objects cannot remove someone else's data.
- [ ] **G6** One active-operation guard covers qualification operations and
  child creation/revalidation/close as required. A trusted cancellation callback
  cannot recursively select/produce/verify/close to exceed limits or invalidate
  an in-progress parent. Reentry fails explicitly and guard/reservation state is
  restored on every exception path.

## H. Immutable review and executed evidence

- [ ] **H1** Obtain exact O3 commit, base, changed-file hashes, all dependency
  revisions, actual runtime inventory, review/test-input inventory and real test
  evidence. Review from a git archive of that commit, not changing worktree
  bytes. Record archive/runtime/probe hashes and command working directories.
- [ ] **H2** Independently inspect implementation and tests against A–G.
  Verify accepted O2 source/protocol prefix and relevant v1 dependencies; inspect
  any separately reviewed C2 delta and affected regressions before acceptance.
- [ ] **H3** Run required O3, O2 and synthetic receipt suites normally and
  under `-O`, then relevant O1/state regressions. Confirm actual executed,
  pass/fail/error/skip counts and exit status. No zero-test or skipped required
  case is accepted as evidence. Check the supported working-directory entry
  points rather than relying on accidental test-import collisions.
- [ ] **H4** Author independent adversarial controls from this checklist:
  recomputed false candidate; copied/mutated opaque handle; final-chunk and
  last-boundary failures; aggregate pre-read/pre-write quotas; accumulated live
  anchors; callback reentry; actual interpreter/library/cache substitution;
  source-renaming and specialization mismatches; fresh-process reexecution.
  Test helpers may construct explicit temporary policy fixtures only.
- [ ] **H5** Trace all operational exceptions and commit points for leaked
  authority, descriptors, reservations or inaccessible artifacts. Fault injection
  must fail for its intended boundary, not an unrelated fixture/environment
  failure. Record reproducible findings with concrete impact and source lines.
- [ ] **H6** Resolve material findings on a new immutable checkpoint and
  rerun affected controls. Distinguish specification, quality and actual external
  qualification selection. Passing code review does not generate a production
  approval root; the controller separately binds final actual review/evidence.

## Review method and present disposition

Requirement reading and SHA-256 extraction have completed. No O3 implementation
or new O3 test was opened, no product execution was performed, and no product
file was edited for this checklist. The next action is the controller's immutable
review handoff. The eventual report will map obligations to code/evidence and
give explicit SPEC and QUALITY dispositions; unchecked boxes here are pending
review, not findings or inferred failures.

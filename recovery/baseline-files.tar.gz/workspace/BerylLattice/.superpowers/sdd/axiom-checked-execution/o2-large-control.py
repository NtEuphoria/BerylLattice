"""Disclosed all-max oracle correctness control; no native/performance claim.

Run with PYTHONPATH pointing at an immutable source snapshot. The controller
supplies an exclusively new output root and separately supervises this process.
"""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import struct
import sys
import time

from axiom.invocation_v2 import InvocationLimits, write_invocation, verify_invocation
from axiom.source_profiles import SourceProfileV2
import source_oracle
from state_artifacts import verify_state


def repeated_i32(value, cells):
    scalar = struct.pack('<i', value)
    for start in range(0, cells, 32768):
        yield scalar * min(32768, cells-start)


def main():
    root = Path(sys.argv[1]).absolute()
    root.mkdir(mode=0o700)
    side = 2048
    cells, outputs = (side+1)**2, side**2
    source = b'''module disclosed_oracle_control;
shape H = 2048;
shape W = 2048;
input image: i32[H+1,W+1] in 0..=1023;
let p[r in 0..H+1,c in 0..W+1] = (image[r,c]+1)*(image[r,c]+1);
output result[r in 0..H,c in 0..W] = ((p[r,c]+p[r,c+1])+p[r+1,c])+p[r+1,c+1];
require plan_workspace_bytes <= 64;
prefer multiplication_ops;
'''
    invocation_limits = InvocationLimits()
    invocation_path = write_invocation(source, repeated_i32(1023, cells),
        repeated_i32(17, outputs), root/'invocation', limits=invocation_limits)
    invocation = verify_invocation(invocation_path, limits=invocation_limits)
    started = time.monotonic()
    limits = source_oracle.OracleLimits(deadline_monotonic_ns=time.monotonic_ns()+420_000_000_000)
    result = source_oracle.evaluate_source_state(source, invocation, root/'oracle',
        profile=SourceProfileV2(), limits=limits)
    elapsed = time.monotonic()-started
    if result.status != 'success' or result.state_manifest is None:
        (root/'incomplete.json').write_text(json.dumps(asdict(result), default=str, sort_keys=True, indent=2)+'\n')
        raise RuntimeError('large disclosed oracle control incomplete: '+result.status)
    state = verify_state(result.state_manifest)
    counts = {}
    for role, expected, count in [('input_after', 1023, cells), ('output', 4194304, outputs)]:
        observed = 0
        for value in state.iter_scalars(role):
            if value != expected:
                raise RuntimeError('full-state control mismatch '+role+' at '+str(observed))
            observed += 1
        if observed != count:
            raise RuntimeError('full-state control length mismatch '+role)
        counts[role] = observed
    checks = {
        'source': result.source_sha256 == hashlib.sha256(source).hexdigest(),
        'invocation': result.invocation_sha256 == invocation.invocation_sha256,
        'state_invocation': result.state_invocation_sha256 == invocation.state_v1_invocation_sha256(),
        'state_metadata': state.metadata.invocation_sha256 == result.state_invocation_sha256,
        'specialization': state.metadata.logical_semantics_sha256 == invocation.specialization_semantics_sha256,
        'preflight': result.input_preflight_scalars == cells,
        'emission': result.emitted_state_scalars == cells+outputs,
        'source_reads': result.input_read_scalars == 8*outputs,
        'ast_visits': result.scalar_evaluations == 77*outputs+20,
        'cache_bound': result.peak_cached_input_bytes <= limits.max_cached_input_bytes,
        'logical_state_bytes': state.logical_bytes == 4*(cells+outputs),
    }
    if not all(checks.values()):
        raise RuntimeError('control identity/counter check failed: '+repr(checks))
    invocation.revalidate()
    record = dict(kind='disclosed-all-max-source-oracle-correctness-control', side=side,
        initial_output_canary=17, expected_output=4194304, counts=counts, checks=checks,
        oracle_wall_seconds=elapsed, limits=dict(deadline_seconds=420, supervisor_seconds=480),
        result=asdict(result), state_logical_bytes=state.logical_bytes,
        source_oracle_sha256=hashlib.sha256(Path(source_oracle.__file__).read_bytes()).hexdigest(),
        python_version=sys.version, python_executable=str(Path(sys.executable).resolve()),
        qualification='none; this is portable correctness evidence, not O3 or native qualification',
        accounting='O2 observable counters only; opaque O1/state verification passes excluded')
    (root/'control.json').write_text(json.dumps(record, default=str, sort_keys=True, indent=2)+'\n')
    print(json.dumps(record, default=str, sort_keys=True), flush=True)


if __name__ == '__main__':
    main()

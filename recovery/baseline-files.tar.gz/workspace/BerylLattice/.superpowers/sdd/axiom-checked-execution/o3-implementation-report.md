# O3 implementation handoff — frozen for controller commit and fresh review

Status: implementation complete and self-reviewed against the accepted O3 plan/preflight; ready for an immutable controller checkpoint and independent semantic/trust-boundary/quality review. This report is not independent review, actual runtime qualification, a production approved root, or native acceptance. No approval root was generated or installed. No commits, worktrees or subagents were created by this implementer.

## Exact owned files

| File | SHA-256 |
| --- | --- |
| `axiom/research/oracle_receipt.py` | `0a6aba2b43ce10202b3d2b1311345420ae6f7fa2f2aa21bbc94f80d1e3cf43e4` |
| `axiom/research/tests/test_oracle_receipts.py` | `77b22683f5b900dc1f66d0a8e012c1afe0223efa1e98faf7002b7713b629b30b` |
| `axiom/research/protocol/source-oracle-v1.md` | `a4921ae8c22541273c01db2236e6df56731f230b468de5708e6a03af2610e8ec` |

Only these three product files were created/changed. The original accepted O2 protocol is the unchanged first 14,840 bytes, SHA-256 `e68b8137a01c227f05951eaff8f9071b2f15e5cdbdd5c11dbf132b195e0b3b05`. Protocol changes append 187 lines. O3 module: 1,074 lines; tests: 722 lines. `git diff --check` passed. Concurrent proof-owned changes were not touched.

Dependencies used by these runs:

- `axiom/research/source_oracle.py`: `a29677691160c2f9b19fa580f47429760ca647d9ff0d7340d66ea07a35dbcb8f` (accepted O2 implementation at `eeb8f2c8e247d42abc73c6727ddfed57ab99a1d9`).
- `axiom/src/axiom/source_profiles.py`: `2d77a02746d815583b926ede83ef553e258fba4d442a12dd3f035c9c04fe9d43` (current C2 before the separately planned source-name cost repair).

## Implemented boundaries

- Explicit controller-supplied approval digest, strict acyclic approval/qualification/tests/review/blob schemas, complete actual runtime binding, bounded pre-read metadata/stat closure accounting and no automatic policy selection.
- Real resolved Python executable, complete non-site stdlib including permitted bytecode, actual Linux executable mappings with device/inode checks, implementation origins and current existing permitted caches. Unknown or missing dependencies reject.
- Producer validates exact completed O2 claims, reconstructs state, preflights the complete owned copy/receipt, copies every member exclusively without hardlinks, then verifies/finally publishes. Producer does not call O2 and grants no execution authority.
- Verifier fixes the O2 entrypoint, checks exact source/family/specialization/v2 and state-v1 invocation identities, reserves candidate plus existing anchors plus conservative new state/manifest and joint temporary allowance, executes once, compares every scalar and preserves invocation input, and commits authority only after final checks.
- Live object identity, strong issuer ownership, session and handle limits, original private pins, reconstructed exposed states, fresh I/O revalidation without AST reexecution, nonblocking operation/reentry guard, and close invalidation before cleanup. Cleanup failures keep conservative debt and block new sessions until retry succeeds. Successful cleanup drops pathname ownership immediately so repeated close cannot reclaim a reused path.
- Test-only temporary policy roots contain clearly labeled synthetic review/test assertions. Those fixtures prove mechanics; they are not actual production evidence or default policy.

## Actual executed tests

All final required O3 cases executed; no O3 skips. `o3-test-observation.json` records exact actual cwd/env/argv, counts and raw-log hashes. The four final O3 commands returned observed process exit code 0.

| Suite / cwd | Normal | Optimized | Skips |
| --- | --- | --- | --- |
| O3 / `axiom` | 31 passed | 31 passed | 0 |
| O3 / `axiom/research` | 31 passed | 31 passed | 0 |
| O2 / `axiom` | 29 passed | 29 passed | 0 |
| Synthetic receipts / `axiom/research` | 26 passed | 26 passed | 0 |
| Exact O1 artifact chunks + invocation / `axiom` | 14 passed | 14 passed | 0 |
| State artifacts / `axiom` | 16 passed | 16 passed | 0 |

Final O3 logs: `o3-final-normal.log`, `o3-final-optimized.log`, `o3-final-research-normal.log`, `o3-final-research-optimized.log`. O2 logs: `o3-o2-{normal,optimized}.log`. Synthetic logs: `o3-synthetic-research-{normal,optimized}.log`. O1 focused logs: `o3-o1-focused-{normal,optimized}.log`. State logs: `o3-state-{normal,optimized}.log`.

Meaningful TDD RED logs precede each implementation task: missing module/API in `o3-task1-red.log`; missing producer in `o3-task2-red.log`; missing independent verifier in `o3-task3-red.log`; not-yet-implemented live revalidation in `o3-task4-red.log`. Task 1 passed 8 cases both modes; Task 2 passed its 3 focused cases both modes; Task 3 passed the then-complete 16-case suite both modes. Later added controls are covered by final 31-case runs.

Observed failures/limitations retained honestly:

1. The unchanged synthetic command from `axiom/` fails discovery because `tests.test_manifest` resolves against `axiom/tests` rather than `research/tests`. `o3-synthetic-{normal,optimized}.log` retain that failure. Running unchanged tests from `axiom/research` fixes the namespace, with 26 actual passes each mode. No out-of-scope import edits were made.
2. A broad `test_*v2.py` regression run passed 30 counted tests but included two existing skipped native Core/Clang-selector class controls. Exact relevant O1 modules were subsequently run: 14 passes per mode, no skips. The broad logs remain; those skips are not O3 acceptance claims.
3. An intermediate optimized fresh-process test correctly rejected a normal-mode child whose existing permitted repository cache paths differed. The child now inherits optimization mode; all final four O3 runs pass. Real qualification should use the controller's genuinely cache-free archive roots and disable bytecode writes before imports to keep one tested subject across modes.
4. Self-review found successful close retained old cleanup paths. This was corrected before handoff and covered by `test_successful_close_does_not_reclaim_reused_path`.

## Actual observed runtime and later qualification preparation

`o3-runtime-observation.json` is actual complete streamed-hash inventory metadata and test-input metadata for this working tree. It is expressly an unapproved observation, not a blob-retaining qualification root. Current normal-mode observation has 1,000 live entries / 56,386,533 bytes:

- 17 implementation source/cache files (344,528 bytes).
- One actual Python executable (30,894,944 bytes; must use O1 chunks).
- 975 non-site stdlib files (21,891,285 bytes).
- Seven mapped runtime libraries (3,255,776 bytes): actual loader/libc/libdl/libm/libpthread/librt/libutil. No fabricated libpython dependency.

The independent controller's later archive subject, test execution, fresh reviewer and selected production approval root are still required. Do not reuse the temporary test assertions. Suggested concrete preparation:

1. Export the final reviewed source snapshot into a genuinely cache-free directory. Start with `-I -S -B` or equivalent trusted startup and set `sys.dont_write_bytecode=True` before imports. Explicitly install the archive `axiom/src`, `axiom` and, for ordinary research test runner compatibility, `axiom/research` paths. Choose the implementation import namespace consistently; loaded modules must originate inside selected live roots.
2. With final O3/O2 imports loaded, `oracle_receipt._runtime_paths()` reports the actual required path→role set for inventory preparation. This private helper performs observation only and issues nothing. Normalize each path against explicit `OracleLiveRoot('repository', archive_axiom)`, `OracleLiveRoot('python', resolved_runtime_root)`, and `OracleLiveRoot('system', resolved_system_library_root)` roots. Inventory every returned complete file via existing O1 `write_blob(file_blocks, actual_length, directory, limits=BlobLimits(...))`, streaming blocks. Use keyword fields when converting `BlobReference`: field order is manifest path, manifest digest, byte length, content digest. Retain every manifest and every chunk, including final executable chunks. No symlink entry may be silently skipped/resolved inside the stdlib tree.
3. Follow the appended protocol's exact closed schemas. All `DocumentRef` and `BlobRef.path` values are relative to the **approval manifest's parent root**, even when the referenced document is nested. Only blob chunk references are relative to their own blob-manifest parent. Inventory logical paths and test inputs must be strictly sorted and unique; runtime role/path set must exactly match actual observation. Include source and every existing permitted current cache, or keep repository caches absent.
4. Write the bounded trusted-base document and qualification document before test evidence. Use actual `sys.version_info[:3]`, `sys.implementation.name`, resolved `sys.executable`, exact `asdict(SourceProfileV2())`, fixed entrypoint/runtime assumption/version tags from the appended protocol. The version tags are declarations, not newly invented dependency APIs. No approval digest is part of the qualification subject itself.
5. Execute required O3, O2 and synthetic receipt suites in both modes against that subject with bytecode writes disabled. Preserve actual stdout/stderr, exit status, exact cwd and environment. The closed run schema has no separate cwd/env fields: record a bounded descriptive argv that represents the actual invocation and retain cwd/env in the actual log/header or retained reviewed record. Those strings are never executed by O3. Use the actual research cwd for synthetic tests as above.
6. Retain all actual test sources/helpers/comparators/fixtures/protocol bytes. Current minimum observed input set is in `o3-runtime-observation.json`: O3/O2/synthetic test files, `research/tests/test_manifest.py`, `src/axiom/reference.py`, `research/experiment_manifest.py`, `research/receipt_admission.py`, source-oracle protocol and `tests/fixtures/inputs/boundary_cases.json`. Execution primitives already occur in the implementation subject. Independently inspect any additional helper/fixture used by the final archive tests; the reviewer must accept completeness and truthful run assertions.
7. Test evidence binds qualification digest. A fresh independent review document binds both qualification and test-evidence digests and retains the actual review text as O1 blob. Only then construct approval linking all three documents; obtain its digest from the controller's separate workflow and pass it explicitly to `select_oracle_qualification`. Scratch must be an absent path; parent directories must already exist. No selection is a production approval merely because the selector accepts its typed schema.
8. Reobserve mappings after the required success/failure paths. Selection and every revalidation require exact actual bytes/origins/dependencies; unresolved mappings fail closed. New libraries/cache paths cannot be silently added after approval. Test fixtures' successful end-to-end checks also exercise actual mapping stability, but do not replace final archive inventory evidence.

The controller reported a pending separate C2 repair that will import new `axiom.source_names_v2`. It does not exist in this tested checkpoint. After that repair, A3 must add the actual new dependency plus its permitted cache to `_REPOSITORY_MODULES`/runtime closure (or adopt a separately reviewed complete transitive rule), rerun normal/optimized O2/O3 integration and fresh-review before real qualification. Current fixed dependency inventory must not be used to silently omit that future helper.

## Review focus / remaining trust limits

Fresh reviewer should inspect exact pre-read ledger traversal, original pins versus caller dataclasses, full scalar comparison, separate resource reservations, callback ordering before final rehashes, registration rollback and cleanup debt/reused-path lifetime. Limits are fixed/tightenable: 512 MiB qualification, 256 MiB semantic, 256 MiB operation temporary; 16,384 retained files; 16 MiB/file; 1 MiB chunks/metadata; depth 16; 65,536 metadata items; one selected qualification, at most sixteen live oracles with shared anchor budget.

Trusted loaded-code/OS/controller/stable-file assumptions remain explicit. This is not a child launcher, process isolation, reflective-monkeypatch defense, cryptographic attestation, correctness theorem, native instrument qualification or O4/O5 acceptance. No held-out/large native campaign was run. Conservative maximum-manifest reservations can reject tight limits. Review and actual controller qualification selection remain outstanding.

Owned product files are paused at the hashes above. Controller may serialize the immutable commit and fresh review; implementer will change nothing further without a follow-up task.

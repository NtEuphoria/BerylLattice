# O2 implementation ready for immutable independent review

Implemented against the declared eabd3098d85427bdad906b79a98aea723d3235df base,
without editing O1, state-v1, C2, Core, shared plans or another owner's files.
No worktree, subagent or commit was created by this implementer. Product files
are now paused for controller commit/review:

| Owned file | SHA-256 |
| --- | --- |
| axiom/research/source_oracle.py | a29677691160c2f9b19fa580f47429760ca647d9ff0d7340d66ea07a35dbcb8f |
| axiom/research/tests/test_source_oracle.py | 8544cec5d9c7e7c10320150b1672cb7e0f62a2e341684d5986abb9387e37a49d |
| axiom/research/protocol/source-oracle-v1.md | e68b8137a01c227f05951eaff8f9071b2f15e5cdbdd5c11dbf132b195e0b3b05 |

## Behavior and self-review

The evaluator freshly admits exact supplied source bytes and revalidates O1,
reserves conservative no-dedup logical snapshot/state/manifest resources and
metadata/file quotas, exclusively creates the destination, fully acquires and
preflights input into an anonymous snapshot, and streams state into private
staging. Invalid input executes no source visitor and preserves every canary.
Success interprets original declarations, names, dimensions, axis bounds,
groups, reads and arithmetic with precharged AST fuel and per-node checked i32.
Producer reads lazily interpret original bodies, retaining no producer/output
cells. Private snapshot reads use a bounded aligned two-chunk LRU with
pre-allocation eviction and exact-length pread. State-v1 metadata explicitly
uses specialization semantics and its separate invocation domain. Staged state
verification, final O1 revalidation and a final control poll precede the atomic
completed rename. No semantic poll or fallible verification follows commit.

Self-review covered original-node ordering/group work, declaration namespaces,
all quota projections, typed/nested entry validation, cache lifetime/units,
identity mapping, prepublication cleanup and postpublication status stability.
Root's in-progress review found an ancestor-open fd leak; ownership is now
recorded immediately after root open and after every child open, with a repeated
missing-ancestor /proc fd-count regression. A first expanded test attempted to
mutate O1 read-only chunk files; the test now explicitly chmods its owned fault
fixture before mutation. Initial implementation used frontend kind `let` rather
than `producer`; the initial one-cell test exposed it and it was corrected.

There are no outstanding self-review findings. Independent review remains
required; this report is implementation evidence, not O3 qualification.

## Tests retained

`o2-initial-red.log` retains two meaningful failed assertions from the deliberately
unimplemented API scaffold: expected one-cell success and invalid-input failure
status/first-bad index. No missing-module/import error is claimed as the RED.
The scaffold is gone. `o2-first-expanded.log` retains the expanded mutation-fixture
permission failure before correction.

Commands below ran from axiom/ unless stated otherwise:

- `PYTHONPATH=src:research python -m unittest discover -s research/tests -p 'test_source_oracle.py' -v`: 29 passed, 1.270s (`o2-normal-green.log`).
- Same with `python -O`: 29 passed, 1.141s (`o2-optimized-green.log`).
- `PYTHONPATH=src:research python -m unittest tests.test_reference tests.test_source_profiles tests.test_artifact_chunks_v2 tests.test_invocation_v2 research.tests.test_state -v`: 51 passed, 3.457s (`o2-dependencies-normal.log`).
- Same dependency command with `python -O`: 51 passed, 3.422s (`o2-dependencies-optimized.log`).
- From axiom/research/: `PYTHONPATH=.:../src python -m unittest discover -s tests -p 'test_source_oracle.py' -v`: 29 passed, 1.303s (`o2-research-discovery-mode.log`).
- Same alternate mode with `python -O`: 29 passed, 1.217s (`o2-research-discovery-optimized.log`).

Both test import modes use a local literal disclosed fixture, avoiding ambiguous
`tests.helpers` namespaces. The dependency logs remain relevant after subsequent
O2-only test additions and the final local fd-ownership/import-style cleanup;
no dependency implementation was changed.

Controls include full independent small-reference comparisons (boundary JSON,
1x1, 5x7, all 12 positions times -1/1024/i32 extrema, names/groups), rejected-input
visitor guards, exact/minus-one work budgets, all source/v2/state identity pins,
byte-for-byte input/source file preservation, complete 32x32 zero/max states,
7-byte blob and 16-byte state chunks, minimum cache and eviction/first/last,
short cache/preservation reads and partial snapshot writes, allocation/recursion,
all cancellation phases and expired deadline, forged invocation/nested records,
mutation at three phases, late output chunk and both verifier failures, wrapped
ENOSPC classification, all state/logical/temporary quota preflights with
zero acquisition/temp creation/writer calls, existing paths/symlink ancestors,
fd cleanup, propagation of unrelated programmer errors, dependency inspection
and a clean subprocess import guard. Production uses no assertions.

## Disclosed feasibility controls

Reproduce from axiom/:

`PYTHONPATH=.:src:research python ../.superpowers/sdd/axiom-checked-execution/o2-throughput-controls.py`

`o2-throughput-controls.log` records Python 3.12.14 and the exact current oracle
code hash for each complete synthetic zero/max run. These timings include the
entire oracle function (entry/final O1 checks, preflight, execution, state writes
and verification, publication). Invocation construction and the independent
postreturn complete-value check are outside that timed function. Every input
and output value and all identities were checked after each run.

| Side/control | Wall seconds | AST visits | Input source reads | Acquired / snapshot written | Snapshot reads | Cache fills / peak payload |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 32 zero | 0.04732 | 78,868 | 8,192 | 4,356 / 4,356 B | 8,712 B | 1 / 4,356 B |
| 32 max | 0.04811 | 78,868 | 8,192 | 4,356 / 4,356 B | 8,712 B | 1 / 4,356 B |
| 128 zero | 0.69285 | 1,261,588 | 131,072 | 66,564 / 66,564 B | 133,128 B | 1 / 66,564 B |
| 128 max | 0.67964 | 1,261,588 | 131,072 | 66,564 / 66,564 B | 133,128 B | 1 / 66,564 B |

32 checked 1,089 input + 1,024 output values; 128 checked 16,641 + 16,384.
The source has 77 visits/output plus 20 declaration/bound visits. Measured
128 throughput is about 1.82–1.86 million original-node visits/second. A naive
2048 zero/max extrapolation is roughly 174–178 seconds for 322,961,428 visits;
it excludes scale-dependent cache effects, helper/I/O growth and contention.
Controller should choose a finite conservative supervised budget after review.
No 2048, historical primary, fresh holdout, native executable, campaign or speed
claim was run/minted by this milestone.

## Documented limitations

- Shared parser/admission frontend is a trusted base; execution independence is
  from physical plans/lowering/reference, not frontend independence.
- Only the presently admitted live fixed-buffer family is supported. Python
  visitor recursion can produce explicit incomplete resource_limit.
- Cancellation/deadline are cooperative; parser, OS calls and existing O1/state
  full verification passes have no internal callback/hard real-time guarantee.
- Temporary quota is logical payload only; cache quota covers retained random
  input bytes only. Neither is OS reservation, allocated-block, heap or RSS bound.
- Counters omit opaque O1/state traversal work and are not O5 campaign accounting.
- Stable paths/files and no hostile same-UID racer are inherited assumptions.
  Cleanup is best effort if filesystem close/removal itself fails; no incomplete
  result returns a completed manifest. Existing destinations are never replaced.
- 32/128 controls fit one default cache chunk; tiny-cache controls exercise
  eviction. No unmeasured large execution was substituted for review/qualification.

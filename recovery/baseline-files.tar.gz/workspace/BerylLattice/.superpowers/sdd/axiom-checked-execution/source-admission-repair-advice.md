# Minimal source-admission repair advice

Date: 2026-10-16. Adviser: `/root/audit_source_work`. Read-only design work;
only this ignored advice file was written. No implementation, tests, commits,
subagents, or acceptance decision. Inspected the current unchanged shared
`frontend.py`, `source_profiles.py`, and the live research accounting design.

## Recommendation

Prefer a **v2-local transient alpha-renamed view of the freshly parsed AST**.
Resolve original semantic identifier spellings with a genuinely deterministic,
charged linear registry, assign at most nine one-character ASCII labels, and
call the existing shared `_validate` / `_profile` on that internal view. Return
and retain the original parsed AST, bytes, spans, names and constraints. Compute
the same normalized profile and five identities as today.

This avoids editing v1/shared frontend code and avoids maintaining a duplicate
semantic validator. It removes long original names from Python hash-table
lookups, so repeated equality probes only compare fixed-size labels. It still
requires an explicit reviewed v2 boundary change: early necessary structural
guards can change the order/code of rejected-source diagnostics. Accepted
language and identities need not change. Original-name resolution is semantic
work and stays in the semantic budget.

If preserving every rejected v2 diagnostic and its order is mandatory, the
smallest clean alternative is a reviewed shared-helper parameterization with
unchanged defaults for v1. There is no ordinary dependency-injection mechanism
in the current helpers that supplies deterministic maps without changing their
code or introducing another transformation/validator.

## Exact locations of the current gap

`frontend._validate` creates the global declaration `set`, shape/tensor dicts,
and a local axis dict per equation. Those containers service:

* `_constant`: shape membership and retrieval;
* `_interval`: axis membership/retrieval, then shape fallback;
* `_validate_scalar`: tensor membership/retrieval;
* `_validate` itself: uniqueness, map insertion and tensor extent lookups.

`frontend._profile` independently creates shape/tensor dict comprehensions,
temporary producer/output dicts, copies each shape map, constructs a temporary
axis dict, and updates the local map. `_normalized` calls those maps' `.get`.
`source_profiles._admit` then extracts H/W with two shape-map lookups.

The parser's `depths[id(node)]` map is a different, separately bounded decoder
mechanism. Fixed JSON identity dictionaries use fixed keys; they do not reinsert
arbitrary original source names. Objective/property comparisons and their caps
are also distinct operation families and must remain charged.

Replacing the research `_name_schedule` alone cannot change these actual calls.
Changing a global `dict` symbol does not affect `{}` or dict comprehensions.
Monkeypatching helpers/builtins, cloning function globals, executing rewritten
source, or temporarily changing names in frozen source records is not an
appropriate injection mechanism.

## V2-local adapter: concrete sequence

1. Validate exact `SourceProfileV2` / `SourceLimitsV2` as today, reserve the
   documented parser/ingestion work, and freshly call `parse_source` on the
   immutable source bytes. Do not trust a caller-created AST or claimed digest.
2. Apply charged necessary guards: exactly two shapes, one input, one producer,
   one output; both shape expressions ungroup to IntegerLiteral. These checks
   reject only sources the existing profile necessarily rejects. Input rank two
   and exactly two axes per equation are optional additional necessary guards
   that simplify the hostile-path bounds. Do not infer acceptance from them.
3. Walk **the declaration tree once**, not all duplicate SourceModule indexes.
   Register declaration names, axis names, NameReference names and ReadExpression
   tensor names in a linear vector of original exact ASCII strings. On each
   lookup charge every candidate/length/character comparison before performing
   it. A full length check can reject unequal lengths before character scanning.
   If no candidate matches, append a new spelling with the next short label.
   More than nine distinct semantic spellings is necessarily outside the
   accepted canonical profile; reject it explicitly rather than silently
   coalescing or truncating names.
4. Construct an immutable transient view with the same declaration order,
   expression operators/association, group wrappers, literals, axis/rank shape,
   intervals and Span/name_span records. Replace **only** the four categories
   of semantic names above, using one global spelling-to-label bijection.
   Reuse original literal/constraint records where safe. Do not render/reparse
   renamed text: that would alter spans and source identity.
5. Run the existing `_validate(view)`. Perform constraint/objective checks on
   the original unchanged values. Extract H/W through `view.shapes` and the
   returned short-key shape map. Perform the same dimension envelope checks,
   then `_profile(view)` and `_canonical_profile()` equality.
6. Return the **original** SourceModule from `_admit`, along with the derived
   H/W/objective/normalized profile. The existing AdmittedLoopKernel constructor
   can continue to retain original bytes/AST/constraints and generate its
   existing identity dictionaries. Never replace `source_digest` with a digest
   of the transient view.

Keep this as a private helper in `source_profiles.py` or a narrowly scoped v2
module; no second public source-admission boundary is needed. The labels can be
`a` through `i`. Their spelling need not avoid the user's names because every
semantic identifier occurrence is transformed consistently and the view is
never reparsed. Labels are structural internal values, not semantic identities.

Do **not** rename module name, input element type, constraint property name,
objective text, operators, keywords or literals. In particular `i32`,
`plan_workspace_bytes`, and objective enum values retain their existing roles.

## Why the transformation preserves admission

On any potentially accepted source, all semantic identifier occurrences use
the five declaration roles and four bound-axis roles; hence there are at most
nine distinct spellings. The registry is globally injective and maps equal
spellings to equal labels. It therefore preserves duplicate-name decisions,
undefined-name decisions, declaration dependencies, and all map lookups.

One global bijection is important: if an axis shadows a shape/tensor spelling,
its label must equal that spelling's label. Creating unrelated labels per
namespace would lose the original equality/shadowing relationship. The shared
validator still supplies the actual lexical maps, and `_profile` still supplies
the same declaration-order and axis-order canonical role names. This is a
renaming lemma, not a new implementation of range checking or profile matching.

Shape parameters, input intervals, arithmetic, groups and binary association
are untouched. `_profile(view)` therefore equals `_profile(original)` whenever
the original is admitted. Family/specialization/constraint/objective identities
are unchanged; exact source identity hashes the original bytes. The returned
AST remains the actual original parser result, so source origins and user
diagnostics can continue to refer to original offsets.

The view's spans deliberately reference original token extents; they are not
assertions that a label occurs in the source bytes. Only the original AST may
serve as the source-origin authority. A proof algorithm using the view must
carry the checked association back to original records/spans.

For diagnostic translation, do not replace alias characters throughout the
message: a one-character alias also appears in ordinary words. The shared
validator's name-bearing forms are a small exact grammar: `undefined shape
{name!r}`, `undefined index {name!r}`, `undefined tensor {name!r}`, and `duplicate
declaration {name!r}`. Match the complete known code/message form against a
fixed alias, then build one replacement message from that alias's original
spelling, preserving the original span. Other diagnostics are unchanged.
Translate once and suppress an alias-bearing chained exception in user-facing
output. This also avoids cascading when the original spelling is itself a
different alias. DiagnosticError exposes `code`, `span`, and the raw `message`
in addition to its formatted exception argument. Match the exact supported
forms against `error.message`; there is no need to parse the formatted argument.

Correction (2026-10-16): the earlier version of this advice incorrectly said
DiagnosticError had no raw message field. Controller/A1 verification and a fresh
read of `model.py` confirm `self.message = message`. The four-form exact,
noncascading translation recommendation is unchanged.

## Costs and reuse: do not introduce another hidden pass

The original-name registry has at most nine candidates. If I is the total byte
length of the 33 semantic identifier occurrences in an accepted source, a
simple bound on character work is `9I`, plus at most `9*33` candidate structural
checks. There is no original-name hashing and no cached-hash assumption.
Actual unequal-length and successful-prefix behavior can tighten this bound.

After renaming, all shared-validator map keys have length one. Any repeated
Python comparison or hash costs a fixed small amount. The model must still
bound/charge probes, map construction/copy/update and resizing; it must not
call them free or retain an unexplained 128-unit allowance. This remaining
constant-size implementation audit is substantially smaller than an adversarial
long-string equality problem. A future deterministic implementation of these
small label maps remains possible without changing the mathematical argument.

The transient-view walk, allocations, original-name comparisons, shared
validation/profile expression visits, canonical comparison, source origin walk,
cap intersection and identity bytes remain semantic charged categories.
Do not double-charge old long-name dict comparisons **and** call them the actual
new algorithm; replace the audited algorithm and recompute its ledger honestly.
Conversely, do not omit the new registry/view pass.

The current research constructor also resolves original names before building
its open roots. If it still does so after this adapter, that is an additional
charged name pass. Reuse is only legitimate if the actual private pipeline
carries the checked occurrence-to-slot mapping, or reconstructs from the view
while retaining original AST origins. Do not infer reuse merely because two
algorithms assign the same roles. Adding a public mutable sidecar or changing
the public source AST to hide the repetition is unnecessary.

For orientation only, if the adapter's registry is the sole original-name
resolution and source-axis names require four further artifact traversals,
`4*sum_axis L <= (4/3)I`. Registry plus those artifact bytes cost at most
`(31/3)I`. Together with raw source hash B, group term 18G and cap term 140C,
the disjoint inequality `I+2G+32C<=B` yields

```
B + (31/3)I + 18G + 140C <= (34/3)B <= 742741 + 1/3.
```

This is not a completed source/proof total. It excludes additional view/group
passes, fixed shared-map work and all proof work; it also assumes actual reuse
of name resolution. Recalculate the group coefficient for the new walk before
using any numerical envelope. The repair is justified by determinism and
equivalence, not by a target number it happens to leave available.

## Rejected paths and decoder separation

The existing validator checks arbitrary parsed structure before cardinality and
shape-literal recognition. Successive nonliteral shape declarations can grow
large integers across declarations. The accepted 54-node/name-role inventory
never bounded those rejected paths. Moving semantic validation into a decoder
counter would not repair this.

The early cardinality and literal guards above remove that specific shape-chain
path without removing any accepted source. Even then, source-byte-bounded but
noncanonical dimension/axis/index expressions can contain many additions. They
must not run uncharged before being rejected by canonical profile equality.

A coarse independent width argument becomes available after the literal guard:
let M=10^10-1 and N<=B<=65536. Shape magnitudes are <=M, and constant-bound
expressions sum at most N literal/shape leaves, giving magnitude <=NM. Axis
endpoints add at most one to that bound. Index expressions sum at most N such
values, giving <=N(NM+1), safely below 2^67. The scalar validator itself does
not evaluate scalar multiplication trees. Thus a conservative 67-magnitude-bit
bound covers these validation intermediates; the fixed profile's much tighter
accepted bounds remain available. This is a width bound, not a work bound.

For work, the wrapper can charge its own guards/registry/view construction
incrementally and reserve an independently derived AST-kind/count/width upper
bound **before** calling the unchanged shared semantic helpers. An overly large
candidate can exhaust that reservation and return the designated incomplete
resource result. Do not run the validator first and charge afterwards. If a
static reservation cannot fit accepted spellings, instrument the semantic
helpers through the reviewed alternative below; do not pretend exhaustion
proves semantic invalidity.

Keep parse byte/token/span/depth bookkeeping in its explicitly bounded decoder
policy. Note that parsing also performs semantic cap recognition/intersection
and exact-source hashing. Those operations need an advance semantic reservation
or a narrow charged hook even though they occur inside `_Parser.parse`.
Ten-digit parsed cap operands fit at most 34 magnitude bits before admission
checks nonnegative i32; a bound for rejected cap tokens must use 34, not 31.
The separately bounded decoder has to cover the whole pre-rejection parser,
not just accepted N<=3778. No reader should mistake its limit for permission to
perform unbounded source validation.

## Shared-helper parameterization if the adapter is not chosen

The smallest clean shared change is an optional private table backend parameter
to `_validate` and `_profile`, defaulting to native set/dict behavior:

* `_validate` obtains declaration-set, shape-map, tensor-map and each axis-map
  from that backend. `_constant`, `_interval`, and `_validate_scalar` already
  receive those maps and need no duplicate logic merely for lookup replacement.
* `_profile` must create **every** map through the backend, including temporary
  comprehensions and copied local maps. Its `.copy`/`.update` operations must
  preserve overwrite semantics and insertion order. `_normalized` already uses
  supplied maps' `.get`.
* The deterministic map is a small ordered vector or charged trie; membership,
  lookup, insertion, `.get`, copying and update have explicit costs and bounded
  growth. The declaration set can use the same vector with a sentinel value.
* V2 passes the backend; v1 calls the unchanged default path. No global state
  or cross-request monkeypatching. Preserve exact checks, order, messages and
  canonical serialization on the default path.

This touches shared frontend code even if v1 observable behavior remains the
same; it therefore needs explicit scope/review approval when the working rule
forbids v1 code edits. Arithmetic/visit hooks for hostile semantic work are a
separate extension: a map factory alone does not meter `_constant` additions
or the rest of `_validate`. Keep the patch small enough that those concerns
cannot be confused with merely replacing the hash table.

## Regression and review requirements

Before accepting either repair:

* Demonstrate unchanged v1 source/semantic digests, canonical bytes, quotas,
  public APIs, retained AST, and diagnostic behavior using the existing frontend
  controls. For the v2-local adapter, the shared frontend file need not change.
* Compare old/new v2 accepted results and all five identities on ordinary and
  extreme dimensions, long/module names, maximum byte padding, deep legal groups,
  zero-padded literals, repeated constraints, both objectives, and alpha-renamed
  programs. Check original bytes, original AST names and exact spans directly.
* Include axis/shape/tensor name shadowing, same axis spellings in separate
  equations, distinct equal-length long-prefix names, and names already equal
  to the chosen internal labels. Those are necessary bijection tests.
* Rejection controls include global/axis duplicates, undefined forward names,
  extra declarations, nonliteral shape chains, wrong rank, changed scalar
  association, invalid caps/objectives, and more than nine distinct semantic
  names. Record any intentionally changed v2 diagnostic precedence explicitly.
* Verify budget-before-work behavior for name comparisons, view construction,
  pre-validator reservation, parser cap/hash reservation, and source/proof
  exhaustion. Reconcile every new pass with the analytical ledger. Avoid a
  passing result based only on a new measured canonical-spelling total.

The adapter is the recommended minimal boundary repair given the requirement
to leave v1/shared code untouched. It solves the long-name repeated-equality
problem while preserving accepted semantics, but is not by itself complete
production hostile-source work enforcement or C1/F1 acceptance evidence.

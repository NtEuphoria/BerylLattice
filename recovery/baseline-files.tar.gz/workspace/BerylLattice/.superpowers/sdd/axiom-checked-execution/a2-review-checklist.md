# A2 independent acceptance checklist — preparation only

Prepared by `/root/review_source_oracle` from the committed repair plan at
`2212ddf` and baseline `d7e22c857ccf681cc94af9a1bfdf98282899b02c`.
Read baseline `source_profiles.py`, the complete frontend's relevant parsing,
validation and normalization paths, baseline source-profile/frontend tests,
and A0's report as context. **The live A1 helper and its implementation/tests
have not been read for this preparation.** This checklist is not implementation
acceptance. SPEC and QUALITY verdicts remain pending an immutable A1 commit.

## 1. Scope, immutable evidence and unchanged interfaces

- [ ] Pin the implementation commit and inspect its complete diff against
  `2212ddf`; expected ownership is the new source-name helper, source_profiles,
  new helper tests and additions to source-profile tests only. Distinguish
  concurrent P1/O3 changes rather than accepting moving files.
- [ ] Export independent baseline and candidate Git archives. Never load two
  versions of `axiom` in one interpreter or reuse one version's module cache.
- [ ] Check byte identity of frontend.py and model.py against `d7e22c8` and
  ensure no v1, source-oracle, invocation/state, Core/native, quota or C1 gate
  change is included. Pin actual dependency hashes in the report.
- [ ] Preserve public source API/constructor signatures, exact-byte fresh
  parsing, configuration revalidation, source/profile quotas and identity
  payloads. A supplied AST/view/alias table must not bypass parsing.
- [ ] Inspect meaningful failing-first evidence and focused pass evidence,
  but run reviewer-controlled tests at the candidate commit before verdicts.

## 2. Independent semantic argument to verify against actual code

The proof obligation is a global injective renaming of semantic spellings,
applied consistently to every binding and every reference. A spelling shared
across namespaces must receive the same alias; distinct spellings must never
collapse. This preserves equality tests, while the unchanged validator retains
all scope and dependency rules. It is not necessary or desirable to invent a
second resolver in the adapter.

- [ ] Review all transformed fields: global Shape/Input/Equation declaration
  names, AxisBinding names, NameReference names and ReadExpression tensor names.
  Include names nested under groups, binary children, dimensions, axis bounds
  and read indices. Audit every AST record kind, not only accepted bodies.
- [ ] Leave module name, input element type/interval, operator, literal, equation
  kind, constraint property/value, objective, cap, source bytes/digest and all
  spans unchanged. They are not registry binding names.
- [ ] Preserve declaration and expression child order, every group wrapper,
  rank/coordinate order and original span/name_span. Do not simplify, fold,
  ungroup bodies, serialize/reparse, or mutate the parsed module.
- [ ] Traverse declarations once to construct the private view; categorized
  tuples must reference those same rebuilt declarations, not independently
  rebuilt or original long-name declarations. Check identity relationships as
  well as structural equality within the private view.
- [ ] Actual shared `_validate` and `_profile` receive only one-character fixed
  aliases in all semantic-name-bearing fields. Their dictionaries may contain
  canonical role strings as values, but no original semantic name as a key.
  H/W extraction must use the view's names, not original long-key lookups.
- [ ] Output `AdmittedLoopKernel.source_module` is the original parsed module,
  not the private view. Compare with an independent fresh parse including all
  names, spans, groups, order and retained constraints. Exact bytes and digest
  remain those supplied by the caller.
- [ ] Verify why normalization commutes with the renaming: `_profile` derives
  shape and tensor roles by declaration order, axis roles by local axis order,
  uses shapes for axis bounds and input dimensions, and overlays local axes
  only for equation bodies. Original spelling cannot affect these roles.

Baseline namespace facts requiring separate controls:

- `_validate` has one global declaration-uniqueness set across shapes/tensors;
  local axes are separately unique only within their equation.
- Axis bounds and input dimensions use shape-only `_constant`; they do not
  resolve local axes even if an axis has already been declared.
- `_interval` resolves a local axis before a shape of the same spelling.
- Tensor reads resolve through the tensor environment independently of axis
  names. Global dependency order still rejects forward and self reads.
- Bare scalar names remain illegal scalar values; merely renaming one cannot
  turn it into a legal read or literal.

## 3. Registry/resource mechanism, independently inspectable controls

- [ ] Storage is bounded to nine original spellings and nine fixed aliases.
  A valid family has five global declaration roles and four axis roles; reused
  spellings reduce that number. Module/type/property/objective spellings do not
  consume this semantic-name capacity.
- [ ] Every occurrence compares against each visited resident at most once.
  Each candidate comparison has an explicit length check and no more than the
  shorter spelling's character/byte comparisons. Parsed identifiers are ASCII,
  so the stated character-versus-byte unit must be explicit and consistent.
- [ ] There is no hidden dict/set/sort/hash lookup on original names, direct
  whole-module equality in the admission path, duplicate scan, or alternate
  unbounded registry. Maps over ids/fixed aliases are different and should not
  be falsely reported as arbitrary-original-name maps.
- [ ] Inspect accounting hooks/counters against real operations, including
  misses, matches, first/last matches, unequal lengths, common prefixes and the
  tenth-name rejection. Tests must not rely on random hash-collision hunting.
- [ ] At the tenth distinct spelling, reject with a documented diagnostic and
  original occurrence span before inserting a tenth retained entry or invoking
  general validation on unsupported input. References, including undefined
  ones, cannot evade registry capacity.
- [ ] Test names with long equal prefixes and different final characters;
  differing lengths; equal text from separate token occurrences; a very long
  output name; names already equal to each private alias; nine distinct names;
  a tenth distinct reference. Check actual resident/lookup work and capacity.
- [ ] Early exact declaration counts, grouped-literal shape checks, input rank
  two and both equation ranks two occur before general constant/index validation.
  Demonstrate that unsupported chains/ranks do not reach `_validate`.
- [ ] Preserve parser limits: immutable bytes, UTF-8/NUL handling, 65,536-byte
  source ceiling, expression-node tightening, ten-digit integer tokens and
  nesting bounds. Check both exact permitted boundaries and rejecting next
  values where fixtures permit them.
- [ ] Do not equate fixed-length keys with unit-cost Python maps. The handoff
  to P1 must enumerate actual scans, visits/copies, group/constraint/source
  identity work and fixed-alias validation/profile calls. A1 measurements do
  not establish the complete C1 envelope or a charge-before-work C5 checker.

## 4. Differential corpus and diagnostics

Run the same literal byte corpus through old and candidate public APIs in
separate archive processes. Compare complete accepted admission fields:
source/family/specialization/constraint/objective identities, H/W and counts,
interval, cap, objective, profile/version, source constraints and original AST.
Identity comparison alone is insufficient to show original-AST preservation.

- [ ] Canonical 1x1, 5x7, 32x32 and 2048x2048, plus 8191x1023,
  8192x1022 and their transpositions. These are admission-only tests, with no
  input/output tensors. Include dimension/cell-envelope rejections.
- [ ] Rename all globals; give producer/output distinct local axes (nine names)
  and reused axes; reuse tensor spellings as axes; reuse shape names as axes
  where the baseline accepts. Compare equal and unequal H/W cases so accidental
  shape substitution is not masked. Reverse/swap names and include original
  spellings that coincide with private aliases.
- [ ] Group shape literals and read indices/bodies, use comments/whitespace and
  zero-padded literals, both objectives, absent/repeated/interspersed constraints
  and different caps, maximum-length sources and long identifiers. Preserve
  exact-source differences while preserving unchanged semantic identities.
- [ ] Rejected cases: duplicate globals/axes; undefined shape/tensor/index;
  forward/self tensor reads; changed shadowing/association; wrong scalar
  literal/operator/read neighbor; illegal bare scalar name; wrong declaration
  counts/ranks; nonliteral shape chains; negative/zero shapes and bad ranges;
  invalid constraints/objectives and typed configuration forgeries.
- [ ] Record old/new diagnostic code, original span and message for supported-
  shaped failures. Preserve ordinary tested codes/spans unless a necessary early
  guard or explicit tenth-name limit actually preempts them. Keep an explicit
  table of intentional precedence changes for already rejected sources.
- [ ] Translate known name-bearing diagnostics in a single noncascading step:
  duplicate declaration, undefined shape/index/tensor. Duplicate axis and
  generic scalar-name errors do not contain a quoted name to rewrite. Preserve
  original span/name_span. Never perform broad substring substitutions in a
  complete message. Test originals equal to other aliases, alias substrings,
  long names and identifiers matching English diagnostic words.
- [ ] A private alias must not be exposed as the source's identifier. If the
  source's actual spelling equals that alias, returning it is correct; the
  diagnostic test must distinguish that legitimate case from leakage.

## 5. Fresh suite execution and v1 protection

At the pinned candidate, from `axiom/`, execute normally and under `-O`:

```sh
PYTHONPATH=src:research python -m unittest discover -s tests -p 'test_source*.py' -v
PYTHONPATH=src:research python -m unittest discover -s tests -p 'test_frontend.py' -v
```

- [ ] Record actual counts, exit status, skips/failures and commit/dependency
  hashes; retain independent differential and adversarial output separately.
- [ ] Run existing v1 golden identities and frontend tests; verify unchanged
  frontend/model bytes and no import/call-path change to v1 admission.
- [ ] Assess test quality: observed short-key validator boundary, meaningful
  negative controls, explicit errors surviving `-O`, and no acceptance derived
  only from the implementer's claimed logs or copied expected new outcomes.

## 6. O2/O1/O3 dependency reassessment after A1 is immutable

- [ ] Inspect O2's actual freshly admitted source object: original declarations,
  axis/tensor names, groups, spans and scalar association remain unchanged.
  Ensure the new helper does not introduce reference/planner/checker/emitter/
  native execution dependencies or return a private renamed AST for execution.
- [ ] Rerun O2 in both existing discovery modes, normal/-O, plus relevant
  reference/source-profile/blob/invocation/state tests. Exercise renamed/grouped
  source and all invalid/canary states against the new admission dependency.
  Include exact-source/family/specialization/v2/state-v1 mapping checks.
- [ ] Distinguish previous O2 acceptance and historical 2048 execution from
  evidence at the new dependency revision. Repeating the large control is not
  needed absent changed interpretation/output or another concrete concern.
- [ ] Verify the A3 handoff names source_names_v2 as an actual execution
  dependency for O3's fixed inventory, including permitted existing bytecode.
  O3 owner/reviewer must check omitted/mutated helper rejection at their final
  immutable checkpoint. Do not grant O3 qualification from A2 acceptance.

## 7. Verdict gates

Issue separate SPEC and QUALITY conclusions only after exact-diff inspection,
fresh execution and the alpha-equivalence argument above. Report concrete
defects with reproductions and distinguish new A1 issues from baseline frontend
limitations or intentional diagnostic-order changes. A2 can approve repaired
C2 while leaving P1/P2 accounting, C1, A3/O3 qualification and native/performance
eligibility explicitly pending. This preparation approves none of them.

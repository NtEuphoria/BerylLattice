# O2 original-AST streaming oracle design advice

Read-only design based on clean HEAD `2e827dacf2b6ece9640df7abdf43a74892d9fc9f`. This is advice, not acceptance, execution evidence, or an implementation. No product files were changed. The next implementation needs fresh independent semantic and quality review.

## Readiness and decisions to record before implementation

O1 supplies the necessary exact-byte transport and C2 supplies `AdmittedLoopKernel.source_module`. O2 can be implemented in its three declared files without importing plans or changing v1. The important remaining decisions are operational and publication contracts, not stencil semantics:

1. Define distinct `timeout` and `resource_limit` incomplete outcomes. The O2 illustrative list omits them, while the global contract explicitly distinguishes timeout and storage/quota failure from completed semantic execution. Record this small clarification in the O2 protocol and execution plan; never encode either as `input_precondition_failed`.
2. Select the O2-owned private input snapshot reader described below. This avoids millions of per-scalar file opens while retaining O1's existing guarantees. Measure a disclosed small case before attempting a large case.
3. Treat cancellation/deadline as cooperative: polls occur before/after O1 trust-boundary calls, for each copied input block, scalar preflight, AST-node dispatch, emitted scalar, and before publication. O1's complete `revalidate()` and the existing state writer's final verifier have no callbacks, so these calls cannot promise a hard real-time deadline. A hard wall-clock limit requires a separately supervised worker/process, not a misleading claim in O2.
4. Use an exclusively reserved operation directory and a hidden staging directory; return a manifest only after atomic publication of the completed subtree. An existing destination rejects without replacing it. A failed attempt removes its staging state and snapshot and has no completed manifest/result.

The existing state dependency is less restrictive than the question suggested: `state_artifacts.ArtifactLimits` already defaults to 1 MiB chunks, 16 MiB **per file**, and 256 MiB aggregate **and expanded logical** bytes. `state-v1.md` documents those values and `test_primary_size_synthetic_streaming_roundtrip_format_only` already handles a ~32 MiB complete state. There is no current 16 MiB state cap or 64 MiB default in this module. Preserve these defaults and existing v1 admission. Use explicitly validated O2/v2 limits when calling it; do not enlarge v1 receipts/export/evaluator limits. The large-profile statement “one state below 64 MiB” is a shape-derived size statement, not permission to widen any v1 contract.

## Proposed public records and signatures

Create only `axiom/research/source_oracle.py`, `axiom/research/tests/test_source_oracle.py`, and `axiom/research/protocol/source-oracle-v1.md` for this milestone. Keep O3 qualification/receipts outside O2.

Use frozen, slotted records with strict exact-type validation and revalidation at public entry (including nested records). Suggested API:

```python
@dataclass(frozen=True, slots=True)
class OracleLimits:
    max_source_bytes: int = 65_536
    max_cached_input_bytes: int = 2_097_152
    max_scalar_evaluations: int = 1_000_000_000
    max_temporary_bytes: int = 268_435_456
    max_input_snapshot_bytes: int = 33_554_432
    state_limits: ArtifactLimits = ArtifactLimits()  # explicit O2 ceiling validation
    deadline_monotonic_ns: int | None = None
    cancelled: Callable[[], bool] | None = None

@dataclass(frozen=True, slots=True)
class OracleResult:
    status: OracleStatus
    state_manifest: Path | None
    first_bad_index: int | None
    source_sha256: str | None
    family_semantics_sha256: str | None
    specialization_semantics_sha256: str | None
    invocation_sha256: str | None  # exact-source v2 identity
    state_invocation_sha256: str | None  # explicit separate domain
    scalar_evaluations: int
    input_preflight_scalars: int
    emitted_state_scalars: int
    input_read_scalars: int
    input_snapshot_bytes: int
    failure_detail: str | None

def evaluate_source_state(
    source_bytes: bytes,
    invocation: VerifiedInvocation,
    destination: Path,
    *,
    profile: SourceProfileV2,
    limits: OracleLimits,
) -> OracleResult: ...
```

Status is `success`, `input_precondition_failed`, `unsupported_source`, `invalid_invocation`, `work_limit`, `cancelled`, `timeout`, `resource_limit`, `allocation_failure`, or `io_failure`. Only the first two have `state_manifest`; only the second has `first_bad_index`. Incomplete results may retain partial counters and successfully checked identities, but never a completion flag, expected-state receipt, or completed-state handle. O3 must independently validate result provenance and files; a caller-constructed frozen record is not authority. A diagnostic code/detail is bounded text, not raw exception repr or retained source/input data.

Ceilings can tighten, never increase. Reject bool counts, non-finite/float deadlines, negative counters, an input cache smaller than one supported cache chunk, and nested state limits above the declared O2 ceilings. Validate temporary projected bytes before creating/consuming streams: private input snapshot + worst-case encoded input/output state + manifest/metadata overhead. Actual peak disk/file counts must also be enforced; deduplication is not permission to skip logical-state accounting. The O2 state ceilings may retain the existing 256 MiB storage/logical limit; the admitted source envelope gives a much smaller per-result size. Document that `max_cached_input_bytes` counts retained input payload, not all Python heap/RSS, parser objects, source bytes, state output buffer, or temporary read buffers. Avoid a claim of a hard Python heap bound.

Counters have explicit units. `scalar_evaluations` counts original source AST node visits, including literals, names, groups, binary operators, read nodes, and index expressions; a producer reread counts its declaration body's nodes again. Increment/check before dispatch so the first over-budget node is not evaluated and the retained counter never exceeds its limit. Preflight comparisons, scalar emission, safe-file verification, snapshot I/O and byte decoding are separate work; their counts must not be mislabeled AST visits. If physical I/O accounting is exposed, count actual source/snapshot/staging reads and writes, not just logical input bytes; O1 full verification does repeated traversal.

## Original-source evaluator

Allowed production dependencies are `axiom.model`, `axiom.source_profiles`, `axiom.invocation_v2`, `axiom.artifact_chunks_v2` (through its public transport), `state_artifacts`, and standard library modules. `source_profiles` already uses the parser/frontend; this is the declared shared trusted base. Do not import `reference.evaluate_source` in implementation: it is the independent small-case test comparator and materializes producer tensors. No planner, checker, selector, emitter, native computation, canonical optimizer DAG, schedule label, ring-buffer lifetime helper, or hard-coded four-neighbor arithmetic is permitted.

Admission reparses **the supplied exact bytes** using `admit_source_v2` and `SourceLimitsV2`. Compare the admitted source/family/specialization, dimensions, and profile with the freshly revalidated invocation and its retained source bytes. Never trust a caller-provided AST or merely a matching family. A changed unsupported equation is `unsupported_source` with no consumed buffer/equation work. A valid admitted source paired with another invocation is `invalid_invocation`. Errors during pre-consumption trust-boundary verification are invalid invocation; physical disk read/write failure after a valid boundary is I/O failure. Keep this phase classification explicit because low-level safe I/O wraps some OSErrors in ValueError.

After admission and revalidation, preflight every input scalar row-major into the snapshot. Retain the first failing index while finishing the complete input scan. Do not call equation evaluation at all on rejection. On success, evaluate source shape literal declarations in source order, then original input dimensions and equation axis bounds using the visitor. Each bound/result is checked i32. The rejected branch may use freshly admitted H/W for metadata without executing source declarations. This keeps the test “no source equation work before complete preflight” unambiguous.

Use a visitor `_evaluate_expression(node, scalars, tensors, work)` with explicit checked-i32 return on **every** original node, including groups and reads. Evaluate left before right and indices in declared order. Python integers supply exact intermediate arithmetic before range checking. Preserve group nodes and association; do not normalize the AST for execution. An explicit bounded evaluation-frame stack is preferable to Python recursion for excessive grouping. If recursion is used initially, catch exhaustion as an incomplete resource outcome, document it, and do not disable the work limit. Never silently strip groups to fit the budget.

Bind tensors by declaration identity/name from the admitted module. `_InputTensor.read(indices)` validates arity, exact integer/i32 indices, dimensions and checked row-major offsets, then reads the private logical input reader. `_ProducerTensor.read(indices)` checks the requested coordinate against that declaration's source-evaluated bounds, binds its declared axis names in a fresh local scalar environment together with shapes, and visits **that declaration's original body**. It stores no produced cells. `_iter_output()` walks output axes in declared Cartesian order and evaluates the original output body per coordinate. Use nested generators/`itertools.product` over bounded ranges, not a product-sized list or dict. Scope follows declarations and axes, never spelling `image`, `p`, `r`, `c`, `H`, or `W`.

For the currently admitted canonical family, all producer coordinates are demanded by outputs when H,W are positive, so lazy evaluation does not omit an otherwise live producer scalar. The admitted profile disallows extra producers or dead arithmetic changes. State this narrow reasoning in the protocol; do not generalize the oracle to arbitrary programs or dead producers without a separate design. Recomputing shared producer cells changes oracle cost, not scalar value/association. Check source axis bounds even though admission recognizes the family; do not replace source expressions with H+1/W+1 shortcuts.

## Efficient bounded input access without weakening O1

`VerifiedBlob.read_i32()` currently safely opens/stats the selected chunk on every scalar read, including cache hits. The original fixture's lazy expansion makes eight input reads per output. At 2048² that is 33,554,432 scalar-safe-open operations; straightforward execution is not a credible unmeasured large gate.

Prefer an O2-owned `_SnapshotI32Reader`:

1. At operation start call `invocation.revalidate()`. Acquire input only through public `invocation.input.iter_bytes()`; this itself fully revalidates before yielding actual chunk bytes. Copy each bounded yielded block into an operation-owned anonymous `tempfile.TemporaryFile`, checking the declared aggregate length, whole-input SHA-256, i32 alignment across generic blob boundaries, and every scalar's range. Generic O1 chunks may split a scalar; retain at most three carry bytes. Retain earliest invalid index, never build a scalar tuple.
2. The snapshot is private to this operation with a pinned file descriptor, no caller-controlled mutable pathname. Finish and close the public traversal before equation work. Drop ingestion block references so they do not overlap the two-chunk evaluation cache unnecessarily. Preflight scans the original acquired bytes, not a derived expected input.
3. Resolve generic logical scalar indices to fixed-size aligned snapshot chunks. A two-chunk LRU holds at most `max_cached_input_bytes`, evicting before a new allocation. Fill a chunk using bounded `os.pread` on the private fd and decode with `struct.unpack_from('<i', ...)`. Check short reads explicitly. No filesystem lookup occurs per cache-hit scalar; no producer/output array is added. This is a source-only random-access byte reader, not a stencil algorithm.
4. Stream `input_after` from the same snapshot; on precondition rejection stream `initial_output` through the public verified blob traversal, preserving every nonzero canary. Success ignores its values but still binds and revalidates its exact identity. All original source buffers remain unchanged.
5. After all output generation and staged state verification, revalidate the entire invocation again, check cancellation/deadline, then publish. Snapshot/stage descriptors close through context managers on all paths. Cache lifetime ends with the call. A snapshot supplies no reusable cross-invocation authority.

The snapshot adds at most 32 MiB disk and makes stable-file assumptions explicit. Full source-file revalidation before/after consumption is still mandatory; files must remain stable for the operation, as documented by O1. This does not claim protection against an adversarial same-UID writer racing individual reads. No changes to O1 `read_i32`, v1 behavior, or production imports are necessary.

An alternative is a separately owned/reviewed O1 `VerifiedBlob.open_read_session()` prerequisite with descriptor-relative pinned chunk opens, ≤2 retained payload chunks, fresh full revalidation on entry/exit, and no cross-operation reuse. Keep existing `read_i32` unchanged. This would need explicit dependency/file-ownership amendment and additional mutation tests. It is more general API work than O2 needs; choose it only if measured snapshot disk/copy cost warrants it.

## Complete state identity and publication

Build `StateMetadata` with `logical_semantics_sha256=admitted.specialization_semantics_sha256`, admitted H/W, the complete original input and initial-output hashes, and the actual completed semantic status/first-bad index. Require `metadata.invocation_sha256 == invocation.state_v1_invocation_sha256()` using its default specialization mapping. Never put the family digest or exact-source-v2 invocation digest in this state-v1 field. Retain exact source and v2 invocation pins separately in `OracleResult` for O3. Renamed/grouped sources may share semantic state while keeping separate exact-source pins.

Feed `write_state` two bounded generators with exact scalar-count checks: snapshot input and either computed output or original output. It writes full signed little-endian i32 canonical state-v1, with input role before output role. Count exactly P+O successfully yielded semantic-state scalars on completion. Call `verify_state` with the **same explicit** validated state limits. No acquisition sidecar, native-observed label, or oracle qualification is minted in O2.

`write_state` currently writes its manifest before its final closure verification, and can leave chunks on a generator/aggregate failure. Therefore never call it at the publicly completed path. Reserve a fresh destination operation directory exclusively using descriptor-relative NOFOLLOW directory operations; place state under a private `.pending-*` child. After writer return, complete state verification, invocation revalidation and final cancellation/deadline poll, rename that child to `completed` within the pinned fresh operation directory. Return `destination/completed/state.json`. The reserved operation directory makes the child target absent under the same stable-files assumption; existing destinations and artifacts are never replaced. Prefer descriptor-relative operations throughout. Do not report completion merely because some `state.json` exists in staging.

No cancellation poll or fallible semantic verification follows the publication commit point. Best-effort bookkeeping cleanup after publication must not relabel a completed artifact incomplete. Before publication, every exception removes its own pending subtree and anonymous snapshot, leaving no completed manifest. Keep failed control diagnostics in the immutable result, not a fabricated successful state. Tests should inject failure during a late output chunk and during final verification, where this distinction matters most.

## Focused tests and execution scope

The small comparator is `axiom.reference.evaluate_source(parse_source(source), input, initial_output)`. It deliberately rejects P>256; do **not** widen or monkeypatch that admission to compare 32×32. Compare every input/output scalar, status and first-bad index for the existing boundary JSON corpus, 1×1 [0,1,2,3]→[30], 5×7 coordinate case, 2×3 each invalid position, extremes -1/1024 and i32 boundary values, renamed names, and grouped source variants. Compare their scalar states independently of their intentionally different v1/v2 semantics identities.

For disclosed training 32×32, use existing disclosed training generator/seed (or clearly labeled known zero/max synthetic correctness control), stream all P+O scalars and assert exact counts, full input preservation, first/last output and hand-known zero/max outputs. This is independent of the small comparator rather than falsely claiming reference coverage beyond 256 input cells. The all-1023 producer value is 1,048,576 and each output 4,194,304.

Force generic chunk boundaries on these same small/disclosed shapes with `BlobLimits(chunk_bytes=7)` (input scalar crosses blob boundaries) and aligned small state chunks (e.g. 16 bytes). Test cache edge first/last scalar reads, evict/refill, exact i32 LE values, cache peak ≤2 MiB and small tightened-cache behavior. A real 1 MiB boundary test can use disclosed 512×512 training shape only if the measured runtime is affordable; it is not required to exercise boundary correctness.

Controls must include:

- Monkeypatch the equation visitor to raise on any visit before complete valid preflight; it stays uncalled for multiple invalid cells including the last index. All original output canaries survive; input remains byte-for-byte unchanged.
- Group-only source change preserves output but increases AST work; work-limit-minus-one fails and exact-enough work succeeds. Changed `+1` to `+2` is unsupported. Alpha renaming still executes. These controls reject a hard-coded stencil shortcut.
- Import/source-dependency inspection plus a clean-subprocess import guard forbids planner/checker/selector/emitter/native modules, including v2 module names. Tests may import reference; implementation may not.
- Typed invocation forged fields and source/input/output files mutated after initial verification reject before equations; mutate just before final revalidation and require no publication.
- Inject AST fuel exhaustion, cancellation before acquisition/mid-preflight/mid-output/just before publication, expired monotonic deadline, MemoryError, source read and snapshot write errors, short private reads, state chunk write/verification failure, tiny state logical/aggregate/metadata/file quotas. Assert distinct incomplete status, no completed manifest and closed handles/removed temporary files. Existing destination remains untouched. Do not treat unrelated programmer exceptions as semantic rejection.
- Add a structural or instrumentation check that no P/O-sized producer/output tuple/dict/list is built; use operation counter/cache instrumentation and source inspection rather than asserting fragile exact RSS. Tracemalloc can support a disclosed size comparison but is not a proof of OS RSS.

Run the O2 tests normal and `python -O`, then `tests.test_reference`, `tests.test_source_profiles`, `tests.test_artifact_chunks_v2`, `tests.test_invocation_v2`, and existing `research/tests/test_state.py` in both modes as appropriate. Retain a meaningful RED assertion before implementation and actual command outcomes after it. Do not execute fresh held-out shapes/seeds or the historical primary.

For optional 2048×2048 training execution, first time complete 32×32 and, if affordable, 128×128 with snapshot reader, recording AST counts, cache misses, source/snapshot I/O and wall time. The existing fixture expands to **77 AST node visits per output**, including lazy producer bodies, before declarations/bounds: 322,961,408 visits at 2048². Its producer body has 13 nodes. Extra groups increase the count, and even admitted source may legitimately hit the 1e9 operational cap. Extrapolate measured rate and bytes conservatively, set an explicit user-authorized task budget/deadline, and run only if feasible. Do not turn this milestone into an expensive correctness/native campaign or silently remove checks to reach the large shape.

## Exit recommendation

O2 is implementation-ready after recording the small outcome/publication/reader clarifications above. Native build/execution is unnecessary. Prefer the O2 private snapshot reader and small tests first; it provides a realistic path to the optional disclosed large shape without importing production scheduling. Stop after portable evidence and fresh independent review. O3 remains a separate next task: source-oracle qualification and receipts must bind the exact independent code/runtime/tests/review and source/invocation pins; successful O2 serialization alone is not qualified oracle correctness.

"""Disclosed zero/max synthetic oracle feasibility controls, no native timing."""
from pathlib import Path
import hashlib
import json
import platform
import struct
import tempfile
import time
from tests.helpers import stencil_source
from axiom.invocation_v2 import InvocationLimits, write_invocation, verify_invocation
from axiom.source_profiles import SourceProfileV2
import source_oracle
from state_artifacts import verify_state
for side in (32, 128):
    for value, expected in ((0, 4), (1023, 4194304)):
        with tempfile.TemporaryDirectory() as temporary:
            directory = Path(temporary)
            source = stencil_source(side, side)
            p, o = (side+1)**2, side**2
            inv_limits = InvocationLimits()
            manifest = write_invocation(source, [struct.pack('<i', value)*p],
                [struct.pack('<i', -991)*o], directory/'invocation', limits=inv_limits)
            invocation = verify_invocation(manifest, limits=inv_limits)
            start = time.monotonic()
            result = source_oracle.evaluate_source_state(source, invocation, directory/'oracle',
                profile=SourceProfileV2(), limits=source_oracle.OracleLimits())
            elapsed = time.monotonic()-start
            if result.status != 'success':
                raise RuntimeError(result)
            checked = verify_state(result.state_manifest)
            input_count = output_count = 0
            for scalar in checked.iter_scalars('input_after'):
                if scalar != value:
                    raise RuntimeError('input mismatch')
                input_count += 1
            for scalar in checked.iter_scalars('output'):
                if scalar != expected:
                    raise RuntimeError('output mismatch')
                output_count += 1
            if (input_count, output_count) != (p, o):
                raise RuntimeError('incomplete state')
            identities_checked = (result.source_sha256 == hashlib.sha256(source).hexdigest() and
                result.family_semantics_sha256 == invocation.family_semantics_sha256 and
                result.specialization_semantics_sha256 == invocation.specialization_semantics_sha256 and
                result.invocation_sha256 == invocation.invocation_sha256 and
                result.state_invocation_sha256 == invocation.state_v1_invocation_sha256() and
                checked.metadata.invocation_sha256 == result.state_invocation_sha256)
            if not identities_checked:
                raise RuntimeError('identity mismatch')
            print(json.dumps(dict(side=side, input_value=value, expected_output=expected,
                python=platform.python_version(),
                oracle_code_sha256=hashlib.sha256(Path(source_oracle.__file__).read_bytes()).hexdigest(),
                oracle_wall_seconds=elapsed, input_checked=input_count, output_checked=output_count,
                ast_visits=result.scalar_evaluations, ast_visits_per_second=result.scalar_evaluations/elapsed,
                input_preflight_scalars=result.input_preflight_scalars,
                emitted_state_scalars=result.emitted_state_scalars, input_read_scalars=result.input_read_scalars,
                acquired_input_bytes=result.acquired_input_bytes, input_snapshot_bytes=result.input_snapshot_bytes,
                snapshot_read_bytes=result.snapshot_read_bytes, cache_misses=result.cache_misses,
                peak_cached_input_bytes=result.peak_cached_input_bytes,
                state_logical_bytes=checked.logical_bytes, identities_checked=identities_checked), sort_keys=True))

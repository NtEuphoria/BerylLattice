# Constructive C1/F1 design advice

Date: 2026-10-16. Baseline inspected: `2e827dacf2b6ece9640df7abdf43a74892d9fc9f`.
Author: `/root/design_constructive_proofs`, a design adviser, **not** an independent acceptance reviewer.

This advice does not resolve F1 or activate C4–C11. I inspected the complete rule/theorem/hand-outline/F1 text in `axiom/docs/loop-plan-v2.md`, the research probe, both C1 reviews, the tracked gate, and the normative plan02/design. No product files, commits, worktrees, or subagents were created. Core remains the normal 4GL compiler; Axiom remains the separate private 5GL research project. All v1 bytes, schemas, quotas, and behavior remain unchanged.

## Recommendation

Finish C1 through a **complete constructive expansion of the three hand derivations**, represented by concrete typed tables and backed by a finite checking-algorithm/cost argument. Use ordinary scalar DAGs plus open source-value functions and capture-free coordinate closures. Do not materialize a fresh 16-node output expression for every region. Do not implement a second public checker in research. The research constructor may build precisely these derivations; only the future generic checker may admit arbitrary candidate bytes. No schedule tag supplies a proof premise.

The 8,814,588 proposal is not a lower bound. Its largest category charges every one of 1,484 hypothetical term rows as an expensive multiplication. The actual required scalar families are much smaller. There is a credible constructive route within the unchanged limits, but neither this advice nor a target allocation establishes full work/byte fit. The next implementation must finish the tables and the source/identity/affine/state cost ledger, then receive fresh independent review.

A complete research milestone is more useful than prematurely authorizing all C4–C11. C3 may proceed independently on immutable grammar/codec work, but freeze its certificate schema only after reconciling it with the completed C1 representation. A codec that round-trips only an invented toy certificate is insufficient evidence for the three complete certificates.

## 1. The representation that removes the artificial term explosion

Use these separate kinds of object:

- An ordered scalar `Term` (`const`, `input`, `add`, `mul`) with typed child/index IDs; its identity contains free binder IDs, never merely textual names. Closed constants have no scope dependency.
- An affine/index table, with explicit sorted typed binder/coefficient pairs and separately typed `mod2`. Source, physical, region, and parity binders have distinct identities.
- A reconstructed open value function. `T(u,v)` and `E(u,v)` are actual DAG roots rebuilt from the retained AST, with fresh formal region coordinates. They are not primitive opcodes or correctness tokens. Source AST origins and the source-binder-to-formal-binder renaming remain explicit.
- A `ValueClosure(root, formal_binders, coordinate_substitution)` inside a region. A prefix endpoint changing from `c` to `c+1` changes the region domain, not its value function. Physical layout/map and logical value coordinates are separate fields.
- A region fact with its domain, map, closure, and provenance. It denotes a universal fact over the bound region coordinates. Output facts carry the same exact source-value payload as scratch facts but have different ownership.
- Immutable state references: scalar environment, scratch fact IDs, and the entire output ledger. Persistent vector/list references can share representation, but each transition has a unique parent/continuation ownership edge. Never equate shared data with permission to reuse an effectful transition.

Pointwise equality of two closures is established by the same checked reconstructed root plus equal normalized coordinate maps under fresh common formal binders, or by ordinary ordered term comparison after an explicitly needed substitution. This is a sufficient equality rule, not a claim of arbitrary extensional equivalence. Joins check region adjacency, physical-map compatibility, and this value equality. They do not need to expand all cell values.

A substitution acts on free binder identities and is restricted to the root's free-variable set before memo lookup. A constant therefore uses one empty substitution, not one copy per region/scope. Check source and target scope, sort, range, freshness and nonescape before lookup. Canonical free-variable sets are computed from actual term children. Sharing must not allow a lemma proved under a parity assumption to escape that assumption. Pure syntactic term nodes can be shared across contexts; scoped proposition proofs retain their context/assumptions.

### A concrete scalar reachability count

For one coordinate pair, T has `Input`, `Add`, `Mul`, plus the shared constant 1. For one output coordinate, E has four coordinate triples and three ordered output adds, plus that same constant: **16 nodes**, depth six. A single reconstructed open E contains the open T at its first coordinate; no additional open T DAG is needed after explicit source-binder normalization.

When region closures are retained as closures, the only additional scalar materializations needed by the written plans are physical producer bodies and consumer bodies:

| Schedule | Additional coordinate-dependent scalar nodes | Total with open source DAG |
|---|---:|---:|
| Inline | one E instantiation: 15 | 31 |
| Materialize | one T instantiation: 3; one E: 15 | 34 |
| Rows2 | stage-zero T: 3; two cases each with refill T: 3 and E: 15 | 55 |

The rows2 bound deliberately treats the two parity contexts as distinct. It does not rely on cross-case semantic sharing. Source/physical expected and actual values intern into the same canonical table only after each has been independently reconstructed. The common closed constant is counted once. The open E construction includes producer expansion from the actual source tree, preserving association. Every source AST occurrence is still visited; DAG sharing does not delete those source visits.

These are constructive ceilings for **scalar value nodes under the specified closure algorithm**, not total proof/symbolic nodes. Affine terms, closure/substitution records, proof premises and source AST nodes must be counted separately. If a constructor expands closures at every base/step/exit or join, it no longer satisfies this count and must report the larger actual inventory. An adversarial dead operation adds its own obligation; the three valid hand plans have no dead extra operation. C4/C5 must check arbitrary dead operations, not restrict candidates to these three counts.

Reachable `(scalar_node, substitution)` memo pairs follow the same recursion: a T application visits its three varying nodes and the constant's empty-environment key; an E application visits fifteen varying nodes plus that constant key. The constructor should emit the exact distinct key set and every lookup event. There is no need to bound a Cartesian product of every term with every region. Equality after common-table interning compares root IDs; each successful intern lookup first compares the full typed key. If separate tables are used instead, collect the actual reachable ordered node-pair graph and memoize pairs; do not assume ID equality across tables.

### Intervals can share pure proofs too

The hand terms use seven numerical interval signatures: input, constant 1, increment, product, and the three output sums. A checked interval lemma is keyed by operator and operand intervals; the physical definition checks operand membership and references that lemma. Every physical definition is still charged, including repeated operations with shared terms. Region endpoint substitution does not change the scalar interval.

For example, multiplication of `[1,1024]` by itself costs `1*1 + 1*11 + 11*1 + 11*11 = 144` multiplication bit units for the four endpoint products, not `4*31*31` for every term row. Addition needs the two monotone endpoints. General multiplication must still handle all four products and extremum comparisons. Sharing is optional for feasibility: charging each of the 4/1/3 physical multiplication instances in inline/materialize/rows2 separately is already small. Charge repeated verification of operand and lemma references even on a cache hit.

One subtle accounting correction: `abs(-2**31).bit_length()` is **32**, so signed-i32 lower-bound comparisons do not fit a blanket 31-bit cost. This does not threaten the 256-bit quota; it does invalidate treating every numerical comparison as at most 31 bits. Derive widths per field/operation.

## 2. Concrete typed schema and required expansion

Use compact canonical JSON integer arrays as already proposed, with a written row grammar, fixed arities where possible, and typed references. The research output must include exact canonical bytes, not an event log masquerading as a certificate. Suggested table directory:

```text
header: format/accounting versions, source/family/specialization/constraint identities,
        exact canonical plan hash, proof root, table counts
binders: namespace, lexical owner, parent scope, sort
scopes: parent, introduced binders, domain-premise IDs, hypothesis owner/discharge
indices: literal | affine(constant, sorted binder/coefficient pairs) | mod2(affine ID)
terms: const(value) | input(index IDs) | add(term IDs) | mul(term IDs)
substitutions: source/target scope, sorted typed binder/index replacements
closures: term root, formal binder IDs, substitution ID
regions: four endpoint IDs, physical map ID, closure ID, fact kind
scalar_envs: ordered SSA/term/interval-proof bindings or persistent single-binding extension
states: scalar_env ID, complete scratch IDs, complete ledger IDs
proofs: rule opcode, scope, operation/block ID if applicable,
        incoming/outgoing state IDs if effectful, typed payload IDs, premise IDs
```

Physical plan bytes separately encode all ordered blocks, instructions, loop bounds, origins, pitch and reserved capacity. Header labels can remain opaque metadata; no proof rule reads the schedule name. Source origins are parser node offsets, validated against an independently traversed retained AST index, not trusted offset ranges.

The row grammar must include all state-equality/conjunction and coverage premises that the old 32/64/128 reservation hid. Each row must have a concrete derivation reason and a concrete parent/consumer. Larger conjunctions become actual rows or explicitly counted variable-arity payloads. No assumed maximum row width. There may be backward ordinary references plus locally bound induction premises, but no self-referential proof node.

Use a block spine so physical coverage is structural: at entry set cursor to first actual operation; each primitive or loop transition consumes precisely the next actual node and feeds its full outgoing state to the next transition; exit requires the cursor at block end. Within each exhaustive parity case the same physical body is checked once under that case. Do not merely compare coverage sets: sets lose order, multiplicity, and skipped-state linkage. State IDs must connect the actual sequence, including inserted operations absent from the certificate.

### Explicit hand graph obligations

Inline:

1. Initial empty S/L; outer base makes exact empty row prefix.
2. Outer arbitrary row binder/domain and scoped invariant; inner base preserves full prior-row ledger and adds an explicitly empty current prefix.
3. Twenty primitive instances with every operand, origin, input coordinate bound, scalar interval/term, store disjointness, singleton and ledger transition.
4. Inner successor exact equality, scope discharge, exit substitution, full-row join; outer successor exact equality, discharge and full-output exit.

Materialize:

1. Producer nested induction with empty initial scratch; prior complete rows and current prefix in each step.
2. Five producer primitive instances, physical row-major bounds, two preserved disjoint scratch frames, singleton addition and adjacent join. The actual prejoin scratch peak is three.
3. Exact producer-loop exit -> consumer-loop incoming state link; never reconstruct the full initialized rectangle as a free premise.
4. Consumer nested ledger induction, eight primitive instances, four checked physical membership/value substitutions at c/c+1 and r/r+1, unchanged scratch, and final ledger equality.

Rows2:

1. Stage-zero loop and five primitive instances establish row zero from uninitialized scratch; ledger stays exactly empty.
2. Outer base links that actual stage-zero result into I(0).
3. Outer arbitrary r with Euclidean partition covering p=0 and p=1, arbitrary quotient q, nonnegative mod arguments, and checked slot identities. For H=1 a case can be unreachable, but its impossibility must be established and discharged; do not delete a case on a schedule assertion.
4. In each case, refill loop base keeps the actual complete current row plus an empty next prefix and the full incoming ledger. Each store proves current-slot and prefix disjointness, invalidates all potentially intersecting facts, establishes its source value, and joins. Consumer base uses the actual refill exit.
5. In each case, consume loop checks all eight primitives and all four membership/value substitutions, conserves both rows and extends the exact ledger. Consumer exit joins the complete row; scratch weakening drops only the old row; successor substitution proves precisely I(r+1).
6. Both case conclusions rejoin with the same complete state assertion; all case/inner hypotheses are discharged. Outer exit proves full output. Numeric parity facts cannot replace the state link between case entry and exit.

Keep the established primitive counts 20/13/31 and induction-instance counts 2/4/6 as independent reconciliation checks against actual operation IDs. Physical node counts remain 22/17/22. They do not predetermine the proof-row count. Region/fact peaks count the transient singleton before its join, simultaneous scalar/fact/ledger components, and case contexts according to an explicit traversal strategy. Case checking can use a depth-first stack; a claim about active state must not silently discard retained proof tables from the separate memory observation.

## 3. Fully charged cost contract

Specify the checking algorithm before optimizing its accounting. It must be generic over the documented rule records, although C1 only constructs three examples. Research may implement charged arithmetic, normalized-key interning, substitution and finite accounting traversal; it must not export arbitrary-candidate eligibility or duplicate the future hostile decoder, planner, native emitter, or full production checker.

The cost ledger needs an independently written obligation-to-operation manifest, not a `mandatory=set(categories)` derived from the same code being tested. Each operation has owner row/call site, inputs, structural units, arithmetic operands/widths, and resulting output or memo hit. Include:

- Fresh source parse/validation/profile visits and original AST-to-open-DAG reconstruction, group-wrapper stripping, index/name resolution, source origin index and cap/objective intersection.
- Plan/certificate/source byte identity traversals, canonical serialization comparison, and all hash inputs. Hashing a cached claimed digest is not source validation.
- Every physical operation, including dead scalar definitions, ordered block coverage, operand lookup, bounds, index normalization and complete syntax-derived dynamic metrics.
- Each proof rule/premise/reference, state edge, full ledger equality/transformation, scratch invalidation/frame test, source equality and final output root.
- Actual reachable substitution keys, composition, free-variable/freshness/nonescape checks, term-key construction, lookup/collision resolution, comparison, depth/node checks and memo hits.
- Affine coefficient assembly/sorting/combination, endpoint elimination, parity/domain checks, footprint/injectivity premises, interval arithmetic and width checks.
- Scope/hypothesis entry/discharge, all base/successor/exit substitutions and case coverage.

Use deterministic bounded interning, e.g. a trie of tagged fixed-width integer key fields. Charge each bit examination/edge operation, key field construction, and final exact-key check. Derive key widths from the actual table maxima and field bounds, not 31-bit slots for every child ID. A balanced tree with explicit worst-case comparison counts is also viable. Python randomized dictionaries without charged key/hash/collision behavior do not by themselves establish the deterministic bound. It is permissible to use a dictionary operationally only with an independently justified conservative charge accounting for all bounded key work and worst-case behavior; a trie is simpler to audit.

The existing normative model distinguishes proof visits/bit work from separately bounded byte/item/digit decoding. Pin this distinction explicitly. Charge every identity byte traversal under a documented streaming hash primitive, as the existing appendix does; do not quietly treat cryptographic hashing as free or claim its internal SHA arithmetic is the same as proof integer arithmetic. If choosing to add decoder byte scans to total work, state precisely which scans and count them all. Native memory/deadline limits are separate. A fully charged abstract operation model is not a CPU instruction count: host loop-counter/budget-counter bookkeeping is included in its specified structural unit rather than recursively charging the work counter's own update. Do not move source semantic validation outside the budget just because the current C2 function has no accounting callback.

The current frontend is uninstrumented for proof work. A future C5 wrapper must reserve a proved source-phase bound before invoking it, then charge the actual independently enumerated visits/arithmetic or use a documented conservative source-phase charge. C1 must audit `_lex`, `_Parser`, `_validate`, `_profile`, `_admit` and the identity paths to justify this reservation; an unexplained “eight passes” allowance is insufficient. Any later change invalidates that algorithm-specific bound. Avoid editing shared v1 frontend behavior merely to add research instrumentation.

## 4. Proving a bound over the whole envelope

Separate structural cardinalities from numeric widths. Construct the graph symbolically in H/W using a finite meta-language for coefficients (`H`, `W`, `H+1`, `W+1`, P, bounded sums/products); specialize those leaves into the actual certificate bytes. Prove by recursion over the fixed constructor syntax that no loop runs over H, W, P, or output cells. The finite source traversal and three fixture descriptions are allowed. Graph construction may have dimension-independent cases for emptiness/equality simplifications; either disable such optional simplifications for these nonempty hand loops or account for every case.

For each actual arithmetic call site, derive an interval and operand bit widths from `1<=H,W<=8192` and `(H+1)*(W+1)<=2^23`. Use checked natural/integer bounds and the actual fixed expression, including differences and negative i32 constants. Never maximize H and W simultaneously at an inadmissible square and present it as a tested profile point. An independently justified enclosing box can be a conservative mathematical upper bound; label it that way and use P's relational bound when needed to tighten it.

Generate a machine-readable ledger of concrete operation call sites and their symbolic width bounds. The total is the finite sum of the documented per-operation costs plus lookup/structural work. Each table's byte bound is the sum of exact punctuation/opcode/reference widths and bounded decimal-field lengths in its concrete rows; canonical encodings at representative extrema corroborate that calculation. H/W substitutions cannot increase node counts; prove this using the constructor recurrence rather than comparing a few graph hashes.

Source spelling also varies. Its cost cannot be proved only with `source_bytes(h,w)`. Build a separate source-feature bound using the actual parser/profile grammar: normalized nodes, group wrappers, identifier bytes, comments/whitespace, constraint count and decimal digit lengths. Source-byte capacity couples these features. For example, six 31-bit cap comparisons per constraint and the maximum 2,048 shortest constraints cannot both be justified from a source consisting of ten-digit caps: larger caps consume more bytes. Use a small exact integer maximization or a hand-checkable dual bound on these feature counts, under 65,536 bytes and depth 32. Check constraints, identifier aliases and deeply wrapped accepted expressions independently. The old `54*33` envelope can remain a valid coarse component only after its exact counting convention is established.

This is the correct place to tighten the previous source allowance rather than erase it. If the full-source envelope does not fit while short canonical sources do, say exactly that; do not claim full C1 quota fit on a canonical-spelling measurement alone. No result in this investigation proves such a failure or an impossibility.

The required final table for each schedule must give actual concrete counts and proved envelope bounds for: source bytes, plan bytes (262,144), certificate bytes (524,288), IR/scalar definitions (4,096 each), loop nesting (4), affine terms (16), active facts (256), pieces (1,024), proof nodes (16,384), parity cases (16), symbolic nodes (65,536), scalar depth (256), intermediate bits (256), and total deterministic work (1,000,000). State clearly whether typed data rows also count as proof nodes. Retain the actual source-expression limit and parser depth/token limits. A partial pass never returns an exact complete metric.

Use `(1,1)`, training squares, `(8191,1023)`, `(8192,1022)` and transpositions as numerical corroboration, without allocating tensor buffers. These finite tests are not the mathematical envelope proof. The largest whole-state/native storage budgets are not certificate/work quotas and cannot subsidize them.

## 5. Research files, APIs, and task split

Keep the existing four C1 owned paths as the gate-facing interface. To keep construction/cost logic reviewable, explicitly authorize these additional research-only paths in the next plan (not silently expand old task ownership):

```text
axiom/research/loop_proof_graph.py
axiom/research/loop_proof_cost.py
axiom/research/fixtures/loop_proof_obligations.json
axiom/research/tests/test_loop_proof_graph.py
axiom/research/tests/test_loop_proof_cost.py
```

Suggested API boundary:

```python
construct_hand_derivation(source_bytes, outline) -> HandDerivation
# Trusted research constructor; complete typed graph + exact physical plan.
# Produces no acceptance/eligibility result for untrusted certificates.

encode_hand_derivation(derivation) -> EncodedHandArtifact
# Exact canonical experimental schema; reconcile with C3 before production freeze.

enumerate_work(derivation, accounting_spec) -> WorkLedger
# Reachable operations/pairs, references, widths, category subtotals, owner IDs.

bound_hand_family(outline, source_envelope, accounting_spec) -> BoundReport
# Finite constructor recurrence and integer-width/byte derivation.
# Every bound references actual rows/call sites and a proved envelope lemma.

run_feasibility() -> FeasibilityReceipt
# Retains provisional blocked outcome. Independent tracked gate is authoritative.
```

A `HandDerivation` should retain plan/source identities, concrete tables, semantic obligation-to-row mapping, the exact construction trace, scope/ownership edges, and no `source_correct=True`/`proof_complete=True` shortcuts. Completeness is a separately audited coverage claim with all missing obligations listed; a Boolean derived by the constructor cannot approve itself. `BoundReport` distinguishes measured bytes/counts, analytical bounds, unproved assumptions, unresolved obligations, and the artifact identities from which it was derived. On any missing row or unbounded algorithm step it is incomplete, not “within budget”.

Suggested sequential tasks and review boundaries:

1. **F1a, contract:** write concrete schema, scoped closure semantics, complete row-level inference expansion and fixed accounting policy. Independently enumerate obligations from the normative theorem/rules. Review before using counts.
2. **F1b, construction:** build all three fully linked graphs and exact bytes; retain annotated graphs/CSV or JSON row inventories. Check physical coverage, scope linkage, all source reconstructions and ownership. No guessed row reservations.
3. **F1c, work:** implement charged primitives and enumerate actual reachable pairs/keys; audit source phase and derive the finite numerical/source envelope bound. Any failure keeps the gate blocked. Do not substitute a larger default work limit to get green tests.
4. **F1d, adversarial evidence:** attack graph linkage, closure/scope sharing and accounting categories, run normal and optimized research suites, reconcile every obligation with exact rows and test evidence. Keep unsupported future-decoder controls explicitly pending C3–C5.
5. **F1e, acceptance:** fresh independent reviewer reads immutable artifacts, complete expansion/cost argument and logs. Reviewer must not be this design adviser or an implementer. Controller records exact commit and all affected artifact hashes in the tracked gate; if the approved artifact set expands beyond three files, explicitly update its identity-binding contract and include fixtures/helpers, not just the old three hashes. Research receipt still cannot self-activate.
6. Only after positive gate review, implement the single production region/proof checker through C4/C5 with generic hand-authored controls, then C6 onward. No early native execution claim follows from F1.

C3 grammar/codec work may overlap the research phase, but shared schema edits have one owner and a reconciliation checkpoint. Prefer completing the narrow F1 gate first over simultaneously creating a research verifier and a production verifier with diverging rules.

## 6. Adversarial controls that matter to this design

Graph/semantic expansion controls:

- Remove a physical dead operation or insert an overflowing dead add; change order or duplicate a transition; ensure the independent operation spine detects omission/multiplicity/state disconnect.
- Reset only an inner ledger, lose an incoming framed write in loop base, or hide a staging output store; the entire base/step/exit state must fail equality/conservation.
- Skip producer-to-consumer or refill-to-consumer linkage; omit a base, change successor to I(k), reference an inner hypothesis after discharge, or reuse an effectful state transition across branches.
- Capture a source formal with a same-spelled plan or region binder; mutate a substitution source/target scope; let a closure root contain a free binder absent from the recorded free-variable set.
- Change scalar association or a coordinate, forge an origin at a UTF-8 interior byte, alter one scratch fact's value closure, or join equal domains with incompatible values/maps.
- Omit/duplicate one parity case, import a case lemma into the other case without its assumption, preserve an overlapping old target row, alias slots, or shorten a staged row by one column.

Accounting/representation controls:

- Deliberately expand closure values at every region; the actual term/key inventory must change, not remain a hard-coded 55.
- Use a diamond/shared-expression DAG and overlapping substitutions; lookup/work grows with reachable nodes/pairs, not expanded trees. Restricting environments must not erase differing free variables.
- Force intern-key collision/equal-prefix traversal; charge the full exact comparison. A root ID from another table is never sufficient equality.
- Remove one work event at each independently listed call-site family; the reconciliation manifest detects the omission even if an implementation dictionary loses its corresponding category.
- Exact limit/limit+1 controls for bytes, nodes, affine width, intermediate integer width, and work, including cache-hit/reference checks. Charges occur before the work/allocation; exhaustion is incomplete unknown.
- Source extremes: accepted repeated constraints with varying digit lengths, maximal legal wrappers, long identifiers and comments/whitespace; graph semantics remains the same but source/identity charges increase.
- Verify integer lower-bound cost at -2**31, largest profile addresses/capacity, zero/single-trip synthetic proof fragments, and unreachable parity scope nonescape.

Do not claim these are production hostile-decoder or arbitrary-candidate semantic tests when they exercise only research constructors/local lemmas. C3/C4/C5 own those later. The complete C1 evidence can consist of instantiated derivations plus their written rule-expansion and cost proofs; implementing a public acceptance API is unnecessary.

## 7. Alternatives and explicit failure path

1. **Recommended: shared open values + explicit graph + cost proof.** Smallest semantic change: the written rules already allow term DAGs, quantified region values, pure lemma sharing and capture-free substitution. New work is making those semantics and their complete encoding concrete. Main risk is accidental scope/effect sharing; the controls above address it.
2. **Fully materialized scalar instances with exact memoization.** Simpler conceptual codec but more repeated source terms/substitutions and potentially much larger cost. It might still fit with actual reachable pairs and operation-specific arithmetic; do not rule it out using 8.8M. Use it only if its completed measured/envelope ledger fits unchanged quotas; it is a useful independent counting cross-check.
3. **Pure written expansion without constructed artifacts.** Allowed by F1, but prone to repeating the reserved-slot problem. If chosen, enumerate every row/field/reference by formula, prove the constructor recurrence and canonical length exactly, and give a complete checker call-site count. For this small graph, emitting the tables is easier to audit.
4. **SMT proof objects or polyhedral engine.** No identified affine obligation needs them; they add encoding/checking costs and do not solve ledger ownership, source equality or scope. No solver success bit is admissible. Reconsider only for a precise unsupported relation beyond the present rules.
5. **Compressed proof macros.** A general induction/sequence rule is legitimate with explicit checked premises. A schedule-specific macro that accepts a stencil label is not. If a larger macro hides rule expansion or suppresses charged work, it does not resolve F1.

If the completed bound exceeds 1,000,000, first report the exact category/call-site and whether it is an upper bound or a certified lower bound. A decisive impossibility claim needs a lower bound on required work for the chosen fixed algorithm/encoding, or a contradiction in a mandatory quota; a conservative upper bound alone is not decisive. Derive which required actual operations exceed the budget and retain a minimal reproducer/complete ledger.

The narrowest redesign, if genuinely necessary, is an explicitly reviewed change to the **v2 representation/check algorithm** that removes redundant expansion or comparisons while preserving all checks. If the problem is instead an accounting ambiguity, resolve and version the accounting policy explicitly; do not relabel previously charged work as free. Only if neither suffices should the user be shown an explicit versioned quota/profile change proposal with before/after bounds and compatibility impact. Do not implement widened quotas, restricted sources, unrolled proofs, or planner-template trust as a quiet fix. Nothing inspected here establishes that a quota/profile change is necessary.

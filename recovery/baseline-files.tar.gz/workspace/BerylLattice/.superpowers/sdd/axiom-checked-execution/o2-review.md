# Independent O2 specification and quality review

Reviewed checkpoint: `eeb8f2c8e247d42abc73c6727ddfed57ab99a1d9`.
Base: `eabd3098d85427bdad906b79a98aea723d3235df`.
Reviewer: fresh `review_source_oracle` agent, independent of O2 implementation and design advice.

**SPEC verdict: APPROVED for the O2 continuation contract.** No blocking specification defect found.

**QUALITY verdict: APPROVED within the documented stable-file, cooperative-control research boundary.** No blocking implementation defect found. This review is not O3 qualification, native correctness, performance qualification, or acceptance of any proof/checker work.

## Immutable scope and method

The exact base-to-checkpoint diff adds only these three files (1,433 lines):

| File | SHA-256 |
| --- | --- |
| `axiom/research/source_oracle.py` | `a29677691160c2f9b19fa580f47429760ca647d9ff0d7340d66ea07a35dbcb8f` |
| `axiom/research/tests/test_source_oracle.py` | `8544cec5d9c7e7c10320150b1672cb7e0f62a2e341684d5986abb9387e37a49d` |
| `axiom/research/protocol/source-oracle-v1.md` | `e68b8137a01c227f05951eaff8f9071b2f15e5cdbdd5c11dbf132b195e0b3b05` |

I read the reviewed continuation spec/plan at the base, master task O2 and its global constraints, the complete three-file change, and the actual model/C2/O1/state APIs. I checked the implementation report only after preparing my own contract review. For execution I exported `git archive eeb8f2c8e247d42abc73c6727ddfed57ab99a1d9 axiom` into `/tmp/o2-independent-review-k_6refb2`; concurrent untracked P1 files were absent. The owned working files still matched the pinned hashes at the end. No product edits, commits, native runs, large runs, subagents, or dependency changes were made by this reviewer.

## Independent contract assessment

| Obligation | Evidence and assessment |
| --- | --- |
| Original-source execution and independence | `_evaluate_expression` visits retained literal/name/group/binary/read/index nodes, charges before dispatch, evaluates left before right and indices in order, and checks every result as i32. `_iter_output` interprets declaration values, dimensions and axis bounds; `_ProducerTensor` binds the actual declaration's axis names and revisits its body. There is no hard-coded stencil evaluator or optimized expression DAG. Direct imports are limited to model/profile/invocation/state and standard library; the clean subprocess import guard passed. Shared frontend admission remains declared trusted base. |
| Complete preflight before equations | `_copy_input` traverses O1 publicly, hashes/counts actual acquired bytes, snapshots them, handles split i32 values with at most three carry bytes, checks every scalar, and retains the earliest failure. Equation/declaration evaluation is lazy and starts only after this routine completes. Invalid-input visitor guards, all invalid positions/extrema, full preflight counts and all nonzero canaries passed. |
| Full state and identities | Success streams every input and output scalar; rejection streams every original input and initial-output scalar. State metadata uses specialization semantics, compares the explicit state-v1 invocation mapping, and retains separate exact-source/v2 identities. Renaming/grouping controls and full 32x32 zero/max state controls passed. Complete state never follows an operational error. |
| Strict public boundary | Exact OracleLimits/SourceProfileV2/VerifiedInvocation types are checked; nested ArtifactLimits are revalidated and cannot widen any ceiling. O1 revalidation checks forged nested invocation/blob records and current actual files. Invalid configuration raises rather than becoming an input rejection. Deadline integers, cancellation bool results and result optional-field/counter invariants have controls. |
| Bounded source execution | Work is charged before each original AST dispatch, including groups and lazy producer rereads. Exact measured fuel succeeds and one less stops incomplete without overrun. Producer/output tensors are not retained; coordinate traversal uses rank-sized recursion. The narrow positive live-producer family justifies lazy evaluation; this is not an unrestricted interpreter. |
| Snapshot/cache bound | The private anonymous descriptor is the repeated-read source. Cache chunks are aligned; at most two are retained; eviction precedes allocation; `pread` length is checked. Tiny/minimum caches, eviction, first/last cells and short reads passed. Separate transport/decoding/preservation buffers and opaque passes are explicitly excluded from the cache-payload claim, which is not an RSS claim. |
| Quotas before acquisition/writes | `_reserve_payload` precedes destination/snapshot creation and input acquisition. It reserves snapshot plus full input/output plus maximum manifest without deduplication. It projects chunk count plus manifest, actual individual lengths, longest status/index metadata, exact item counts, depth, logical/aggregate/file bounds, and the state writer's additional admission bound. Independent exact-boundary and minus-one controls below confirmed the projection. O1 entry verification is disclosed earlier opaque boundary work. |
| Failure distinctions | Unsupported source, invalid invocation, work, cancellation, timeout, resource, allocation and I/O outcomes remain distinct. Only the two semantic outcomes carry manifests; only input rejection carries a bad index. Explicit revalidation errors are classified by boundary phase, subsequent helper errors by artifact phase, with wrapped ENOSPC/EDQUOT/EFBIG preserved as resource failure. Interpreter ValueErrors are protected from helper-error translation; unrelated programmer errors propagate through cleanup. |
| Cooperative controls | Polls cover entry, pre/post O1 verification, reservation, acquisition/preflight, expression dispatch, reads, preservation/emission and final prepublication. The specification and protocol disclose uninterruptible parser/O1/state/OS passes and do not promise hard deadlines. Early/mid-preflight/mid-output/prepublish cancellation and expired deadline tests passed. |
| Ownership and publication | Ancestor opens are NOFOLLOW and descriptor-relative; destination creation is exclusive; ancestors are not created. Owned partial state stays under `.pending`. Complete state is verified, original invocation revalidated, result allocated and snapshot closed before the final poll and atomic rename. No fallible semantic verification or poll follows publication. Existing destinations and symlink ancestors are preserved/rejected. Independent fault probes verified all owned open/mkdir failures, rename failure and snapshot-close failure without fd growth or completed output. |
| Scope and reporting | Protocol separates local counters from O5 campaign accounting, logical temporary payload from physical storage reservation, and O2 result from qualification authority. No source/reference admission widening or O3/native qualification claim is introduced. |

## Fresh execution evidence

All commands below ran in the isolated archive, not solely from owner logs. All exited zero, with no skipped tests in these selected suites.

From the archive's `axiom/` directory:

```sh
PYTHONPATH=src:research python -m unittest discover -s research/tests -p 'test_source_oracle.py' -v
PYTHONPATH=src:research python -O -m unittest discover -s research/tests -p 'test_source_oracle.py' -v
PYTHONPATH=src:research python -m unittest tests.test_reference tests.test_source_profiles tests.test_artifact_chunks_v2 tests.test_invocation_v2 research.tests.test_state -v
PYTHONPATH=src:research python -O -m unittest tests.test_reference tests.test_source_profiles tests.test_artifact_chunks_v2 tests.test_invocation_v2 research.tests.test_state -v
```

Results: **29/29 O2** normally and under `-O`; **51/51 dependencies** normally and under `-O`. Logs: `o2-review-normal.log`, `o2-review-optimized.log`, `o2-review-dependencies-normal.log`, `o2-review-dependencies-optimized.log`.

From the archive's `axiom/research/` directory:

```sh
PYTHONPATH=.:../src python -m unittest discover -s tests -p 'test_source_oracle.py' -v
PYTHONPATH=.:../src python -O -m unittest discover -s tests -p 'test_source_oracle.py' -v
```

Results: **29/29** in each mode. Logs: `o2-review-research-normal.log`, `o2-review-research-optimized.log`.

I also wrote and actually executed an independent probe using explicit checks that remain active under `-O`: **29 checks passed normally and 29 under `-O`**. Exact source and output are retained in `o2-review-extra.log`; optimized output is in `o2-review-extra-optimized.log`. Run from the isolated `axiom/` directory with `PYTHONPATH=.:src:research python ../extra_review.py` and the same command using `python -O`.

The probe independently derived a rejected 1x1 state's actual 911-byte manifest and 47 JSON items, then simultaneously tightened metadata size/items/depth, file size/count, logical/aggregate bytes, cache, input snapshot and temporary payload to exact valid values. The result completed and preserved the nonzero output canary. Reducing each operational quota by one rejected before `_copy_input` or destination creation. It separately injected rename failure, snapshot-close failure, postcommit descriptor-close errors, every O2-owned ancestor/destination open failure and both mkdir failures, checking cleanup and `/proc/self/fd` sets. Postcommit close errors left the completed semantic result intact.

## Findings and limits

There are **no requested fixes and no blocking findings** against these three O2 files. Adding the independent exact-boundary/publication-fault probes to the permanent suite would improve future regression protection; their successful execution is retained here and is not a condition on this approval.

Existing dependency limitations are not new O2 defects: state-v1 enforces several closure quotas late, so O2's own conservative preflight is necessary; O1/state helpers perform extra opaque traversals and can wrap OS errors; their path model does not isolate hostile same-UID mutation. Cleanup is deliberately best effort when the filesystem refuses removal or close. An injected refusal of the cleanup helper's own open can consequently leave staging, consistent with the explicit protocol limitation; this does not produce a completed manifest. Successful fd-path controls used failures in O2-owned construction/publication operations while allowing cleanup itself to run.

This evidence establishes the reviewed O2 boundary for the supported family. It does not establish unrestricted source semantics, hard real-time deadlines, physical disk/RSS reservation, large-shape throughput, an O3 trust anchor, a native execution result, or any C1/proof acceptance.

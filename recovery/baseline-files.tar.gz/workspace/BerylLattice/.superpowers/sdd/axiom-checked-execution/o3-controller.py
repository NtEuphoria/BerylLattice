"""Controller evidence preparation only: never creates or selects an approval.

Copy this exact reviewed script into a cache-free immutable archive's
axiom/qualification-controls/ before freezing that evidence subject. Runtime
inventory, real test runs and their inputs are retained in separate phases.
An independent review and explicit controller approval selection come later.
"""
import sys
sys.dont_write_bytecode = True

import argparse
from dataclasses import asdict
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import subprocess
import tempfile
import time


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_blocks(path):
    with path.open('rb') as stream:
        while block := stream.read(65536):
            yield block


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('phase', choices=('inventory', 'tests', 'check-subject'))
    parser.add_argument('--repository', required=True, type=Path)
    parser.add_argument('--evidence', required=True, type=Path)
    parser.add_argument('--commit', required=True)
    args = parser.parse_args()
    repository = args.repository.resolve(strict=True)
    evidence = args.evidence.absolute()
    controller = Path(__file__).resolve(strict=True)
    if not controller.is_relative_to(repository):
        raise ValueError('run the retained controller copy inside the archive')
    if not re.fullmatch('[0-9a-f]{40}', args.commit):
        raise ValueError('a full immutable source commit is required')
    if any(repository.rglob('*.pyc')) or any(repository.rglob('*.pyo')):
        raise ValueError('repository subject must genuinely be cache-free')
    sys.path[:0] = [str(repository/'src'), str(repository/'research')]
    import oracle_receipt as api
    import source_oracle
    from axiom import artifact_chunks_v2 as blobs
    from axiom.invocation_v2 import InvocationLimits, write_invocation, verify_invocation
    from axiom.source_profiles import SourceProfileV2

    roots = (
        api.OracleLiveRoot('repository', repository),
        api.OracleLiveRoot('python', Path(sys.executable).resolve().parents[1]),
        api.OracleLiveRoot('system', Path('/usr/lib').resolve(strict=True)),
    )

    def logical(path):
        for root in roots:
            if path.is_relative_to(root.directory):
                return root.name+'/'+path.relative_to(root.directory).as_posix()
        raise ValueError('actual runtime/evidence file has no selected live root: '+str(path))

    def document(name, value):
        raw = blobs.canonical_json(value)
        with (evidence/name).open('xb') as stream:
            stream.write(raw)
        return dict(path=name, sha256=digest(raw), byte_length=len(raw))

    def blob(name, path):
        ref = blobs.write_blob(file_blocks(path), path.stat().st_size,
                               evidence/name, limits=blobs.BlobLimits())
        return dict(path=ref.manifest_path.relative_to(evidence).as_posix(),
                    manifest_sha256=ref.manifest_sha256,
                    sha256=ref.sha256, byte_length=ref.byte_length)

    # This same tiny prelude is used for each observation phase and later live
    # controls. It discovers lazy execution imports without granting authority.
    source = b'''module disclosed;
shape H = 1; shape W = 1;
input image: i32[H+1,W+1] in 0..=1023;
let p[r in 0..H+1,c in 0..W+1] = (image[r,c]+1)*(image[r,c]+1);
output result[r in 0..H,c in 0..W] = ((p[r,c]+p[r,c+1])+p[r+1,c])+p[r+1,c+1];
'''
    prelude = []
    with tempfile.TemporaryDirectory(prefix='axiom-o3-controller-prelude-') as temporary:
        root = Path(temporary)
        for index, values in enumerate(((0, 1, 2, 3), (0, 1024, 2, 3))):
            manifest = write_invocation(source, [struct.pack('<4i', *values)],
                [struct.pack('<i', 17)], root/f'invocation-{index}',
                profile=SourceProfileV2(), limits=InvocationLimits())
            invocation = verify_invocation(manifest, limits=InvocationLimits())
            result = source_oracle.evaluate_source_state(source, invocation,
                root/f'candidate-{index}', profile=SourceProfileV2(),
                limits=source_oracle.OracleLimits())
            expected = 'success' if index == 0 else 'input_precondition_failed'
            if result.status != expected:
                raise ValueError('disclosed import prelude failed: '+result.status)
            prelude.append(dict(status=result.status, first_bad_index=result.first_bad_index))

    runtime = api._runtime_paths()
    if args.phase == 'inventory':
        evidence.mkdir(mode=0o700)
        inventory = []
        for index, (path, role) in enumerate(sorted(runtime.items())):
            inventory.append(dict(role=role, logical_path=logical(path),
                blob=blob(f'inventory/{index}', path)))
        inventory.sort(key=lambda item: item['logical_path'])
        trusted = document('trusted-base.json', dict(
            schema='axiom-oracle-trusted-base-v1', assumptions=[
                'Trusted fresh CPython process, honest loaded code, operating system and stable files.',
                'Shared reviewed parser/model/v2 admission, invocation/blob and state primitives.',
                'Explicit independent review and controller-selected approval root; serialized claims grant no authority.',
                'Cooperative cancellation, logical payload quotas and no hostile same-UID races or reflection.',
                'Repository is an immutable Git archive with this separately retained controller; bytecode writes disabled before imports and in children.',
            ]))
        subject = document('qualification.json', dict(
            schema='axiom-oracle-qualification-v1',
            entrypoint='source_oracle.evaluate_source_state',
            runtime_assumption='trusted-fresh-python-in-process-v1',
            source_profile=asdict(SourceProfileV2()), versions=api._VERSIONS,
            python=dict(implementation=sys.implementation.name,
                        version=list(sys.version_info[:3]),
                        executable_logical_path=logical(Path(sys.executable).resolve())),
            inventory=inventory, trusted_base=trusted))
        # These are the reviewed three-suite sources, imported helpers,
        # independent comparator, fixture, protocol and actual controller.
        inputs = (
            ('test_source', 'research/tests/__init__.py'),
            ('test_source', 'research/tests/test_oracle_receipts.py'),
            ('test_source', 'research/tests/test_source_oracle.py'),
            ('test_source', 'research/tests/test_receipts.py'),
            ('test_source', 'research/tests/test_manifest.py'),
            ('test_source', 'research/experiment_manifest.py'),
            ('test_source', 'research/receipt_admission.py'),
            ('test_comparator', 'src/axiom/reference.py'),
            ('fixture', 'tests/fixtures/inputs/boundary_cases.json'),
            ('protocol', 'research/protocol/source-oracle-v1.md'),
            ('test_source', controller.relative_to(repository).as_posix()),
        )
        retained = []
        for index, (role, relative) in enumerate(inputs):
            path = repository/relative
            retained.append(dict(role=role, logical_path=logical(path),
                                  blob=blob(f'test-inputs/{index}', path)))
        retained.sort(key=lambda item: item['logical_path'])
        observation = dict(commit=args.commit, qualification=subject,
            repository=str(repository), controller_sha256=digest(controller.read_bytes()),
            live_roots={root.name: str(root.directory) for root in roots},
            prelude=prelude, test_inputs=retained,
            runtime_files=len(runtime), runtime_bytes=sum(p.stat().st_size for p in runtime),
            approved=False)
        document('subject-observation.json', observation)
        print(json.dumps(dict(phase='inventory', qualification_sha256=subject['sha256'],
                              runtime_files=len(runtime), approved=False)), flush=True)
        return

    observation = json.loads((evidence/'subject-observation.json').read_bytes())
    subject_raw = (evidence/'qualification.json').read_bytes()
    if (observation['commit'] != args.commit or
        observation['repository'] != str(repository) or
        observation['controller_sha256'] != digest(controller.read_bytes()) or
        observation['qualification']['sha256'] != digest(subject_raw)):
        raise ValueError('subject/controller identity changed')
    subject = json.loads(subject_raw)
    by_logical = {logical(path): (path, role) for path, role in runtime.items()}
    if {i['logical_path']: i['role'] for i in subject['inventory']} != {
            name: pair[1] for name, pair in by_logical.items()}:
        raise ValueError('actual runtime paths/roles changed')

    def check_files():
        for item in subject['inventory']:
            path = by_logical[item['logical_path']][0]
            if api._hash_live(path, item['blob']['byte_length']) != item['blob']['sha256']:
                raise ValueError('runtime subject bytes changed')
        for item in observation['test_inputs']:
            prefix, relative = item['logical_path'].split('/', 1)
            if prefix != 'repository':
                raise ValueError('unexpected test-input root')
            path = repository/relative
            if api._hash_live(path, item['blob']['byte_length']) != item['blob']['sha256']:
                raise ValueError('test-input bytes changed')
        if any(repository.rglob('*.pyc')) or any(repository.rglob('*.pyo')):
            raise ValueError('repository bytecode appeared')

    check_files()
    if args.phase == 'check-subject':
        print(json.dumps(dict(phase='check-subject', unchanged=True, approved=False)), flush=True)
        return

    (evidence/'logs').mkdir()
    runs, observations = [], []
    for command, pattern in (('o3', 'test_oracle_receipts.py'),
                             ('source_oracle', 'test_source_oracle.py'),
                             ('synthetic_receipts', 'test_receipts.py')):
        for mode in ('normal', 'optimized'):
            argv = [sys.executable, '-S', '-B']
            if mode == 'optimized':
                argv.append('-O')
            argv += ['-m', 'unittest', 'discover', '-s', 'tests', '-t', '.', '-p', pattern, '-v']
            environment = dict(os.environ)
            for key in ('PYTHONHOME', 'PYTHONSTARTUP', 'PYTHONINSPECT', 'PYTHONOPTIMIZE'):
                environment.pop(key, None)
            environment.update(PYTHONDONTWRITEBYTECODE='1',
                PYTHONPATH=str(repository/'src')+os.pathsep+str(repository/'research'))
            cwd = repository/'research'
            log = evidence/'logs'/f'{command}-{mode}.log'
            header = dict(argv=argv, cwd=str(cwd),
                env={key: environment[key] for key in ('PYTHONDONTWRITEBYTECODE', 'PYTHONPATH')},
                qualification_sha256=observation['qualification']['sha256'])
            print(json.dumps(dict(starting=command, mode=mode)), flush=True)
            started = time.monotonic()
            with log.open('xb') as stream:
                stream.write((json.dumps(header, sort_keys=True)+'\n').encode())
                stream.flush()
                result = subprocess.run(argv, cwd=cwd, env=environment,
                    stdout=stream, stderr=subprocess.STDOUT, timeout=360)
            raw = log.read_text()
            count = re.findall(r'^Ran ([0-9]+) tests? in ', raw, re.MULTILINE)
            # Every required case must execute successfully for this controller
            # package. Retain any failure log and do not create passing evidence.
            if result.returncode or len(count) != 1 or not raw.rstrip().endswith('\nOK'):
                raise ValueError(f'required suite did not pass cleanly: {command}/{mode}')
            tests = int(count[0])
            if tests <= 0 or re.search(r'\.\.\. (skipped|expected failure|unexpected success)', raw):
                raise ValueError('required suite contains an unqualified outcome')
            retained_log = blob(f'run-logs/{command}-{mode}', log)
            run = dict(command_id=command, argv=argv, mode=mode, tests=tests,
                passed=tests, failed=0, errors=0, skipped=0, exit_code=result.returncode,
                log=retained_log)
            runs.append(run)
            observations.append(dict(**header, command_id=command, mode=mode,
                tests=tests, elapsed_seconds=time.monotonic()-started,
                exit_code=result.returncode, log_sha256=digest(log.read_bytes())))
            check_files()
            print(json.dumps(dict(completed=command, mode=mode, tests=tests)), flush=True)
    test_evidence = document('tests.json', dict(schema='axiom-oracle-tests-v1',
        qualification_sha256=observation['qualification']['sha256'],
        inputs=observation['test_inputs'], runs=runs))
    document('test-observation.json', dict(runs=observations, test_evidence=test_evidence,
                                          approved=False))
    print(json.dumps(dict(phase='tests', test_evidence_sha256=test_evidence['sha256'],
                          approved=False)), flush=True)


if __name__ == '__main__':
    main()

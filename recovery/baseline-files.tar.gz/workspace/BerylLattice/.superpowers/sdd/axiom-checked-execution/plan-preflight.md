# Continuation plan independent preflight

Reviewer: `/root/review_continuation_plan`, 2026-10-16. Read-only review against repository baseline `2e827dacf2b6ece9640df7abdf43a74892d9fc9f`; only this report is written. No product edit, test execution, native execution, commit, or delegated review was performed.

**Verdict: PASS for implementation dispatch. No blocking contradiction or missing prerequisite was identified.** This approves the plan's consistency, not mathematical C1 feasibility, O2 correctness, a production checker, or any downstream gate. The existing C1/F1 outcome remains blocked.

Reviewed final continuation snapshots, including the controller's R1 clarification verified below:

| Document | SHA-256 |
|---|---|
| `docs/superpowers/specs/2026-10-16-axiom-proof-oracle-continuation-design.md` | `e61cf3915e07265eacb8ccc6da6db219860e6e251556f1963a8213e3e19db474` |
| `docs/superpowers/plans/2026-10-16-axiom-proof-oracle-continuation.md` | `68e12cd713aa740882b54dac8aea22b4b984130ef78e9730d302df88712557ad` |

The review also read the two retained design-advice reports; master README gates, ownership, and I1; master plan 02 source/IR/proof contracts and C1–C11 requirements; master plan 03 O1–O6; the existing `loop-plan-v2.md` rule argument and F1 appendix; the tracked C1 gate; and relevant source-profile, invocation, blob, feasibility, and state-artifact APIs. The master remains authoritative. The cloud setup skill was consulted; this review needs no environment change.

## Task consistency table

| Task | Inputs and ownership | Output, failures, and checks | Disposition |
|---|---|---|---|
| P0 | Both advice reports, continuation documents, master contracts; controller owns plan/spec and progress. | Fresh task/interface table, resolved concrete findings, retained ignored evidence; only plan/spec committed. | Consistent. This report supplies independent preflight, not C1 acceptance. No additional user approval is required. |
| P1 | Accepted immutable C2 and written general rules; owns only listed research helpers, manifest, tests, feasibility probe and proof document. | Concrete ordered graphs and exact bytes; independent obligation map; complete work and finite envelope argument; both normal and optimized `test_loop_proof*.py` discovery. Unproved bound or missing premise remains F1 blocked. | Consistent. Actual graph rows, transient states, both parity branches, source origins, ledger conservation and all quota categories are required. Proposed 31/34/55 scalar counts cannot be accepted as total proof counts. |
| O2 | Fresh source bytes, revalidated O1 invocation, C2 profile, explicit limits; three owned research files only. | Independent original-AST streaming state; distinct complete/incomplete outcomes; normal/optimized oracle tests and source/reference/blob/invocation/state regressions. Full preflight precedes any equation work. | Consistent. Snapshot/cache avoids producer/output tensors while preserving original association. See guardrail R1 for existing state-writer quota behavior. |
| P2 | Immutable P1 checkpoint plus complete artifact closure and argument. Controller owns tracked gate; fresh reviewer is neither adviser nor implementer. | Independent completeness/accounting decision; exact hashes, command evidence and precise unresolved findings. Only controller records reviewed `proceed`; tests alone cannot activate it. | Consistent. Existing `run_feasibility()` remains a provisional research boundary and is not an executable self-approval path. |
| O2R | Immutable O2 implementation/test/protocol snapshot. Fresh independent reviewer owns report; fixes return to O2 owner. | Semantic/dependency/resource/publication/quality review and affected reruns; complete O2 does not confer O3 qualification. | Consistent. Review must examine injected failure paths as well as small numerical equality. |
| I0 | P2 disposition, including a possible explicit blocked outcome, and O2R disposition; controller owns integration documentation and recovery notes. | Combined regressions, unchanged v1/Core checks, immutable reviewed commits, bundle and changed-file restoration, explicit actual/blocked evidence. | Consistent. A completed review task with a blocked C1 result can be recorded/recovered; it does not open downstream proof/native work. Do not interpret the dependency row as requiring C1 positivity merely to preserve useful O2 work. |
| Downstream | Positive required master gates and exact master task ownership. | C3 schema reconciliation, C4/C5 rules/checker, C6 independent bridge, C8–C11, B4–B7, O3–O6 and I1 retain original tests/reviews. C7 promotion remains optional and separate. | Consistent. C1 blockage stops C4–C11; O2/O3 work can continue. B7/O6 share the single 118-call G3 campaign; throughput and graph sizes do not qualify measurement/publication. |

## Shared files and interfaces: task-pair table

Every pair among the six implementation/review/integration/downstream roles is listed, including pairs that intentionally share no writable surface.

| Pair | Shared surface or dependency | Consistency / required handoff |
|---|---|---|
| P1 / O2 | Read-only C2 frontend/model/profile semantics and identities. | Disjoint write ownership. P1 uses reconstructed ordered terms for proof; O2 executes original AST nodes. Neither may change shared admission or use the other's computed results as semantic authority. |
| P1 / P2 | Research graph/cost/fixture/probe/tests and `axiom/docs/loop-plan-v2.md`; gate in `docs/reviews/loop-proof-feasibility.md`. | P1 produces immutable artifacts; P2 reviews all new helpers/fixtures and relevant audited dependency identities. Controller alone edits the gate. Any later change to approved non-review artifacts invalidates the approval. |
| P1 / O2R | Shared read-only source/profile trusted base. | No writable overlap or approval substitution. O2R may identify pre-existing dependency limitations without expanding O2 ownership or approving P1. |
| P1 / I0 | P1 code, exact hashes, focused logs, final proof document. | Controller serializes integration and commits. I0 must preserve blocked findings and distinguish constructed evidence from accepted proof feasibility. |
| P1 / downstream | Experimental proof grammar/cost model and shared `loop-plan-v2.md`; later C3/C4/C5 consumers. | Positive P2 precedes C4–C11. C3 explicitly reconciles experimental encoding with strict production records/codecs; research constructors confer no arbitrary-candidate eligibility. Shared document edits must be serial. |
| O2 / P2 | Immutable source/profile dependency only. | No direct implementation or approval coupling. P2 cannot treat oracle success as proof or approve O2 by passing C1. |
| O2 / O2R | `source_oracle.py`, its tests and protocol; source/input/state dependencies. | Reviewer receives immutable checkpoint, independently checks semantics/resources/publication, returns fixes to the same owner and reruns affected checks. |
| O2 / I0 | Oracle code/protocol, full-state tests, failure controls and disclosed timing/counters. | Controller records actual outcomes and opaque helper passes. Local counters must not be relabeled complete campaign I/O. |
| O2 / downstream | `OracleLimits`, `OracleResult`, exact-source and semantic identities, `source-oracle-v1.md`. | O3 alone extends protocol with qualified receipts/selected trust anchors. O5 needs its own actual acquisition/comparison accounting; O2 success records cannot stand in for native execution. |
| P2 / O2R | Separate review records and immutable checkpoints. | Independent decisions; neither reviewer may use the other's PASS as evidence for its own obligation. No shared writable product file. |
| P2 / I0 | Tracked C1 gate and exact review/hash closure. | Controller integrates the actual review decision; reviewed code must remain byte-identical. I0 may retain a blocked checkpoint, but cannot set proceed itself. |
| P2 / downstream | C1 go/no-go record and approved rules/accounting. | Positive decision opens the declared proof-dependent work, not native correctness or measurement automatically. Changed proof artifacts require renewed review. |
| O2R / I0 | Oracle review, addressed findings and rerun logs. | I0 retains reviewed implementation identity and distinguishes reviewed O2 from later O3 qualification. |
| O2R / downstream | Reviewed oracle boundary and trusted-base statement. | O3 qualification still binds exact code/runtime/tests/review; native or proof receipts cannot replace source execution. |
| I0 / downstream | Implementation record, recoverable commits/evidence, master gates and shared documentation. | Preserve master ownership and dependency order; serialize shared schema changes. Native G3, measurement G4 and later publication chronology remain distinct. |

## Existing API boundary checks

| Boundary | Existing evidence and required interpretation | Result |
|---|---|---|
| C2 → P1/O2 | `admit_source_v2` retains original module and exact bytes and derives separate source/family/specialization identities; profile and source limits revalidate exact records. | Compatible. Fresh admission is explicit; no caller-supplied AST is trusted. P1's source-phase bound must audit actual frontend/profile algorithms and bind their identities. |
| O1 → O2 | `VerifiedInvocation.revalidate()` reconstructs invocation, compares exact source/blob metadata, and clears caches. `VerifiedBlob.iter_bytes()` revalidates then hashes actual yielded bytes. Generic chunks may split i32. | Compatible. Private snapshot is acquired only through public transport; carry bytes, length/hash checks, final invocation revalidation and mutation tests are required. |
| O1 → state-v1 | `state_v1_invocation_sha256()` defaults to specialization semantics and original input/initial-output hashes. | Compatible. StateMetadata uses specialization identity; exact-source v2 invocation remains a separate result field. |
| state artifacts → O2 | `write_state` writes chunks and manifest, then calls `verify_state`; failed generation/verification can leave partial artifacts. | Compatible only with planned private staging and prepublication verification. R1 makes pre-write tightened quota enforcement concrete. |
| Publication → caller/O3 | Fresh destination, private pending child, verified complete state, final invocation/deadline/cancellation checks, atomic rename to `completed`. | Compatible. Completion point is rename; postcommit cleanup cannot relabel committed state. Existing destinations remain untouched and incomplete results expose no completed-state handle. |

## Concrete guardrails and exact recommended clarifications

**R1 — preflight all tightened state ceilings before writes (addressed in the final plan/spec).** The plan already required enforcing these ceilings, but merely forwarding `state_limits` to `write_state` is insufficient. In `axiom/research/state_artifacts.py:423`, the writer preflights logical bytes and part of metadata capacity, then writes all chunks; file-count and aggregate checks occur only in final `verify_state`. A tiny `max_files` or `max_aggregate_bytes` can therefore be exceeded transiently before rejection.

Recommended clarification: “Before consuming streams or writing, preflight a conservative no-dedup chunk count plus one manifest, projected manifest bytes/items/depth, each file size, aggregate and logical state bytes against the tightened state limits. Do not rely on the writer's final verification to enforce a pre-write resource ceiling.” The controller incorporated this requirement in plan O2 step 3 (line 83) and spec temporary-quota paragraph (line 43); the reviewer read the actual amended text and verified the final document hashes above. The O2 owner can implement this without changing state-v1 or shared dependencies. Include zero-consumption/zero-payload-write checks for these insufficient reservations. Content-addressed sharing must not reduce the reservation.

**R2 — retain precise failure phase mapping (nonblocking implementation check).** The stated status set and planned protocol allow this without changing the master. Safe file helpers wrap some operating-system errors in `ValueError`; final `ValueError` cannot automatically mean invalid invocation. Document and test the exact bounded mapping: malformed/changed invocation at its trust boundary is `invalid_invocation`; operational write/read failure after valid admission is `io_failure` or the explicitly selected resource outcome; budget/metadata/file ceiling exhaustion is `resource_limit`; programmer exceptions must not become semantic rejection. Select and document a deterministic ENOSPC mapping. Do not broaden catch-all exception handlers to make failure tests pass.

**R3 — freeze positive C1 acceptance to the audited dependency closure (nonblocking implementation check).** P1c already requires source-algorithm identity binding and P2 requires all new helper/fixture hashes. Carry both through the gate: include the exact frontend/profile/model algorithms whose work was bounded, or bind an immutable repository commit that unambiguously covers them alongside explicit research artifact hashes. A helper-only hash table cannot justify an unchanged source-phase bound after frontend changes.

These are concrete ways to satisfy existing requirements, not new scope or an extra approval gate. No blocker requires stopping P1/O2 dispatch.

## Acceptance limits

The unchanged proof quotas, source-spelling envelope, all accepted source bytes, charged exact-key operations, actual state transitions, reachable substitutions and complete serialization remain research obligations to establish during P1. The reviewed plan does not show that they fit. The prior 8,814,588 estimate is explicitly conditional/loose and is not impossibility evidence. Both rows2 parity cases and induction scope discharge must be derived, not supplied by schedule labels.

O2's 97 MiB conservative envelope is a logical temporary payload reservation, not disk blocks, disk availability, or Python RSS. Full preflight on invalid input and preservation of every input/output scalar remain mandatory. Tiny bounded tests, dependency guards and mutation/failure injection can establish implementation evidence; they do not qualify O3 or complete G3. No fresh holdout or native timing campaign is authorized by this preflight.

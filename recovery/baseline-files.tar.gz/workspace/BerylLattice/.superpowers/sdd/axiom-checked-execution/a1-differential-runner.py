"""Execute one source implementation per interpreter; never mix live imports."""
import dataclasses
import hashlib
import json
from pathlib import Path
import sys

root, corpus, output = map(Path, sys.argv[1:])
sys.path.insert(0, str(root / 'axiom/src'))
from axiom.frontend import parse_source
from axiom.model import DiagnosticError
from axiom.source_profiles import SourceLimitsV2, SourceProfileV2, admit_source_v2


def freeze(value):
    if dataclasses.is_dataclass(value):
        return {'type': type(value).__name__, 'fields': [
            [field.name, freeze(getattr(value, field.name))]
            for field in dataclasses.fields(value)]}
    if isinstance(value, bytes):
        return {'bytes_hex': value.hex()}
    if isinstance(value, tuple):
        return [freeze(item) for item in value]
    return value


def digest(value):
    return hashlib.sha256(json.dumps(freeze(value), sort_keys=True,
                                   separators=(',', ':')).encode()).hexdigest()


results = []
for case in json.loads(corpus.read_text()):
    source = bytes.fromhex(case['source_hex'])
    try:
        admitted = admit_source_v2(source, profile=SourceProfileV2(), limits=SourceLimitsV2())
    except DiagnosticError as error:
        result = {'name': case['name'], 'status': 'rejected', 'code': error.code,
                  'span': dataclasses.asdict(error.span), 'message': error.message}
    else:
        result = {'name': case['name'], 'status': 'accepted',
                  'identities': {field: getattr(admitted, field) for field in (
                      'source_digest', 'family_digest', 'specialization_digest',
                      'constraint_digest', 'objective_digest')},
                  'height': admitted.height, 'width': admitted.width,
                  'cap': admitted.cap, 'objective': admitted.objective,
                  'input_interval': admitted.input_interval,
                  'original_ast_sha256': digest(parse_source(source)),
                  'retained_ast_sha256': digest(admitted.source_module),
                  'retained_source_hex': admitted.source_bytes.hex()}
    if result['status'] != case['expected']:
        raise RuntimeError(f'Unexpected outcome for {case["name"]}: {result["status"]}')
    results.append(result)
output.write_text(json.dumps(results, indent=2) + '\n')
print(f'{len(results)} source outcomes retained in {output}')

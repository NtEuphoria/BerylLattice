# A0 source-admission repair: independent plan preflight

Reviewer: `/root/review_continuation_plan`, 2026-10-16. Repository baseline at inspection: `d7e22c857ccf681cc94af9a1bfdf98282899b02c`. Read-only review; only this report is written. No implementation edits, tests, commits, subagents, A2 acceptance or C1 approval.

**Final verdict: PASS for the plan; no unresolved blocker.** The reviewer read the amended final repair plan and continuation table and verified their hashes below. The identified O3 dependency-inventory/ownership omission is resolved: A3 explicitly permits its existing owner to update `oracle_receipt.py`, bind the new helper and permitted bytecode, add omission/mutation controls, and obtain fresh dependency-closure review. This verdict is not implementation acceptance or C1 approval.

## Reviewed material and identities

Read the bounded-source plan, amended continuation task graph, both `source-name-bound-advice.md` and `source-admission-repair-advice.md`, unchanged frontend/model/source-profile APIs, relevant existing source-profile tests, and the live O3 inventory seam to assess the new dependency. The adviser reports are background, not acceptance evidence.

| Artifact | SHA-256 |
|---|---|
| Final repair plan | `61b11fc862cc9d59e0f2fefd625eda5c29d0b2e8bf5fbc7bc087a7c8b72b2655` |
| Continuation including explicit I0→A3 prerequisite | `4014e1f9b1b707d1c165f30c4c786eeb57932570b416cecd028c419bb72d251d` |
| Baseline `source_profiles.py` | `2d77a02746d815583b926ede83ef553e258fba4d442a12dd3f035c9c04fe9d43` |
| Baseline `frontend.py` | `2b6f291ce350fa32c1a09e64a0de425a3d02e9633535b13949fac1a8063afa71` |
| Baseline `model.py` | `dd45837debec9302a19d194d1fe8805176c902164f4432fc5391bcc274b96408` |

## Semantic preservation argument

An accepted source has exactly five global declaration roles (two shapes, input, producer, output) and four local axis roles. Its semantic name occurrences must resolve to those declarations or axes: `_constant` checks shape membership, `_interval` checks axes then shapes, `_validate_scalar` checks tensor membership and rejects bare scalar names. There can therefore be at most nine distinct semantic spellings. Module name, element type, constraint property and objective are not such bindings and must remain unchanged. Early count, grouped-literal-shape and rank-two checks are all necessary conditions for the existing canonical profile; moving them earlier cannot exclude a previously accepted source.

One global injective map preserves every equality/non-equality of spellings, including equality across nominal namespaces. Shared validation still supplies actual scope rules: axis bounds consult shapes, index expressions consult local axes before shapes, tensor reads consult tensors, and declaration uniqueness uses the global set. Global renaming therefore preserves duplicate detection, dependency order, undefined references, shadowing and tensor/index separation. Separate per-namespace renaming would not establish this argument and is correctly forbidden. A source name already equal to an internal alias poses no issue when every semantic occurrence is transformed consistently.

`_profile` emits canonical role labels by declaration/axis order, not user spelling. Its local shape-map copy plus axis update preserves shadowing under the global bijection; its tensor map remains separate. Consequently the normalized profile, H/W, family/specialization/constraint/objective identities remain unchanged for accepted inputs. Exact source identity continues to hash original bytes. Returning the original parsed module retains names, spans, groups, association, source origins and constraints; the transient view cannot become source-origin authority merely because its spans are original.

This is a plan-level argument conditional on faithful implementation. A2 must review actual rebuilding, equality and every name-bearing field and verify the differential controls. Passing samples alone is not the preservation proof.

## Task table

| Task | Inputs and ownership | Completion/failure evidence | Assessment |
|---|---|---|---|
| A0 repair preflight | Source-work gap, repair/advice documents, continuation graph; controller owns plan/table and reviewer owns ignored report. | Semantic preservation, actual algorithm/accounting boundary, task/interface ownership table. | Consistent. The identified dependency-inventory correction below is resolved; no implementation or C1 acceptance is issued. |
| A1 bounded adapter | A0; owns new `source_names_v2.py`, `source_profiles.py`, new adapter tests and additions to source-profile tests only. | Meaningful RED; boundary checks that only aliases reach shared validators; deterministic scan counts; old/new accepted identities and original AST; rejection/diagnostic and normal/optimized source/frontend tests. | Consistent. No shared frontend/model/v1 edits, public AST input or second semantic validator. Registry bounds and early guards are necessary admission conditions, not acceptance shortcuts. |
| A2 admission acceptance | Immutable A1 checkpoint and exact baseline comparison. Independent reviewer/report; controller acceptance record. | Independent SPEC/QUALITY, bijection/accepted-language reasoning, differential/adversarial evidence, exact unchanged frontend/model bytes and v1 controls. | Consistent. A2 accepts repaired C2 only; no author self-approval or implicit C1 proceed. |
| A3 dependency reconciliation | A2 plus actual P1/O3 readiness. P1 accounting files, O3 dependency inventory/tests/protocol, controller integration record. | New call-site/source bound, fresh O2/O3 and invocation/state regressions, exact new dependency identities before any qualification root. | Consistent after R1: final plan explicitly authorizes `oracle_receipt.py` inventory and controls under its existing owner. |

## All A0–A3 task-pair interfaces

| Pair | Shared surface | Contract and assessment |
|---|---|---|
| A0 / A1 | Approved plan, four-file implementation ownership, private adapter contract. | No user approval round is necessary. A1 receives explicit guards, global bijection, diagnostics and measurement obligations. Compatible. |
| A0 / A2 | Preservation criteria, baseline identities and independent report. | Plan review does not substitute for immutable implementation review. Compatible. |
| A0 / A3 | Continuation dependency graph and new admission module. | I0 explicitly depends on A3; final plan includes the exact O3 runtime-inventory handoff in R1. Compatible. |
| A1 / A2 | Adapter/source-profile code and tests, original bytes/AST and baseline differential results. | A2 checks all written files at one immutable checkpoint, including no original-name lookup leakage and no hidden second traversal. Compatible. |
| A1 / A3 | Actual adapter call sites and new dependency closure. | A3 uses the implemented algorithm/revision, not the former logical map-candidate graph. New source helper is a real O2/O3 execution dependency. R1 applies. |
| A2 / A3 | Accepted C2 revision and exact artifact hashes. | Later tests/qualification bind the new revision; prior O2/O3 acceptance remains historical and cannot be silently carried forward. Compatible. |

## Cross-workstream interfaces and ownership

| Pair | Shared interface/file | Contract and assessment |
|---|---|---|
| A1 / shared frontend | `_validate`, `_profile`, `_constant`, `_interval`, `_normalized`. | Unchanged helper bytes receive only fixed aliases in every semantic-name map. H/W extraction must use view declarations/short-key shapes. Original source strings cannot leak through categorized tuples or an extraction lookup. Compatible. |
| A1 / model/original AST | Immutable SourceModule and name-bearing node records. | Rebuild declarations once and derive categorized references from those rebuilt objects. Preserve original module separately; no mutation, reparse, normalization or source digest replacement. Compatible. |
| A1 / v1 | Shared frontend/model and old admission APIs. | No edits to their bytes or call path. Existing v1 identities/diagnostics/limits remain exact; baseline differential tests are isolated, not mixed live imports. Compatible. |
| A1 / P1 | Fresh C2 admission and research source reconstruction/accounting. | Disjoint writes but changing read dependency; P1 must bind actual A2 bytes, pay new view/scan work and any repeated original-name resolution. No inherited 270-edge/one-comparison-per-resident assumption. Compatible after A3 reconciliation. |
| A1 / O2 | O2 calls C2 admission and interprets retained original AST. | Original AST/value contract is preserved. O2 implementation stays unchanged, but relevant semantic/mutation/limit tests must rerun against new dependency. Historical 2048 execution stays pinned to its historical source. Compatible. |
| A1 / O3 | Loaded source admission helper and qualification inventory. | Live `_REPOSITORY_MODULES` is fixed and omits the new module; `_runtime_paths` derives repository files from it. R1 must add source/helper bytecode and missing/mutated-helper controls under O3 ownership. |
| A1 / O1 | Invocation fresh admission and source/family/specialization mapping. | Public signatures and identity payloads unchanged; rerun invocation tests so fresh admission/revalidation exercise new C2. Compatible. |
| A2 / P2 | Repaired C2 implementation and cost model identities. | A2 is not C1 mathematical approval. P2 separately reviews accepted/rejected-source accounting, all proof payloads and fixed quota fit. Compatible. |
| A2 / O3 review | New qualified dependency bytes and actual tests. | No production qualification root until source helper, O3 code and exact runtime closure are fixed and reviewed. Earlier tests cannot be relabeled new dependency evidence. Compatible with R1. |
| A3 / I0 | Integration/recovery record, combined test checkpoint and dependency hashes. | Amended I0 row explicitly requires A3. Controller serializes commits; disjoint writers still record the actual dependency snapshot used. Compatible. |

## R1: dependency-inventory/ownership correction — resolved

The live `axiom/research/oracle_receipt.py` defines `_REPOSITORY_MODULES` as a fixed tuple containing `axiom.source_profiles` but not future `axiom.source_names_v2`. `_runtime_paths()` inventories source and existing `__cached__` only for those repository modules. Adding the new source-admission module without updating this tuple would allow executed source-name code to be absent from the supposed complete qualified implementation closure.

The initial A3 row granted the O3 owner only its tests/protocol. The final plan applies the exact fix: its existing O3 owner updates the already-owned `oracle_receipt.py` inventory seam and tests/protocol, pins `axiom.source_names_v2` source and every permitted existing cache, adds omission/mutation rejection controls, and receives fresh dependency-closure review. Qualification/test/review identities are rebuilt only after the dependency is accepted. A1 never edits O3 files. The reviewer read this actual final wording and verified the document hashes above; this finding is closed at plan level.

## Accounting and diagnostic review conditions

- The repair must implement an actual bounded list scan: explicit length check, at most one comparison per resident per occurrence, at most nine stored spellings, no dict/set/sort/hash or whole-AST equality over original names hidden in the path. Tests inspect actual calls/events; random collision hunting is unnecessary.
- A fixed one-character alias removes long equality amplification, not all hash-table cost. P1 still needs an audited bound for probes, repeated alias comparisons, copying, updates and resizing. The previous long-name graph/density result is conditional and cannot be reused unchanged.
- Pay registry character/length/structural work, transient copies, declaration/expression/group visits, constraint/objective processing, source hashes, canonical identities, source-origin walks and retained names in artifacts. If research reconstruction independently resolves original names again, pay that actual extra pass; reuse requires an actual retained checked mapping, not matching intent.
- Early guards stop nonliteral shape-growth chains and excessive declarations/ranks before general validation. They do not establish a complete hostile-source work policy. Parser cap intersection and hashing remain semantic work even when implemented inside parsing; rejected ten-digit caps may require 34 bits. Decoder limits, rejected-source reservations and future charge-before-shared-helper work remain separate P1/P2/C5 obligations. Do not expand A1 into a production checker merely to satisfy those later obligations.
- Registry rejection of a tenth spelling and moved guards may change diagnostic precedence on already-rejected sources. Document the chosen code/span and intentional differences. Preserve ordinary supported-shaped diagnostics when not preempted. Translate only the exact quoted identifier field in known messages, in one noncascading pass; never general substring replacement. Test originals equal to aliases and containing other alias spellings.
- The nine-name proof applies only to accepted family roles. Invalid sources can contain more references/names and must reject under the explicit early registry cap; no proof about accepted roles justifies skipping their processing unboundedly.
- Differential evidence covers all identities, original names/spans/groups/order, shape/axis/tensor cross-namespace reuse, separate equation axes, aliases as user names, long prefix and differing-length spellings, zero-padded literals, repeated constraints and objectives. The tests compare actual old/new public outcomes from isolated archived baseline execution.

## Acceptance limits

No complete C1 bound, production hostile-candidate budget enforcement, O3 qualification or native eligibility follows from this plan review. The repair solves the identified repeated-long-key comparison problem if implemented as specified. A2 and A3 must produce their own immutable evidence; C1 remains blocked until P2 independently accepts complete proof/accounting under unchanged quotas.

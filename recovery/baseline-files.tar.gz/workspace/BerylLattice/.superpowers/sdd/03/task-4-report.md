# Plan03 Task4 implementation report

Owned files: `axiom/research/evaluate_adapter.py`,
`axiom/research/tests/test_evaluate_adapter.py`,
`axiom/research/protocol/export-v1.md`. No commits made, as directed. No Core
source changes. No unrelated broad suite run.

## Interfaces implemented

- `admit_export(request, experiment, python, evaluator, limits=ArtifactLimits())`
  returns frozen `ExportAdmission`: original request/experiment/tool identities,
  bounded full closure, independent retained snapshot, Python version and profile.
- `evaluate(admission, request, python, evaluator, output)` returns `EvaluationRun`
  with exit status/result, exclusive result and run-receipt paths, retained root,
  tool hashes/version. Both APIs keep native eligibility false.
- `VERIFIER_VERSION`, pinned evaluator SHA-256 and Git blob constants are public.
  Exact envelope schema, path semantics, mapping and trust limitations are in
  `protocol/export-v1.md`.

Every evaluator measurement maps bijectively to a typed research receipt. The
separate envelope pins the fixture-author-selected independent expected manifest
and oracle sidecar; these are never selected from measurement self-claims.
Complete observed/expected chunks, acquisition, raw observations, compiler and
artifact evidence, all direct references and both executable tools count in the
closure. Distinct equal-content files count separately; expanded logical state
length is separately bounded. Both original and retained closures receive fresh
complete semantic admission immediately before and after fixed-argv execution.
Caller-fabricated admission objects have no authority of their own.

## Rulings and trust limits

1. Correctness1x1 uses `synthetic_correctness_fixture` and evaluator selection
   role. Its post-policy A/A pilot is fixture machinery, not a claim of the full
   research held-out chronology. A separate descriptive held-out profile uses the
   actual approved8191x1/seed65537 stratum, real approved LCG input bytes, separately
   authored expected four-neighbor arithmetic and full `validate_chronology`.
   Root explicitly requested both profiles. The2047x2049 primary remains frozen
   and cannot be exported as admitted synthetic/native primary evidence here.
2. Fixture expected values remain an explicit fixture-author assumption, never a
   reviewed scalable oracle or widened Plan01 source profile. Native remains
   unavailable regardless of JSON or evaluator decisions.
3. Executable tools count under the same16MiB/file bound. The environment's
   default Python3.12 executable is30,894,944bytes and correctly fails; fixture
   execution selects available `/usr/bin/python3` (Python3.13,6,832,784bytes), with
   exact hash and version recorded. Package tests run the project Python3.12.
4. Retained files/directories are read-only, fully hashed/revalidated, and copied
   with exclusive creation. This is reproducibility storage, not an adversarial
   same-UID sandbox. Runtime shared libraries/stdlib/OS remain explicit execution
   assumptions, not a hermetic closure claim. Neither limitation permits native
   eligibility.
5. Historical analytical freeze inputs are explicitly synthetic and authored
   using the unchanged pinned evaluator function. Actual freeze/evaluate CLI
   tests use current time and exact supported argv, never `--now`; no promise of
   byte-identical freeze timestamps. External evaluation retains `selection_only`
   or `synthetic_gate_pass`, never automatic adoption.

## RED/GREEN evidence

Commands below ran from `/workspace/BerylLattice/axiom/research` unless noted.

- RED: `PYTHONPATH=. python -m unittest tests.test_evaluate_adapter -v`
  -> missing `evaluate_adapter` import, expected absent-module failure; log
  `task-4-red.log`. The initial12 mutation/mapping/roundtrip tests were written
  before production implementation. A first shell attempt from the wrong cwd
  failed to open its log, then the command above was run from the proper cwd.
- First integration failure: focused correctness roundtrip failed because the
  default Python tool exceeds16MiB. Logged in `task-4-first-green.log`; fixed
  fixture interpreter selection without weakening quotas. Self-review also
  aligned the adapter's successful state status with the existing `success`
  enum, not evaluator's `complete` spelling.
- Focused both profiles: `PYTHONPATH=. python -m unittest
  tests.test_evaluate_adapter.AdapterTests.test_synthetic_correctness_roundtrip_retains_external_selection_only
  tests.test_evaluate_adapter.AdapterTests.test_approved_small_held_out_fixture_is_descriptive_synthetic_gate_pass -v`
  ->2/2 PASS37.780s (`task-4-profile-red.log`, despite historical filename).
- Initial owned suite: `PYTHONPATH=. python -m unittest tests.test_evaluate_adapter -v`
  ->14/14 PASS96.778s (`task-4-suite.log`).
- Stronger independent-oracle control, real freeze CLI and native-profile/oracle
  pin rejection: focused3 tests ->3/3 PASS15.557s (`task-4-additional.log`). The
  same-wrong-output control explicitly demonstrates the unchanged evaluator
  alone gives `synthetic_gate_pass` on equal wrong observed pairs, while external
  admission rejects them against independently pinned expected output.
- Pinned evaluator analytical suite: copied only `evaluate.py` and
  `test_evaluate.py` into disposable
  `/tmp/axiom-pinned-evaluator-tests-m_5zd8ty/tools/beryl-experiments`, with the
  required disposable `build` directory. From that copied directory,
  `/usr/bin/python3 -m unittest test_evaluate -v` ->18/18 PASS1.275s.
  Log: `task-4-pinned-evaluator-tests.log`.
- Final current-source16-test suite: pending final process result below.

## Self-review

Checked exact evaluator schema/CLI/pins, native denial, genuine role separation,
independent oracle selection, full direct/indirect quotas, every receipt mapping,
chronology, stale/fabricated admission, copied evidence equality, and full
pre/post verification. The oversized-indirect-file control was tightened to7MB
so the bounded Python executable fits and the failure actually reaches the
hidden diagnostics file. Equal-content quota test asserts nonempty duplicate
content paths. The fixture loader initially used `importlib`, incidentally
creating an ignored bytecode cache in the Core tool directory; it now executes
captured source bytes without loader cache writes, and the generated cache was
removed. No Core source was edited. Independent review remains root-owned.

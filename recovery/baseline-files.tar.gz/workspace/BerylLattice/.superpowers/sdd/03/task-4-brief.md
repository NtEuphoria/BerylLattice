# Authorized implementation task

The user explicitly requested implementation of all three reviewed plans. Earlier planning-only restrictions no longer block implementation. Work in /workspace/BerylLattice.

# Axiom Research Evidence Infrastructure Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Produce independently verifiable semantic-state artifacts and frozen experiment manifests without pretending native measurements already exist.

**Architecture:** A separate research package validates complete state, provenance, dataset separation and measurement receipts before invoking the existing Beryl evaluator. It can operate on synthetic fixtures immediately; native admission remains blocked until a larger-buffer backend and genuine resource/timing observations exist.

**Tech Stack:** Python 3.12 standard library, little-endian i32 chunks, canonical JSON/SHA-256, existing evaluator as a pinned external tool.

**Spec:** [Performance protocol](../../../../axiom-foundations-2026-10-15/performance/protocol.md), [harness audit](../../../../axiom-foundations-2026-10-15/performance/harness-gaps.md), [research program](../../../research-program.md).

## Global Constraints

- Synthetic fixtures always retain `synthetic` provenance; passing them cannot become native evidence.
- Complete state includes post-call input and output, status and first failing coordinate, not only a checksum.
- Primary endpoint (W,H)=(2047,2049), seed65537: input16,793,600 bytes; output16,777,212 bytes; combined33,570,812 before metadata.
- Existing evaluator limits:16 MiB per file,256 MiB summed over unique resolved paths,16,384 files. The external gate applies these to the full direct/indirect closure, with a separate expanded logical-length check. Equal bytes in different files count twice.
- Existing evaluator threshold remains max(5%, pilot baseline noise); no threshold retuning or unsupported pooled/multiple-comparison claim.
- Native resource values unavailable are null/unavailable, never zero. Exact resource definitions must match the approved collector/evaluator contract.
- No native collection is enabled or performance claim produced by this plan alone.

## Review Focus

- Omitted/reordered coverage or duplicate logical offsets must fail; repeated chunk content at distinct offsets is valid; Task1.
- Reusing pre-call input as alleged observed post-call input: provenance must distinguish acquisition and expected state; Tasks1/3.
- Held-out workloads used during training under a different filename: content identities detect contamination; Task2.
- Timer measures process duration instead of the checked call: receipt must be ineligible; Task3.
- Compression/chunking bypasses aggregate byte limits: account for all decoded unique bytes; Task1.

## File map

Future root `/workspace/BerylLattice/axiom/research/`:

```text
state_artifacts.py         complete-state writer/verifier/comparator
experiment_manifest.py     frozen roles, inputs, candidate/baseline chronology
receipt_admission.py        external semantic/resource/identity prerequisites
evaluate_adapter.py         invokes pinned existing evaluator only after admission
tests/test_state.py
tests/test_manifest.py
tests/test_receipts.py
tests/fixtures/             explicitly synthetic evidence
protocol/                  versioned approved schemas and measurement definitions
```

Use `PYTHONPATH=.` from this directory. This package consumes Plan02 manifests without importing its code generator. It is useful independently as a validator; it does not execute arbitrary commands embedded in receipts.


### Task 4: Existing evaluator adapter and reproducibility checks

**Interfaces:** `admit_export(request: Path, experiment: FrozenManifest, python: Path, evaluator: Path, limits: ArtifactLimits) -> ExportAdmission`; `evaluate(admission: ExportAdmission, request: Path, python: Path, evaluator: Path, output: Path) -> EvaluationRun`. Export admission constructs the full closure, checks chronology/each measurement/oracle evidence and binds request, experiment, tools, verifier version and semantic contract. ChronologyResult and MeasurementAdmission cannot substitute for it. Do not trust a caller-supplied success bit; revalidate all bound bytes immediately before/after execution in retained immutable evidence storage.

- [ ] Write tests for synthetic mislabeled held-out, request/evaluator mutation, a changed indirect chunk behind an unchanged manifest, fabricated ExportAdmission or substituted local admission, equal-content distinct paths over budget, too many files, hidden oversized closure and threshold-policy change.
- [ ] Run owned tests; invoke `[python, evaluator, 'freeze' or 'evaluate', '--input', request, '--output', output]`. References resolve from the input file's parent; create a self-contained evidence root and fresh output file (the evaluator uses exclusive creation). Record Python version/hash, evaluator hash, exit status and result JSON. The evaluator uses current time: use valid historical fixture chronology, no invented `--now`, and no byte-identical timestamp promise.
- [ ] Run existing analytical evaluator tests in an isolated source snapshot and our synthetic adapter fixtures. Preserve `synthetic_gate_pass`/selection-only/native distinctions. Do not convert “eligible” into automatic adoption.
- [ ] Implement the external export-v1 contract: evaluator `semantic.state` references the canonical state manifest as an opaque equality object; per-run acquisition/oracle sidecars remain outside its exact schema. An external admission envelope binds request, manifests, all chunks, sidecars, tool identities and semantic assumptions. Verify the full transitive closure and independent oracle before/after evaluation; evaluator-v1 checks only direct references. Passing the evaluator alone certifies neither chunk completeness nor source semantics. If immutable closure or reviewed mapping is unavailable, native eligibility remains unavailable; do not substitute an unchecked digest.
- [ ] Commit as `feat(research): connect admitted evidence to the frozen evaluator`.

## Separate research gates before native collection

These are intentionally not guessed implementation tasks. Each produces a concrete design before code changes:

1. **Large-buffer lowering:** compare a structured-loop Core path, a versioned checked IR adapter and a bounded MLIR experiment. Specify actual owned/borrowed storage, address width, allocation/copy behavior, first failure and post-lowering resource scope. Large H/W may exceed both current experimental IR and AST-reference limits. Choose a path only after a small compiled storage experiment establishes its contract.
2. **Plan-v2 checker:** define loop/address semantics and a proof/checking procedure without unrolling millions of operations. Include multi-consumer last use and orientation if admitted. Prove the narrow model theorem and connect implementation to it; never reuse v1 acceptance on an unexamined v2 plan.
3. **Native capture repair:** use the existing P9 repair contract and actual `tools/beryl-bench/run.py`, `receipts.py`, `tools/beryl-experiments/evaluate.py`. Define each required metric and its platform instrumentation, correct compiler forwarding/identity and text-section accounting, add checked-call timing and safe Rust execution. Missing portable retained/allocation measurements require a new explicit exploratory profile, not evaluator-v1 eligibility.
4. **Independent scalable source oracle:** specify a separate wide-integer, streaming evaluator for the large logical stencil and its complete boundary semantics. Bind formula/version, exact input and initial output; compare expected and observed chunks by logical coordinate. It must not import planner/emitter/collector logic. Validate against Plan01 on its small admitted profile and hand-worked boundary controls, then test large-shape stream coverage, first-error preservation and same-wrong-output rejection. Plan01's <=256-cell admission is not silently widened. This gate is required before any large native semantic admission, irrespective of pair agreement.

Only after those gates and this evidence package pass may the frozen native protocol run. This sequencing avoids giving an implementer fictional APIs or treating unsupported infrastructure as a minor TODO.

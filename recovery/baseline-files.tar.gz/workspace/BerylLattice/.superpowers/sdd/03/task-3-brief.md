# Authorized implementation task

The user explicitly requested implementation of all three reviewed plans. Earlier planning-only restrictions no longer block implementation. Work in /workspace/BerylLattice.

# Axiom Research Evidence Infrastructure Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Produce independently verifiable semantic-state artifacts and frozen experiment manifests without pretending native measurements already exist.

**Architecture:** A separate research package validates complete state, provenance, dataset separation and measurement receipts before invoking the existing Beryl evaluator. It can operate on synthetic fixtures immediately; native admission remains blocked until a larger-buffer backend and genuine resource/timing observations exist.

**Tech Stack:** Python 3.12 standard library, little-endian i32 chunks, canonical JSON/SHA-256, existing evaluator as a pinned external tool.

**Spec:** [Performance protocol](../../../../axiom-foundations-2026-10-15/performance/protocol.md), [harness audit](../../../../axiom-foundations-2026-10-15/performance/harness-gaps.md), [research program](../../../research-program.md).

## Global Constraints

- Synthetic fixtures always retain `synthetic` provenance; passing them cannot become native evidence.
- Complete state includes post-call input and output, status and first failing coordinate, not only a checksum.
- Primary endpoint (W,H)=(2047,2049), seed65537: input16,793,600 bytes; output16,777,212 bytes; combined33,570,812 before metadata.
- Existing evaluator limits:16 MiB per file,256 MiB summed over unique resolved paths,16,384 files. The external gate applies these to the full direct/indirect closure, with a separate expanded logical-length check. Equal bytes in different files count twice.
- Existing evaluator threshold remains max(5%, pilot baseline noise); no threshold retuning or unsupported pooled/multiple-comparison claim.
- Native resource values unavailable are null/unavailable, never zero. Exact resource definitions must match the approved collector/evaluator contract.
- No native collection is enabled or performance claim produced by this plan alone.

## Review Focus

- Omitted/reordered coverage or duplicate logical offsets must fail; repeated chunk content at distinct offsets is valid; Task1.
- Reusing pre-call input as alleged observed post-call input: provenance must distinguish acquisition and expected state; Tasks1/3.
- Held-out workloads used during training under a different filename: content identities detect contamination; Task2.
- Timer measures process duration instead of the checked call: receipt must be ineligible; Task3.
- Compression/chunking bypasses aggregate byte limits: account for all decoded unique bytes; Task1.

## File map

Future root `/workspace/BerylLattice/axiom/research/`:

```text
state_artifacts.py         complete-state writer/verifier/comparator
experiment_manifest.py     frozen roles, inputs, candidate/baseline chronology
receipt_admission.py        external semantic/resource/identity prerequisites
evaluate_adapter.py         invokes pinned existing evaluator only after admission
tests/test_state.py
tests/test_manifest.py
tests/test_receipts.py
tests/fixtures/             explicitly synthetic evidence
protocol/                  versioned approved schemas and measurement definitions
```

Use `PYTHONPATH=.` from this directory. This package consumes Plan02 manifests without importing its code generator. It is useful independently as a validator; it does not execute arbitrary commands embedded in receipts.


### Task 3: Fail-closed native evidence admission

**Interfaces:** `admit_measurement(receipt: MeasurementReceipt, experiment: FrozenManifest) -> MeasurementAdmission`. Receipt schema includes actual toolchain/artifact/run identities, state verification, call-boundary timer scope, all eight paid components, raw resource observations with units/scope, sampling session/reset information and collector version. Define unsupported/missing evidence explicitly. This is not admission of an entire evaluator request.

The exact paid keys are `setup`, `capture`, `compute`, `maintenance`, `invalidation`, `conversion`, `cleanup`, `cold_refresh`; exact resource keys are `peak_bytes`, `retained_bytes`, `allocations`, `text_bytes`, `build_ns`, `edit_check_ns`. Consult the pinned evaluator contract for their admission rules; do not invent similarly named substitutes. Empty semantic stdout/events are valid only for an operation whose declared semantics has none; instrumentation diagnostics are retained separately. Across plans, Core internal trace offsets are not Axiom semantic events.

- [ ] Write failing admission tests for unavailable resources, fake measured zeros, whole-process timer scope, missing preflight/initialization/copy/cleanup costs, stale executable, synthetic provenance, incomplete input/output and mismatched semantic boundary. Include baseline/candidate agreeing on the same wrong complete output: format/pair equality passes, independent oracle admission fails.
- [ ] Run `PYTHONPATH=. python -m unittest tests.test_receipts -v`; observe missing admission.
- [ ] Implement schema and consistency checks. Do not claim that JSON validates physical instrumentation: require retained raw observations and a reviewed collector version. It is impossible to infer measurement honesty from scalar fields alone; list collector/hardware/OS assumptions in each acceptance record.
- [ ] Make native status unavailable until approved collector definitions and the independent scalable-oracle gate below are complete. Bind each comparison to oracle version, exact semantics, shape/input/initial-output and expected status; compare every actual scalar, including observed post-call input. Retain process RSS, arena capacity, allocator peak, retained bytes and allocation count as distinct quantities.
- [ ] Commit as `feat(research): reject incomplete native measurement evidence`.


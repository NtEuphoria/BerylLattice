# Authorized implementation task

The user explicitly requested implementation of all three reviewed plans. Earlier planning-only restrictions no longer block implementation. Work in /workspace/BerylLattice.

# Axiom Research Evidence Infrastructure Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Produce independently verifiable semantic-state artifacts and frozen experiment manifests without pretending native measurements already exist.

**Architecture:** A separate research package validates complete state, provenance, dataset separation and measurement receipts before invoking the existing Beryl evaluator. It can operate on synthetic fixtures immediately; native admission remains blocked until a larger-buffer backend and genuine resource/timing observations exist.

**Tech Stack:** Python 3.12 standard library, little-endian i32 chunks, canonical JSON/SHA-256, existing evaluator as a pinned external tool.

**Spec:** [Performance protocol](../../../../axiom-foundations-2026-10-15/performance/protocol.md), [harness audit](../../../../axiom-foundations-2026-10-15/performance/harness-gaps.md), [research program](../../../research-program.md).

## Global Constraints

- Synthetic fixtures always retain `synthetic` provenance; passing them cannot become native evidence.
- Complete state includes post-call input and output, status and first failing coordinate, not only a checksum.
- Primary endpoint (W,H)=(2047,2049), seed65537: input16,793,600 bytes; output16,777,212 bytes; combined33,570,812 before metadata.
- Existing evaluator limits:16 MiB per file,256 MiB summed over unique resolved paths,16,384 files. The external gate applies these to the full direct/indirect closure, with a separate expanded logical-length check. Equal bytes in different files count twice.
- Existing evaluator threshold remains max(5%, pilot baseline noise); no threshold retuning or unsupported pooled/multiple-comparison claim.
- Native resource values unavailable are null/unavailable, never zero. Exact resource definitions must match the approved collector/evaluator contract.
- No native collection is enabled or performance claim produced by this plan alone.

## Review Focus

- Omitted/reordered coverage or duplicate logical offsets must fail; repeated chunk content at distinct offsets is valid; Task1.
- Reusing pre-call input as alleged observed post-call input: provenance must distinguish acquisition and expected state; Tasks1/3.
- Held-out workloads used during training under a different filename: content identities detect contamination; Task2.
- Timer measures process duration instead of the checked call: receipt must be ineligible; Task3.
- Compression/chunking bypasses aggregate byte limits: account for all decoded unique bytes; Task1.

## File map

Future root `/workspace/BerylLattice/axiom/research/`:

```text
state_artifacts.py         complete-state writer/verifier/comparator
experiment_manifest.py     frozen roles, inputs, candidate/baseline chronology
receipt_admission.py        external semantic/resource/identity prerequisites
evaluate_adapter.py         invokes pinned existing evaluator only after admission
tests/test_state.py
tests/test_manifest.py
tests/test_receipts.py
tests/fixtures/             explicitly synthetic evidence
protocol/                  versioned approved schemas and measurement definitions
```

Use `PYTHONPATH=.` from this directory. This package consumes Plan02 manifests without importing its code generator. It is useful independently as a validator; it does not execute arbitrary commands embedded in receipts.


### Task 1: Complete-state artifacts under file-size limits

**Interfaces:** `write_state(input_after: Iterable[int], output: Iterable[int], metadata: StateMetadata, directory: Path) -> Path`; `verify_state(manifest: Path, limits: ArtifactLimits) -> VerifiedState`; `compare_state(a: VerifiedState, b: VerifiedState) -> StateComparison`. StateMetadata contains logical semantics identity, shape, original-input and initial-output identities, status and first_bad_index. AcquisitionMetadata is a separate sidecar: run, timestamps, mode, collector, plan, emitted-kernel and binary identities. ArtifactLimits defaults: chunk bytes1,048,576; per-file16,777,216; aggregate bytes268,435,456 by resolved path; max files16,384.

- [ ] Write tests for exact little-endian encoding including INT32_MIN/MAX, shape-length/status consistency, first mismatch coordinate, empty/missing/extra/reordered coverage, overlapping offsets, corrupt bytes, duplicate JSON keys and expanded-byte limits. Include a repeated-content positive case: two legitimate all-zero chunks can share a hash/path at different logical offsets. Resource/source-precondition rules remain separate from the encoding's full i32 capacity.
- [ ] Run `PYTHONPATH=. python -m unittest tests.test_state -v`; observe missing implementation.
- [ ] Implement streaming chunks, each at most1 MiB, with typed input/output role, contiguous offset, byte length and SHA-256 in a canonical ordered manifest. Verify every actual byte, exact total counts, no path escape and aggregate unique-byte accounting. Deduplication identifies immutable content, not an excuse to omit acquisition provenance.
- [ ] Separate the canonical semantic manifest from acquisition sidecars. Run, emitted-Core kernel, binary, collector/plan identities and absolute paths belong only in sidecars. Use logical semantics and invocation identities in state. Add two runs with distinct plans/emitted kernels but byte-identical state manifests and distinct acquisition sidecars. Include sidecars/manifests/pilot artifacts in the complete path/byte/file closure budget; repeated successful state may share immutable content only after each invocation is acquired and compared.
- [ ] State acquisition is a separate trust obligation: synthetic fixtures and observed native dumps are labeled distinctly. The writer cannot prove that a caller supplied real post-call memory. Require the future native collector to bind actual dump paths to a completed invocation, and independently compare post-call input with the original input.
- [ ] Verify a generated primary-size synthetic state losslessly without a file exceeding limits; report it only as artifact-format validation. Compression is unnecessary in v1; do not silently introduce decompression trust/limits.
- [ ] Commit as `feat(research): verify complete chunked semantic state`.


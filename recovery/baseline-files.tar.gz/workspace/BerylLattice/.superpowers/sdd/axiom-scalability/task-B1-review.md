# B1 independent spec and quality review

Reviewed immutable range `958de943aeba6f8fd00dd983924499c6ca32a85c..aaa6d2f2c87ff47ee15c7f4f0bc809a45846831c` against `task-B1-brief.md`, the implementation report, shared design/plans, C2 admission and original-source reference evaluator, and relevant pinned Core source.

The retained `task-B1-review.diff` is byte-for-byte the exact Git diff for this range (SHA-256 `6e6f1990e46f0f3ef7ef8c23f692b72e17ae19cfddd49f38da2ac948d3bec46b`). All five reviewed product files match their immutable reviewed versions. Concurrent controller/C1 files are outside this review.

## Spec verdict: PASS

No blocking or important spec findings. This verdict applies to B1's test-only executable specification; it is not native qualification or production adapter approval.

- Ownership and scope match the ruling: four fixture/test files and the contract document are the only product changes. No production lifecycle, compiler, source-profile, v1 protocol or oracle implementation changed. The report and document consistently defer actual native execution/qualification to B2/B3.
- Size planning consumes fresh `admit_source_v2` calls with `SourceProfileV2()`/`SourceLimitsV2()` rather than inventing another `AdmittedLoopKernel`. `_sizes` checks exact integer capacity in `0..P`, counts and all calculated byte quantities against target bounds, and charges all reserved capacity against the admitted effective source cap. Tests cover the P ceiling, both dimension maxima, rejected size combinations, the primary/square byte counts, source cap and target-size failure. Large cases remain arithmetic only.
- `prepare` and checked invocation admit actual source bytes. The checked entry admits before its event interval and binds the source hash before callbacks. The comparison independently obtains the retained original source AST and calls the existing `evaluate_source`; it does not reuse callback-produced output as expected state. Original input/output snapshots are retained independently of mutated buffers.
- Valid and invalid callback paths observe real calls and actual Python state. Success records metadata, one preflight, exact allocation, zeroing, body mutation, integrity, cleanup and timer end before acquisition/comparison. Invalid input preserves complete input/output, identifies the first row-major violation, and performs neither scratch allocation nor body invocation. Inline observes the initialized empty scratch descriptor with no allocator request.
- Boundary, source rejection, resource, process, acquisition, integrity and later comparison failures are distinguished. Corrupt descriptors and traps never become completed states, partial acquisition is rejected before comparison, and original allocated scratch is used for cleanup. The local `comparison_error` is expressly separated from the shared NativeRunV2 completion enum.
- The negative controls execute their bad behavior: allocation before preflight records a 24-byte allocation, a caller validation bit invokes the body and changes the canary output to `[45,74]`, and the used-cell control actually reserves 24 bytes while reporting four. Their retained assertion failures demonstrate concrete detection; these are not prose searches or invented traces. The production-like good fixture is tested through its checked entry, including rejection of the extra `validated` argument.
- The contract records the expected LP64/C11 layout, integer representation, helper pointer signatures, private binding/manifest requirements and fail-closed assertions. It separately preserves identities, complete acquisition, storage quotas, paid timing scopes and allocation/resource distinctions from the shared oracle and measurement contracts.

## Quality verdict: PASS

No actionable quality findings within B1 scope.

The adapter is small and explicitly test-only. It separates preparation, size calculation, owned descriptor state, callbacks and checked orchestration. Exact-type checks avoid Python bool/float acceptance at entry. The fault cases cover both preservation and failure classification rather than asserting only event strings. Tests use unittest assertions and explicit exceptions, so optimized Python retains their checks. The deliberately bounded tiny-execution surface and arithmetic-only larger surface are documented consistently.

The hand-written Core source is plausible against the pinned language/source evidence without claiming it has compiled. It uses ordinary module/functions and integer ranges, let/input and inout/output/scratch parameters, scalar temporaries, and separate get/set statements. At H=1/W=2, producer positions 0..5 and consumer reads `c`, `c+1`, `c+3`, `c+4` stay in 0..5 for c=0,1. Producer computation retains both source `value+1` operations; output sums preserve left association. Admitted input bounds keep all scalar arithmetic safely in i32. The two loops' endpoints and terminal updates are small and representable. No owning local List, growth, clear, descriptor replacement or collection-mutation loop is introduced.

Manual state arithmetic agrees with the JSON: producer values for 0..5 are `[1,4,9,16,25,36]`, giving `[46,74]`; all-zero and all-1023 inputs give `[4,4]` and `[4194304,4194304]`. First/last/multiple-invalid cases preserve both canaries.

Pinned Core HEAD is `0a678b4ae6d41190c4f5a8bf063caba05759d20d`. Its `src/back/c_backend.c` List declaration and parameter lowering support the documented descriptor field/pointer expectations; `src/sema/ownership.c` documents whole-call receiver borrowing, and `src/sema/storage.c` distinguishes collection iteration from the allowed integer range loops. B1 appropriately makes the actual emitted declarations, assertions and compiler admission B2 obligations.

## Evidence and limits

- Read the exact five-file diff, both task documents, retained RED/control/GREEN logs, source admission/reference dependencies, shared oracle/measurement requirements and the relevant Core source.
- Retained normal and optimized logs each show all 14 focused tests passed. Read all three standalone control logs and confirmed their expected concrete assertion failures. These are implementation-run evidence, not newly repeated reviewer executions.
- Independently checked immutable diff identity, absence of changes to its five working-copy files, exact Core pin and `git diff --check` for the reviewed range. No new concrete concern warranted a runtime probe.
- Did not rerun already-passing same-code suites, invoke the Core compiler, run a native worker, create large states, or change/commit product files. Only this local review report is written.
- Python callback behavior does not prove C memory ownership, native allocation interception, Core acceptance, actual generated ABI, clock scopes or production lifetime guarantees. B2/B3 and later evidence tasks must establish those independently. This is an explicit milestone boundary, not a B1 defect.

Disposition: B1 may be accepted for its specified milestone. No revisions requested.

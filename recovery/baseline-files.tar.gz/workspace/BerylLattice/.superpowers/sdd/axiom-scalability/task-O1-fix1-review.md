# O1 fix1 independent rereview

**Specification verdict: PASS. Implementation quality verdict: PASS.**
Both findings from the initial review are resolved. No additional important
finding was identified in the scoped correction.

Reviewed exact commit: `64da9e296f6c82f11ce5410c1421677fc6fc990f`.
Actual parent: `9912ead6c330fb0f302e687aca577fecad005bc0`.
Original O1 baseline: `7e72feeed82648b059e6f9884a2ebc56cf0a27a0`.
Scoped fix diff SHA-256:
`e3150914adbc62401016dcc67da8e73cf9c7f8bf06ea44e0088ccff6475e778f`.

I reviewed `task-O1-fix1-report.md`, the exact changes across all five owned
files against the previously reviewed complete files, and retained RED/GREEN
logs. Independently compared all five working files with `git show` of the
exact reviewed commit, compared the retained scoped diff with `git diff` of
the exact baseline/fix commits, and verified all seven retained log lengths
and SHA-256 values against `retained-o1-fix1-logs/inventory.json`. All match.
Concurrent B3/C1 changes and controller documentation remain outside this scope.

## Finding dispositions

**O1-R1: RESOLVED.** `VerifiedBlob.revalidate()` now validates its existing
reference, limits, tuple/container type, exact chunk-record type, integer
fields, normalized paths, hashes, coverage, counts and cache bound before
performing fresh file verification and equality checks. Integer validation
uses `type(value) is int`, so floats and bools cannot pass through Python's
cross-type value equality. The scalar reader checks the reference/limits/tuple
and each probed or consumed chunk before offset arithmetic or slicing; it also
rejects missing coverage explicitly. It retains binary search rather than
adding a complete table scan per scalar read.

`VerifiedInvocation.revalidate()` first validates invocation limits, path/hash,
exact immutable `bytes` source storage, exact manifest type and its fields, and
exact nested `VerifiedBlob` records and metadata. Nested blob limits must match
the invocation's validated limits. Its subsequent complete actual-storage
verification and freshly admitted source comparison remain intact. Reference
validation no longer normalizes/mutates caller-held metadata during a trust
boundary check. The host contract is now explicitly an exact string.

The two added tests reproduce the original float/bool chunk acceptance,
malformed containers/chunk types and nested limits, mutable retained source
bytes, and invalid invocation limits. They require explicit `ValueError` at
revalidation/scalar-read boundaries. Retained typed RED records the intended
six failures plus the float-slice TypeError; normal and optimized GREEN show
the new controls pass. This directly addresses the original reproducer, so no
additional execution of the same reproducer was necessary.

**O1-R2: RESOLVED.** The test-only import now uses
`from research.state_artifacts import StateMetadata`. It relies on the existing
repository namespace under ordinary `PYTHONPATH=src` and introduces no sys.path
mutation or production research dependency. Retained normal and optimized
focused commands both use `PYTHONPATH=src` and pass all 14 tests, including the
actual state-v1 mapping comparison. The separately retained mapping test also
passes with `PYTHONPATH=src`.

## Regression evidence and limits

Inspected both retained focused GREEN logs: **14 tests PASS normally and under
Python -O**. Inspected both retained frontend/state regression logs: **28 tests
PASS normally and under Python -O**. Normal regression uses `PYTHONPATH=src`;
optimized regression retains `PYTHONPATH=src:research`. Import RED and typed RED
are concrete failures corresponding to the two corrected findings.

The fix does not change accepted serialized schemas, identity preimages,
source admission, signed-i32 transport, extent-before-stream ordering,
descriptor-relative no-symlink reads, actual content hashing, or cache eviction.
Full revalidation still checks actual files before acceptance and clears cached
bytes. Added full metadata validation is bounded by existing file/item limits;
scalar validation remains bounded by searched/used chunks. No production
research import, held-out data, native execution, oracle result, or semantic
comparison was added.

Original limitations remain appropriate: consumers must revalidate at trust
boundaries; files must remain stable during consumption; same-UID races are not
an OS snapshot guarantee; source/metadata/transient read buffers are additional
to the two retained chunks; enclosing stores own aggregate budgets and account
read amplification. This review does not promote transport acceptance into
native qualification or O2/O5 evidence. The controller's independent final
standard-product-suite run is separate from this scoped review and was not
claimed as completed here.

## Exact product file SHA-256

| File | SHA-256 |
|---|---|
| `axiom/src/axiom/artifact_chunks_v2.py` | `e97078fc62c368cda070b8c1ba9a3ff1fd2abfe5102552108eaab6eaa84f7ab6` |
| `axiom/src/axiom/invocation_v2.py` | `9039a6706e89d54c97f5c508725994d0a8f0f210c255c668de56121cc54d9c1c` |
| `axiom/tests/test_artifact_chunks_v2.py` | `266c5badaa51d8a112934c05de0e80351d4acd075b86cf1e74c709bba0ddb5bf` |
| `axiom/tests/test_invocation_v2.py` | `f8dc5105ef1887b12c7f7612b0f2807e7205773a183508d0dfb3592834a3b5f9` |
| `axiom/research/protocol/invocation-v2.md` | `e538e6dcf1ffb424518b920886d05bb30b75c7740fc2b4760a212c6daf1169c9` |

Only this local review artifact was written; no product changes, new tests,
commits, worktrees or subagents were created during rereview.

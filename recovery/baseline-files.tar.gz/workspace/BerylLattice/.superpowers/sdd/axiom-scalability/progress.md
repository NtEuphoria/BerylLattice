# SDD ledger — plan: docs/superpowers/plans/2026-10-16-axiom-scalability/README.md

## Execution authority and baseline

Latest user instruction authorizes continued planning and building. Scope remains confidential; no publication or external messages. Baseline Lattice 1011eea5edf0bd13208409e385a9b77c43adbc57; Core 0a678b4ae6d41190c4f5a8bf063caba05759d20d.

Ruling: Use the existing isolated cloud checkout on branch work — onboarding explicitly avoids additional worktrees unless requested — recovery verification uses an ordinary scratch clone, not a worktree.
Ruling: Execute the reviewed plan; its historical statement that the request is planning-only is superseded by the latest user instruction — no change to confidential/publication boundaries — local work remains reversible.
Ruling: Skill helper resources could not be read through the skill provider; use equivalent task extraction and diff packaging with retained exact text — no requirement or review may be omitted — helper convenience only is lost.
Ruling: Focused tests per task, full suites at integration boundaries — higher-priority developer guidance and plan verification policy agree — broaden only for relevant failures or concerns.
Ruling: Retain this plan's ledger and review evidence for recovery — project evidence requirements take priority over generic scratch cleanup — disk footprint is bounded and reviewed.
Ruling: One implementation agent at a time; independent read-only preflight/review may run concurrently — shared-file safety and SDD discipline — reduces implementation parallelism.

## Tasks

G0: in progress. Preflight: pending.

## G0 evidence

Plan preservation commit: 67769dc08d11bc5d67c8632824d58a2cb09aa92e. Baseline record commit: 089e7f2. Existing bundle verified; new complete bundle /workspace/scratch/axiom-scalability-plan-20261016.bundle verified. Fresh scratch clone ran tools/setup-cloud.sh successfully with Python 3.12.14. Source inventories retained (85 Lattice files, 682 Core files) and planning archive at /workspace/scratch/axiom-scalability-execution-20261016/. Existing native toolchain receipt revalidated through load_toolchain; known two Core baseline failures remain classified. Draft revision 3 unchanged; remote cloud publication/fresh-task restoration remains unverified.

Ruling: G0 permits local implementation after demonstrated clean-checkout restoration — a genuine new cloud-task snapshot depends on product publication and is not necessary to execute locally — do not claim remote persistence or fresh-task verification.
Ruling: Execute C2 before B1 executable contract tests — B1 consumes C2 profile and cannot own a duplicate — C2 initially creates only admission section of loop-plan-v2.md, later extended by C1.
Ruling: B1 ordering adapter is test-only — assigned files contain no production lifecycle — B3 remains sole production host owner.
Ruling: Resolve B5/O4 staging as O1 blob contract → B5 inventory schema → O4 synthetic verifier → real B5 inventory integration — prevents circular completion — no later performance capability needed for build qualification.
Ruling: G4 implementation readiness is distinct from actual final experiment evidence — preserve M5a→M3→M6a→M5b→pilot→M6b/M7 chronology — final qualification claims require actual complete evidence.
Ruling: Assign straightforward checked scalar Core comparison source/build integration to M5a with B4/B5 boundary review — required comparator lacked an explicit producer — timing remains unavailable until it exists.

G0: local restoration complete; independent cloud-task restoration unverified.

## Preflight acceptance

Full table: [preflight.md](preflight.md), 46 task/gate rows and 438 interface/file-pair rows. P1–P5 accepted through rulings above, including serialized shared ownership. G1 contracts ready for C2/B1/C1; this does not pass proof/native feasibility.

Task C2: in progress. BASE 089e7f2. Brief task-C2-brief.md.

C2 implementer: /root/implement_c2_source_profile (gpt-6.1-sol, high). Read-only C1 advice: /root/proof_rule_advice (gpt-6-astra, high); advice is not independent acceptance review.

Task C2: implementation 958de943aeba6f8fd00dd983924499c6ca32a85c; 33 normal and 21 optimized focused/directly affected tests passed; task-C2-review.diff generated from recorded BASE. Independent reviewer /root/review_c2_source_profile (gpt-6.1-sol, high); acceptance pending.

Task C2: complete. Commit 958de943aeba6f8fd00dd983924499c6ca32a85c. Independent spec PASS and quality PASS; task-C2-review.md. No findings. Source index-semantics naming reviewed against separate mathematical plan/native bounds contract; no violation in source-only API.

Task B1: in progress. BASE 958de943aeba6f8fd00dd983924499c6ca32a85c. Brief task-B1-brief.md.

Ruling: Allow B1 boundary fixtures and C1 research proof feasibility to run concurrently with disjoint explicit ownership and serialized commits — developer proactive-delegation guidance and the reviewed plan permit independent workstreams, superseding the generic skill's blanket one-implementer limit — controller must scope task diffs to owned paths and review integrated changes before completion. No shared schema edit is concurrent.

Task C1: in progress. Source BASE 958de943aeba6f8fd00dd983924499c6ca32a85c. Owns only loop-plan-v2.md, research/loop_proof_feasibility.py, its test, docs/reviews/loop-proof-feasibility.md. B1 owns disjoint files. Hold C1 commit until controller authorizes commit serialization.

Task B1: implementation aaa6d2f2c87ff47ee15c7f4f0bc809a45846831c. 14 focused tests pass normally/-O; 3 independent bad-adapter commands fail as intended. Review package task-B1-review.diff; reviewer /root/review_b1_buffer_contract. C1 commit window opened, scoped owned files only.

Task B1: complete. Commit aaa6d2f2c87ff47ee15c7f4f0bc809a45846831c. Independent spec PASS/quality PASS, no findings; task-B1-review.md. Test-only boundary contract, no native qualification inferred.

Task B2: in progress. BASE aaa6d2f2c87ff47ee15c7f4f0bc809a45846831c; brief task-B2-brief.md. Disjoint from C1; commits serialized by controller.

Task C1: implementation 0e3c6b7d6a451cb74d6caa8666b817d3d56544d3, four owned paths; scoped diff task-C1-review.diff. 10 normal and 10 optimized tests pass. Status DONE_WITH_CONCERNS: gate blocked pending independent review; actual measured primitive-event traces are not production certificate counts. Reviewer /root/review_c1_proof_feasibility (gpt-6-astra high), task-C1-review-instructions.md. B2 commit window opened after C1 commit.

Sanitizer prerequisite: root smoke found missing ASan/UBSan/LSan runtimes. /root/prepare_sanitizer_runtime used signed Debian metadata and exact libclang-rt-19-dev 1:19.1.7-3+b1 SHA256 0c03a0a8fa37228e2de6c36d02ff0806643885c515a8137d1bcd22e248497cd6 in a NEW scratch prefix. All clean/fault controls passed; original qualified Clang prefix inventory unchanged. Report sanitizer-prerequisite-report.md; evidence /workspace/scratch/axiom-scalability-execution-20261016/sanitizer-runtime-jtv4b5ih. This is a prerequisite, not B3 host qualification.
Ruling: Use explicit -resource-dir for sanitizer configurations and bind the entire override inventory — adding libraries to a new scratch prefix preserves concurrent B2 compiler identity — sanitizer configuration and production optimized configuration remain distinct.

Task B2: implementation cf01790ca3fa97e22e60a842427a3c582dec5a5b; actual parent C1 0e3c6b7. 13 native normal +13 optimized and50 related regressions pass; six actual complete states, ABI/hash/pin controls rejected. Reviewer /root/review_b2_native_binding (gpt-6-astra high), task-B2-review.diff. No B8 trigger.
Task C1: fix round1 for independent F1 — complete hand-proof representation/byte/node/fully charged work bound remains absent; scratch peak convention also needs correction. General written argument accepted, gate blocked. Same implementer reactivated, C1 commit window open; task-C1-fix1-report.md expected. No C4–C11 execution before approved gate.

Task B2: complete. Commit cf01790ca3fa97e22e60a842427a3c582dec5a5b. Independent spec PASS and code-quality/ABI PASS, no defects; task-B2-review.md. Both evidence inventories rehashed, all 12 complete states across normal/Python-O runs checked independently. Native build mode was C -O0; Python -O is not native optimization. G2a tiny Core seam passes; B8 not triggered.

Task B3: in progress. BASE cf01790ca3fa97e22e60a842427a3c582dec5a5b. Brief task-B3-brief.md; C1 has current commit window, B3 must request its window.

Task O1: in progress. BASE cf01790ca3fa97e22e60a842427a3c582dec5a5b; dependencies C2/B1 approved, B6 schema frozen in plan/B1. Owns five O1 files; disjoint C1/B3. Explicit writer helper authorized for extent rejection before iterator reads; production-safe state-v1 mapping, declared ownership not actual heap proof. Commit window must be requested.

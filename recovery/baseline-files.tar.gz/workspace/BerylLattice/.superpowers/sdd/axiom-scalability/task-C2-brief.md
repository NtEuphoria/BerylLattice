# Task C2 implementation brief

Read this first: these are the task requirements, with exact values to use verbatim.

## Global constraints

1. Preserve all v1 interfaces, accepted/rejected cases, canonical bytes and native-unavailable behavior. Introduce explicitly named v2 protocols/profiles.
2. Start from exact clean Lattice/Core baseline identities in the shared design. Product execution requires preserving the current local work and demonstrating restoration first.
3. Source dimensions are fixed; input values and host-owned buffers are runtime data. Initial bounds are H/W≤8192 and P≤2^23.
4. Correctness, abstract storage, native allocation, timing and publication are separate gates. None implies another.
5. Only the private checked entry invokes kernels. Complete acquisition and independent comparison are mandatory for every admitted native invocation.
6. A missing proof, metric, qualification, observation or dependency is unavailable/ineligible; no guessed zero or success flag repairs it.
7. Keep Axiom private. No external model contact, public issue, preprint, repository publication or submission is part of this implementation plan.

## Normative interfaces and file ownership

| Proposed file | Responsibility |
|---|---|
| `axiom/src/axiom/source_profiles.py` | Explicit v2 source admission, profile envelope, family and specialization identities |
| `axiom/src/axiom/loop_model.py` | Immutable IR, proof records, limits, candidate and constraint request types |
| `axiom/src/axiom/loop_codec.py` | Strict bounded encoding/decoding and exact canonical bytes |
| `axiom/src/axiom/loop_regions.py` | Small checked region, affine, parity and induction-premise rules |
| `axiom/src/axiom/loop_checker.py` | Actual-plan proof traversal, source-derived scalar semantics and eligibility |
| `axiom/src/axiom/loop_storage.py` | Compositional abstract scalar-liveness accounting, separately gated |
| `axiom/src/axiom/loop_planner.py` | Three untrusted candidate/certificate generators |
| `axiom/src/axiom/loop_selection.py` | Deterministic budgeted portfolio search |
| `axiom/src/axiom/loop_evidence.py` | V2 replay and durable exact artifact identity |
| `axiom/src/axiom/loop_core_emit.py` | Owned by the Core plan; consumes and freshly checks this plan's public candidate interface |
| `axiom/tests/support/loop_interpreter.py` | Test-only concrete execution independent of proof rules |

The public checking boundary is:

```python
admit_source_v2(source_bytes: bytes, *, profile: SourceProfileV2,
                limits: SourceLimitsV2) -> AdmittedLoopKernel

check_loop_plan(source_bytes: bytes, candidate: LoopCandidate, *,
                constraints: ConstraintRequestV2,
                limits: LoopLimits) -> LoopCheckResult
```

The Core-owned `emit_loop_core(source_bytes, candidate, *, constraints, limits)` uses the same inputs and performs a fresh check; it does not accept a caller-provided success receipt. Native target/toolchain configuration is a separate Core compilation boundary, not an implicit change to the logical proof request.

`SourceProfileV2` identifies the fixed-buffer stencil profile, its dimensions/cell envelope and index semantics. `SourceLimitsV2` retains the 65,536-byte source bound and existing bounded parser behavior. `AdmittedLoopKernel` retains exact source bytes/hash, original AST, H/W, input domain, source constraints, objective, `family_digest` and `specialization_digest`. The family digest binds normalized equations, scalar/boundary semantics and profile but excludes fixed H/W; the specialization digest binds the family digest and exact H/W. A proof binds the specialization. Neither digest aliases a v1 digest. At the shared serialization boundary, these are named `family_semantics_sha256` and `specialization_semantics_sha256`; they are derived mappings of those record fields, never separately mutable identities. Exact source bytes use the shared `source_sha256` field.

`LoopCandidate` contains exact `plan_bytes` and `certificate_bytes`, both immutable bytes. `ConstraintRequestV2` contains additional workspace and optional abstract-storage caps, each null or an exact integer in `0..2^31-1`; it never supplies trusted source caps. The checker derives source constraints from fresh source bytes and intersects each property independently. `LoopLimits` contains source limits plus the exact limits below. All public records reject bool as integer, mutable nested values and unknown versions.

## Source, arithmetic and identities

The new source profile is `axiom-stencil-fixed-buffer-v1`:

```text
1 <= H,W <= 8192
P = (H+1)*(W+1) <= 2^23
O = H*W
input: i32[P], admitted values 0..1023
producer(r,c) = (input(r,c)+1) * (input(r,c)+1)
output(r,c) = ((producer(r,c)+producer(r,c+1))
                +producer(r+1,c))+producer(r+1,c+1)
```

The actual parsed AST, including association, governs computation. The equations above describe the currently supported normalized family. Every source and physical scalar operation uses checked i32 semantics. Producer values are 1..1,048,576; successive output sums are bounded by 2,097,152, 3,145,728 and 4,194,304. Dead operations are still checked and counted. Mathematical index analysis must separately prove that generated i32 arithmetic and checked host byte arithmetic fit their machine domains.

The dimension/cell caps are proposed engineering admission limits, not a language theorem or native memory promise. They cover the existing corpus and leave room for independent scaling controls. The execution profile also requires `0 <= scratch_capacity_cells <= P`, even for hand-authored plans; unused capacity still counts. One complete semantic state is strictly below 64 MiB, and reserved plan scratch is at most 32 MiB. Actual memory/work/evidence budgets remain separate.

On source precondition failure, the result identifies the first invalid input index in canonical row-major order. The complete input and original output remain unchanged. No scratch allocation, scratch initialization or body execution precedes this decision. Only success and input-precondition failure are completed semantic states. Invalid handles, native resource failure, traps, timeout, cancellation and missing acquisition have separate execution-failure records.

Use three distinct identities:

1. `source_sha256`: exact retained bytes, including names, spelling and formatting.
2. `family_semantics_sha256`: versioned canonical shape-independent equations, tensor roles/types, scalar arithmetic and boundary semantics. Alpha-normalize bound names; exclude literal H/W values and optimization preferences. Include the source-profile semantics version. Do not treat arbitrary ASTs as the canonical family.
3. `specialization_semantics_sha256`: family identity plus exact H/W and the versioned specialization contract.

Source constraints and objective have their own canonical identities and effective-cap intersection. They must remain bound to checking/replay even though they are not the value semantics. Source ordering/path fingerprints, generated C, binaries, compiler pins, plan bytes, certificate bytes and execution instances have separate identities. Never substitute one for another. V1 byte formats, hashes, admission limits and replay behavior remain unchanged.

## Task C2: Add explicit scalable source admission and identities

**Files:** Create `axiom/src/axiom/source_profiles.py`; create `axiom/tests/test_source_profiles.py`; modify `axiom/docs/loop-plan-v2.md`.

**Interfaces:** Produce `SourceProfileV2`, `SourceLimitsV2`, `AdmittedLoopKernel`, and `admit_source_v2(source_bytes, *, profile, limits)`. Retain exact bytes and original AST. Use the existing bounded parser and structural validation without modifying the public v1 admission behavior.

- [ ] Write `SourceProfileTests.test_v1_still_rejects_large_shape` and `test_explicit_v2_accepts_training_shape`: the same 32-by-32 source is unsupported through v1 and admitted through explicit v2. Write `test_dimension_and_cell_envelope`: H/W=8193 is rejected, H=8191/W=1023 is admitted at exactly `P=2^23`, H=8192/W=1022 is admitted, H=8192/W=1023 is rejected because P exceeds `2^23`, and nonpositive/bool dimensions are invalid.
- [ ] Write `test_family_and_specialization_identities`: alpha-renaming leaves family/specialization identity unchanged; a shape change preserves family and changes specialization; source whitespace changes exact source hash; changed scalar grouping/range/profile cannot reuse admission. Write `test_caps_derived_from_actual_source`: sources with caps 64 and 0 retain equal value-semantic identities but distinct exact source/constraint identities, and repeated source constraints intersect to their minimum.
- [ ] Run from `axiom/`: `PYTHONPATH=src python -m unittest tests.test_source_profiles -v`. Expected initial failure: missing v2 admission API. Implement the records/admission, preserving declaration-order shape roles and the original canonical scalar profile.
- [ ] Run the same command and `PYTHONPATH=src python -m unittest tests.test_frontend -v`. Expected pass: new boundaries and unchanged v1 tests. Record old representative v1 semantic/hash fixtures unchanged.
- [ ] Review namespace, family/specialization and integer-domain boundaries independently. Commit named files with `feat(axiom): add explicit fixed-buffer source profile`.


## Execution rulings

C2 runs before B1 because B1 consumes the shared profile. C1 has not yet created axiom/docs/loop-plan-v2.md: create that document with only the source-profile/admission section, explicitly leaving proof feasibility unestablished; C1 will extend it. Do not create speculative checker, IR or native APIs. Preserve the public v1 frontend behavior and golden byte identities. The existing bounded parser may be reused, and a minimal private shared structural helper refactor is permitted if necessary with unchanged v1 tests. Never use caller-created AST records as trusted admission.

Use the existing isolated cloud checkout /workspace/BerylLattice on branch work. No new worktree. Work only on this task, use TDD, retain failing and passing evidence in this workspace, self-review, then commit explicit owned paths. Do not spawn subagents; the controller supplies independent review. Run focused tests normally and with -O for public validators, existing frontend tests, and any directly affected regressions. No need to repeat unrelated exhaustive suites per task.

## Report contract

Write full report to .superpowers/sdd/axiom-scalability/task-C2-report.md: status DONE/DONE_WITH_CONCERNS/NEEDS_CONTEXT/BLOCKED, exact commits, files, APIs, RED/GREEN command and evidence paths, self-review, deviations/concerns. Return only status, commits, a one-line test summary and concerns.

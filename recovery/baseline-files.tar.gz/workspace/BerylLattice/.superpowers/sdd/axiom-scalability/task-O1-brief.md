# Task O1: bounded shared blob and invocation transport

## Global Constraints

- Core is the separate 4GL; Axiom is the experimental 5GL. These plans do not publish either confidential project.
- Existing source/plan/state/receipt/export v1 behavior remains unchanged, including native admission being unavailable in v1.
- The large profile admits positive output H and W, each at most 8192, with P=(H+1)*(W+1) at most 8,388,608. O=H*W. All extent arithmetic is checked before consuming streams or allocating buffers.
- Arithmetic is exact signed i32 at every original scalar node; source input values must be in [0,1023]. Whole-input row-major preflight precedes all producer/output work.
- Input is immutable, output is exclusive and disjoint, and every initial-output scalar is preserved on input-precondition failure.
- Source bytes, family semantics, specialized semantics, invocation, physical plan, emitted kernel, executable and individual run have separate identities.
- The shared invocation transport contains no oracle, plan generation, semantic optimization, or measurement computation.
- Canonical evidence uses signed little-endian i32. The host ABI must independently qualify its representation and conversion obligations.
- A completed semantic state has only success or input_precondition_failed. OOM, cancellation, timeout, malformed boundaries, capture failure and oracle exhaustion are distinct non-completed execution/evidence outcomes.
- Semantic store: at most 268,435,456 unique retained bytes, 16,777,216 bytes per file, 1,048,576-byte chunks, 16,384 files. Metadata is at most 1,048,576 bytes per document, depth 16 and 65,536 items. Qualification store: separately at most 536,870,912 unique retained bytes with the same file/chunk/count/metadata bounds. Neither changes v1.
- The semantic bound is per admitted stratum capsule. A campaign binds at most 256 stratum roots and 131,072 files overall, one shared qualification root, at most 8 GiB retained semantic bytes and a separate 1 GiB failure quarantine. Unique-path accounting traverses the complete campaign index, so splitting references across roots cannot evade these bounds.
- Temporary capture disk is at most 256 MiB for the single active acquisition. Reserve space before launch. Filling temporary storage or failure quarantine stops incomplete and preserves existing outcomes; it never authorizes discarding unfavorable samples.
- Every native invocation acquires and compares all required bytes before semantic state may be shared. Identity hashes alone never establish comparison.
- No new test computes or executes fresh held-out data. Use the disclosed training and correctness cases; retain historical primary/thin-shape exposures in plan 04's ledger.
- New code is verified with normal and optimized Python. Product checks use explicit errors, not assertions that disappear under -O.

## Review Focus

- A canonical state reused by hundreds of invocations must not conceal an invocation that never ran or never captured its last bytes; O5 tests acquisition absence and skipped-final-chunk controls.
- A valid typed invocation object whose underlying files are replaced must fail at the oracle/native boundary; O1 and O3 tests mutate verified files after construction.
- Equal logical states do not imply equal exact source identities, and specialization identity cannot substitute for family identity; O1/O3 test renamed sources, changed H/W and forged bindings.
- Source and native failure paths must preserve nonzero initial output and distinguish invalid input from allocation or evidence failure; O2/O6 test multiple invalid cells and injected OOM/capture faults.
- Read amplification from comparison, deduplication and replay must not evade a logical-work budget merely because only one state is stored; O5 tests separate storage, acquisition and logical-read counters.

## Ownership and dependencies

Plan 02 owns source_profiles.py and its admit_source_v2 result, AdmittedLoopKernel. This plan consumes that profile but does not alter the plan checker or its proof rules. Plan 01 owns loop_core_emit.py, core_native_v2.py, and axiom/native/v2/{buffer_host,host_protocol,operation_allocator}.{c,h}; this plan does not create a second host or allocator under research.

The following new files have one owner:

| File | Responsibility |
| --- | --- |
| axiom/src/axiom/artifact_chunks_v2.py | Bounded typed arbitrary-byte blob transport; production-safe dependency. |
| axiom/src/axiom/invocation_v2.py | Exact source/buffer invocation identity and immutable verified transport. |
| axiom/research/source_oracle.py | Interpretation of original source equations over bounded readers. |
| axiom/research/oracle_receipt.py | Bind expected state to actual source invocation and qualified oracle identity. |
| axiom/research/evidence_stores.py | Two-store closure traversal and complete qualification inventory. |
| axiom/research/native_acquisition.py | Validate one native capture and perform independent complete comparison. |
| axiom/research/state_store.py | Share canonical state only after per-invocation comparison; account work. |
| axiom/research/tests/test_large_correspondence.py | Cross-plan source/native integration and fault controls. |

Use existing state_artifacts.py as a versioned dependency; do not refactor it gratuitously. If a new generic blob format needs similar descriptor-relative primitives, put the v2 implementation in the low-level module and retain v1 compatibility tests. Avoid a production import of research modules.

All task commands below run from /workspace/BerylLattice/axiom unless stated otherwise. Prefix Python commands with PYTHONPATH=src:research. Native tests must fail preflight when explicitly requested without qualification; ordinary portable unit discovery may mark a clearly named native-only test unavailable. A skipped native test never satisfies a task's native exit gate.

## O1: Shared bounded blob and invocation transport

**Dependencies:** Plan 02's source-profile contract; plan 01's host transport schema review. Can be implemented before native execution exists.

**Files:** Create src/axiom/artifact_chunks_v2.py, src/axiom/invocation_v2.py, tests/test_artifact_chunks_v2.py, tests/test_invocation_v2.py, and research/protocol/invocation-v2.md.

**Interfaces:**

- BlobReference names an immutable manifest of exact byte length and ordered contiguous chunks, each with length/path/hash. A blob is not a semantic state.
- BlobLimits fixes chunk/file/metadata/count bounds; enclosing stores own aggregate budgets.
- write_blob(blocks: Iterable[bytes], byte_length: int, directory: Path, *, limits: BlobLimits) -> BlobReference.
- verify_blob(reference: BlobReference, *, limits: BlobLimits) -> VerifiedBlob.
- VerifiedBlob.revalidate() and iter_bytes() recheck actual identities; bounded read_i32(index: int) uses checked offsets and little-endian decoding.
- InvocationManifest binds source bytes/hash, family_semantics_sha256, specialization_semantics_sha256, source_profile, H, W, input and initial_output blob references, and explicit disjoint owned-buffer boundary.
- verify_invocation(manifest: Path, *, limits: InvocationLimits) -> VerifiedInvocation.
- VerifiedInvocation exposes source_bytes, source_sha256, family_semantics_sha256, specialization_semantics_sha256, H, W, input, initial_output, invocation_sha256, and revalidate(). Input/output lengths are exactly 4P and 4O.
- Invocation identity hashes canonical source/shape/contract/input/initial-output identities; it excludes physical plan, run, path and timing. Do not confuse it with state-v1's semantic invocation identity: retain an explicit mapping between the two domains.

- [ ] Write test_chunk_transport_exact_coverage, test_chunk_reader_bounds_and_endianness, test_invocation_exact_source_and_family_bindings, test_invocation_extent_rejected_before_iterator_read, and test_verified_invocation_revalidates_mutated_files.

  Assert duplicate keys, booleans as counts, negative/overflowed offsets, missing/overlapping chunks, symlinks and partial final scalars reject. For W=2047/H=2049 assert P=4,198,400 and exact input/output lengths 16,793,600 / 16,777,212. This assertion is arithmetic-only; do not generate the historical primary input in this task. For W=2048/H=2048 assert 33,570,820 combined state bytes. For a forbidden extent, use an iterator that raises if touched and assert zero reads.

- [ ] Run the new tests and retain the intentional RED result:

      PYTHONPATH=src:research python -m unittest tests.test_artifact_chunks_v2 tests.test_invocation_v2 -v

  Expected RED: missing v2 transport/API or a concrete failed boundary assertion, not an unrelated import/environment failure.

- [ ] Implement only the declared format/readers and immutable records. Enforce maximum H/W/P before aggregate arithmetic is converted to a native-size representation. Source/profile checks reparse source bytes through source_profiles.admit_source_v2; compare the resulting three identities, never trust caller hashes. A maximum of two 1 MiB input chunks may reside in the reader cache.

- [ ] Run the command above normally and with python -O; run existing tests.test_frontend and research/tests/test_state.py. Expected GREEN: all portable cases pass, v1 fixtures unchanged, mutation-after-verification rejects.

- [ ] Request independent schema/spec and implementation-quality review, resolve all important findings, then commit only owned files with message: feat(axiom): add bounded v2 invocation transport.

**Stop:** Do not let a dependency ambiguity create two incompatible invocation schemas. Reconcile field names with plan 01 before committing.

`NativeRunV2` has these public fields, agreed with O1/O5:

```text
run_manifest: Path
run_sha256: str
invocation_sha256: str
completion: NativeCompletion
observed_capture: Path | None
timing_raw: Path | None
allocation_raw: Path | None

NativeCompletion = complete | boundary_error | resource_error | unavailable
                 | timeout | cancelled | process_error | acquisition_error
                 | integrity_error
```

`complete` means a normal semantic invocation with complete acquisition: either valid computation or first-invalid source rejection. It is not an oracle match or performance admission. `observed_capture` is required for `complete` and cannot denote an accepted complete observation for any other completion. Resource failure remains `resource_error` even when output was preserved. Diagnostic references may retain partial data without granting it accepted capture status.

The bound run manifest records invocation/build identity, preparation/outcome classification, semantic first-invalid result when applicable, scope receipts, allocator cleanup, supervisor cleanup, process outcomes and retained diagnostics. The bound capture contains the semantic status/index and complete state transport; O5 independently compares it with the source oracle. No other completion class can yield successful semantic or timing admission. Public fields do not leak C pointers, descriptors or allocator internals. Every path, content digest and schema is revalidated on consumption; a dataclass or path string is not evidence authority.

`emit_loop_core` must freshly reparse/admit the supplied source and independently check the candidate under the supplied constraints/limits. A caller-provided accepted flag or mismatched candidate check is not sufficient. `build_native_v2` freshly validates emission provenance and qualification. `invoke_native_v2` freshly validates build/invocation artifacts; metadata never authorizes execution of stored arbitrary argv.

Do not retrofit these results into v1 `NativeRun`, whose success schema requires a Core differential test. Preserve v1 APIs, finite limits and receipt semantics.


## Reviewed dependency and API decisions

C2 source admission (958de943) and B1 host schema (aaa6d2f) are independently approved. Consume source_profiles.py as the single source profile; preserve v1. B2 actual Core seam is independently approved at cf01790. O1 can proceed independently of C1 proof gate and B3 lifecycle; these are different owned files. B6 will consume VerifiedInvocation later and must revalidate actual storage, never trust a declared disjointness flag.

Implement the exact BlobReference/BlobLimits/VerifiedBlob, InvocationManifest/InvocationLimits/VerifiedInvocation public APIs. Additional safe writer helper write_invocation(source_bytes, input_blocks, initial_output_blocks, directory, *, limits) is authorized if needed to establish the required reject-before-iterator-read boundary; document exact signature and identities before handoff. Source and expected extents must be admitted before consuming either iterator. No source range preflight here: out-of-domain i32 input must remain transportable so the real source rejection path can run. Empty generic byte blobs are permitted if schema supports them; input/output counts are always exact nonzero profile counts.

Production modules must not import research. Keep explicit state-v1 identity mapping in protocol documentation and production-safe data only; test equivalence using research state metadata is permitted. A source identity binds exact retained bytes; semantic invocation identity excludes paths, physical plan/run/timing. Blob references/verified records are immutable metadata; revalidation must inspect actual files, and cached reads cannot grant perpetual authority. Bound cache to two input chunks. Every trust-boundary full traversal verifies actual bytes; document stable-file/concurrency assumptions rather than pretending same-UID filesystem immutability. No hash-only comparison or oracle outcome in O1.

The explicit owned/disjoint contract is a required host behavior, not evidence of actual pointer ownership. File-content sharing may be valid transport; it does not authorize heap aliasing. Use secure descriptor-relative bounded path handling, forbid symlinks/escape/unknown schemas, exact integer domains, bounded JSON ingestion before unbounded allocation, and reject altered files after verification. Enclosing stores own aggregate budgets; do not silently widen any profile or v1 budget. Record any format ambiguity before committing; do not invent a second chunk/qualification format.

## Execution discipline

Existing isolated /workspace/BerylLattice on branch work, no worktree/subagents. C1 owns loop proof research/docs; B3 owns native/v2, native tests, B2 fixture retrofit. You own ONLY the five O1 files. No shared schemas are to be changed concurrently. Use TDD, normal and Python-O focused tests plus directly affected v1 frontend/state regressions. Current skills provider is unavailable, but retain the reviewed task/test/review workflow; no need for a plugin install. Request a controller commit window, commit explicit owned paths only, self-review. Full report .superpowers/sdd/axiom-scalability/task-O1-report.md with exact interfaces/schema, commands/logs, RED/GREEN, memory/I/O limits and assumptions, commits/deviations. Return compact status/SHA/tests/concerns.

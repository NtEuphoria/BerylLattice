# O1 independent specification and implementation review

Reviewed commit: `7e72feeed82648b059e6f9884a2ebc56cf0a27a0`.
Parent: `00dd07949d6fa32437c53460cf6a340d8f85567e`.
Exact retained diff SHA-256: `4a5133775e8b5b886175c49d34f696f5e0a02826082a2529a0c83f970b905376`.
The retained diff matches `git diff` of that exact range. Review includes all five
added files, task brief/report, C2 `source_profiles.py`, B1
`core-buffer-contract-v1.md`, and state-v1 identity mapping/test.
Concurrent C1/B3 files are outside this review.

**Specification verdict: CHANGES_REQUIRED.** The on-disk format and source
admission meet the principal O1 requirements, but caller-created verified
records can pass revalidation without satisfying the strict typed/immutable
record contract (finding O1-R1).

**Implementation quality verdict: CHANGES_REQUIRED.** Fix O1-R1 and the
controller-reported portable-test import regression O1-R2 before acceptance.
No product files were edited in this review.

## O1-R1 — P2: equality permits malformed typed records through revalidation

Locations: `axiom/src/axiom/artifact_chunks_v2.py:263-269,334-338` and
`axiom/src/axiom/invocation_v2.py:163-176` (line numbers at reviewed commit).

`ChunkReference` has no field validation, and `VerifiedBlob.revalidate()` only
compares the caller's chunk tuple against freshly decoded metadata using normal
Python dataclass equality. Thus `ChunkReference(0.0, 4.0, valid_path,
valid_hash)` compares equal to the actual integer-valued chunk. A manually
constructed `VerifiedBlob` containing it passes `revalidate()` but its valid
`read_i32(0)` raises `TypeError: slice indices must be integers or None or have
an __index__ method`. This is not a filesystem race or a forged digest: all
underlying files and hashes are valid and stable, and only normal public
constructors are needed.

The invocation boundary has the same issue: replacing `VerifiedInvocation.input`
with a blob containing float chunk offsets/lengths passes invocation
`revalidate()`. Replacing `source_bytes` with `bytearray(original_source_bytes)`
also passes, leaving a mutable retained source value despite the immutable exact
bytes contract. Equality checks establish matching values, not strict record
types. This defeats the required rejection of manually forged typed records at
the very boundary downstream O2/B6 are instructed to call.

A focused Python reproducer using the disclosed 1x1 source, four input scalars,
and output 29 produced:

```text
Malformed float chunk metadata passed VerifiedBlob.revalidate
scalar failed: TypeError slice indices must be integers or None or have an __index__ method
Malformed float chunk and mutable source bytes passed VerifiedInvocation.revalidate
```

Fix by validating caller-held record types and exact primitive domains before
comparison/use: exact chunk record/tuple and integer fields, nested blob/reference/
limits records, exact immutable source bytes, and valid invocation metadata.
Constructors can reject malformed records early, but revalidation must retain
its own trust-boundary checks rather than assume constructor provenance. Preserve
actual-byte revalidation and the two-chunk cache bound. Add focused normal and
optimized tests showing malformed public records reject at the boundary with an
explicit error, and genuine records still read/revalidate correctly.

## O1-R2 — P2: test module requires an extra research PYTHONPATH

Location: `axiom/tests/test_invocation_v2.py:16` at the reviewed commit.

The unconditional `from state_artifacts import StateMetadata` works under the
O1-specific `PYTHONPATH=src:research`, but fails ordinary portable unit discovery
under `PYTHONPATH=src python -m unittest discover -s tests -v`. The controller
reported this concrete failure from B3's full suite and assigned the original
implementer a separate fix. This review did not duplicate that run or edit.
Retain the legitimate state-v1 equivalence test using the established test-only
research import convention; production must continue not to import research.
Review the exact follow-up test change and its src-only normal/-O evidence.

## Evidence and compliant behavior

Inspected `/tmp/O1-red.log`, `/tmp/O1-green.log`, `/tmp/O1-optimized.log`,
`/tmp/O1-v1.log`, and `/tmp/O1-v1-optimized.log`. RED is the intended missing O1
module. Retained GREEN shows 12 focused tests in normal and optimized Python,
and 28 frontend/state regressions in each mode. The controller also retained
these logs under `.superpowers/sdd/axiom-scalability/retained-o1-logs/`.
No broad suite was rerun: only the new focused O1-R1 reproducer was executed.
The reviewed tests do not cover the forged typed-record case above.

The serialized manifest route strictly rejects duplicate/unknown keys,
noncanonical JSON, floats/nonfinite values, bool counts, oversized integer tokens,
metadata byte/depth/item violations, and invalid coverage. File traversal is
descriptor-relative and NOFOLLOW for all components, with regular-file and
bounded-size checks, before/after fingerprints, and actual content hashing.
Missing/FIFO/directory files, symlink leaves/ancestors, and changed files have
focused rejection tests. Writer names use exclusive creation; malformed blocks
or failed iterators leave no newly accepted final manifest. Aggregate inventories
remain the enclosing store's responsibility.

Source bytes are freshly admitted through the existing C2 API. Shape/product and
exact lengths are checked before buffer streams; invalid source values (-1/1024)
remain transportable signed-i32 values. Family, specialization and exact source
identities are distinct and freshly compared. The invocation digest excludes
paths/chunking/physical execution, and tests verify re-chunk/relocation equality
and exact-source inequality. State-v1 mapping matches the existing canonical
preimage without widening v1 admission. B1's buffer contract string correctly
states required host behavior and makes no claim of established heap ownership.

The reader's two-entry cache and complete-traversal hashing are implemented;
cache hits reopen/stat files. Transient chunk/join buffers and source retention
are additional bounded memory, as documented. Per-scalar stat cost and repeated
full traversals are explicit limitations. Stable-file/same-UID concurrency
assumptions are appropriately limited; this review does not demand an OS
snapshot or treat file mode as immutability. No O2/oracle, semantic comparison,
native execution, or performance claim is made.

## Product file SHA-256 at reviewed commit

| File | SHA-256 |
|---|---|
| `axiom/src/axiom/artifact_chunks_v2.py` | `1e28637459e44bb9887b4b476f615b846e0905051e4c2db425a67de748c12b1c` |
| `axiom/src/axiom/invocation_v2.py` | `b893f67e87ab315edea64b903121d05e814461f849e7bc6a7a6cd794a75fa554` |
| `axiom/tests/test_artifact_chunks_v2.py` | `2c34bffe060183ab30746688a3caa3e83faaaf1ad31d3794135780213c29f14d` |
| `axiom/tests/test_invocation_v2.py` | `f70868b18474df5edafad7e5967da37c728a80056e8d51ac51bb57810cdcbfb8` |
| `axiom/research/protocol/invocation-v2.md` | `86de1c3425ef1849f7ddbe53e1479e3930ac35df076be1b60b8b2d8f991f2e7b` |

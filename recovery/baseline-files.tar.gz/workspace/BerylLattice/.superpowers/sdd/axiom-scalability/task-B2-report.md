# B2 implementation report

Status: DONE

Accepted B1 dependency: `aaa6d2f2c87ff47ee15c7f4f0bc809a45846831c`.
Actual parent for this scoped commit: C1
`0e3c6b7d6a451cb74d6caa8666b817d3d56544d3`.
Commit: pending (recorded below after scoped commit).

Existing `/workspace/BerylLattice`, branch `work`; no worktree or subagents.
Controller granted the B2 commit window after C1 completed. Only these three
new B2 paths are in the product change:

- `axiom/src/axiom/core_native_v2.py`
- `axiom/tests/test_core_native_binding_v2.py`
- `axiom/tests/fixtures/core_native_v2/tiny-binding-host.c`

B1 fixtures/contract, v1 code and concurrent C1 files are unchanged by B2.
The onboarding and cloud runtime skills were consulted; the existing exact
qualified toolchain was reused after loading/revalidation, without rebuilding
Core or changing environment/toolchain configuration.

## Private APIs and binding

`NativeBindingUnavailable` is a typed private binding gate. `_FixtureBinding`
is a frozen record; `_bind_fixture(toolchain, sources, generated_c)` binds
ordered source paths and SHA256s, generated C SHA256, pinned source inventory,
Core and Clang executable hashes, original qualification receipt path/hash,
runtime source/header/regenerated embedded-runtime hashes, qualified helper
names/symbols, actual typedef, signatures and target/layout version.
`_validate_binding` revalidates toolchain identity and exact current binding
bytes; `_binding_assertions` renders only the supported pin/declarations.
These are the smallest seam qualification helpers, not a production worker,
complete runtime manifest format, source emitter or arbitrary-kernel binder.

The actual public Core CLI emitted 6,206 stdout bytes from the independently
hand-written B1 `tiny-1x2.be`; stderr was empty and exit status 0. Those bytes
are retained exactly as `emit-c.stdout` and `generated.c`, and the unchanged
file is included in the host translation unit. No internal frontend/lowering
entry, regex rewrite, direct-C stencil replacement or descriptor cast is used.

The actual typedef is `be_t_List_3ci32_3e`, with expected field types
`int32_t *`, `int32_t`, `int32_t`; data/len/cap offsets 0/8/12; size/alignment
16/8. C11 `_Generic` asserts every field type and both actual function-pointer
types, including const input descriptor pointers and mutable output/scratch
pointers. `_Static_assert` also checks Linux/x86-64, C11, CHAR_BIT=8,
sizeof(int32_t)=4, pointer size=8 and the complete expected descriptor layout.
Top-level parameter restrict does not weaken any assertion.

Both helpers have their actual deterministic qualified C symbols. The selected
Clang compiled with `-std=c11 -O0 -fvisibility=hidden` and strict errors for
incompatible pointers, implicit declarations and integer conversions. Exact
argv, cwd, exit status, stdout and stderr are retained for all commands.

## Tiny execution and explicit lifetime

The fixture executable admits only process operation `invoke`, followed by
exactly eight runtime i32s (six input and two initial output values). Host
malloc/initialization establishes sole retained input/output ownership; their
actual emitted descriptors are borrowed by the private checked function.
Preflight precedes scratch allocation. Success allocates/zeros six scratch
cells, invokes the real emitted body, checks all descriptor pointer/length/
capacity fields and frees the original scratch owner. Source rejection checks
metadata without scratch allocation/initialization/body. Full input/output
acquisition follows the checked function, then input/output are explicitly
freed; Python compares every acquired value against independent B1 cases.
The observed C events describe this fixture lifetime; they are not independent
allocator accounting/interposition or measured timing receipts.

| Native case | First bad index | Complete acquired output | Complete input |
|---|---|---|---|
| valid [0,1,2,3,4,5] | none | [46,74] | unchanged |
| minimum [0,0,0,0,0,0] | none | [4,4] | unchanged |
| maximum [1023,1023,1023,1023,1023,1023] | none | [4194304,4194304] | unchanged |
| first-invalid | 0 | [-99,77] | unchanged |
| last-invalid | 5 | [-99,77] | unchanged |
| multiple-invalid | 1 | [-99,77] | unchanged |

Five helper-selection requests (short and qualified body/preflight names and
an extra-operation string) exit 64 with no stdout. The readelf/nm evidence
shows helpers local/hidden and absent from defined dynamic exports for this
executable profile. There is no same-process hostile caller sandbox claim or
shared-library export qualification.

## TDD and final verification

From `axiom/`, the final required-native command was:

```sh
AXIOM_TEST_CORE=/workspace/beryl \
AXIOM_TEST_CLANG=/workspace/scratch/cloud-onboarding-native-20261016/toolchain/usr/lib/llvm-19/bin/clang \
AXIOM_V2_REQUIRE_NATIVE=1 \
AXIOM_V2_BINDING_EVIDENCE=/workspace/scratch/axiom-B2-native-binding \
PYTHONPATH=src python -m unittest tests.test_core_native_binding_v2 -v
```

- `task-B2-red.txt`: exit 1, 11 intended missing-implementation failures.
- `task-B2-red-evidence.txt`: exit 1, missing retained LLVM evidence assertion.
- `task-B2-red-manifest.txt`: exit 1, two manifest pin/signature rendering
  guards not yet implemented; corrected before final validation.
- `task-B2-green.txt`: exit 0, 13 tests passed with real native prerequisites.
- `task-B2-optimized.txt`: same command with `python -O`; exit 0, 13 passed.
- `task-B2-regressions.txt`: exit 0, 50 tests passed using
  `PYTHONPATH=src python -m unittest
  tests.test_core_toolchain.ToolchainNegativeTests
  tests.test_core_toolchain_load.StrictToolchainReceiptTests
  tests.test_core_emit tests.test_core_runner tests.test_core_buffer_contract_v2 -v`.
- `task-B2-required-native-red.txt`: both explicit selectors removed and
  `AXIOM_V2_REQUIRE_NATIVE=1`; expected setup failure before any execution,
  unittest exit 5 (zero tests, one setup error). This is a fail-closed control,
  not positive native evidence or a skip.
- `git diff --check` and scoped staged whitespace check passed.

Binding controls actually compile negative translation units, never execute
mutants and preserve failed Clang argv/stderr: wrong symbol (undeclared),
removed input const (both function assertions fail), wrong body return
signature (body assertion fails), altered len type/layout (field/size checks
fail), separately declared identical-looking descriptor (strict incompatible
pointer error). Modified generated-C bytes and wrong Core pin are rejected by
binding identity gates before execution; guard receipts retain their observed
errors. An additional manifest-rendering test rejects false pin/signature
claims. Native prerequisites cannot become positive qualification via skips.

## Retained evidence and identity closure

Final normal evidence:
`/workspace/scratch/axiom-B2-native-binding/axiom-B2-binding-w199uac8`.
Final optimized evidence:
`/workspace/scratch/axiom-B2-native-binding/axiom-B2-binding-xpk439j7`.
The evidence path is printed by every actual native run. Earlier RED/first
GREEN directories remain available under the same parent, with exact logs.

The final normal semantic store contains 26 inventoried files, 9,344 total
bytes including inventory; qualification store contains 78 inventoried files,
553,409 total bytes including inventory. These are respectively below 256 MiB
and 512 MiB; every file fits a single 1 MiB chunk. Inventory records path,
size, SHA256 and mode, and sealing rejects symlinks/oversize files, verifies
actual inventory and hashes, and makes evidence read-only. Original qualified
tools remain at their receipt-bound paths; the copied original receipt binds
that preexisting external qualification closure rather than claiming to copy
all compiler dependencies into this tiny store. O1 owns general chunked
artifact transport and large-file materialization.

Before/after each admitted native run, all selected Toolchain identities and
binding bytes are revalidated. The actual executable and full local compile
inputs (generated C, assertions, host, runtime h/c) have retained path/hash/
size/mode identities, verified before/after use. Their sealed files were also
independently rechecked after the run; recorded execution modes still match.

| Final artifact | bytes | SHA256 |
|---|---:|---|
| generated.c | 6206 | 58df74f30528c4ea691c631cde2317c6ebb398da9b589683dfcc857ed5875965 |
| qualified/worker | 23400 | e9f97cbe90a469508c90aff326b9696f56ae5c8dff630bd2094fbc6a37118f11 |
| qualified/worker.ll | 84960 | 5401c5b5f2451f5d8718f68b99d0f84a3329b677af99bf0f91a68c1066bbeba2 |
| qualified/worker.s | 64196 | 85e71f97a6698a9b8e260629bf4971039f76d928798cebe8b1f7fd995101e453 |

## Self-review and limits

`task-B2-boundary-review.txt` retains actual emitted code, observed LLVM
helper/caller boundary lines and symbol tables. Reviewed emitted preflight
range/value predicates/first index, List get/set bounds accesses, explicit
checked producer additions/multiplication and checked left-associated output
sums against the hand source. Retained LLVM shows hidden helper signatures,
preflight/body calls in the private checked function, and host lifetime calls;
this inspection is not an independent allocation-absence proof. The emitted
translation unit contains an unused List push helper and full runtime, which
are preserved unchanged. No absence-by-substring allocation claim is made.

The reused exact toolchain still records two known pinned Core unit failures:
`IR: initialized SET destination remains readable during later scalar capture`
at `tests/unit/test_ir.c:15` and `:50` (2 of 10,814 checks, 583 cases). It is not
fully green. These baseline failures did not affect this actual emission and
private binding qualification. Compiler/config/known-component identities and
runtime regeneration are bound; transitive SDK/linker/dynamic dependencies are
not a complete hermetic closure. Path-sensitive source identities are kept
apart from generated-byte and executable hashes. Relocation and hostile
same-UID immutability are not established.

No unresolved B2 failure or demonstrated Core inadequacy; B8 was not triggered.
B3 must implement production owned invocation/allocator integration; B7 must
independently qualify allocations/interposition. This tiny successful seam is
not a large-shape, allocation-measurement, oracle, timing, performance,
production binding or publication qualification. Controller independent review
remains separate from this self-review.

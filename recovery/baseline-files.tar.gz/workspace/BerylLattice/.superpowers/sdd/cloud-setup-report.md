# Reusable cloud setup implementation and verification

Date: 2026-10-16 UTC. Scope: `tools/setup-cloud.sh` and
`docs/cloud-environment.md`; this ignored report records verification evidence.
No Core source, test, dependency, repository configuration, earlier artifact,
cloud environment configuration, global package database or Git commit was changed
by this setup implementation.

## Implementation

`/workspace/BerylLattice/tools/setup-cloud.sh` requires Python >=3.12, sets its
own `PYTHONPATH`, and performs one minimal `axiom check` by default. The prototype
needs no third-party Python dependencies. `--native` validates the exact clean
Core pin, selects the expected Clang binary/configuration, invokes the public
`inspect_toolchain`, `prepare_snapshot`, and `build_core` APIs, and retains fresh
snapshots/command receipts/native evidence on every invocation. Configuration
candidates are checked before the selected driver is executed; unexpected files
block setup. Existing installations are not overwritten.

On the current Debian 13 amd64 development image, a missing private installation
uses a rootless, isolated APT configuration. HTTPS and Debian signed metadata
verification remain enabled. Six exact versions and SHA256 values from the
previous authenticated receipt are embedded in the script, and all package
identities/hashes are checked before extraction. Bootstrap logs, authenticated
APT metadata, downloaded debs, installed host package versions and package
receipt are retained. The full native qualification builds actual Core, runs
the actual unit suite, and requires native witness execution plus IR/assembly/
driver-job captures. No synthetic successful receipt substitutes for execution.

Suggested environment `install_script` (parent owns draft configuration writes):

```sh
bash /workspace/BerylLattice/tools/setup-cloud.sh
```

## Commands and observed outcomes

```sh
bash -n /workspace/BerylLattice/tools/setup-cloud.sh
bash /workspace/BerylLattice/tools/setup-cloud.sh
```

Both exited 0. Python was 3.12.14; default example returned `status=admitted`,
height 5, width 7, semantic digest
`17692e7e1022cc35edf4d6f0e4f0a42fdd8252f836e5b01f933854236198ac26`.
Default setup took approximately 0.08 seconds; no full portable suite was run
as part of this smoke check.

```sh
bash /workspace/BerylLattice/tools/setup-cloud.sh --native \
  --core /workspace/beryl \
  --prefix /workspace/scratch/cloud-onboarding-native-20261016
```

Exited 0. This actually executed `bootstrap-signed-apt` in a new private prefix,
including a new authenticated index update, all six package downloads, pinned
SHA256 and package identity verification, and rootless extraction. It did not
reuse the previous bootstrap directory. APT fetched 16.3 MB of metadata and
15.5 MB of packages from `https://deb.debian.org/debian`. Evidence root:

`/workspace/scratch/cloud-onboarding-native-20261016/qualification-57lxdp8j`

Final receipt:

`/workspace/scratch/cloud-onboarding-native-20261016/qualification-57lxdp8j/receipts/toolchain.json`

```sh
bash /workspace/BerylLattice/tools/setup-cloud.sh --native \
  --core /workspace/beryl \
  --prefix /workspace/scratch/cloud-onboarding-native-20261016 \
  --clang /workspace/scratch/axiom-toolchain-setup/toolchain/usr/lib/llvm-19/bin/clang
```

Exited 0. This actually executed `reuse-explicit`, checking the previous selected
Clang binary/configuration before execution and performing another fresh C11
probe, Core snapshot/build/unit/native qualification. Final receipt:

`/workspace/scratch/cloud-onboarding-native-20261016/qualification-nmu16_9d/receipts/toolchain.json`

The no-`--clang` reuse of an existing private installation (`reuse-private`)
shares the same identity/preflight/build path but was not separately executed.
The signed bootstrap and explicit reuse branches above were both executed.

For both completed native runs:

| Observation | Result |
| --- | --- |
| C11 compilation and witness execution | Passed |
| Core debug build | Exit 0 |
| Actual Core unit suite | Exit 1, `known_pinned_baseline_failure` |
| Actual Core native witness/evidence qualification | Exit 0 |
| Retained qualification artifacts | 8, bound by hashes |
| Core pin | `0a678b4ae6d41190c4f5a8bf063caba05759d20d` |
| Selected Clang SHA256 | `0a3c55936ac43954fbe4914e6e73b577ca9e35e75d89ef13d3e28c187f41ca1a` |

The Core unit suite remains failed: 2 of 10814 checks across 583 cases in
`IR: initialized SET destination remains readable during later scalar capture`,
with BE0401 overlapping exclusive borrows of `n`. The public API classified
the exact known baseline failure; the original return code and full diagnostics
remain in `receipts/unit.json`. No unit-green claim is made. Unexpected failure
patterns continue to block qualification.

Loaded both completed receipts through `axiom.core_toolchain.load_toolchain`
and invoked `revalidate_identity()` again; both passed. This validated retained
command consistency, source/configuration/binary/component identities and
qualification artifact hashes without rerunning receipt-supplied arguments.

Manual negative checks invoked the script through Python `subprocess.run`,
asserting return code 1 and the specified error:

1. `--native --prefix /workspace/scratch/cloud-onboarding-negative-20261016 --core /workspace/BerylLattice`:
   rejected unexpected Core pin before bootstrap or native execution.
2. `--native --prefix /workspace/scratch/cloud-onboarding-negative-20261016 --clang /usr/bin/false`:
   rejected unexpected Clang hash before selected-driver execution. Retained
   `qualification-isas2hlf/setup-failure.json` under that prefix.
3. Same negative prefix and `--clang` pointing to the verified prior installation,
   with `CLANG_CONFIG_FILE_USER_DIR` set to a disposable directory containing
   `unexpected.cfg`: rejected unexpected configuration candidates before driver
   execution. Retained `qualification-s0kynabo/setup-failure.json`.

After qualification, checked `git -C /workspace/beryl rev-parse HEAD` and
`git -C /workspace/beryl status --porcelain --untracked-files=all`: exact expected
pin and empty output. Original Core checkout remains untouched and clean.
`git diff --check -- tools/setup-cloud.sh docs/cloud-environment.md` passed;
new file paths were still untracked at this subtask's handoff.

## Limits

The current image supplies GCC support, headers, SDK/linker and runtime libraries.
Selected executable/configuration bytes and observed loaded compiler libraries
are identified; complete transitive SDK/linker/runtime identity is not claimed.
This is actual local Core/toolchain qualification, not Axiom conformance or
native performance admission. Existing development packages remain necessary
for rootless bootstrap; unavailable pinned packages or dependencies fail closed.

Cloud onboarding instructions were previously read/applied by the parent. This
subtask reused the established trusted setup report and commands, with stricter
package identity checks and the public qualification API. The parent retains
ownership of reading/preserving current cloud draft configuration and saving a
reviewable draft. No configuration publication was performed here.

Local files or local-only commits do not establish fresh-task restorability.
The script must be present in the selected remotely restorable repository
revision before a fresh task can rely on the proposed install command. No
fresh-task restoration was claimed or tested.

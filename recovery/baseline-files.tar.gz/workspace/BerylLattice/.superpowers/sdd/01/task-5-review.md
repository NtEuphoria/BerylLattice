# Plan 01 Task 5 review

Reviewed commit `4e81e5d20d95905a0952461a063e6866f2ba08bd` and the four files in `task-5-review-package.txt`, against `task-5-brief.md`, the implementer report, and `/workspace/scratch/axiom-program-2026-10-15/prototype-contract.md`. Implementation files were read only; this review report is the sole written artifact.

## Spec compliance verdict: approved

No blocking findings. `make_plan` supports exactly the three required generator IDs, in the specified stable order. The implementations emit actual explicit operations using public plan records, without importing the checker or reference evaluator. All producer occurrences consist of one input load, one increment, and a multiplication of the increment by itself. Consumer additions retain the admitted left-associated source structure. One common constant is permitted by the contract.

The schedules themselves match their names and resource claims. Inline produces the four neighbors per output without scratch. Materialization reserves and fills the full producer domain. The ring schedule reserves exactly two rows; at `planner.py:81–88`, all columns of an output row complete before `stage(row+2)` can overwrite its retired producer row. This also handles height one, width one, and tall or wide input domains. H5/W7 gives arena capacities 0/16/48 cells, workspace bytes 0/64/192, and independently counted multiplication opcodes 140/48/48.

Origins use retained AST byte offsets rather than generated text or physical operation positions. The contract specifies integer source-origin IDs without mandating a separate allocation scheme, so the documented choice is acceptable. Extra grouping nodes are removed only for locating the admitted operator structure; consumer operator grouping is preserved. No Core source changes or public unchecked execution API are introduced. The extra `tests/plan_interpreter.py` is appropriately confined test infrastructure.

The conformance corpus is independent of planner expectations: literal source fixtures are parsed into the retained AST, the reference evaluator interprets that AST, and a separate numeric interpreter executes each serialized and decoded operation stream. Scalar arithmetic in the interpreter checks exact i32 after every defining operation. Planner test expectations count actual `mul` opcodes and explicit reserved cells, rather than trusting generator costs or classifying producer expressions.

Coverage counts in the report agree with the loops: 81 + 729 + 729 + 19,683 = 21,222 exhaustive source inputs; 64 shapes times 32 cases = 2,048 seeded inputs; nine edge shapes times three vectors = 27 inputs. These total 23,297 inputs and 69,891 executions across three schedules, separately from earlier probe receipts. The all-admitted-shapes test counts 955 shapes and 2,865 generated streams; its structural checks are distinct from the source-oracle numeric corpus.

Serialized mutations exercise the actual plan decoder/checker boundary. Wrong-neighbor and one-row alias mutations have coordinate-sensitive numeric counterexamples while the checker conservatively returns unknown. The early overwrite targets a slot still live for the next output, rather than a semantically dead retired slot. The commuted increment is equivalent and is correctly expected to return unknown with no fabricated witness. The report retains concrete source and mutant output vectors.

## Code quality verdict: approved

No blocking findings. The implementation is small and direct, keeps generation outside the checker trust boundary, and centralizes dense SSA allocation and origin attachment in `emit`. Scratch capacity and schedule ordering are explicit. There are no product `assert` checks, source execution calls, hidden scratch reservations, or new runtime dependencies. Immutable public plan records are reused rather than duplicated.

The independent interpreter is deliberately simple and checks initialized scratch, dense definitions, unique output writes, complete output coverage, and scalar range. Its callers pass checked valid streams for positive cases and deliberately decoded mutants for negative cases. It does not become a public runtime entry or confuse scratch-only accounting with total process memory. No separate quality changes are requested.

## Verification

The reported normal and optimized nine-test runs and the 87-test discovery receipt were inspected, not rerun unchanged. The five discovery skips concern explicit native toolchain selection and do not suppress Task 5 tests.

A new targeted probe ran from `axiom` with `PYTHONPATH=src`, using shapes `(2,84),(84,2),(3,63),(63,3),(4,50),(50,4),(6,35),(35,6)`. These near-limit aspect ratios extend beyond the seeded H/W 1..8 numeric corpus. The probe renamed tensors, inserted a multibyte UTF-8 comment, added redundant groups, and used a coordinate-sensitive input vector. For all 24 specializations it:

- compared the physical interpreter output against the source-AST evaluator;
- independently checked the generated stream under an unrelated plan label;
- traced producer input lineage and verified that every ring refill of row two or later followed completion of its entire consuming output row.

Result: all 24 specializations passed. This is supplementary targeted evidence, not a claim of an all-shape theorem. No additional implementation defect was found.

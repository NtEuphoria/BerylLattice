# Task 7 independent review

Verdict: **changes required** — one P2 exact-replay binding defect. Reviewed both
spec compliance and code quality against the Task 7 brief and binding
`/workspace/scratch/axiom-program-2026-10-15/prototype-contract.md`.

## Finding

**P2 — Fresh replay receipts can identify different plan bytes from those replayed.**
`axiom/src/axiom/evidence.py:312–322` decodes the retained bytes, invokes
`check_plan`, and returns its result without checking the fresh plan digest against
the manifest. The plan decoder accepts whitespace/noncanonical JSON, whereas the
checker hashes the canonical `encode_plan` representation. Consequently a canonical
manifest naming a noncanonical plan snapshot passes exact replay and returns an
eligible `CheckResult` whose `plan_digest` differs from the supplied snapshot's
SHA-256. This breaks the contract that a returned receipt binds the exact retained
artifact, although the decoded operations still receive a fresh semantic check.

Targeted reproduction on H5/W7: publish normally; set `raw = b' ' +
result.selected_plan_bytes + b'\n'`; replace the manifest's `plan_digest`,
`plan_file`, and matching saved/attempt check digests with `sha256(raw)`; encode the
manifest canonically; call `replay(source, raw, manifest, Limits())`. Observed
`eligible=True`, input digest `da17be5bd4b84ca1badf26742afdf638fa36b172c957f4a0d96f3375aad59a43`,
returned digest `387c2ee208975f0a73f325d36765d09d8b08e94158196932dd41c674b53886e8`.
All reference files can also be published under their new names, so CLI reference
verification does not resolve this discrepancy.

Reject noncanonical plan bytes with a typed identity/format diagnostic before
returning a receipt, or explicitly reconcile fresh and retained exact identities.
Add a regression that changes both the snapshot and coherent manifest identities;
the existing whitespace tamper test retains the old manifest and cannot catch it.

## Other reviewed behavior

Source/semantic/constraint/ranking/version binding, source-cap preservation and
additional-cap forwarding, fresh checks rather than saved-history proof, forged
public selected-record rejection, null no-eligible selection, bounded decoding,
JSON routing/exit classes, and manifest-last publication were traced through the
implementation. No further blocker found. Pinned no-follow directory descriptors
constrain mutations through ancestor replacement; external subsequent content
mutation is expressly detected rather than prevented. No shell execution exists.

Additional fresh probes: maximum 256-cell input (`H=1,W=127`) evaluates successfully
through the CLI; a published plan replaced by a symlink is rejected by reference
verification. Did not repeat the reported 20 normal/optimized or 61 dependency
tests, nor the concurrent 955-shape selection validation. No product files edited.

## Scoped round 1 fix rereview

Verdict: **approved** — the P2 is resolved; no new important defect found in the
fix. Reviewed `task-7-fix.diff` and the appended report of 22 passing normal and
optimized tests. The added canonical-byte equality guard closes the exact-byte
identity gap before checking and returns the specified typed `$.plan` diagnostic.
The change preserves general decoder behavior and does not alter the emitter.
New regressions coherently rewrite manifests and publish matching references,
covering the original failure instead of an incidental old-hash/missing-file error.

Fresh independent probe reran the original coherent-whitespace reproduction: it
now raises `REPLAY_IDENTITY_MISMATCH` at `$.plan`. Canonical replay with additional
caps null, 0 and 192 still produces respectively valid/satisfied, valid/violated,
and valid/satisfied results, each with `plan_digest == sha256(input_plan_bytes)`.
Did not repeat the reported 22-test suites or broaden the review beyond this fix.

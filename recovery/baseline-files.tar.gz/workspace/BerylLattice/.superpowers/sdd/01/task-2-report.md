# Plan01 Task2 implementation report

Owned deliverables:
- `axiom/src/axiom/reference.py`
- `axiom/tests/test_reference.py`
- `axiom/tests/fixtures/inputs/boundary_cases.json`

Implemented the public `evaluate_source(module, data, initial_output) -> ExecutionResult`. Every invocation first calls `admit_source`; unsupported source raises its admission diagnostic before any runtime boundary inspection. The evaluator independently interprets retained original AST nodes and original declaration/axis names, using exact Python arithmetic with explicit i32 checks per visited scalar node. It imports no planner/checker/plan-format modules.

The public result is a frozen dataclass with `status`, `first_bad_index`, `output`, and `input_after`; status uses `ExecutionStatus` (`success`, `input_precondition_failed`). Boundary errors use `DiagnosticError(code, span, message)` with codes `BOUNDARY_TYPE`, `BOUNDARY_LENGTH`, `BOUNDARY_I32`, and `BOUNDARY_ALIAS`. Owned exact tuple/list containers are accepted, scalar types must be exact `int`, every input and initial output scalar must fit i32, and caller containers are unchanged. All input range preflight completes before any equation visits or destination computation; precondition failure returns the complete destination snapshot and first row-major bad index.

Shared APIs consumed: `frontend.admit_source`; model SourceModule, immutable expression and equation records, Span, DiagnosticError. Kernel height/width/input_interval are used only for checked boundary dimensions/range; scalar equations, bounds, names and reads are evaluated from original AST.

TDD evidence:
- `PYTHONPATH=src python -m unittest tests.test_reference -v`: observed expected missing `axiom.reference` failure before implementation (task-2-red.log).
- Same command after implementation: 12/12 pass.
- `PYTHONPATH=src python -O -m unittest tests.test_reference -v`: 12/12 pass.
- `PYTHONPATH=src python -m unittest discover -s tests -v`: 35/35 pass at this task boundary (task-2-suite.log).
- `PYTHONPATH=src python -O -m unittest discover -s tests -v`: 35/35 pass (task-2-suite-optimized.log).

Coverage includes exact outputs 4/4194304/7, coordinate-sensitive H5/W7 oracle, alpha-renaming, all invalid input positions, unchanged complete destinations, exact boundary types and i32 extents, original admission rejection, dependency imports, and actual interpreter call tracing.

Ruling: use `sys.setprofile` in the test to observe actual equation evaluator visits rather than the brief's proposed production test callback. Invalid final input cell yields zero visits; valid input yields visits. This follows the parent's explicit instruction to avoid test-only production interfaces. Cost if wrong: test tracing may need adaptation if the private helper is refactored.

No commits made; parent serializes commits. No unresolved failures or known concerns within Task2's admitted profile.

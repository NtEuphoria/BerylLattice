# Authorized implementation task

The user explicitly requested implementation of all three reviewed plans. Earlier planning-only restrictions no longer block implementation. Work in /workspace/BerylLattice.

# Axiom Correctness Prototype Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking. Native execution is recommended for this first tightly coupled prototype; no implementation is authorized by this planning document alone.

**Goal:** Parse one declarative stencil family, independently check three physical plans, select only eligible plans and replay exact evidence.

**Architecture:** Python owns a small source AST, independent source evaluator and immutable explicit physical plans. A checker reconstructs expressions and storage facts from actual operations; the planner is outside its trust boundary. Core lowering is the next plan, not a dependency of this executable correctness prototype.

**Tech Stack:** Python 3.12+, standard library, `unittest`, deterministic canonical JSON and SHA-256.

**Spec:** [Prototype contract](../../../prototype-contract.md), implementing the [foundation design](../../../../axiom-foundations-2026-10-15/axiom-v0-design.md).

## Global Constraints

- Axiom is the distinct language; Core's source repository remains unchanged in this plan.
- One canonical two-stage stencil; input [H+1,W+1], output [H,W], H/W positive and input cells <=256.
- Input interval [0,1023]; exact i32 per scalar node; output range [4,4194304].
- Preflight scans row-major before plan computation/output writes; failure preserves complete output and first invalid index.
- `plan_workspace_bytes` counts only the reserved scratch arena; SSA values and native memory are excluded. The valid SSA-staged positive control exposes that limitation.
- Formats and checkers are versioned; unknown, unsupported and invalid are distinct.
- Limits: source bytes 65536; plan bytes 2097152; plan operations 20000; expression nodes 100000; check steps 100000 by default.
- No solver, learned model, third-party package, general DAG lowering, unchecked public entry or public release.
- Tests and diagnostics must work under Python `-O`; product checks use explicit conditions, not `assert` statements.

## Review Focus

- UTF-8 comments before an error: byte offsets must identify the actual source bytes; Task 1.
- JSON duplicate keys, booleans masquerading as integers and oversized integer tokens: reject before execution; Task 3.
- A valid but structurally different expression: return unknown rather than false inequivalence; Task 4.
- Exhaustion immediately after a valid incumbent and stale cap on replay: preserve only independently eligible artifacts; Tasks 6–7.
- Additional reserved but unused scratch: account for it and reject a violated cap; Task 4.

## Files and boundaries

All implementation paths below are relative to future `/workspace/BerylLattice/axiom/`. Do not create them during research planning.

```text
src/axiom/model.py          source records, spans, diagnostics and limits
src/axiom/frontend.py       lexer/parser and canonical profile admission
src/axiom/reference.py      source-AST evaluation and checked boundary
src/axiom/plan_format.py    immutable plan and operation types
src/axiom/codec.py          strict versioned decoding/canonical encoding
src/axiom/checker.py        independent symbolic/storage/range checker
src/axiom/planner.py        three physical plan constructors
src/axiom/selection.py      budgets, ranking and incumbent state
src/axiom/evidence.py       exact replay and atomic artifact publication
src/axiom/__main__.py       CLI, no duplicated compiler logic
tests/test_*.py             tests owned by the corresponding tasks
tests/fixtures/            source/plan/negative-control artifacts
examples/stencil.ax        the contract's H5/W7 example
docs/prototype.md           exact supported contract and commands
```

Run commands from this future root with `PYTHONPATH=src`. Each task ends with a local commit of only its named files after checking the diff. Do not push. If the checkout is still unborn, create its first local commit only when implementation begins; follow the workspace skill then. Keep generated receipts outside tracked source unless deliberately small fixtures.


### Task 5: Three generators and positive/negative conformance

**Files:** Create `planner.py`, `tests/test_planner.py`, `tests/test_conformance.py`.

**Interfaces:** `make_plan(kernel: AdmittedKernel, plan_id: str) -> Plan`; supported IDs exactly `inline-v1`, `rows2-v1`, `materialize-v1`. Use plan types/codec; no calls into checker internals or source oracle implementation.

- [ ] Write tests asserting H5/W7 workspace capacities 0/16/48 cells and producer occurrences140/48/48. Check output correctness through Task4 and independent numeric interpretation in tests; do not let the planner manufacture its own expected values.

```python
k = admit_source(parse_source(stencil_source(5, 7, None)))
expected = {'inline-v1': (0, 140), 'rows2-v1': (64, 48),
            'materialize-v1': (192, 48)}
for name, counts in expected.items():
    checked = check_plan(k, make_plan(k, name), Limits())
    assert checked.semantic_status == 'valid'
    assert checked.constraint_status == 'satisfied'
    assert checked.check_complete
    assert (checked.workspace_bytes, checked.multiplication_ops) == counts
```
- [ ] Write mutations of the serialized operation stream for wrong neighbor, one-row alias and early overwrite. Require checker invalid/unknown as justified and retain actual numeric counterexamples from the independent source evaluator where available. A mutation that is semantically equivalent must not be mislabeled invalid.
- [ ] Run `PYTHONPATH=src python -m unittest tests.test_planner tests.test_conformance -v`; observe missing generators.
- [ ] Implement exact fixed-shape expansion of the three schedules. Ring refill occurs only after the entire consuming row; all scratch capacity is explicit. Independently count mul opcodes in tests; do not trust planner-supplied costs or require classification against producer expressions.
- [ ] Run edge shapes `(1,1),(1,7),(7,1),(2,3),(3,2),(5,7),(15,15),(1,127),(127,1)` subject to actual limits. Exhaust {0,1,1023} for `(1,1),(1,2),(2,1),(2,2)` and 32 seeded cases per H/W in1..8. Preserve counts separately from the old probe's receipt.
- [ ] Commit as `feat(axiom): generate and validate the three stencil schedules`.


# Task 3 implementer report

Status: implementation ready for independent review; no commit made (controller serializes Git).

Owned files only:
- `axiom/src/axiom/plan_format.py`
- `axiom/src/axiom/codec.py`
- `axiom/tests/test_codec.py`
- `axiom/tests/fixtures/plans/{inline-1x1,duplicate-key,overlong-integer}.json`

Read the Task 3 brief and prototype contract. Applied executing-plans, test-driven-development, and verification-before-completion skills.

## Interfaces and behavior

`Plan` and `Operation` are frozen, slotted dataclasses with the agreed fields. Their constructors grant no trust; `validate_plan(plan, limits)` is the reusable independent checker boundary. It rejects wrong record/tuple/exact-int types, malformed or unknown operation shapes, invalid headers, capacity overflow, non-dense SSA definitions, forward/self references, and scratch indices beyond capacity. It does not allocate scratch. Input/output bounds, scratch initialization, output uniqueness/coverage, semantics, and constraints remain checker responsibilities.

`DecodeError(ValueError)` exposes `code`, `field_path`, and `path` (alias). `encode_plan`, `decode_plan`, and `plan_digest` provide the requested interfaces. Every operation is serialized with the same six fields, including null and empty defaults. Semantic digests are lowercase SHA-256 strings; plan labels are arbitrary Unicode text with 1..256 UTF-8 bytes. Operation order is preserved.

`canonical_json(value)` accepts only JSON primitives, exact integers, lists, and string-keyed dictionaries; keys sort, separators are compact, UTF-8 remains unescaped, floats and invalid surrogate strings are rejected. `strict_json_loads(data, *, max_bytes=2097152, max_items=300000, max_depth=64, max_integer_digits=10)` is reusable by future evidence schemas. It rejects malformed UTF-8, duplicate keys, floats/NaN/Infinity, trailing data and excessive nesting. Container item quotas apply before parsing/accumulating an additional item; integer token quotas apply before conversion. `decode_plan` additionally stops before parsing an excess operation, independently of the global item bound.

## TDD and verification

- RED: `PYTHONPATH=src python -m unittest tests.test_codec -v` recorded in `task-3-red.log`: expected `ModuleNotFoundError: No module named 'axiom.codec'` before production modules existed, matching the task's explicit missing-codec expectation.
- GREEN: same command passed 12/12 tests (log `task-3-green.log`).
- `PYTHONPATH=src python -O -m unittest tests.test_codec -v`: 12/12 pass. Product checks use no assert statements.
- `PYTHONPATH=src python -m unittest discover -v`: 23 actual codec/frontend tests passed; one loader error `tests.test_reference` because concurrent worker's module `axiom.reference` did not yet exist. This is an observed ongoing task dependency, not suppressed.
- `git diff --check`: clean (owned files are still untracked pending controller's serialized commit).

Coverage includes an independently authored inline 1x1 fixture, canonical bytes and digest, reordered object keys, significant operation order, real malformed duplicate/oversized-token artifacts, boolean masquerading as integers, unknown fields/opcodes/versions, bad types/opcode shapes, i32 boundaries, capacity bounds, negative indices/origins, dense SSA/prior references, sparse maximum-capacity handling, byte/operation/container/depth quotas, invalid UTF-8/surrogates/syntax, and direct untrusted in-memory records.

## Rulings

- Task 3: Ruling: plan labels use a 256 UTF-8 byte bound and all JSON integer tokens use at most ten decimal digits — the contract requires bounded arbitrary labels and bounded token conversion but does not name these two precise limits; ten digits also matches the source literal policy and admits every required i32/capacity value — cost if wrong: future artifacts may require a versioned or explicit revised bound.
- Task 3: Ruling: reusable structural validation performs dense SSA/prior-reference and scratch-arena-bound checks, leaving initialization/output properties to checking — these facts are available without source dimensions or symbolic execution and ensure decoded and in-memory artifacts receive the same boundary checks — cost if wrong: the checker must avoid relying on decoding as a substitute for calling validation itself.
- Task 3: Ruling: no local commit or task-done script yet — controller explicitly serializes commits while frontend/reference workers share the checkout — cost if wrong: controller must record the final committed task range and suite status.

## Concerns and limits

The broader test suite must be rerun after the reference worker completes. The generic JSON helpers enforce primitive encoding policy only; future source/receipt/manifest owners must still enforce their separate exact field schemas and supply suitable byte/item quotas. Plan encoding uses default Limits because the requested encode interface has no limits parameter; decode/checker structural validation consumes caller-provided Limits. No review findings are known at handoff.

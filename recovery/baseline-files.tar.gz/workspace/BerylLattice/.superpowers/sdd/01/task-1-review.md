# Task 1 review — commit 67fbee14

Spec verdict: changes requested for one identity-normalization defect. The required source records, interfaces, bounded parser, exact binary-expression comparison, snapshot/semantic identities, fixtures and frontend tests are present. No confirmed admission of a changed scalar expression or unbounded parser execution was found.

Quality verdict: changes requested for the same defect; otherwise no important implementation-quality issue identified in this task's files.

## Finding

### P2 — Keep tensor identities separate from local axis identities when normalizing reads

`axiom/src/axiom/frontend.py:381-385` overlays axis bindings on the dictionary containing tensor bindings. `_normalized` then uses that overlaid dictionary for both a read's tensor name and its index names (`frontend.py:368-369`). This does not match the frontend's own structural resolution: `_validate_scalar` resolves a read base in `tensors`, while `_interval` resolves its index names in `axes` before shapes (`frontend.py:309-318`, `282-291`). A structurally valid canonical stencil therefore becomes unsupported solely because a bound axis has the same spelling as a tensor.

Reproduce from `/workspace/BerylLattice/axiom`:

```sh
PYTHONPATH=src python - <<'PY'
import re
from axiom.frontend import admit_source, parse_source
from tests.helpers import stencil_source

source = stencil_source(5, 7)
canonical = admit_source(parse_source(source))
renamed = re.sub(rb'\br\b', b'image', source)
# The producer is now image[image,c], where the read base is the input
# and the index is its local row binding. Structural validation accepts it.
other = admit_source(parse_source(renamed))
assert canonical.semantic_digest == other.semantic_digest
PY
```

Actual result: `DiagnosticError: UNSUPPORTED_PROFILE at byte 0`. The same row-axis substitution to `H` succeeds and preserves the semantic digest, so shadowing is already supported rather than consistently forbidden. Substitution to `p` also incorrectly fails. The contract requires resolving identities and alpha-normalizing declaration/bound-axis names; normalize a read base with the tensor bindings and its indices with their index/axis bindings. Add a focused case to the alpha-renaming test.

## Shape-name and order assessment

The authoritative contract's line 28 says “Only H and W shape constants are initially recognized,” while line 30 permits varying names and requires identity resolution/alpha-normalization. The task brief further explicitly limits normalization to “declaration/axis identity renaming only.” Read together, these support two shape-parameter roles whose declarations may be renamed; accepting `Rows`/`Cols` is not a confirmed violation. No fixed-spelling blocker is reported.

The implementation assigns those roles by declaration order (`frontend.py:375`, `432`). Exact observed behavior:

* Renaming all H/W occurrences to Rows/Cols: accepted, dimensions `(5, 7)`, same semantic digest.
* Swapping the two independent declaration statements while leaving all H/W references alone: `UNSUPPORTED_PROFILE`.
* Simultaneously swapping the H/W identifier spellings everywhere: accepted with the original logical dimensions `(5, 7)`; the first declaration now happens to be named W.

This is an order-sensitive exact-profile recognizer, not a recognizer that binds the literal identifier H to height. The task authorizes identifier renaming but does not explicitly authorize declaration reordering, so rejection of a reordered declaration list is not independently reported as a defect. If fixed literal H/W spellings or declaration-order independence are intended, that needs a contract clarification rather than assuming either rule is already unambiguous.

## Verification

Inspected the review diff, actual `model.py`, `frontend.py`, test helper and frontend tests against the task brief and prototype contract. Ran:

* `PYTHONPATH=src python -m unittest tests.test_frontend -v`: all 11 tests passed.
* `PYTHONPATH=src python -O -m unittest tests.test_frontend -v`: all 11 tests passed.

Additional focused probes exercised undefined shape names, excessive source bytes, ten-digit out-of-profile shapes, a long unparenthesized expression, malformed nested reads, and reassociated consumer arithmetic. They returned typed diagnostics without an uncaught exception. Existing tests also cover UTF-8 byte offsets, invalid UTF-8/NUL, duplicate names, shape/range/index bounds, huge tokens, scalar literal i32 bounds, node quotas, constraints and retained grouping. Semantic hashing excludes formatting/cap/objective as required and preserves binary addition/multiplication structure.

No source edits were made during this review.

## Scoped re-review — commit ba561c1

Spec verdict: approved. The previously reported identity-normalization defect is fixed. Ordered shape-parameter roles and renamed shape declarations are accepted as the documented scope clarification; declaration reordering is not a promised normalization operation.

Quality verdict: approved. No remaining important issue found in the scoped fix or its regressions.

Reviewed `task-1-fix.diff` and the changed frontend/test code. `_normalized` now resolves read bases using a separate tensor map and scalar/index names using the shape/local-axis map. Axis bounds and input dimensions retain their shape context. This matches structural validation and preserves the exact binary expression tree.

The added regression exercises both row and column axes renamed to either input or producer names, checks equal semantic identities and distinct snapshots, and retains the exact renamed source bytes. Reran the entire owned frontend suite: all 12 tests passed both normally and under `python -O`.

Additional focused probes passed for simultaneous `r→image,c→p`, `r→p,c→image`, and `r→H,c→W` substitutions, all preserving the canonical semantic digest. Undefined tensor reads inside the shadowing cases still returned `UNDEFINED_NAME`. The original P2 finding is closed. No source edits were made during re-review.

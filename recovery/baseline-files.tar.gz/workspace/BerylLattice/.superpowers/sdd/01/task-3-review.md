# Plan 01 Task 3 review

Reviewed commit: `a3a857f10f219e7174dd60562ece528b5b3e4d6d` (`feat(axiom): define strict physical plan artifacts`). Scope: the six files in `task-3-review.diff`, the task brief, and `/workspace/scratch/axiom-program-2026-10-15/prototype-contract.md`. No implementation files changed during review.

## Spec compliance verdict: changes requested

The immutable format, JSON boundary, canonical encoding, error fields, operation shapes and dense/prior-definition SSA checks satisfy the task. One important gap remains in the promised parity between direct in-memory records and decoded plans: the public direct-record validator does not enforce its byte quota.

### P2 — Apply the effective byte quota to direct Plan validation

Location: `axiom/src/axiom/codec.py:215–278`, particularly lines 221–222 and 273–276.

`validate_plan` checks that `limits.plan_bytes` is positive but never uses it afterward. Consequently a direct Plan passes validation even when its canonical artifact is larger than that limit. Unlike operation count, origins tuple length has no independent bound, so this also admits arbitrarily large per-operation metadata under the default limit. `encode_plan` subsequently rejects an oversized artifact, but only after scanning and materializing it with its own default limits; that does not make `validate_plan(plan, effective_limits)` a bounded checker boundary.

The contract explicitly requires in-memory Plan/Operation records to receive the same structural validation as decoded plans, including bounds, and Task 3 exposes this validator for that purpose. A checker that trusts successful validation would admit direct records that could not pass the corresponding decoder quota and would perform unbounded metadata work outside the operation count.

Reproduce from `/workspace/BerylLattice/axiom`:

```sh
PYTHONPATH=src python - <<'PY'
from dataclasses import replace
from axiom.codec import DecodeError, decode_plan, encode_plan, validate_plan
from axiom.model import Limits
from axiom.plan_format import Operation, Plan

p = Plan(1, 'a' * 64, 'x', 0, (Operation('const', dst=0, value=1),))
data = encode_plan(p)
print(len(data))  # 238
print(validate_plan(p, Limits(plan_bytes=1)))  # None: accepted
try:
    decode_plan(data, Limits(plan_bytes=1))
except DecodeError as error:
    print(error.code)  # BYTE_LIMIT

large = replace(p, operations=(
    replace(p.operations[0], origins=(0,) * 1048576),
))
print(validate_plan(large, Limits()))  # None: accepted
try:
    encode_plan(large)
except DecodeError as error:
    print(error.code)  # BYTE_LIMIT
PY
```

Suggested correction: validate direct records against the supplied canonical-size budget using a bounded size calculation or bounded serialization path. Reject obviously excessive tuple lengths before scanning/copying all elements, and stop budget accounting as soon as the effective byte limit is exceeded. Keep input byte enforcement in `decode_plan`; direct records have no original input bytes, so canonical size is the relevant direct-record measure. Add regression coverage for a small custom byte quota and a single oversized origins tuple.

## Code quality verdict: changes requested

The implementation is compact, explicit and free of executable deserialization. Opcode shape validation is centralized, exact type checks correctly exclude bool, and errors consistently carry categories and paths. The custom parser enforces the operation quota before parsing an excess element, and integer digit quotas before conversion. Sparse scratch handling is preserved: validation never allocates the declared arena.

The byte-quota gap above is the only blocking quality finding from this review. It weakens the stated role of `validate_plan` as the common untrusted-record boundary. No separate semantic-checker obligations are charged to Task 3: shape-dependent input/output bounds, scratch initialization and output coverage are correctly left to the checker.

## Verification

Executed from `/workspace/BerylLattice/axiom`:

- `PYTHONPATH=src python -m unittest tests.test_codec -v`: 12 tests passed.
- `PYTHONPATH=src python -O -m unittest tests.test_codec -v`: 12 tests passed.
- The reproduction above: both quota mismatches confirmed.
- A deterministic 50,000-case short malformed-input probe (seed 1803) against `strict_json_loads`: no leaked exception or accepted non-JSON syntax; all 335 accepted cases matched `json.loads`.
- Additional exact-byte/exact-operation boundary checks and direct/decoded wrong-type probes for version, capacity, destination and literal fields passed.

The supplied tests additionally establish canonical fixture identity and SHA-256 identity, object-key reordering invariance, operation-order significance, duplicate-key rejection, bool/integer separation, null/field shapes, unsupported versions/opcodes, i32 constant bounds, nonnegative indices, scratch capacity bounds, dense SSA ordering, prior-reference checks, float/NaN rejection, UTF-8/surrogate rejection, malformed JSON/depth rejection and overlong integer token rejection. Those results support the implementation outside the quota issue; the random probe is supplementary evidence, not a proof of parser correctness.

## Scoped fix review — commit 582ac57

Reviewed `task-3-fix.diff` and commit `582ac57b5d918bd836f0829f67b7be61b8508d67`. The following verdicts supersede the initial changes-requested verdicts above.

**Spec compliance verdict: approved.** The P2 finding is resolved. Direct-record validation now checks exact canonical byte size against the supplied `Limits`. The accounting starts with the bounded header containing an empty operations array, adds each bounded operation shell and inter-operation comma, then charges origins separators and digits. This matches the encoder's actual size, including escaped labels, UTF-8 labels, negative i32 constants, and multi-digit origins. Oversized origins tuples are rejected using their length before inspecting or copying their elements. The new character-count guard also bounds label work before UTF-8 encoding.

**Code quality verdict: approved.** No additional important findings in the scoped fix. The keyword-only `limits` parameter on `encode_plan` and `plan_digest` preserves existing calls and correctly propagates explicit byte and operation limits. Default `Limits()` is safe here because the record is frozen. `plan_digest` hashes the exact bytes produced using the same effective limits, avoiding the previous default-limit conflict for explicitly enlarged quotas.

Fix verification, from `/workspace/BerylLattice/axiom`:

- `PYTHONPATH=src python -m unittest tests.test_codec -v`: all 15 tests passed.
- `PYTHONPATH=src python -O -m unittest tests.test_codec -v`: all 15 tests passed.
- 300 deterministic generated valid streams (seed 582), covering all seven opcodes, varied origin counts/digit widths, Unicode and escaped/control-character labels: validation and decoding succeeded with `plan_bytes=len(encode_plan(plan))`, and validation returned `BYTE_LIMIT` with one byte less for every case.
- Instrumented `_integer` while validating an origins tuple containing 1,048,576 elements under default limits: `BYTE_LIMIT` occurred with zero calls inspecting origin elements, confirming early rejection.
- A direct plan with 20,001 dense `const` operations encoded to 1,609,132 bytes, decoded identically, and hashed to SHA-256 of those bytes with explicit `plan_operations=20001` and `plan_bytes=4194304`. Encoding without explicit limits returned `OPERATION_LIMIT`, confirming that the opt-in extension preserves defaults.
- The owned tests separately verify a canonical artifact above the default byte quota round-trips and hashes correctly with explicit enlarged limits, and that explicit tiny byte limits reach both encoding and digest paths.

No implementation files changed during this follow-up review; only this report was appended.

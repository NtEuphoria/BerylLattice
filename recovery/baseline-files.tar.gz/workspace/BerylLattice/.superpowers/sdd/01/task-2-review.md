# Plan 01 Task 2 review

Reviewed commit `bb9d306eb28876de49b860a644bd7cf4c574c6bc` using `task-2-review.diff`, the Task 2 brief, and `/workspace/scratch/axiom-program-2026-10-15/prototype-contract.md`. Scope: `axiom/src/axiom/reference.py`, `axiom/tests/test_reference.py`, and the input fixture added by the commit. Frontend admission was inspected to establish the evaluator's supported input assumptions.

## Specification verdict: PASS

No important specification findings.

- `evaluate_source` calls `admit_source` before boundary inspection. Unsupported source produces the admission diagnostic rather than a runtime outcome.
- The interpreter traverses retained source declarations, bounds, index expressions, and scalar AST nodes. It computes with Python integers and checks the i32 range at each visited expression node. It does not substitute a schedule generator or a hard-coded stencil formula.
- The public boundary accepts exact built-in tuple/list containers, rejects bool/float/noninteger scalars, checks extents and i32 representation with typed diagnostics, and snapshots observations into immutable tuples. It rejects direct input/output aliasing and never mutates caller buffers.
- Every input value is checked against the admitted interval in row-major order before shape evaluation, producer/output equation evaluation, or destination computation. Rejection returns the first failing offset and the complete initial destination. Success returns the complete evaluated output and unchanged input snapshot.
- Status values are lowercase `StrEnum` members and the observation record is frozen. There are no planner, checker, or plan-format imports.
- Owned tests cover all required exact examples, a separately written H5/W7 four-neighbor oracle, renaming, rejection at every input position, complete destination preservation, boundary diagnostics, and admission ordering. Test-only profiling records zero equation visits on rejection and confirms equation visits on success.

## Code-quality verdict: PASS

No important correctness, maintainability, or regression findings.

The implementation is small and its boundary, expression evaluation, and equation iteration responsibilities are separated clearly. Evaluation recursion is bounded by the frontend's admitted source limits; tensor allocation is bounded by the 256-cell profile. Exact built-in containers and exact integer checks prevent custom container/scalar behavior at this boundary. Product checks do not rely on Python assertions.

## Verification

- `PYTHONPATH=src python -m unittest tests.test_reference -v`: 12 tests passed.
- `PYTHONPATH=src python -O -m unittest tests.test_reference -v`: 12 tests passed.
- Additional deterministic independent-formula probes: 80 cases across H/W `(1,127)`, `(127,1)`, `(15,15)`, `(1,1)`, `(2,3)`, `(3,2)`, `(5,7)`, and `(7,5)` passed, including maximum admitted input extents.
- A direct expression probe for `(2147483647 + 1) * 0` raised `EVALUATION_I32` at the overflowing intermediate node, confirming per-node checks rather than final-result-only validation.

The historical red-test step cannot be established from the final patch alone; this does not affect the implementation or verification verdicts. No source changes were made during review.

# Task 6 implementation report

Scope: `axiom/src/axiom/selection.py`, `axiom/tests/test_selection.py`. No commits or unrelated file edits. Binding brief `.superpowers/sdd/01/task-6-brief.md`; binding contract `/workspace/scratch/axiom-program-2026-10-15/prototype-contract.md`.

## Public API

`select_plan(kernel, limits, total_check_steps, objective, optional_check_steps=None) -> SearchResult` returns frozen SearchResult/AttemptRecord records. The selected plan, exact canonical bytes, and eligible CheckResult are committed together. SearchStop and ArtifactState are separate enums. Attempts retain source, semantic, constraint, ranking and physical plan identities plus the assigned call allowance and charged work. SearchResult retains the original Limits for evidence serialization under the same quotas. `ranking_digest(Objective)` supplies the shared versioned policy identity for evidence/replay.

## Implementation decisions and self-review

- Initial inline admission consumes total checking allowance. Optional checking begins only after initial eligibility and consumes both remaining total and optional allowance. Call limits are the minimum of the positive per-call, total-remaining and optional-remaining allowances; zero means no checker call.
- Candidate order is exactly inline, rows2, materialize. Only fully eligible results can enter the ranking; primary metric, secondary metric and literal plan label determine ranking. Labels never establish legality. There is no portfolio-infeasibility result and no global-optimality claim.
- Source admission is repeated before generation and the supplied kernel must match its retained bytes. A forged huge dimension cannot reach a generator. Source admission diagnostics under narrower source quotas propagate as typed ValueError subclasses; plan/check quotas produce the independent checker's precise incomplete receipt.
- Ruling: checker exceptions/cancellation with no returned work receipt consume the full assigned call allowance conservatively; generation/encoding failures consume only known checker work. This never refunds work that could have occurred and does not claim physical CPU measurement. Cost if wrong: the interrupted attempt may leave less budget than its actual work would have consumed, but cannot exceed authorized checking allowance.
- Ruling: exhaustion on a later incomplete checker call stops search with its available coherent incumbent; a non-budget unknown or invalid later candidate remains an attempt and permits examination of the remaining portfolio. Cost if wrong: an alternate policy could discover a later candidate with unused total allowance after a per-call step exhaustion; the returned artifact remains independently eligible.
- Ruling: exact Objective enums are required; equivalent strings are rejected, and a mismatch is rejected instead of mutating the admitted kernel. Cost if wrong: callers must convert a supported string to Objective first.
- Runtime cancellation is best effort and has no reproducibility guarantee. Tests inject KeyboardInterrupt at generation/check boundaries before inline and after inline/rows2 commits.
- Self-review checked budget underflow/zero limits, malformed checker return handling, independent selected-byte digest agreement, source-cap preservation, immutable incumbent retention and quota independence. No known correctness blocker. The author self-review does not replace the root's independent review.

## TDD and verification evidence

- Initial RED: `PYTHONPATH=src python -m unittest tests.test_selection -v`, recorded in `task-6-red.log`: missing selection module (ImportError), as the brief expected.
- Initial GREEN: same command, `task-6-green.log`: 10/10 PASS in 0.840s.
- Malformed-checker receipt regression RED: `test_malformed_checker_receipt_stops_with_no_artifact`, `task-6-receipt-red.log`: bool receipt triggered AttributeError while constructing the failure attempt. Root cause: unchecked return value was assigned to the public receipt variable before validation.
- Regression GREEN: validate into a temporary local before publishing the receipt; `task-6-receipt-green.log`, 1/1 PASS in 0.006s.
- Additional exact optional-budget/initial-constraint-failure/improved-incumbent-interruption tests: `task-6-extra-green.log`, 3/3 PASS in 0.309s.
- Quota regression verification: `task-6-quota-green.log`, 1/1 PASS in 0.015s. A test initially used expression_nodes=1, which correctly failed fresh source parsing; changed its checker-exhaustion case to expression_nodes=100 after observing the typed parser diagnostic.
- Optimized Python: targeted suite excluding the exhaustive enumeration, `task-6-optimized-green.log`: 14/14 PASS in 0.868s; runtime product checks do not depend on assert.
- Exhaustive test: 955 real uncapped selections, each with three fresh independent physical checks (2,865 actual checker calls); then 14,518 cap/objective selections across 0 and each row/materialization boundary at -1/exact/+1 plus unbounded. The latter inject only independently rebuilt context constraints into the real receipts and verify the generated physical stream stays identical. They exercise the real selector but deliberately do not repeat the equivalent semantic scan. Separate real end-to-end tests cover cap0/cap64/uncapped, both objectives, H1/W1 and H1/W7.
- Complete selection/full project verification: pending current exhaustive run and complete suite; report will be updated with actual output.

## Tooling notes

Executing-plans and test-driven-development skills were read before implementation. The secondary writing-good-tests resource was unavailable. The skills provider subsequently stopped exposing packages; an attempted systematic-debugging skill read returned `skill package is not available`. Followed the already-loaded test-first workflow and inspected the observed failure's root cause directly.

# Plan 01 Task 4 independent review

Reviewed commit: `820e1b940a9f88340bdce25e1975a55fc396ad8e` and its exact task-4 review package. Reviewed the task brief, implementation report, binding prototype contract, checker, checker tests/fixtures, and relevant codec/frontend/model boundary implementations.

## Verdicts

- **Specification compliance: PASS.** No blocking discrepancy found.
- **Code quality: PASS.** No actionable correctness or maintainability finding found within this task's scope.

## Basis

The checker validates direct records using the same structural boundary as decoding, including exact integer types, dense SSA, operand ordering and reserved scratch bounds. It reparses retained source bytes with current limits, checks source-derived identity fields, and uses the fresh AST for symbolic semantics and source caps. Additional caps tighten the effective constraint and contribute to the constraint digest. Neither the planner nor reference evaluator is imported.

Expression nodes retain integer arena edges, so aliases and repeated operands do not copy expression trees. Construction and comparison use explicit stacks; conceptual AST/operation/comparison visits charge the specified work counter. Separate expression allocation limits apply, and scratch storage is sparse regardless of declared capacity. Arithmetic checks cover dead operations. Interval imprecision remains unknown; invalid arithmetic and output mismatch classifications require concrete endpoint witnesses. Output coverage and scratch initialization are checked independently of plan labels. Whole-operation metrics remain unavailable until the symbolic operation scan finishes. Eligibility uses the complete/valid/satisfied conjunction.

The manual SSA-staged control and arbitrary label are accepted without widening the production portfolio. Reserved arena bytes include unused cells and intentionally exclude SSA retention, as required by the resource contract. Existing tests cover exact quota boundaries, structural mismatches, forged source identity/caps, unsafe dead arithmetic, recursive-depth adversaries, immutable records and normal/optimized execution.

## Independent targeted probes

I did not repeat the reported unchanged test suites. A separate `PYTHONPATH=src python` probe exercised these additional combinations against the reviewed implementation; all assertions passed:

1. Dead arithmetic `x * (1023-x) * 10000` has safe uniform endpoint samples but overflows for `x=511`. Result: `unknown`, `INCONCLUSIVE_INTERVAL`, complete, 132 work units. It is never eligible merely because the two samples are safe.
2. Store an output expression to scratch, load it to SSA, overwrite the slot, then output the retained SSA value. Result: valid and eligible, 128 work units. Scratch updates do not retroactively alter loaded expressions.
3. Producer axis names overlap `H`/`W`; output axis names overlap the input/producer tensor names and differ from producer axes. The freshly admitted source remains valid and the manual plan checks successfully, 125 work units.
4. Replace the output with constant 1. Result: invalid with concrete witness `uniform_input=0`, `expected=4`, `actual=1`, 80 work units.
5. Declare the maximum accepted arena capacity of 2,147,483,647 cells on the valid inline plan. Result: semantic-valid with exactly 8,589,934,588 workspace bytes, constraint-violated and ineligible, 125 work units; no proportional arena allocation.

Reported suite evidence remains attributed to the implementer: 28 checker tests pass normally and under `-O`; the normal aggregate run reports 89 tests with 6 native-gated skips. No claim is made that endpoint probing decides general semantic equivalence or all possible overflow; the conservative unknown behavior is intentional.

# Plan 01 Task 5 — three generators and conformance

Implemented only `src/axiom/planner.py`, `tests/test_planner.py`, `tests/test_conformance.py`, and the independent test-only `tests/plan_interpreter.py`. No commits created; root owns serialization/review.

`make_plan(kernel, plan_id)` supports exactly `inline-v1`, `rows2-v1`, and `materialize-v1`, exposed in that stable order as `PLAN_IDS`. Each stream has one constant and dense ordered SSA definitions. It reads fixed dimensions and original expression origins from the admitted kernel, uses byte offsets from retained AST spans for origin IDs, and never imports the checker/oracle or executes source snippets. The two-row schedule refills a retired row only after all output columns consuming it complete. Scratch reservation is explicit and source grouping is preserved.

## TDD and verification

- RED: `PYTHONPATH=src python -m unittest tests.test_planner tests.test_conformance -v` failed with two import errors specifically because `axiom.planner` did not exist. Exact output: `task-5-red.log`.
- GREEN, same command: 9 tests passed in 16.557s. Exact output: `task-5-green.log`.
- Optimized interpreter: `PYTHONPATH=src python -O -m unittest tests.test_planner tests.test_conformance -v` passed all 9 tests. Exact output: `task-5-optimized.log`.
- Whole currently available suite: `PYTHONPATH=src python -m unittest discover -s tests -v` ran 87 tests in 21.093s, OK with five skips. Exact output: `task-5-full.log`. All five are `test_core_toolchain.ActualToolchainTests` requiring explicit pinned Core/Clang selection: `test_real_isolated_build_keeps_failed_baseline_and_qualifies_native`, `test_selected_clang_preflight_has_c11_run_receipt`, `test_snapshot_inventory_rejects_dirty_source_and_extra_files`, `test_unbuildable_selected_compiler_produces_no_success_receipt`, `test_untracked_snapshot_file_is_rejected`.
- `git diff --check` passed. Root must inspect/add newly created files, since they are untracked until its serialized commit.

## Exact coverage

H5/W7 independently checked arena bytes/mul opcodes: inline `(0,140)`, rows2 `(64,48)`, materialize `(192,48)`; capacities are respectively 0/16/48 cells. Canonical encoded bytes are decoded and reencoded, actual decoded plans are checked, and independent stream opcode counts match checker metrics.

Every one of the 955 admitted positive H/W shapes was generated for all three labels (2,865 specializations), with exact capacities, one constant, dense SSA, multiplication counts, and finite operation formulas checked. Inline has `1+16*H*W` ops; rows2/materialize have `1+4*(H+1)*(W+1)+8*H*W`. Maxima observed across this domain are 3,601 inline and 2,825 staged operations, below 20,000.

Numeric cases compare the retained source-AST evaluator against a separate test-only interpreter of every physical operation, for every schedule. Plans are checked once per source/test case and then reused across that source's input vectors; the oracle never imports the planner.

- Restricted alphabet `{0,1,1023}` exhaustions: `(1,1)` 81; `(1,2)` 729; `(2,1)` 729; `(2,2)` 19,683. Total **21,222 source inputs**, **63,666 schedule executions**.
- Seed `20261015`: exactly 32 cases for every H/W in 1..8: **2,048 source inputs**, **6,144 schedule executions**.
- Edge shapes `(1,1),(1,7),(7,1),(2,3),(3,2),(5,7),(15,15),(1,127),(127,1)`: zero, 1023, and coordinate-sensitive vectors: **27 source inputs**, **81 schedule executions**.
- Main corpus total: **23,297 inputs**, **69,891 interpreted schedule executions**. This is distinct from earlier probe receipts.

## Serialized negative and equivalent controls

Mutations operate on serialized JSON operation streams and are then strictly decoded and independently checked. At H2/W3 with input `(0,1,2,3,4,5,6,7,8,9,10,11)`, the independent source evaluator returns `(66,98,138,242,306,378)`.

- Wrong first neighbor: actual `(69,98,138,242,306,378)`; checker returns `unknown` without claiming a fabricated witness.
- Two rows aliased into a one-row arena: actual `(122,170,226,362,442,530)`; checker returns `unknown`.
- Early overwrite of slot one after the first output, before neighboring consumers: actual `(66,95,138,242,306,378)`; checker returns `invalid` with a concrete uniform-input witness.
- Commuting the producer increment's add is semantically equivalent but structurally different: checker returns `unknown`, no witness; numeric interpretation agrees with the source for zero, 1023, and coordinate-sensitive vectors. It is never mislabeled invalid.

Ruling: origin IDs are original AST UTF-8 byte offsets because the contract requires source-origin integers but defines no separate ID allocation scheme. This retains stable source identity without changing model/codec; root can choose a different numbering convention later if explicitly versioned.

Ruling: the early-overwrite mutant targets slot one, which remains live for the next consumer. Overwriting slot zero after the first output would be a dead-store change in this shape and would be semantically equivalent; it must not be used as a negative correctness control.

## Dependencies and remaining status

Task 4 checker is present and all conformance checks execute against its public `check_plan` interface, including `.eligible` and tuple-pair opcode counts. No dependency remains for this task. Native toolchain integration is outside Task 5 and its five explicit environment-dependent tests are skipped in the generic suite. The SSA-staged positive control stays solely in checker tests; it is deliberately not a fourth supported generator. No public unchecked execution entry was added. Root integration/review/commit remains outstanding.

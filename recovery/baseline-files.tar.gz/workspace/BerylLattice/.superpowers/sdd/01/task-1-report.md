# Task 1 report: source parsing and exact profile admission

Status: complete, pending the controller's integrated review.

## Owned files

- `axiom/src/axiom/__init__.py`
- `axiom/src/axiom/model.py`
- `axiom/src/axiom/frontend.py`
- `axiom/examples/stencil.ax`
- `axiom/tests/__init__.py`
- `axiom/tests/helpers.py`
- `axiom/tests/test_frontend.py`
- `axiom/tests/fixtures/source/invalid_utf8.ax`
- `axiom/tests/fixtures/source/extra_producer.ax`

No other task's source or tests were edited.

## Implementation

The lexer validates immutable bytes, source-byte quota, strict UTF-8 and NUL prohibition before tokenization. It scans byte offsets directly, including through multibyte UTF-8 comments. ASCII identifiers, decimal integers limited to ten digits before conversion, explicit operators and punctuation are tokenized. Integer unary minus is accepted only on literals.

The parser creates frozen, typed dataclass AST variants and retains the complete original source snapshot and ordered declaration AST. Expression node and depth quotas are explicit checks, and product code contains no `assert`. Parentheses survive as GroupExpression nodes. Addition and multiplication preserve left associativity and multiplication precedence. Parse returns SourceModule even when a structurally valid source will later be outside the supported profile.

Admission validates duplicate and undefined names, positive dimensions, intervals, axis ranges, tensor rank and statically bounded read coordinates across all declarations before comparing with the canonical profile. Extra producers, changed constants/ranges, arbitrary constant-propagated dimensions and reassociated arithmetic are unsupported. Unknown hard properties/objectives and invalid caps have distinct codes. Source caps may be absent. Multiple source cap declarations are conservatively combined with minimum.

Normalization changes declaration and bound-axis identities only; GroupExpression wrappers are ignored during profile comparison while the binary expression tree is preserved. The semantic SHA-256 includes normalized equations, dimensions, exact-i32 arithmetic and boundary semantics. It excludes spelling, whitespace, source comments, constraints and objective. The snapshot digest hashes the exact input bytes.

## Settled shared APIs

- `parse_source(data: bytes, limits: Limits = Limits()) -> SourceModule`
- `admit_source(module: SourceModule) -> AdmittedKernel`
- `DiagnosticError(code: str, span: Span, message: str)`; attributes `code`, `span`, `message`.
- `Span(offset: int, length: int)` stores original UTF-8 byte positions.
- `SEMANTICS_VERSION = 'axiom-stencil-i32-v1'`.
- `Objective` is StrEnum with `MULTIPLICATION_OPS='multiplication_ops'` and `PLAN_WORKSPACE_BYTES='plan_workspace_bytes'`.
- Also defined `SemanticStatus(valid, invalid, unknown)` and `ConstraintStatus(satisfied, violated, unknown)` as StrEnums for future owner modules.
- `Limits(source_bytes=65536, plan_bytes=2097152, plan_operations=20000, expression_nodes=100000, check_steps=100000)` validates every value as a positive exact int, rejecting bool.
- Expression variants: `IntegerLiteral(value, span)`, `NameReference(name, span)`, `BinaryExpression(operator, left, right, span)`, `ReadExpression(name, indices, span, name_span)`, `GroupExpression(expression, span)`; `Expression` is their union.
- `ShapeDeclaration(name, value, span, name_span)`.
- `InputDeclaration(name, element_type, dimensions, input_interval, span, name_span)`.
- `AxisBinding(name, lower, upper, span, name_span)`.
- `EquationDeclaration(name, axes, expression, span, name_span, kind)` where kind is `producer` or `output`.
- `ConstraintDeclaration(property_name, value, span)`.
- `SourceModule(source_bytes, source_digest, module_name, shapes, inputs, producers, outputs, cap, objective, span, declarations, constraints)`; collection fields are tuples. `objective` can hold an unsupported string until admission issues its typed diagnostic.
- `AdmittedKernel(height, width, cap, input_interval, objective, source_digest, semantic_digest, source_expressions, semantics_version, source_module)`. `source_expressions` is exactly `(original_producer.expression, original_output.expression)`; `source_module` retains all declarations and source bytes for the independent evaluator. All required field names match the plan.

## Test-first and verification evidence

All commands ran from `/workspace/BerylLattice/axiom` using Python 3.12.14.

1. RED: `PYTHONPATH=src python -m unittest tests.test_frontend -v` failed with `ModuleNotFoundError: No module named 'axiom.frontend'`, confirming the required missing interface. Full log: `task-1-red.log`.
2. First implementation run: 10/11 passed; the purported supported-structure negative fixture narrowed the producer's first row from 0 to 1 but retained consumer reads of row 0, so the implementation correctly reported INVALID_INDEX instead of UNSUPPORTED_PROFILE. The fixture was corrected to narrow only the output domain, preserving valid reads while changing the profile. Full log: `task-1-green-attempt.log`.
3. GREEN: `PYTHONPATH=src python -m unittest tests.test_frontend -v`: 11 tests passed. Full log: `task-1-green.log`.
4. Optimized GREEN: `PYTHONPATH=src python -O -m unittest tests.test_frontend -v`: 11 tests passed. Full log: `task-1-green-optimized.log`.
5. Whole currently present suite: `PYTHONPATH=src python -m unittest discover -v`: 35 tests passed, comprising frontend, codec and reference suites. Full log: `task-1-discovery.log`. Concurrent task files may continue changing after this snapshot; the controller owns final integrated verification.

Coverage includes canonical and alpha-renamed sources, exact snapshot and semantic identities, unchanged AST retention, UTF-8-comment byte spans, duplicates/undefined names, nonpositive and oversized dimensions, inverted ranges and invalid coordinates, depth/node/byte quotas, ten-digit limits and out-of-i32 scalar literals, invalid UTF-8/NUL, extra producer, changed square constant, arithmetic reassociation, default and explicit policies, unsupported properties/objectives, invalid caps and malformed syntax.

## Rulings and concerns

Ruling: declaration and axis renaming includes shape identifiers, using the two literal shape declarations' ordered identities as height and width. This implements the contract's alpha-normalization rather than restricting spelling to H and W. Cost if wrong: future grammar clarification may change shape identity assignment.

Ruling: redundant grouping wrappers are retained in the original AST but ignored in semantic profile comparison; binary operator grouping is never rewritten. This preserves exact source grouping relevant to arithmetic while allowing redundant parentheses. Cost if wrong: a stricter surface-syntax profile could reject currently admitted redundant parentheses.

The parser is the source-byte trust boundary. Source records are frozen and typed; admission is designed for parser-produced SourceModule records rather than a separate hostile Python-object decoder. Strict in-memory plan-object validation belongs to the separate plan boundary required by the contract.

No deferred source implementation work or dependency concern blocks Tasks 2–3. No push, merge or external publication was performed.

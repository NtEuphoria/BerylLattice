# Authorized implementation task

The user explicitly requested implementation of all three reviewed plans. Earlier planning-only restrictions no longer block implementation. Work in /workspace/BerylLattice.

# Axiom Correctness Prototype Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking. Native execution is recommended for this first tightly coupled prototype; no implementation is authorized by this planning document alone.

**Goal:** Parse one declarative stencil family, independently check three physical plans, select only eligible plans and replay exact evidence.

**Architecture:** Python owns a small source AST, independent source evaluator and immutable explicit physical plans. A checker reconstructs expressions and storage facts from actual operations; the planner is outside its trust boundary. Core lowering is the next plan, not a dependency of this executable correctness prototype.

**Tech Stack:** Python 3.12+, standard library, `unittest`, deterministic canonical JSON and SHA-256.

**Spec:** [Prototype contract](../../../prototype-contract.md), implementing the [foundation design](../../../../axiom-foundations-2026-10-15/axiom-v0-design.md).

## Global Constraints

- Axiom is the distinct language; Core's source repository remains unchanged in this plan.
- One canonical two-stage stencil; input [H+1,W+1], output [H,W], H/W positive and input cells <=256.
- Input interval [0,1023]; exact i32 per scalar node; output range [4,4194304].
- Preflight scans row-major before plan computation/output writes; failure preserves complete output and first invalid index.
- `plan_workspace_bytes` counts only the reserved scratch arena; SSA values and native memory are excluded. The valid SSA-staged positive control exposes that limitation.
- Formats and checkers are versioned; unknown, unsupported and invalid are distinct.
- Limits: source bytes 65536; plan bytes 2097152; plan operations 20000; expression nodes 100000; check steps 100000 by default.
- No solver, learned model, third-party package, general DAG lowering, unchecked public entry or public release.
- Tests and diagnostics must work under Python `-O`; product checks use explicit conditions, not `assert` statements.

## Review Focus

- UTF-8 comments before an error: byte offsets must identify the actual source bytes; Task 1.
- JSON duplicate keys, booleans masquerading as integers and oversized integer tokens: reject before execution; Task 3.
- A valid but structurally different expression: return unknown rather than false inequivalence; Task 4.
- Exhaustion immediately after a valid incumbent and stale cap on replay: preserve only independently eligible artifacts; Tasks 6–7.
- Additional reserved but unused scratch: account for it and reject a violated cap; Task 4.

## Files and boundaries

All implementation paths below are relative to future `/workspace/BerylLattice/axiom/`. Do not create them during research planning.

```text
src/axiom/model.py          source records, spans, diagnostics and limits
src/axiom/frontend.py       lexer/parser and canonical profile admission
src/axiom/reference.py      source-AST evaluation and checked boundary
src/axiom/plan_format.py    immutable plan and operation types
src/axiom/codec.py          strict versioned decoding/canonical encoding
src/axiom/checker.py        independent symbolic/storage/range checker
src/axiom/planner.py        three physical plan constructors
src/axiom/selection.py      budgets, ranking and incumbent state
src/axiom/evidence.py       exact replay and atomic artifact publication
src/axiom/__main__.py       CLI, no duplicated compiler logic
tests/test_*.py             tests owned by the corresponding tasks
tests/fixtures/            source/plan/negative-control artifacts
examples/stencil.ax        the contract's H5/W7 example
docs/prototype.md           exact supported contract and commands
```

Run commands from this future root with `PYTHONPATH=src`. Each task ends with a local commit of only its named files after checking the diff. Do not push. If the checkout is still unborn, create its first local commit only when implementation begins; follow the workspace skill then. Keep generated receipts outside tracked source unless deliberately small fixtures.


### Task 1: Source parsing and exact profile admission

**Files:** Create `src/axiom/__init__.py`, `model.py`, `frontend.py`, `examples/stencil.ax`, `tests/__init__.py`, `tests/helpers.py`, `tests/test_frontend.py`, `tests/fixtures/source/invalid_utf8.ax` and `tests/fixtures/source/extra_producer.ax`.

**Interfaces:** `parse_source(data: bytes) -> SourceModule`; `admit_source(module: SourceModule) -> AdmittedKernel`. Invalid/unsupported input raises `DiagnosticError(code: str, span: Span, message: str)`; Span stores byte offset/length. Define all source records, objective enums, `Limits`, and typed expression variants here according to the contract. Other modules do not reparse source text.

- [ ] Write `test_canonical_and_alpha_renamed_stencil`, asserting H/W=5/7, input interval=(0,1023), cap=64, objective=`multiplication_ops`, and equal semantic hashes after identifier renaming but distinct snapshot hashes.
- [ ] Define test-only `stencil_source(h: int, w: int, cap: int | None=64, objective: str='multiplication_ops') -> bytes` in `tests/helpers.py`, rendering only the contract's literal source template. It must not import planner/checker/emitter. Pin the admission assertions:

```python
k = admit_source(parse_source(stencil_source(5, 7, 64)))
assert (k.height, k.width, k.cap) == (5, 7, 64)
assert k.input_interval == (0, 1023)
assert k.objective == 'multiplication_ops'
```

Use exact AdmittedKernel field names `height`, `width`, `cap`, `input_interval`, `objective`, `source_digest`, `semantic_digest`, `source_expressions`, `semantics_version` in all tasks.
- [ ] Write `test_byte_spans_after_utf8_comment`, duplicate/undefined-name, range-bound, expression-depth, huge-token, invalid-UTF8 and NUL tests. A valid extra producer, changed square constant or reassociated source expression must return `UNSUPPORTED_PROFILE`; nonpositive H/W is `INVALID_SHAPE`.
- [ ] Run `PYTHONPATH=src python -m unittest tests.test_frontend -v`; confirm tests fail for the missing interface, not accidental fixture errors.
- [ ] Implement bounded lexing/parsing and exact canonical-profile recognition, preserving source grouping. Define normalization explicitly: declaration/axis identity renaming only; no algebraic normalization or arbitrary constant propagation.
- [ ] Run the same command normally and with `python -O`; both must pass. Commit as `feat(axiom): parse and admit the bounded stencil source`.


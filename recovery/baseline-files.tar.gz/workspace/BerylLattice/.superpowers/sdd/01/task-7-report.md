# Task 7 report — exact evidence/replay and CLI

Implementation is complete for the assigned Task7 files, with no commit or
subagent. Root owns serialized review, integration and commits. This report is
not a claim that the entire multi-plan program is complete.

## Scope and APIs

Created `axiom/src/axiom/evidence.py`, `axiom/src/axiom/__main__.py`,
`axiom/tests/test_evidence.py`, `axiom/tests/test_cli.py`, and
`axiom/docs/prototype.md`. Independent frontend/reference/checker/planner/codec
and selection modules were not edited.

- `write_attempt(directory: Path, module: SourceModule, result: SearchResult) -> Path`
  returns `directory/manifest.json`. It validates retained source/frozen records,
  source objective, limits, selected exact bytes, matching attempt/ranking metrics,
  and a fresh eligible checker result. Public success bits are never sufficient.
- `ReplayManifest` is a frozen typed v1 record with exact content-addressed
  source/plan filenames and SHA-256s, semantic/constraint/ranking identities,
  semantics/plan/checker/check-accounting/search-budget-accounting versions,
  original effective cap, objective/key, saved selected check, typed attempt
  history, termination, limits and total/optional budget context.
- `decode_manifest` rejects unsupported versions/policies, unknown/missing or
  duplicate fields, noncanonical JSON, invalid types, malformed identities,
  excessive field sizes/container counts, wrong paths and incoherent accounting.
  Bounds: 262144 bytes; 4096 JSON items; depth12; three attempts; witness32 pairs;
  opcode counts7; labels256 UTF-8 bytes; reasons/witness text2048; ten-digit work
  values/positive limits; caps <=2147483647. Boolean integer substitutions fail.
- `replay(source, plan_bytes, manifest_bytes, limits, cap=None)` verifies exact
  hashes and source/plan/semantic/ranking/constraint/version context, freshly
  re-admits, then calls `check_plan(..., additional_cap=cap)`. Saved check status
  is history only. Fresh metrics must match the recorded ranking key.
- `ReplayError` derives from `DecodeError` and has `code`/`field_path`. Unsupported
  identity/version errors are typed diagnostics, never successful checks.
- `verify_references` checks all on-disk published source/plan snapshots. CLI
  calls it before accepting replay, even when supplied source/plan paths name
  other copies. Bytes-only replay cannot infer a filesystem directory.
- Noeligible manifests preserve source/history with all selected-artifact fields
  null. No plan bytes or replay success can be inferred from that manifest.
- CLI handlers are separate functions under an extensible argparse dispatcher.
  Commands are check/plan/replay/eval; exits0/2/3/4/5/6 are tested. No Core witness
  or conformance command was implemented here. No shell is invoked by the CLI.

## RED → GREEN evidence

1. Initial tests were written first. Command from `axiom/`:
   `PYTHONPATH=src python -m unittest tests.test_evidence tests.test_cli -v`.
   `task-7-red.log`: 5 discovered test entries, 4 failures + 1 import error;
   evidence module and executable package entry were absent as expected.
   (A preceding shell invocation used an incorrect relative prefix; corrected
   before the retained red run; no product files existed from that invocation.)
2. Initial implementation: 12 own tests passed.
3. Self-review regressions first failed in `task-7-selfreview-red.log`: four
   failures for null exception constraint identity, false optional accounting,
   false selected ranking key, and missing referenced source despite a matching
   external source copy. Fixed all four; 16 own tests passed.
4. CLI source tamper classification first failed in `task-7-public-red.log`:
   expected invalid2 but received infrastructure5 because reference verification
   preceded exact-byte identity checking. Replay now establishes requested-byte
   identities first, then verifies referenced files before accepting; 18 passed.
   Direct public-history rejection/bounded validation also ran in this pass.
5. Root identified ancestor-swap risk. Two controlled regressions in
   `task-7-ancestor-red.log` failed before the fix. The test reconstructs the
   current temporary in the attacker-controlled swapped ancestor, allowing the
   old path-based publisher to follow it; merely renaming the ancestor was not a
   sufficient reproducer. The old implementation accepted outside publication
   and replaced an outside manifest sentinel. Fixed with a no-follow directory
   walk, pinned dirfd, dirfd-relative temp/link/unlink/replace, no-follow regular
   reads, directory identity checks before/after replace, and pinned reference
   verification. Both regressions now pass and outside files are preserved.

Final normal own command:
`PYTHONPATH=src python -m unittest tests.test_evidence tests.test_cli -v`
→ **20 tests, OK** (`task-7-green.log`).

Final optimized own command:
`PYTHONPATH=src python -O -m unittest tests.test_evidence tests.test_cli -v`
→ **20 tests, OK** (`task-7-optimized-final.log`).

Directly relevant optimized dependency command, before the final I/O-only fix:
`PYTHONPATH=src python -O -m unittest tests.test_evidence tests.test_cli tests.test_codec tests.test_checker -v`
→ **61 tests, OK** (`task-7-optimized.log`).

`rg -n '\bassert\b' src/axiom/evidence.py src/axiom/__main__.py`
→ no matches (exit1 is the expected no-match result).

Root explicitly requested no broad suite during concurrent exhaustive selection
validation; full `unittest discover` and integrated optimized gates are deferred
to root's serialized integration, not represented as having passed here.

## H5/W7 demonstration

`task-7-demo.log` retains exact JSON outputs. Plan command:
`PYTHONPATH=src python -m axiom plan examples/stencil.ax --out /workspace/scratch/axiom-task7-demo --check-steps 100000`
→ exit0, completed, rows2-v1, selected key `[48,64,"rows2-v1"]`, selected check
work4253, total search work12847, optional work8506.

Plan bytes:
`plan-387c2ee208975f0a73f325d36765d09d8b08e94158196932dd41c674b53886e8.json`.
Exact replay with the published manifest → exit0, valid/satisfied, cap64.
Additional replay cap192 → exit0, cap64 retained, new constraint digest.
Additional replay cap0 → exit4, semantic valid / constraint violated, cap0,
new constraint digest. Each replay performs a fresh checker invocation.

## Self-review and rulings

- Ruling: output is a canonical manifest plus content-addressed source/plan
  snapshots; attempts/history are inline bounded records, so no separate history
  file can be silently missing. Cost if wrong: downstream tools must consume the
  documented schema rather than assuming historical filenames.
- Ruling: bytes-only replay has exact-byte context; CLI additionally verifies
  published reference files. Cost if wrong: API callers managing an on-disk
  bundle must call `verify_references` themselves; the distinction is documented.
- Ruling: manifest canonical encoding is required, beyond ordinary permissive
  JSON syntax. This follows the contract's canonical JSON format. Cost if wrong:
  hand-edited pretty JSON requires recanonicalization before replay.
- Ruling: directory ancestors must be actual directories, not symlinks, and
  publication uses Linux/POSIX dirfd APIs. This prevents redirection after an
  ancestor swap. Cost if wrong: a caller using a symlink output path must choose
  its real path; broader platform support would need another safe I/O adapter.
- Fresh source admission, exact checker identity/metrics, source cap plus
  additional-cap accounting, strict typed history, and noeligible null selection
  were reviewed together. History is never proof and rank replay is not a claim
  of global optimality.
- Atomicity is manifest-last plus fsync and no-replace immutable publication.
  Pinned descriptors prevent unintended outside mutation. Arbitrary later
  external modification of referenced bytes is detected rather than prevented;
  no filesystem protocol promises cryptographic isolation from arbitrary writers.
- Trusted components and source/span/alpha-label roles are explicit in docs.
  The independent original-AST oracle is unchanged. There is no native ABI or
  performance claim, no general DAG support, no unchecked public execution, no
  product assert-based validation, and no shell evaluation of artifact data.
- No deferred minor findings.

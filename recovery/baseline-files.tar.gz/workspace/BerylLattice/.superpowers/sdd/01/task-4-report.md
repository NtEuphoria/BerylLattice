# Task 4 report: independent final-plan checker

Status: implementation stable and ready for root-owned commit and independent review. No commit or subagent was created. Files owned: `axiom/src/axiom/checker.py`, `axiom/tests/test_checker.py`, and four fixture/document files under `axiom/tests/fixtures/plans/checker/`.

## Shared interfaces

- `check_plan(kernel: AdmittedKernel, plan: Plan, limits: Limits, *, additional_cap: int | None = None) -> CheckResult`.
- `CHECKER_VERSION = 'axiom-checker-v1'`; `CHECK_ACCOUNTING_VERSION = 1`; `ACCOUNTING_VERSION = 1` is an alias.
- Frozen, slotted `CheckResult`, in contract field order: `semantic_status: SemanticStatus`, `constraint_status: ConstraintStatus`, `check_complete: bool`, `reason: str`, `witness: tuple[tuple[str, int | str], ...] | None`, `workspace_bytes: int | None`, `multiplication_ops: int | None`, `opcode_counts: tuple[tuple[str, int], ...] | None`, `work_used: int`, `source_digest: str`, `plan_digest: str | None`, `checker_version: str`, `effective_cap: int | None`, `constraint_digest: str`.
- `.eligible` is derived exclusively from complete + semantic-valid + constraint-satisfied.
- `opcode_counts` uses sorted immutable pairs and includes only observed opcodes. Counters remain `None` until the whole symbolic physical-operation scan finishes, including when source construction or an early operation exhausts a quota. A later comparison exhaustion retains complete operation counters.
- Witnesses identify structural fields or operation/output positions and concrete uniform-input endpoint assignments where applicable. Potentially large overflow `result` values use decimal strings, preserving the codec's ten-digit integer bound.
- Constraint digest hashes codec canonical JSON of `{version: 1, property: 'plan_workspace_bytes', source_cap, additional_cap, effective_cap}`. Effective cap is the minimum supplied cap; absent caps are unbounded. Invalid additional caps raise `ValueError` (including bool), as invalid API context.
- Structural plans use shared `validate_plan(plan, limits)` and `plan_digest(plan, limits=limits)`; root approved and codec owner implemented the latter optional keyword.
- Reason codes include `VALID`, `CHECK_STEPS_EXHAUSTED`, `EXPRESSION_NODES_EXHAUSTED`, `STRUCTURAL_MISMATCH`, `INCONCLUSIVE_INTERVAL`, `ARITHMETIC_OVERFLOW`, `OUTPUT_VALUE_MISMATCH`, storage/coverage/index violations, source identity failures, and shared frontend/codec diagnostic codes. Quota/unsupported diagnostic codes yield unknown; concrete violations yield invalid with witnesses.

## Implementation evidence

Full source scalar expressions are built by independently interpreting the retained source AST, including producer read expansion and index ASTs. Source parsing/admission is reused only for the admission boundary: each call reparses retained source bytes and compares derived scalar kernel identity fields, then uses the fresh AST exclusively. Replaced AST metadata cannot replace source semantics; replaced caps cannot weaken the bytes' hard constraint. No planner or reference evaluator is imported.

Expression DAG edges are integer arena indices; no recursive equality, recursive hashing, producer token shortcut or algebraic rewriting. Source construction and equality comparison use explicit stacks. Every conceptual comparison pair is charged even when its physical expression is shared. Scratch is a sparse map, including billion-cell declarations. Bounds and two concrete uniform-input endpoint values propagate per scalar node; dead arithmetic is checked and every multiplication opcode counts. Inconclusive intervals cause unknown, and their conditional safe subintervals prevent unbounded intermediate Python integers without enabling validity.

Exact manual 1x1 accounting: 77 source AST visits (5 output grouping/add nodes, 20 producer-read/index nodes, 52 expanded producer nodes), 17 operations, 31 scalar comparison pairs = **125 work steps**. Every work quota 1..124 is tested for exhaustion and ineligibility, and 125 completes. Complete operation counters appear at 94 steps. The independent H5/W7 SSA-staged fixture has **285 operations, 48 multiplication operations, zero scratch bytes and 4065 work steps** (`35*77 +285 +35*31`). The H2/W2 allocation boundary is exactly 164 DAG nodes; this shape isolates checker allocation from the parser's separately applied AST node quota.

Fixtures independently specify canonical inline 1x1, SSA-staged 5x7 with an arbitrary label, and uninitialized scratch. Tests construct direct malformed, altered, overwritten, bounded-depth and arithmetic controls from the records without importing production schedule generators.

## RED / GREEN verification

- Initial 19-test checker suite ran before implementation and failed because `axiom.checker` did not exist; after implementation all 19 passed.
- Source trust-boundary regressions ran RED: forged kernel cap, forged retained output AST, forged source hash, forged semantic hash, and ignored source-byte limit were all accepted incorrectly. Reparse/admission binding made them GREEN.
- Overflow witness serialization regression ran RED with `INTEGER_TOKEN_LIMIT` for an actual overflow result; decimal-string result representation made it GREEN. A concurrent full-suite runner observed this intentional RED; root was notified when fixed.
- Final `PYTHONPATH=src python -m unittest tests.test_checker -q`: **28 tests passed**.
- Final `PYTHONPATH=src python -O -m unittest tests.test_checker -q`: **28 tests passed**.
- Final `PYTHONPATH=src python -m unittest discover -s tests -q`: **89 tests passed, 6 skipped**. Skips are native Core/clang gated controls requiring `AXIOM_TEST_CLANG` and `AXIOM_TEST_CORE`; no failures.
- A prior full `-O` snapshot also passed (88 tests, 6 native skips); the final small overflow-witness representation change was covered by the final normal and `-O` checker suites and final complete normal suite.
- `git diff --check` reported no tracked diff errors; implementation and fixture files are newly created and uncommitted as requested.

## Rulings and limitations

- Root-authorized hardening reparses source bytes on every check, with source parsing/admission outside the deterministic checker-work counter and subject to its own Limits. This prevents forged immutable records from weakening constraints. It adds bounded admission work per candidate; the counter remains checker work rather than total compiler time.
- Endpoint assignments are concrete witnesses, not a solver. Structural inequality with equal sampled values remains unknown; an in-bounds wrong neighbor therefore need not produce invalidity. Interval imprecision likewise remains unknown. This is required conservative incompleteness.
- Scratch workspace excludes SSA retention by contract; the staged positive control deliberately demonstrates that limitation.
- No native lowering, planner, selector or execution-entry changes were made. Root remains responsible for independent review, committing and integration.

# Lattice research: incremental semantics and artifact reuse

Research note, 2026-10-15. Recommendations only; no compiler implementation,
build, benchmark, installation or configuration change was performed.
Lattice Core is the user's normal 4GL language under development. Axiom is a
separate next-generation 5GL language. Shared query/artifact infrastructure
would be an implementation choice, not a definition of Axiom's language.

## Scope and primary-source evidence

Exactly three documents were read. Their fetched bytes, retrieval times, URLs,
SHA-256 hashes and HTTP ETags are recorded in `sources.json`. URLs identify
mutable upstream branches; the local SHA-256 identifies the exact snapshot.
The documents contain historical passages; this is evidence for mechanisms,
not an assertion about a measured current rustc/LLVM release.

1. Rust Compiler Development Guide, **Queries: demand-driven compilation**:
   https://rustc-dev-guide.rust-lang.org/query.html
   (`rustc-query.md`, lines 18–28). Queries memoize results and dynamically record
   other queries they read. This supports on-demand computation and dependency
   graphs; it does not establish that every compiler phase is already incremental.
2. Rust Compiler Development Guide, **Incremental compilation in detail**:
   https://rustc-dev-guide.rust-lang.org/queries/incremental-compilation-in-detail.html
   (`rustc-incremental-in-detail.md`). Mechanisms supported by this source:
   - Pure query functions and explicit dependencies: lines 3–9 and 33–37.
   - Red–green validation: lines 94–191. A changed input need not change an
     intermediate result, so re-evaluation can stop further invalidation.
   - Stable cross-session identities: lines 220–263. Sequential numeric IDs
     cannot safely be persisted as durable item identities.
   - Stable result fingerprints: lines 267–313. Fingerprinting has a real cost;
     the guide explicitly says it can make incremental compilation slower.
   - Reused nodes must carry their dependency edges into the next graph:
     lines 316–355. Cache promotion addresses unused-but-still-valid entries:
     lines 358–384.
   - Backend work can be tracked at code-generation-unit granularity even
     though the backend itself is not query based: lines 388–415.
   - Projection queries isolate small results from monolithic state changes:
     lines 497–539. Volatile source spans can harm reuse: lines 552–558.
3. Clang documentation, **ThinLTO**:
   https://clang.llvm.org/docs/ThinLTO.html
   (`llvm-ThinLTO.md`, lines 13–25, 125–194). Compact per-module summaries feed
   a combined index; transformations occur in parallel module backends. A
   linker cache must be enabled and supports pruning policies. This guide does
   not specify complete internal cache-key construction. Its performance prose
   and linked historical blog are not local Lattice measurements.

## Architecture recommendations, not source claims

The reviewed checkout at `0a678b4` emits C/EnforceScript from a typed AST and has
an experimental schema-5 IR. Do not require a compiler rewrite, Rust adoption,
or an entire new middle end to investigate incremental semantics.

Start by separating query boundaries around existing compiler operations:

`source snapshot -> parse/module index -> item signature/body projections ->`
`name resolution/type/effect facts -> validated IR fragment -> emission unit`.

Names here are proposed responsibilities, not existing API names. A coarse
parser can initially rerun while unchanged item projections keep downstream
facts reusable. Introduce persistent caching only after in-process query
semantics and dependency tracing can be checked against full recomputation.
Avoid a whole-program query result as the direct input to every item query.

Keep three independently invalidated layers:

- **Semantic facts:** signatures, layouts, resolved names, effects, bounds and
  validated IR. These belong in Core's independently correct compilation path.
- **Candidate and proof artifacts:** candidate transforms, their obligations,
  proofs or validation evidence, and budgeted search state. Both languages may
  consume shared infrastructure when their explicit semantics agree.
- **Target artifacts:** selected schedules/layouts, emitted C or backend IR,
  objects and final links. Changes in performance models need not invalidate a
  target-independent semantic theorem, but can invalidate candidate selection.

A ThinLTO-style summary layer is useful architectural precedent for bounded
cross-module decisions. It is not a substitute for semantic invalidation and
is not automatically available merely because Core emits C. A future Clang
backend experiment must pin compiler/linker versions, module partitioning,
flags and cache state. Current coarse emission may limit object reuse.

## Keys and dependency contracts

A query identity and a reusable result's validity are different things.
Proposed query identity: `(query kind/version, stable package/module/item
identity, relevant semantic configuration)`. Its memo records read dependencies
and stable result fingerprints. A changed source hash can make a query dirty
without making its semantic output changed. Source file offsets, traversal IDs,
raw pointers and arena indices must not be durable identities. Ambiguous item
identity after edits should conservatively miss the cache.

Use compiler/schema versions as conservative namespace invalidators first;
only split version invalidation more finely after correctness is established.
Use unambiguous, versioned serialization with complete type/domain tagging.

| Artifact | Proposed required inputs for validation or cache identity |
|---|---|
| Semantic query result | Stable query identity; source/item projection; every queried name/import/type/effect/layout/constant fact; relevant language options and dependency metadata identities. |
| Search attempt/checkpoint | Canonical validated IR; semantic assumptions and dependency fingerprints; permitted transformations/rules; search implementation/version; deterministic seed/order; cost model/profile/target used by search; budget class and consumed resources. |
| Proof/certificate | Exact source and candidate semantic artifacts; precise obligation and admitted domain; assumptions/axioms including arithmetic, bounds, effects and destruction order; proof format and checker semantics/version; target assumptions if used by the theorem. |
| Selected optimization | Candidate and validated proof identities; selection objective/cost model/profile; target/ABI and relevant backend pipeline; optimization policy. |
| Emitted C/IR/object | Exact validated input and lowering implementation; target/features/ABI; compiler/backend and library interfaces; codegen flags; imported bodies/summaries actually used; debug/source mapping where applicable. |

These are design inputs to audit, not an exhaustive implemented key schema.
A hash match checks identity subject to collision assumptions; it does not prove
semantic equivalence. Cache records should include content digests and versioned
metadata, reject malformed/incomplete entries, and fall back to recomputation.

A valid proof can outlive a changed cost model when no cost-model fact appears
in its theorem. Keep proof reuse distinct from a claim that its candidate is
still the fastest. If a persisted proof is rechecked, report that as proof
checking rather than new search; if it is reused without rechecking, state the
trusted cache/checker-version boundary explicitly. A timeout or exhausted budget
is an outcome of that attempt, never evidence that no legal candidate exists.
Changing the budget or seed should permit retry; a previously validated candidate
can remain an incumbent if its own semantic dependencies are unchanged.

## Invalidation correctness requirements

1. Every semantically relevant read goes through the tracked input/query layer.
   Include negative name lookups: adding a declaration/import can change a
   previously absent lookup or candidate set without changing the caller body.
   A callee's unchanged signature does not justify reusing a caller optimization
   that depended on the callee's body, purity or effect summary.
2. Publish immutable results for one source/configuration snapshot. Never mix
   facts from different edits. Replace a recomputed query's dynamic dependencies
   with its new read set; preserve edges for reused queries. If branching changes,
   do not replay obsolete dependent computations as though still applicable.
3. Treat relevant options, imported metadata and modeled external inputs as
   tracked inputs. Reject or recompute work with untracked mutable state; a
   caching annotation cannot make an impure operation deterministic.
4. Separate semantic payloads from current source locations where possible.
   Reuse of a type fact must not replay an old error location, silently omit a
   diagnostic, or retain stale debug mappings. Cache diagnostics as explicit
   results with current mapping dependencies, not hidden one-time side effects.
5. For recursive analyses, define cycle/fixed-point handling explicitly; ordinary
   memoization over the documented acyclic model does not solve recursion.
6. Use atomic cache publication and bounded storage. Persist graph edges and
   reusable values consistently; avoid losing valid values merely because a
   warm compilation never materialized them. Missing/corrupt/version-mismatched
   entries should be cache misses, not accepted partial results.

Items 1–6 are our proposed engineering contract. They extend the principles in
the cited documents; the documents do not prove this contract for Lattice.

## Latency experiment: distinguish the user's waits

Measure these wall-clock endpoints independently on the same pinned workload:

- Edit accepted -> current complete diagnostics (`T_feedback`).
- Build requested -> validated ordinary Core artifact available (`T_core`).
- Optimization requested -> requested optimized artifact available (`T_opt`).
- Final link time and produced-program runtime, reported separately.

If a mode requests synthesis as a required contract, its contract diagnostics
belong to that mode; ordinary Core readiness does not imply the contract passed.
Search can be separately budgeted without conflating Core with Axiom's language
identity. Log search timeout, cancellation and proof-check outcomes explicitly.

Record phase wall time, process CPU time, peak RSS, cache lookup/hash/read/write
cost, query executed/reused/green-after-recompute counts, proof recheck/search
counts, backend units rebuilt, link time and cache bytes. Parallel phase CPU
sums are not end-to-end wall time. Report cold build, warm no-op build, warm
one-item edit and process restart with disk cache separately. Record filesystem
cache conditions without claiming privileged cache flushing occurred.

For a first experiment, predeclare repetitions and ordering (for example 30
paired cached/uncached runs per edit with randomized pair order), preserve raw
observations, report median/tail dispersion, and pin CPU/resource allocation,
compiler versions, flags, source revision and backend. Choose numeric success
thresholds after a pilot baseline, before evaluation; no speed target is already
supported by these sources. A correct implementation that loses time to hashing,
serialization or coarse backend recompilation is a legitimate negative result.

## Small falsifiable edit matrix

Use one small multi-module program with two independent functions and a caller,
plus the bounded fixed-array fusion candidate described in the roadmap review.
Run each edit from the same populated baseline cache, then compare a cached
build to a clean recomputation of the exact edited source/configuration. Check
accepted/rejected status, current diagnostics, complete observable behavior and
validated artifacts. Binary identity is an extra check only where deterministic
emission is established; a runtime sample alone is not a proof of equivalence.

| Edit/control | Expected reuse or invalidation to test | Falsifier |
|---|---|---|
| No edit, including a new compiler process | Reuse valid semantic and artifact entries; measure disk load overhead. | Changed result/diagnostic, missing graph dependency on later edit, or claimed warm speedup absent in timings. |
| Insert comment/blank lines before a function | Semantic projections may remain green; source-map/diagnostic mappings update. | Old diagnostic locations or avoidable whole-program semantic invalidation under the proposed projection design. |
| Change a private function body while its signature/effect summary stays equal | Recompute body-dependent work; unrelated function and signature-only caller checks may remain green. | Stale body-dependent optimization, or unrelated semantic work reruns contrary to the declared dependency contract. |
| Change a used signature/type/layout or introduce an effect | Recompute affected callers, obligations and target artifacts. | A previously valid candidate/proof survives despite using the changed fact, or an expected type/effect error disappears. |
| Add a declaration/import that changes name resolution | Invalidate lookup candidate sets, including a prior missing lookup. | The cached build resolves a different symbol or reports a different error from the clean build. |
| Change the fusion candidate's proven bound/overflow/effect assumption | Rebuild its obligation; reject or fall back if the candidate no longer validates. | Cached fusion accepted under the previous domain or changed trap/destruction order. |
| Change target features/ABI or compiler/schema/checker version | Invalidate dependent artifacts; semantic reuse only where explicitly target/version independent. | Wrong-target object reuse, unsupported old proof format accepted, or stale layout fact. |
| Change only cost model/profile or search budget | Reconsider selection/search as appropriate; independently valid semantic proofs may remain reusable. | Timeout treated as impossibility, stale selection presented as newly optimized, or a proof reused despite a changed assumption. |

Add one fault-injection control outside ordinary edit timings: truncate one cache
entry and confirm a safe miss/recompute with the same outcome as clean build.
All correctness rows must pass before claiming incremental correctness. Query
counts test the proposed granularity; wall time separately tests whether the
extra machinery pays for itself. Neither pass establishes a speed advantage
over Rust, LLVM or another language.

# Axiom architecture and performance: research decisions

2026-10-15. Private working research, using Superpowers brainstorming and
parallel investigation. This records alternatives and recommendations; it is
not an approved implementation specification or a performance result.

## Confirmed goal

Lattice Core is the normal 4GL language under development. Project Axiom is
the next-generation moonshot 5GL language in its own right. The user selected
this first programmer experience:

> Declare domain computations and constraints; Axiom chooses layouts and
> schedules.

That choice defines the first demonstration, not the limit of the eventual
language. Core and Axiom may share checked representations and backends where
their semantic contracts agree. Sharing infrastructure does not require
identical surface languages or all of the same source semantics.

The supplied roadmap is proposed architecture, not evidence that its described
subsystems exist. The inspected Beryl baseline is commit
`0a678b4ae6d41190c4f5a8bf063caba05759d20d` on `v0.2-performance`.

## Recommendation

Complete a bounded design round, then build a small executable language slice.
The highest-value work is specifying the computation/constraint contract, the
boundary between meaning and physical execution, and independently checked
schedule choices. A larger list of optimizer techniques would not resolve those
dependencies.

Proposed architecture: a distinct Axiom frontend produces a typed logical
computation representation. A deterministic baseline and bounded planner
produce physical plans. Legality checks admit plans against explicit source
contracts. Validated plans lower through an adapter to an admitted shared
representation/backend. Keep reference interpretation available as an oracle
for the supported language subset.

This is an architecture proposal. Today's Core production path still emits
from its typed AST; its schema-5 IR is limited to experimental differential
tests. No proposed shared production path exists merely because it appears
in this note.

## Three architecture options

| Option | Benefit | Cost or limitation | Recommendation |
|---|---|---|---|
| Axiom lowers directly to Core source | Fast bootstrap; reuse current checking and C generation; readable intermediate output. | Logical shapes, plan identity and source diagnostics need additional representation; Core's source language may not express every Axiom contract. | Useful reference/bootstrap path, with explicit conformance obligations. |
| Distinct Axiom logical representation and physical plans, with an adapter to a checked common subset | Preserves domain information and language identity; allows small trusted legality rules and backend reuse. | Requires a minimal IR contract, source mapping and separately validated lowering. Current Core IR is only a starting point. | Preferred direction; begin with one array domain and one CPU target. |
| Adopt a broad MLIR-based middle end immediately | Established operations, analyses, bufferization and lowering infrastructure. | C++/build integration, language-semantic bridging, op interfaces, ownership ABI and pipeline costs. No local benefit has been measured. | Evaluate with a bounded adapter experiment before committing the whole project. |

The second option does not mean implementing a full replacement for MLIR. It
means deciding which facts Axiom must retain, and evaluating existing machinery
against that contract. An MLIR implementation could later serve the same
architecture if it earns its integration cost.

## Improvements supported by this research

### 1. Separate computation, hard constraints, objectives and budgets

The language contract should distinguish:

- **Meaning:** value equations, iteration domains, shapes, arithmetic, failure
  behavior and observable effects.
- **Hard constraints:** properties every accepted implementation must satisfy,
  such as a supported scratch-storage bound or forbidden allocation.
- **Objectives:** preferences among legal implementations, such as lower
  latency, fewer bytes moved or smaller code.
- **Search budgets:** compiler work/time/memory limits, which constrain the
  attempt rather than changing the program's meaning.

A speed estimate is not a static guarantee. A declared input range is either
proved at the caller, checked at a boundary, or an explicitly defined precondition;
writing an annotation must not silently justify unsafe operations on arbitrary
inputs. Exact arithmetic is the initial contract. Approximate floating-point
behavior would need its own explicit domain and error semantics.

An inconclusive optional search can return a validated baseline **only if that
baseline also satisfies every hard constraint**. If no such implementation is
known within budget, report unknown/exhausted/unsupported accurately. Do not
silently weaken a no-allocation or other hard requirement. A disproved property
and an unsuccessful search are different outcomes.

### 2. Preserve shapes and value semantics before selecting storage

MLIR's official bufferization guide recommends tensor tiling/fusion before
conversion to mutable buffers [S1]. Its rationale explains progressive lowering
and why reconstructing lost high-level structure can be difficult [S2].

For Axiom, retain typed use-def relationships, shapes, index maps, structured
iteration, effects, failure ordering and source origins until fusion decisions
are made. At the storage boundary, add base-allocation/view identity, writable
destinations, alias/equivalence facts, liveness, initialization and responsibility
for deallocation. Existing broad effect flags alone do not establish these facts.

One-Shot Bufferize is a useful bounded destination-or-fresh-allocation mechanism;
it does not search every reusable buffer or implement general Perceus reuse.
Deallocation is separate. MLIR's default ownership ABI can require copies when
a returned memref shares an argument's allocated base, including disjoint views
[S1, S3]. Those are concrete integration questions for Axiom's future view model.

### 3. Make physical plans inspectable and replayable

Halide separates computation placement from storage placement/lifetime. Its
tutorial shows why circular-buffer reuse can stop being legal when loops execute
in parallel [S4]. Exo exposes small transformations, inspections and references
that can survive transformations, with legality tied to effect analysis [S5].

Axiom's planner can use similar concepts internally while programmers express
domain computations. Record which operations were fused, which values were
materialized, where storage lives and which assumptions justify the plan. Retain
a replayable plan identity and source mapping so a surprising result can be
explained without rerunning search.

Storage minimization is not automatically time minimization: recomputing a
producer can eliminate temporary memory while increasing arithmetic work. Rank
whole plans, including recomputation, traffic, code size and boundary costs.

### 4. Start with finite plan selection and explicit termination

The first domain needs a small finite portfolio, not general equality saturation.
Keep the baseline among candidates; check legality before evaluating profitability.
Introduce e-graphs later for a specific equivalence domain that benefits from them.

The fetched egg runner implements node, iteration and time limits, but checks
them between operations [S6]. Such cooperative limits are not hard deadlines or
peak-memory guarantees. If Axiom promises stronger limits, the planner needs
bounded expansion, cancellation and an outer resource boundary. Record stop
reason, explored candidates and resource use. A timeout is not proof of impossibility.

Use deterministic work limits, stable candidate order and versioned seeds for
reproducible experiments, with a wall-clock guard for operational control. Save
the selected validated plan so later builds can replay it without search.

### 5. Separate semantic validity, search history and target profitability

The rustc query documentation describes dynamically tracked dependencies,
stable identities, result fingerprints and red–green validation [S7]. Changed
source can yield unchanged semantic results, stopping downstream invalidation.
It also explicitly acknowledges that fingerprinting has overhead and can lose
time. ThinLTO provides precedent for summaries and cached backend work [S8].

Start with small semantic projections around the existing compiler, even if
parsing initially remains coarse. Keep separate reusable records for semantic
facts, candidate/legality evidence and emitted target artifacts. A changed cost
model can require re-selection without invalidating a target-independent theorem;
a changed effect, arithmetic assumption or relevant callee body can invalidate
the candidate itself.

Keys and dependencies must include stable item identities, semantic configuration,
source/candidate identities, assumptions, rule/checker versions and relevant
target/profile facts. Arena indices are not persistent identities. Negative name
lookups and current diagnostic locations also matter. Compare cached compilation
with clean recomputation before claiming reliable incrementality.

### 6. Define the validation boundary before promising proof

Use small transformation rules with explicit preconditions and a validator that
does not accept a candidate merely because the planner generated it. Differential
tests and counterexample tests are essential regression evidence; they are not
proof for every possible input.

Alive2 demonstrates LLVM-level translation validation but explicitly does not
support interprocedural transformations [S9]. It cannot replace validation of
Axiom's source semantics, an arbitrary fusion pass, storage lifetimes or timing
security. Rosette illustrates that solver-aided languages require an explicitly
supported symbolic subset; unsupported host-language constructs can invalidate
reasoning [S10]. A solver integration is therefore a scoped design decision,
not an automatic correctness guarantee.

Constant-time behavior, general concurrent scheduling and accelerator semantics
remain separate research obligations. No results here establish those guarantees.

## A more informative first language experiment

Keep the previous two-loop integer fusion example as a legality control. For
the first Axiom language demonstration, use a small declarative stencil with a
real materialization-versus-recomputation choice. These equations specify a
candidate problem, not finalized Axiom syntax:

```text
p(u,v)   = (input(u,v) + 1)²
out(u,v) = p(u,v) + p(u+1,v) + p(u,v+1) + p(u+1,v+1)
```

Specify immutable input, disjoint output, explicit boundary domains and integer
inputs in [0,1023]. Under that domain the largest producer result is 1,048,576
and the largest output is 4,194,304, within signed 32-bit range. Establish the
input-domain contract before relying on those bounds.

Compare three sequential plans: full intermediate materialization, inline
recomputation, and scanlines with a two-row circular intermediate. A scratch
constraint should affect which plans are admissible. An impossible or unproved
constraint must produce the defined outcome, not an unchecked fallback.

The legality corpus includes changed first traps, live old values, overlapping
destinations, incorrect boundaries, unsupported effects, and storage reuse
across overlapping iteration lifetimes. Exercise exhausted-budget fallback and
exact plan replay. An independent reference computes complete expected outputs.

**Important current limit:** Core's experimental IR has a 256-cell aggregate
bound (`src/ir/ir.h:29`). Tiny shapes can exercise semantics and plan validation,
but cannot establish large-array throughput. Use one shape within the existing
admitted subset first. Larger/dynamic buffers need a separately specified
storage and lowering path; do not just remove the bound to produce a benchmark.

An invalid trace falsifies a legality rule. Identical backend output can falsify
the claimed added benefit on a workload. More recomputation, conversions, checks
or compile time can erase the benefit of smaller intermediate storage. Preserve
such results.

## Performance evidence and stopping rules

Measure correctness first, then pass-off/pass-on results against straightforward
and manually scheduled C and safe Rust with equivalent arithmetic, targets and
backend settings. Report runtime, intermediate storage/traffic, code size,
compilation resources and search cost separately. Freeze held-out inputs before
tuning. Select numerical improvement/regression thresholds after pilot noise
measurement and before final evaluation; this research supports no speed figure.

For compilation, measure edit-to-diagnostics, ordinary build-to-runnable artifact,
and optimization-request-to-validated-artifact separately. Warm no-op, warm edit,
cold build and process-restart cache scenarios are different workloads. A faster
cache lookup is not a faster complete build. The companion incremental memo
contains an eight-case edit/invalidation matrix.

Where optimized code will run repeatedly, report the break-even point: extra
search and compilation cost divided by measured per-run saving, when that saving
is positive. Keep compile-time and runtime improvements attributable to their
own work. A single aggregate score cannot establish a general language advantage.

Finish this research phase when five reviewable items exist:

1. A minimal semantic contract for the chosen computations and constraints,
   including invalid inputs, traps, hard constraints and exhausted search.
2. A Core/Axiom interface decision with the minimal shape/effect/ownership facts
   and an identified reference/lowering path.
3. The small plan portfolio and its explicit legality obligations and negative cases.
4. A benchmark protocol covering baseline equivalence, held-out cases, compiler
   cost and attributable gains, with honest treatment of the current IR size limit.
5. A scoped prototype plan and named unresolved questions that the prototype can
   actually falsify.

This memo frames those items; it does not claim to be their completed formal
specification. Under Superpowers, present and refine the selected architecture,
then prepare the written design for review before implementation planning.
Research that cannot change one of these decisions can wait for prototype evidence.

## Source record

Fetched from official project GitHub sources on 2026-10-15 with normal TLS
verification. Cached source manifests record URLs and SHA-256 hashes. Branch
URLs are mutable; hashes identify the exact reviewed local bytes. No cited
performance experiment was rerun here.

- **S1:** [MLIR Bufferization](https://github.com/llvm/llvm-project/blob/main/mlir/docs/Bufferization.md).
- **S2:** [MLIR Rationale](https://github.com/llvm/llvm-project/blob/main/mlir/docs/Rationale/Rationale.md), a design discussion rather than normative language semantics.
- **S3:** [MLIR Ownership-Based Buffer Deallocation](https://github.com/llvm/llvm-project/blob/main/mlir/docs/OwnershipBasedBufferDeallocation.md).
- **S4:** [Halide scheduling lesson](https://github.com/halide/Halide/blob/main/tutorial/lesson_08_scheduling_2.cpp).
- **S5:** [Exo design](https://github.com/exo-lang/exo/blob/main/docs/Design.md).
- **S6:** [egg runner source](https://github.com/egraphs-good/egg/blob/main/src/run.rs).
- **S7:** [rustc queries](https://github.com/rust-lang/rustc-dev-guide/blob/master/src/query.md) and [incremental compilation](https://github.com/rust-lang/rustc-dev-guide/blob/master/src/queries/incremental-compilation-in-detail.md).
- **S8:** [Clang ThinLTO](https://github.com/llvm/llvm-project/blob/main/clang/docs/ThinLTO.md).
- **S9:** [Alive2](https://github.com/AliveToolkit/alive2/blob/master/README.md).
- **S10:** [Rosette](https://github.com/emina/rosette/blob/master/README.md).

Companion analyses: `ir-storage/assessment.md` and
`incremental/research-notes.md`. Source caches are local research material,
not installed dependencies. No compiler code, repository history, external
messages or cloud configuration were changed in this research round.

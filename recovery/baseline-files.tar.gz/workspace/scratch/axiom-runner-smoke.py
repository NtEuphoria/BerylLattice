import json
from dataclasses import fields
from pathlib import Path
from axiom.core_toolchain import Toolchain,CommandReceipt,FileIdentity
from axiom.core_emit import emit_core
from axiom.codec import encode_plan
from axiom.frontend import parse_source,admit_source
from axiom.planner import make_plan
from axiom.model import Limits
from axiom.core_runner import run_core
raw=json.loads(Path('/workspace/scratch/axiom-toolchain-task1/receipts/toolchain.json').read_text())
for k in ('compiler','clang','snapshot','source_repository','receipt_path'): raw[k]=Path(raw[k])
for k in ('clang_config','clang_components','native_artifacts'):
    raw[k]=tuple(FileIdentity(Path(v['path']),v['sha256'],v['size']) for v in raw[k])
def receipt(v):
    v['argv']=tuple(v['argv']);v['cwd']=Path(v['cwd']);return CommandReceipt(**v)
for k in ('build_receipt','unit_receipt','native_receipt'): raw[k]=receipt(raw[k])
raw['preflight_receipts']=tuple(receipt(v) for v in raw['preflight_receipts'])
for k in ('source_inventory','snapshot_inventory'):raw[k]=tuple(tuple(v) for v in raw[k])
for k in ('identity_limits','generated_changes'):raw[k]=tuple(raw[k])
chain=Toolchain(**raw)
source=Path('/workspace/BerylLattice/axiom/tests/fixtures/core_emit/minimal.ax').read_bytes()
bundle=emit_core(source,encode_plan(make_plan(admit_source(parse_source(source)),'inline-v1')),Limits(),(0,1,2,3),(-99,))
for lane in ('reference','ast','ir'):
    run=run_core(bundle,chain,lane,Path('/workspace/scratch/axiom-runner-smoke'))
    print(lane,run.classification,run.reason,run.cwd,flush=True)
    if run.report_bytes:print(run.report_bytes.decode(),flush=True)

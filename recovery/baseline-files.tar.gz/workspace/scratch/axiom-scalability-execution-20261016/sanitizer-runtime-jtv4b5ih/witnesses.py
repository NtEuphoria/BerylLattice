import os,json,hashlib,subprocess,shutil,time
from pathlib import Path
ROOT=Path(__file__).parent
ORIGINAL=Path('/workspace/scratch/cloud-onboarding-native-20261016/toolchain')
CLANG=ORIGINAL/'usr/lib/llvm-19/bin/clang'
resource=ROOT/'prefix/usr/lib/llvm-19/lib/clang/19'
records=[]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,data): (ROOT/name).write_text(json.dumps(data,indent=2)+'\n')
def inventory(p):
    return [{'path':str(x.relative_to(p)),'symlink':os.readlink(x)} if x.is_symlink() else {'path':str(x.relative_to(p)),'sha256':sha(x),'size':x.stat().st_size} for x in sorted(p.rglob('*')) if x.is_file() or x.is_symlink()]
def run(argv,*,env=None):
    started=time.time(); r=subprocess.run([str(a) for a in argv],cwd=ROOT,env=env,capture_output=True,text=True,timeout=30)
    item={'argv':[str(a) for a in argv],'cwd':str(ROOT),'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'duration_seconds':time.time()-started}
    if env is not None: item['environment_overrides']={k:env[k] for k in ('ASAN_OPTIONS','UBSAN_OPTIONS','LSAN_OPTIONS') if k in env}
    records.append(item); save('witness-commands.json',records)
    return r
clean=ROOT/'clean.c'
clean.write_text('#include <stdlib.h>\n#include <stdio.h>\nint main(void) { int *p = malloc(4*sizeof *p); if (!p) return 2; for(int i=0;i<4;i++) p[i]=i; int value=p[3]; free(p); printf("clean:%d\\n",value); return value!=3; }\n')
common=[str(CLANG),'-resource-dir='+str(resource),'-std=c11','-O1','-g','-fno-omit-frame-pointer']
initial=run(common+['-fsanitize=address',str(clean),'-o',str(ROOT/'initial-header-probe')])
copies=[]
if initial.returncode:
    assert "'stddef.h' file not found" in initial.stderr or "'stdarg.h' file not found" in initial.stderr, initial.stderr
    original_headers=ORIGINAL/'usr/lib/llvm-19/lib/clang/19/include'
    for path in sorted(original_headers.rglob('*')):
        if not path.is_file(): continue
        target=resource/'include'/path.relative_to(original_headers)
        if target.exists(): continue
        target.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(path,target)
        copies.append({'source':str(path),'target_relative_to_resource':str(target.relative_to(resource)),'sha256':sha(target),'size':target.stat().st_size})
save('copied-original-headers.json',copies)
header_targets={x['target_relative_to_resource'] for x in copies}
resource_inventory=inventory(resource)
for x in resource_inventory: x['origin']='qualified_original_resource_header_copy' if x['path'] in header_targets else 'authenticated_libclang-rt-19-dev_package'
save('overridden-resource-inventory.json',resource_inventory)
faults={
'address': '#include <stdlib.h>\nint main(void) { int *p=malloc(sizeof *p); if(!p) return 2; *p=9; free(p); return *(volatile int *)p; }\n',
'undefined': '#include <limits.h>\nint main(void) { volatile int x=INT_MAX; return x+1; }\n',
'leak': '#include <stdlib.h>\n__attribute__((noinline)) void lose(void) { char *p=malloc(91); if(!p) abort(); p[0]=7; __asm__ volatile("" : : "r"(p) : "memory"); }\nint main(void) { lose(); return 0; }\n'
}
opts={'ASAN_OPTIONS':'detect_leaks=1:halt_on_error=1:symbolize=0','UBSAN_OPTIONS':'halt_on_error=1:print_stacktrace=1:symbolize=0','LSAN_OPTIONS':'exitcode=23:symbolize=0'}
env=dict(os.environ,**opts)
results=[]
for sanitizer in ('address','undefined','leak'):
    for case in ('clean','fault'):
        source=clean
        if case=='fault':
            source=ROOT/(sanitizer+'-fault.c'); source.write_text(faults[sanitizer])
        binary=ROOT/(sanitizer+'-'+case)
        compile_result=run(common+['-fsanitize='+sanitizer,'-fno-sanitize-recover=all',str(source),'-o',str(binary)])
        assert compile_result.returncode==0, compile_result.stderr
        r=run([binary],env=env)
        if case=='clean': assert r.returncode==0 and r.stdout=='clean:3\n' and not r.stderr, (sanitizer,r)
        else:
            marker={'address':'AddressSanitizer: heap-use-after-free','undefined':'runtime error: signed integer overflow','leak':'LeakSanitizer: detected memory leaks'}[sanitizer]
            assert r.returncode!=0 and marker in r.stderr, (sanitizer,r)
        results.append({'sanitizer':sanitizer,'case':case,'binary':str(binary),'binary_sha256':sha(binary),'source':str(source),'source_sha256':sha(source),'compile_returncode':compile_result.returncode,'run_returncode':r.returncode,'detected':case=='fault'})
binary=ROOT/'address-undefined-clean'
r=run(common+['-fsanitize=address,undefined','-fno-sanitize-recover=all',str(clean),'-o',str(binary)]); assert r.returncode==0,r.stderr
r=run([binary],env=env); assert r.returncode==0 and r.stdout=='clean:3\n' and not r.stderr
results.append({'sanitizer':'address,undefined','case':'clean','binary':str(binary),'binary_sha256':sha(binary),'source':str(clean),'source_sha256':sha(clean),'compile_returncode':0,'run_returncode':r.returncode})
after=inventory(ORIGINAL); save('original-prefix-after.json',after)
assert after==json.loads((ROOT/'original-prefix-before.json').read_text()),'original prefix changed'
save('witness-results.json',{'scope':'Sanitizer prerequisite checks only; not B3 host correctness or production qualification.','result':'PASS','clang':str(CLANG),'clang_sha256':sha(CLANG),'resource_dir':str(resource),'flags':['-resource-dir='+str(resource),'-std=c11','-O1','-g','-fno-omit-frame-pointer','-fsanitize=address,undefined','-fno-sanitize-recover=all'],'runtime_environment_overrides':opts,'copied_original_header_count':len(copies),'resource_inventory_count':len(resource_inventory),'original_prefix_unchanged':True,'results':results})
print((ROOT/'witness-results.json').read_text())

import os,json,hashlib,subprocess,shutil,time
from pathlib import Path
ROOT=Path(__file__).parent
ORIGINAL=Path('/workspace/scratch/cloud-onboarding-native-20261016/toolchain')
CLANG=ORIGINAL/'usr/lib/llvm-19/bin/clang'
RECEIPT=Path('/workspace/scratch/cloud-onboarding-native-20261016/qualification-57lxdp8j/receipts/toolchain.json')
records=[]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,data): (ROOT/name).write_text(json.dumps(data,indent=2)+'\n')
def inventory(p):
    return [{'path':str(x.relative_to(p)),'symlink':os.readlink(x)} if x.is_symlink() else {'path':str(x.relative_to(p)),'sha256':sha(x),'size':x.stat().st_size} for x in sorted(p.rglob('*')) if x.is_file() or x.is_symlink()]
def run(argv,*,cwd=ROOT,env=None,check=True):
    started=time.time(); r=subprocess.run([str(a) for a in argv],cwd=cwd,env=env,capture_output=True,text=True,timeout=180)
    item={'argv':[str(a) for a in argv],'cwd':str(cwd),'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr,'duration_seconds':time.time()-started}
    records.append(item); save('commands.json',records)
    if check and r.returncode: raise RuntimeError(f'command failed: {argv}, exit {r.returncode}')
    return r
save('original-prefix-before.json',inventory(ORIGINAL))
receipt=json.loads(RECEIPT.read_text()); assert sha(CLANG)==receipt['clang_sha256']
for cfg in receipt['clang_config']: assert sha(Path(cfg['path']))==cfg['sha256']
save('compiler-identity.json',{'clang':str(CLANG),'clang_sha256':sha(CLANG),'toolchain_receipt':str(RECEIPT),'toolchain_receipt_sha256':sha(RECEIPT),'clang_config':receipt['clang_config']})
policy=json.loads(Path('/etc/codex/network-policy.json').read_text())
assert not policy['vpn_configured']
assert any(r.get('host')=='deb.debian.org' for r in policy['http_network_policy']['egress_rules'])
save('network-policy-evidence.json',{'policy_path':'/etc/codex/network-policy.json','policy_sha256':sha(Path('/etc/codex/network-policy.json')),'vpn_configured':False,'deb.debian.org_allowed':True,'inherited_proxy_variable_names':sorted(k for k in os.environ if 'proxy' in k.lower()),'inherited_ca_variable_names':sorted(k for k in os.environ if 'CA_' in k or k in ('SSL_CERT_FILE','SSL_CERT_DIR','REQUESTS_CA_BUNDLE','CURL_CA_BUNDLE')),'environment_changes':'APT_CONFIG only, subprocess-local'})
apt=ROOT/'apt'; packages=ROOT/'packages'
for directory in (apt/'lists/partial',apt/'cache/archives/partial',apt/'parts',packages): directory.mkdir(parents=True)
keyring=Path('/usr/share/keyrings/debian-archive-keyring.gpg'); ca=Path('/etc/ssl/certs/ca-certificates.crt')
sources=apt/'sources.list'; sources.write_text(f'deb [signed-by={keyring}] https://deb.debian.org/debian trixie main\n')
options={'Dir::Etc::main':'-','Dir::Etc::parts':str(apt/'parts'),'Dir::Etc::sourcelist':str(sources),'Dir::Etc::sourceparts':'-','Dir::State::lists':str(apt/'lists'),'Dir::Cache':str(apt/'cache'),'Acquire::https::CaInfo':str(ca),'Acquire::https::Verify-Peer':'true','Acquire::https::Verify-Host':'true','Acquire::AllowInsecureRepositories':'false','APT::Get::AllowUnauthenticated':'false','Acquire::Retries':'2','APT::Get::List-Cleanup':'false','Debug::pkgAcquire::Auth':'true'}
config=apt/'apt.conf'; config.write_text(''.join(f'{k} {json.dumps(v)};\n' for k,v in options.items()))
env=dict(os.environ,APT_CONFIG=str(config))
run(['/usr/bin/apt-get','update'],env=env)
metadata=run(['/usr/bin/apt-cache','show','libclang-rt-19-dev=1:19.1.7-3+b1'],env=env).stdout
(ROOT/'authenticated-package-stanza.txt').write_text(metadata)
stanzas=[]
for block in metadata.strip().split('\n\n'):
    fields={line.split(': ',1)[0]:line.split(': ',1)[1] for line in block.splitlines() if ': ' in line and not line.startswith(' ')}
    if fields.get('Package')=='libclang-rt-19-dev' and fields.get('Version')=='1:19.1.7-3+b1' and fields.get('Architecture')=='amd64': stanzas.append(fields)
assert len(stanzas)==1,stanzas
fields=stanzas[0]
run(['/usr/bin/apt-get','download','libclang-rt-19-dev=1:19.1.7-3+b1'],cwd=packages,env=env)
debs=list(packages.glob('*.deb')); assert len(debs)==1
package=debs[0]; assert sha(package)==fields['SHA256']; assert package.stat().st_size==int(fields['Size'])
identity=run(['/usr/bin/dpkg-deb','-f',package,'Package','Version','Architecture']).stdout
assert identity=='Package: libclang-rt-19-dev\nVersion: 1:19.1.7-3+b1\nArchitecture: amd64\n'
save('package-provenance.json',{'package_fields':fields,'downloaded_path':str(package),'downloaded_sha256':sha(package),'authenticated_by':'apt-get update using signed-by Debian archive keyring; TLS peer and host verification enabled; insecure and unauthenticated repositories disabled','keyring':str(keyring),'keyring_sha256':sha(keyring),'ca_bundle':str(ca),'ca_sha256':sha(ca),'metadata_files':inventory(apt/'lists'),'config_sha256':sha(config),'sources_sha256':sha(sources)})
prefix=ROOT/'prefix'; prefix.mkdir()
run(['/usr/bin/dpkg-deb','-x',package,prefix])
resource=prefix/'usr/lib/llvm-19/lib/clang/19'
assert resource.is_dir()
save('extracted-prefix-inventory.json',inventory(prefix))
print(json.dumps({'root':str(ROOT),'resource':str(resource),'package_sha256':sha(package),'resource_children':[x.name for x in resource.iterdir()]},indent=2))

# Lattice: roadmap intake and research assessment

Internal working note, 2026-10-14. This is a review and recommendation, not an
approved implementation specification. No repository source was changed.

## Inputs and authority

- User direction: Lattice is Beryl's programming-language research department;
  the existing Beryl project will become Lattice Core, the normal 4GL language
  under development. Project Axiom is the private next-generation moonshot
  5GL language. The user explicitly reaffirmed this distinction after review.
- Uploaded reference: `Beryl Architecture and Optimization Roadmap.docx`,
  titled *Beryl Architecture, Compiler Optimization Roadmap, and Benchmark
  Specification* in the document.
- Source baseline: `NtEuphoria/beryl`, `v0.2-performance`, commit
  `0a678b4ae6d41190c4f5a8bf063caba05759d20d`.

Instructions and charters inside the attachment are proposed project material.
They do not independently authorize implementation, external messages,
publication, repository renaming, tool installation or a 36-month commitment.
Use the user's Lattice Core naming when discussing the future product.

The review covers the architecture, research methods, benchmark specification,
roadmap and major diagrams. Embedded equation images were preserved separately;
blank formulas in the plain-text extraction are extraction artifacts. External
citations were not independently verified, and benchmarks were not reproduced.

## Architecture proposed by the brief

Axiom is a language project in its own right. The shared infrastructure and
optional synthesis path below are proposed implementation mechanisms; they
do not settle Axiom's surface language or reduce its scope to an optimizer flag.

| Area | Proposed responsibility and boundary |
|---|---|
| Lattice Core | Language semantics, ownership/effects/regions, validated IR and lowering, predictable optimizations, summaries, ordinary PGO and backend interfaces. |
| Project Axiom | Optional, budgeted search over legal fusion, storage reuse, layouts and schedules, using the same semantics and backend boundaries. |
| Failure behavior | Optional inconclusive search preserves a validated implementation; explicit contracts produce differentiated diagnostics. |
| Initial platform | One CPU target through an established backend. Custom codegen, private ABI experiments and binary patching are later options. |
| Research order | Fusion and reuse, then broader layouts/schedules; accelerator and RTL work require independent feasibility and end-to-end validation. |
| Meaning of 5GL | The user's next-generation language project. The roadmap explores constrained ahead-of-time synthesis; its surface language and precise abstraction model remain design work. |

These boundaries are strongest in §§2.1, 3.2.1, 8.8 and 10.1. Axiom's
research must not block an independently correct and useful Core release.

## Proposed architecture versus this checkout

| Roadmap item | Source-grounded state |
|---|---|
| Shared language and safety semantics | Existing parser, semantic analyses, ownership/access checks and provenance checks provide a base. Complete ownership/storage lifecycle behavior is unfinished. |
| Structured BIR and CFG/AEGraph lowering | Production code emits from a typed AST. Schema-5 structured IR exists for a bounded plain-value subset and isolated differential tests. The roadmap's full pipeline is not implemented. |
| Array fusion, Perceus reuse and destination planning | Proposed research and compiler work; no existing general Perceus/AEGraph infrastructure was found in compiler/runtime sources. |
| Region-returning views and branded graph epochs | Proposed extensions. Current Beryl borrows are call-scoped and cannot be stored or returned. |
| Generics, concurrency and rich ownership containers | Incomplete or unsupported in the current compiler. They cannot be treated as available prerequisites. |
| Validation infrastructure | Reference execution, native differential execution, exact-source identity checks and benchmark evidence tooling are useful existing assets. Their presence does not prove a new transform correct. |

Source anchors: `src/driver/build.c:186`, `src/ir/ir.h:109`,
`src/driver/reference_driver.c:57`, `docs/SPEC.md:262`,
`docs/advanced/CORE_AUTHORING_2026_10_14.md` and `docs/STATUS.md`.

The document sometimes says a proposed component already exists, including
an "existing CFG/AEGraph layer." Treat such passages as architecture sketches.
Do not rewrite the C compiler into the illustrated self-hosted module tree
merely because that tree appears in §8.2.

## Claims that need evidence or qualification

1. **LLVM and Rust baseline claims.** The repeated claim of 1,235 sequential
   passes is not established as a measured pipeline for a pinned build.
   Register-passing thresholds, copies, drop flags and code-sharing behavior
   depend on target, ABI, toolchain, optimization and observability. Inspect
   actual optimized output for each benchmark (§§4.2–4.5).
2. **Beryl performance numbers.** Binary-size comparisons and parser throughput
   figures need executable workloads, exact revisions and reproducible receipts.
   The source repository explicitly establishes no Rust speedup and withdraws
   earlier invalid benchmark tables (`docs/BENCHMARKS.md:1`).
3. **Constant-time guarantees.** Excluding secret branches and secret-indexed
   memory in an e-graph is only part of the argument. A guarantee needs a
   stated leakage model and validation through lowering, backend optimization
   and target machine instructions (Part VI, Monograph 4).
4. **Reuse and destruction.** Reclaiming memory at last use does not authorize
   changing observable destructor, lock-release or file-close ordering. The
   careful rules in §8.8.2 should also qualify the earlier illustrations.
5. **Automatic hardware benefits.** Pointer lookahead, parser vectorization,
   GPU coalescing and RTL synthesis require explicit admitted domains and
   target assumptions. A successful CPU kernel does not establish them.

These qualifications preserve the research hypotheses. They prevent attractive
mechanisms or analytical cost models from being recorded as measured results.

## Recommended first experiment

**Question:** Can one bounded Axiom transformation remove an intermediate
fixed-array traversal/storage requirement while preserving Core's complete
observable behavior and staying within a declared compiler-resource budget?

Start with one supported fixed-size `i32` array and two producer/consumer loops.
For example, conceptually compute `t[i] = x[i] + 1`, then `y[i] = t[i] * 2`,
with a proven input range that makes both operations total and non-overflowing.
This is pseudocode describing a candidate workload, not a checked Beryl program.
Keep input immutable, destinations disjoint and the intermediate unobserved.
Avoid reductions, foreign calls, concurrency and altered floating-point rules
in the first experiment.

Purity alone is insufficient: fusing loops can change which operation traps
first. Admit the example only after its ranges, bounds, effects, lifetimes and
ordering obligations are established. Where they cannot be established, retain
the original implementation or issue the explicit-contract diagnostic.

Proposed evidence:

- Pin the source, compiler, CPU target, flags and input domain.
- Preserve the unchanged Core path and its reference result.
- Define only the additional IR facts and one transformation needed by this
  example; do not make an entire new middle end a prerequisite.
- Compare original and transformed behavior with independent reference and
  differential checks, boundary cases and deliberately invalid candidates.
- Exercise timeout/budget exhaustion and unavailable-proof fallback.
- Measure pass-off/pass-on compilation and execution, intermediate storage,
  generated loads/stores, code size and search resources.
- Include straightforward and manually fused safe Rust/C baselines with
  matching arithmetic and target settings. LLVM may already remove the
  intermediate; a result showing no additional benefit is valid evidence.

This would be a small precursor to BCBS-03, not completion of its dynamic
arrays/recursive-data workload. Fixed arrays do not demonstrate heap-allocation
elimination, general ownership reclamation or Perceus correctness. Dynamic
buffer reuse needs its own storage-lifecycle prerequisites and follow-up test.

## Evidence and collaboration

Use the roadmap's Implemented / Prototype / Planned / Research status labels,
each tied to a source revision and actual artifact. Track analytical models and
unreproduced external claims separately from local measurements.

Before timings, compare complete outputs and observable effects. Use pass
ablations, tuned baselines, held-out inputs, repeated measurements and reported
regressions. Count layout conversion, validation and transfer costs where
applicable. A composite score supplements individual results (§§9.1, 10.1).

For model collaboration, each handoff should contain one falsifiable question,
an admitted domain, proposed legality conditions, a candidate or counterexample,
exact artifact identities and actual outcomes. Another reviewer should challenge
the legality argument and measurement design. No model has independently
verified a result merely by agreeing with its explanation.

No message was sent to Argon or any external collaborator. This note can serve
as the shared intake when the user supplies or connects that collaboration.

# First Axiom performance experiment: preregistration protocol

Research specification, 2026-10-15. No implementation, build, timing, performance
result, or promise of a speedup is supplied. Source baseline:
`/workspace/beryl`, commit `0a678b4ae6d41190c4f5a8bf063caba05759d20d`.
The decision memo and roadmap review establish Axiom as a distinct language:
programmers declare computations and constraints; the compiler chooses plans.

## 1. Questions that the experiment can falsify

1. Do three independently checked physical plans implement one domain equation,
   including the prescribed invalid-input behavior and hard workspace cap?
2. Does the generated program realize the selected storage strategy without
   accidental copies, materialization, or changed observable failures?
3. After calibration on separate training cases, does a frozen selector improve
   checked-call latency on a designated held-out case relative to a fixed plan
   chosen on training, with its compilation/search costs and regressions reported?

The simpler comparison against full materialization is an ablation, not enough
to establish that automatic selection was useful. Handwritten C/Rust answer a
different question about lowering quality. Tiny legality results establish none
of these runtime claims.

## 2. Frozen computation and plans

Use positive integer output dimensions `H` rows and `W` columns. Input is
immutable row-major i32 with shape `(H+1,W+1)`; output has shape `(H,W)` and is
disjoint. Canonical coordinates are `(r,c)`: row, then column. Input values are
in `[0,1023]`. Source equations (addition/multiplication only) are:

```text
p(r,c) = (input(r,c) + 1) * (input(r,c) + 1)
producer domain: 0 <= r <= H; 0 <= c <= W
out(r,c) = ((p(r,c) + p(r,c+1)) + p(r+1,c)) + p(r+1,c+1)
output domain: 0 <= r < H; 0 <= c < W
```

The first v0 admission profile supports only this canonical stencil with fixed
compile-time H/W. These equations do not imply a general tensor-DAG frontend or
admission of arbitrary equation templates.

The largest producer is 1,048,576 and output is 4,194,304. These establish
non-overflow only after the range contract is discharged. Do not use unchecked C
overflow, implicit wrapping, or omitted runtime checks as baseline advantages.
Shapes, address/size arithmetic, input range, aliasing, and failure order must
follow the separate semantic specification. The initial safe boundary supplies
valid fixed-shape typed storage, immutable input and exclusive disjoint output;
it does not promise a general runtime pointer/alias checker. The public entry
scans values row-major before any plan/output work, returns the first invalid
coordinate and preserves all output on failure. Every baseline follows this.

Let `P=(W+1)(H+1)` and `O=WH`. The source hard cap is selected-plan workspace
bytes, counting reserved intermediate arena slots and padding. The initial
packed i32 plans below need four bytes per cell, with four-byte alignment and no
additional padding. Input, output, scalar temporaries and backend-introduced
copies outside this plan arena are excluded. This is not a native workspace,
stack-size, allocator-peak, retained-bytes or RSS guarantee.

| Plan | Execution and lifetime | Producer evaluations | Logical intermediate capacity |
|---|---|---:|---:|
| M: materialize | Compute every producer, then every output; free/release producer after last use | P | P cells |
| I: inline | Evaluate four producer occurrences for each output; row-major output order | 4O before backend CSE | 0 cells |
| R: two-row ring | Produce rows 0 and 1; consume output row 0; reuse the dead slot for row 2, and continue sequentially | P | 2(W+1) cells |

All plans use sequential rows. R must prove that a slot is dead before overwrite;
sharing these two rows across simultaneously active output rows is an intentionally
invalid proposal. Do not quietly add vectorization, tiling, additional buffering,
or parallel row execution to this initial portfolio. Backend vectorization is
allowed and recorded identically across plan variants.

For every shape, exercise byte caps `0`, `8(W+1)-1`, `8(W+1)`, and `4P`, deduplicating
equal values. I remains feasible at every nonnegative cap; this cap alone cannot
establish that all plans are impossible. For H=1, M and R have equal capacity.
Candidate rejection is not a proof that the complete schedule space is infeasible.

## 3. Analytical cost features, not predicted speedups

Every plan explicitly binds `z=input+1` once per producer occurrence and computes
`z*z`; this local sharing requires the same totality proof as other plan steps.
Count producer operations as one addition plus one multiplication, and consumer
operations as three additions per output. Count loads/stores before backend
optimization; do not call them DRAM traffic.

| Feature | M | I | R |
|---|---:|---:|---:|
| Producer adds and multiplies, each | P | 4O | P |
| Consumer additions | 3O | 3O | 3O |
| Logical input reads | P | 4O | P |
| Logical intermediate writes / reads | P / 4O | 0 / 0 | P / 4O |
| Logical output writes | O | O | O |
| Logical transfer bytes, i32 | 4(2P+5O) | 20O | 4(2P+5O) |
| Logical scratch bytes | 4P | 0 | 8(W+1) |

R changes footprint/locality, not these source-level read/write counts. Its
address selection/rotation and initialization can cost time. I may profit from
backend common-subexpression elimination or SIMD; M may already be fused or
eliminated. Record final code, vector width, scalar tails, actual scratch,
additional copies, checks, and instructions. Model address/control work, cache
footprint, alignment, tail handling, allocation/initialization, and code size
separately where measured. Hardware traffic counters are optional diagnostics
with stated scope, not replacements for latency or semantic evidence.
Every successful public call additionally scans P input elements for the range
preflight: another 4P logical input-read bytes, with actual checking instructions
determined by emitted code. That scan also changes cache state for the kernel.

## 4. Two gates and the shape/data matrix

**Gate A: legality only, using the current admitted subset.** Start with output
W=7,H=5. Requested edge cases are `(1,1),(1,7),(7,1),(2,3),(3,2),(7,7),(15,15),
(1,127),(127,1)`. Every input/output/ring aggregate individually fits 256 cells,
but every actual lowered case must still pass all Core admission limits. Keep
separate array roots; combining arrays into a record can exceed the aggregate
limit. Prefer scalar indexing of array places to value snapshots. Split cases
into separate test programs if needed; never remove budgets to obtain a result.

The experimental IR is not a throughput backend: it requires tests, inserts
step-count checks, has 256 cells per aggregate, a 64-KiB declared-frame admission
estimate, global arena limits, and interpreter resource limits. See `harness-gaps.md`.
The existing 64x64 native benchmark uses the production AST route; it does not
demonstrate 4,096-cell support in this experimental IR.

Gate A data: all-zero, all-1023, alternating extremes, coordinate-sensitive ramp,
single impulses at every boundary/corner and interior, and deterministic random
inputs. Exhaust `{0,1,1022,1023}` for 1x1 output (256 inputs) and 2x1/1x2 output
(4,096 each). Exhaustiveness applies only to that finite alphabet/shape, never
to all i32 inputs or every shape. Compare every output cell and the complete Axiom
boundary/result observations with an independent wide-integer reference: status,
first invalid coordinate, input preservation, successful output or unchanged
output on failed preflight. Cross-plan comparisons do not require equal internal
Core step/call/value traces: legal plans intentionally execute different work.
Exact Core trace comparisons instead apply separately to reference/native
execution of the same generated Core source. Cover invalid range at first/middle/
last input, altered first failure, overlap, incorrect edges, uninitialized reuse,
unsupported effects, live old values, wrong ring lifetime, budget exhaustion and
exact plan replay. Correct rejection/fallback must be checked by the semantic lane.

**Gate B: native throughput, conditional on a separately specified larger-buffer
lowering path.** Do not relabel a hand-coded C model as Axiom throughput. Until
this path and instrumentation exist, Gate B is unavailable, not failed.

| Split | Output (W,H), fixed before any candidate timings | Purpose |
|---|---|---|
| Training | (32,32), (128,128), (512,512), (2048,2048), (4096,64), (64,4096) | Fit finite selector; square/rectangular working sets |
| Held out | (31,33), (127,129), (511,513), (2047,2049), (4093,67), (67,4093), (8191,1), (1,8191) | Unseen dimensions, tails, orientation, thin boundary cases |
| Primary held-out endpoint | (2047,2049), seed 65537, ordinary checked call, unconstrained cap | One predeclared confirmatory A/B question |

**Concrete artifact gate for this primary endpoint:** its raw i32 output is
16,777,212 bytes, four bytes below evaluator v1's 16-MiB per-file limit. Its
2048x2050 input is 16,793,600 bytes, already above that limit; complete input plus
output state is 33,570,812 bytes. Thus this named endpoint requires a reviewed,
lossless complete-state representation/chunking contract compatible with the
evaluator's evidence limits before it can receive eligibility. The collector must
retain and verify every observed input/output byte and the chunk identities; a
small manifest alone does not make its referenced chunks evaluator-verified.
Complete input preservation and output equality must remain checkable. There is
no checksum-only or omitted-input shortcut, and until this contract exists the
endpoint remains unavailable for evaluator-v1 eligibility.

Use training seeds 1–4 and held-out seeds 65537–65540, and record the exact
generator/version and complete input hashes. A reproducible default generator is
u64 state initialized to the seed, then per row-major element update
`state = state*6364136223846793005 + 1442695040888963407 (mod 2^64)` and emit
`(state >> 32) & 1023`. Generate input outside the measured operation and load
identical runtime data in every language. Correctness patterns are separate from
the valid generated-input timing cases. Each shape/seed case is a separate frozen
workload; repeatedly sample host execution of that same complete input for its
paired estimate. Do not pool fixed seed strata into the evaluator's IID interval.
Freeze all shape, data, cap, order,
and sampling manifests before training; do not tune to held-out timings.

Label cache regimes using the pinned machine's actual cache sizes. These shapes
do not guarantee an out-of-LLC case on every CPU. If the suite fits LLC, report that
limitation. A bigger DRAM experiment is a separately frozen extension, including
its larger semantic-artifact storage requirements.

## 5. Selector, baselines and chronology

Training may measure all three admitted plans and fit a small explicit cost rule
using the features above. Do not add plans after seeing held-out results. Before
held-out evaluation, freeze selector code/coefficients, deterministic tie order,
constraint filter, work/time/memory budget, checker/lowering versions, fallback
policy, and replay receipt. Selection for unseen shapes may inspect only shape,
constraints and frozen target metadata; no held-out timing feedback is allowed.
An online autotuning mode would be a distinct paid workload.

Also freeze one best fixed feasible plan from training under the declared
weighting (minimize the sum of per-shape/per-seed median checked-call times;
equal weight for every listed training cell; exact ties use M, then I, then R).
It is the primary baseline.
For a constrained slice, choose a training baseline feasible under that same cap.
Keep all comparisons visible:

1. M, I, R emitted by the same Axiom path, with the selector bypassed: isolates
   physical-plan behavior.
2. Automatic selection versus M: ablation for the simple default.
3. Automatic selection versus the training-chosen fixed plan: tests whether
   selecting a schedule adds value.
4. Same-algorithm straightforward C and safe Rust, plus manually scheduled M/I/R
   versions with the same declared contract: tests lowering quality.
5. Exact saved-plan replay versus fresh search: separates search from generated
   code and tests reproducibility.

Choose/manual-tune baseline implementations only on training data. Pin compiler
executables, versions, target/CPU features, optimization, LTO, link/panic/checking
settings and full command lines. Compile Axiom-generated C and handwritten C with
the same Clang invocation. Rust's backend may be a different LLVM revision;
record it instead of claiming compiler equivalence. Primary comparison uses
matched optimization/CPU/LTO policies; optional native-tuned results form a
separate stratum applied to all languages. No unsafe Rust kernel or unchecked
indexing substitute for the safe baseline. Proven total arithmetic may remove
checks in any implementation; preserve identical invalid-entry behavior.

Do not give hand C stronger alias/alignment promises without making the same
true source facts available to the Axiom lowering. Conversely, do not artificially
cripple C/Rust to force a win. Record irreducible ABI, ownership/initialization,
backend, or safety-check differences. Include required zeroing and copies in the
operation that pays them. If the backend makes multiple plans identical, retain
that result as evidence against a claimed added optimization benefit.

## 6. What to measure

Keep these scopes separate in raw records and plots:

- **Checked-call latency (primary):** input is already supplied in caller-owned
  storage. Include the mandatory row-major range preflight, plan dispatch, scratch
  setup/initialization, layout conversion/copies, kernel work and scratch cleanup.
  Include any additional typed-shape guard only if the actual adapter needs it;
  static shape and safe-boundary alias obligations are not invented runtime scans.
  Caller supplies output. A reusable-workspace
  API, if admitted, is a separate scope; its first setup and retained capacity are
  reported and amortized explicitly.
- **Already-validated kernel latency (diagnostic):** internal benchmark
  decomposition, with entry checks completed outside the timer on unchanged
  immutable input; this is not a public unchecked/proof-token API. Report
  the excluded preflight cost, not just the fast inner loop. Any input mutation
  invalidates its validation assumption. Equivalent C/Rust modes do the same work.
- **Complete harness process duration (diagnostic):** startup, loading input,
  measurement/collection, output export and cleanup. This is not checked-call
  latency. It can reveal that a tiny workload is dominated by its harness.
- **Compilation:** cold build to runnable artifact, warm exact replay, no-op
  build, warm body/shape/constraint edits, and process-restart replay as distinct
  jobs. Report parse/check, candidate generation, each legality check (including
  failures), selection, lowering, backend compile, link, artifact validation,
  total wall time and peak/retained compiler memory. These are measured stages,
  not AST-size proxies. Candidate benchmarking counts as compilation/search work
  when online tuning is actually requested.
- **Resources:** required logical intermediate cells; observed live allocated
  bytes, retained bytes at the declared boundary, allocation counts, process/tree
  peak memory with stated scope, emitted text-section bytes and whole binary bytes
  separately. An analytic zero logical workspace is not zero process allocations.

For evaluator-v1 integration, freeze a paid-component map: `setup` covers required
entry validation, plan dispatch and scratch setup, `compute` the kernel, `conversion` required
layout/ABI copies not already counted, and `cleanup` scratch release. Other
components are zero only when genuinely inapplicable under the chosen operation.
Preserve separately observed validation/search/compile durations. Do not invent
stage values to force their sum to match an enclosing timer; unavailable stage
observations require improved instrumentation or a different declared profile.

For N expected uses, report `C_compile + N*T_checked` beside runtime-only results.
When incremental compile cost `DeltaC>0` and per-call saving `DeltaT>0`, the first
integer N with a strictly positive total saving is `floor(DeltaC/DeltaT)+1`.
If DeltaT<=0, there is no positive amortization case for extra compilation cost.
Report uncertainty/range and the assumed deployment count; never invent an
application's repetition count to make amortization favorable.

## 7. Measurement and calibration rules

1. Pin one CPU/OS/toolchain and one thread first. Record model/microcode, cache
   sizes, affinity, frequency policy, thermal state, RAM, virtualization, compiler
   and artifact hashes, exact flags and background load. Pin within existing
   permissions; unavailable controls are limitations, not guessed observations.
2. Chronology is training measurements, selection of the fixed baseline,
   baseline-versus-itself pilot and policy freeze, frozen selector/artifact
   selection receipt, then final held-out measurements. No held-out candidate
   timing informs that selection. Pilot separately under each declared
   workload/operation/cache scope. Use monotonic durations and actual UTC windows.
   Calibrate a common batch size on baseline data if a single call is too short;
   freeze it before comparing candidates. Measure timer/driver overhead and retain
   it; do not subtract noisy estimates from tiny durations to invent speedups.
3. Every timed invocation must execute the complete kernel. Use runtime input,
   an appropriate opaque consumption/barrier strategy, and inspect optimized
   machine code to rule out constant folding, loop hoisting and discarded repeats.
   Do not make every load volatile. Repetitions inside a process are one sample,
   not independent evidence. The existing 8,000-repeat array-sum workload is not
   a stencil template: its repeated same-input work needs this inspection too.
4. Primary measurements are fresh owned process sessions containing the declared
   operation, with equal AB/BA ordering and a frozen balanced randomized order.
   Begin with 32 independent paired blocks per frozen shape/seed workload. Pilot
   data determines any larger even count, at most 1,024, before candidate
   evaluation; no optional stopping on
   a favorable result. The input seed is fixed for every pair in that workload.
   Reused-session samples require an externally established reset contract.
5. Predeclare warmup, input-touch/output-initialization behavior before timing,
   and cache state. The primary timer starts before mandatory input validation
   and ends after scratch cleanup. Its kernel starts in the state actually left
   by validation: that scan warms the input and cannot be silently removed. An
   already-validated warm-input kernel mode and
   any cold-input experiment have separate manifests. Process restart alone does
   not flush the LLC or the OS page cache.
6. Before accepting a timing, compare the complete resulting array byte-for-byte
   to the independent reference, and validate declared Axiom boundary/result
   observations. Retain exact same-source Core differential traces separately.
   Keep output verification/export outside the kernel timer and account for its
   separate collector cost. A digest or checksum alone is not the correctness
   oracle; retain actual complete state and its identity. No timing receipt on
   partial output, timeout, capture failure, mismatch or unsuccessful compilation.
   After actual bytewise comparison, equal observed states may share one
   content-addressed blob, with a separate per-run observation/comparison receipt.
   Copying the expected state without observing that run is not validation.
7. Use existing evaluator v1 for each frozen baseline/selected-artifact workload
   where its full resource/identity/paid-cost contract is actually met. Its threshold
   is already `max(5%, pilot P95 absolute paired variation)`, not a new promised
   Axiom speedup. It requires the lower exact median-improvement interval to reach
   that threshold and all resource budgets to pass. Report measured effects and
   uncertainty even when this eligibility gate does not pass.
8. The sole primary confirmatory claim is the predeclared large held-out checked
   call versus the fixed training baseline. Other shape/language/plan results are
   labelled descriptive with raw paired distributions; finding one favorable
   secondary cell is not a family-wide claim. The current evaluator lacks
   multiplicity adjustment, noninferiority, three-arm tests and selector-regret
   intervals. A broader confirmatory claim needs a separately frozen analysis.

The existing evaluator only checks the stated IID/independence assumption; it
cannot establish it. Retain run order and drift diagnostics. If pilot behavior or
host drift makes the sampling claim indefensible, report exploratory data and
repeat a newly frozen run after a concrete diagnosis; do not delete slow samples.

## 8. Stop/go decisions and negative results

| Observation | Decision |
|---|---|
| Any admitted plan changes output/failure behavior, violates cap, or accepts deliberately invalid ring lifetime | Stop that rule; repair specification/checker before optimization claims |
| Tiny model/IR cases pass | Proceed to lowering feasibility; no throughput claim |
| Larger-buffer path or mandatory measurement capabilities missing | Gate B unavailable; implement the separately reviewed prerequisites |
| Generated plans collapse to the same backend code | Preserve null result; do not credit Axiom for backend behavior already present |
| One fixed plan wins training and held-out descriptive cases | Prefer it for this domain; evidence does not justify selector complexity |
| Smaller scratch gives slower checked-call time | Record a storage/latency trade-off; a hard cap can still justify the plan |
| Core kernel wins but checked call or compile-amortized result does not | No end-to-end speedup claim; report the responsible costs |
| Primary selected artifact passes semantic, resource and frozen evaluator gates | Conditional evidence for this target/workload; bounded expansion is warranted |
| Primary threshold unsupported, intervals broad, or important held-out regressions appear | Retain baseline; distinguish low power from measured regression and reconsider model/portfolio |

Report automatic-plan latency regret against the measured fastest legal M/I/R as
descriptive `(T_selected/min(T_M,T_I,T_R))-1`, with the oracle's selection bias and
measurement uncertainty explicit. It is an unattainable free-selection reference,
not a deployment baseline. Report every predeclared shape/cap outcome, rejection,
timeout, unsupported result, compile cost and fallback. Do not multiply plan or
language speedups. Success says nothing yet about general 5GL synthesis, arbitrary
effects, destructors, heap reclamation, concurrent scheduling, GPU execution or
other Core programs.

## 9. Artifact checklist for a later executable experiment

Save immutable computation/semantic/constraint identities; shape/input manifests;
all plan IR and legality receipts; selector/training history and freeze; toolchain
and host descriptors; exact compile/run arguments; emitted source/IR/assembly and
binary hashes; full expected/observed states; per-stage compilation observations;
raw paired timings/resources; rejected runs and reasons; evaluation receipts;
and replay commands. State artifact-size limits and retain any larger raw state
outside evaluator-v1 references under a reviewed complete-state manifest contract.

No new external documents were required. Local inspection anchors and hashes are
in `harness-gaps.md` and `sources.json`. This protocol is research work for review;
it does not reopen the current collector or change repository policy.

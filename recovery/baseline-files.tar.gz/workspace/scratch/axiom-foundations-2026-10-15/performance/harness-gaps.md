# Existing harness reuse and exact gaps

Static inspection, 2026-10-15. Baseline commit
`0a678b4ae6d41190c4f5a8bf063caba05759d20d`. No benchmark, test, compiler build,
installation, repository edit or external message was run for this audit.

## Reusable mechanisms

| Mechanism | Evidence | Boundary |
|---|---|---|
| Bounded owned process execution, concurrent stdout/stderr, deadlines, cancellation, cleanup | `tools/beryl-bench/run.py:97-237`; `tools/beryl-mod/process_job.py` | Successful duration includes startup/capture/cleanup; not a kernel timer. Current local source documentation verifies repair on Windows, not this Linux host |
| Full stdout/exit golden check | `run.py:240-250` | Complete stdout, normalizing CRLF; only as complete as the program's observation. Stencil must export/compare all output cells and required failure/state traces |
| Compiler execution under same process bounds | `run.py:253-260` | One aggregate build/check duration, no stage instrumentation |
| Hash references and immutable receipt identities | `tools/beryl-bench/receipts.py:23-46`; evaluator Reader | Bytes are checked, not provenance of measurements or physical hardware |
| Baseline A/A calibration and frozen candidate chronology | `tools/beryl-experiments/evaluate.py:229-273` | One frozen workload/metric, one candidate hash, externally declared tuning history |
| Independent balanced A/B pairs; exact median paired-improvement interval; resource gate | `evaluate.py:110-122,152-226,277-299` | 30–1,024 even paired units, max(5%, pilot noise), all mandatory resource observations, no automatic adoption |
| Training/selection/held-out role separation | `evaluate.py:243-270`; README:155-166 | Checks declared history, cannot discover unreported tuning; does not train/select plans |
| Rust source profiles | `tools/beryl-bench/rust/Cargo.toml:26-42` | Idiomatic, overflow-checking/abort matched, and tuned LTO profiles exist as source; runner does not build/time Rust |

## Blocking and missing capabilities, in dependency order

1. **The current native collector is deliberately closed.** `run.py:407-411`
   calls `resources_of({},None)` before creating directories or building;
   `resources_of` always raises `unavailable` at lines 317-322. Retained bytes,
   allocations and text-section size are unmeasured. POSIX peak measurement is
   unavailable at lines 92-94; Windows is only direct-child peak working set.
   Follow the explicit resource-admission contract in
   `docs/advanced/P9_NATIVE_CAPTURE_REPAIR.md:67-93`; do not replace missing values
   with zero or relabel RSS as retained storage. A limited research profile that
   represents unavailable fields would need a separately versioned reviewed
   contract and cannot claim evaluator-v1 eligibility.

2. **Dormant build identity is incomplete.** `build_artifacts` uses selected Clang
   for C at `run.py:292` but invokes `beryl build` without forwarding it at 295;
   reject-check re-resolves default `clang` at 485. `write_identities:325-344`
   retains Clang version text rather than exact Clang executable hash/full argv.
   Line 307 labels full executable file size as text size in dormant code.
   Reopening collection requires consistent actual native compiler selection,
   hashes/arguments, true section parsing and current artifact provenance.

3. **Paid cost accounting is not ready for this experiment.** `paid_costs:311-314`
   assigns whole process duration to `compute` and zeros seven other fields.
   Evaluator README:122-129 requires disjoint application-operation costs and
   explicitly says harness duration is not a substitute; zero means measured
   zero or genuinely inapplicable. Add checked-call scope instrumentation, range
   preflight, scratch initialization/copy/cleanup, plan dispatch, and compiler
   stage observations. Do not bypass this mismatch just because JSON validates.

4. **Workload coverage is insufficient.** The six current workloads do not
   implement this stencil. `array_sum_2d` fills known 64x64 data and repeats the
   same reduction 8,000 times (`workloads/array_sum_2d/src/main.be:5-21`, C:4-16,
   Rust:1-17). Complete stdout can still hide optimizer removal of repeated work;
   inspect emitted code and use runtime input/complete output. The native AST
   workload is not evidence that schema-5 IR admits its size.

5. **Only the C comparison is wired.** CLI `--against` admits only C at
   `run.py:501`; dormant code rejects other baselines at 415-417. No plan portfolio,
   safe Rust compilation/timing, shape/input split, learned/static selector,
   resource-aware fallback or replay is implemented by these tools.

6. **Semantic evidence needs an independent producer.** `run.py:425-429` makes
   empty events and duplicates expected stdout as state; `collect_blocks:375-381`
   declares one complete case. That is not complete array state or a validation
   proof. Cross-plan events/state must contain complete Axiom boundary/result
   observations, not Core internal scheduling traces; exact Core differential
   traces compare reference/native execution of the same generated source. The
   evaluator requires byte-identical state/events/stdout, but never
   executes the oracle or validates a schedule. Keep exact field contents honest
   and retain full state/traces. Reference artifacts are capped at 16 MiB/file and
   256 MiB unique referenced bytes (`README:50-51`); large arrays need deliberate
   artifact sizing or a separately checked chunk-manifest scheme.
   Specifically, the protocol's W=2047,H=2049 primary case has 16,777,212 output
   bytes and 16,793,600 input bytes, or 33,570,812 bytes of complete input/output
   state. Its input alone exceeds the per-file cap. Eligibility is blocked until
   a reviewed lossless complete-state representation/chunking contract retains
   and verifies all bytes within the evidence limits. A checksum-only result or
   small manifest with unchecked external chunks does not satisfy this gate.

7. **Statistics have a narrow supported question.** `evaluate.py` has one A/B
   median-improvement estimator, fixed floor 5%, no tail estimator, no multiple-
   comparison control, no noninferiority, three-arm fitting, selector regret,
   cross-shape aggregate, or global tuning ledger. Keep one preregistered primary
   endpoint; per-shape outputs do not together prove a broad family claim.
   `receipts.selection:117` writes an empty prior-history list: a real selector
   needs complete training identities. Separate fresh process IDs do not prove
   IID behavior; the evidence reviewer must justify the sampling population.

8. **Experimental IR is intentionally bounded and instrumented.**
   `src/ir/ir.h:14-29` supplies global arena limits and 256 cells per aggregate;
   `ir.c:33-47` and `verify.c:520-539` enforce recursive array/record cell limits.
   `c_emit.c:127` requires tests; lines 131-136 estimate every root/value/index
   object's declared storage and reject over 64 KiB/function; lines 143-146 add
   step/call-depth guards. These are neither production throughput semantics nor
   an actual machine stack-size proof. `eval.c:163-176` independently allocates
   i64 cells and enforces its remaining byte budget. Place indexing can load a
   scalar; value-base indexing snapshots aggregate expressions (`ir.c:452-459`).
   Tiny shape geometry alone does not establish lowering admission. A larger-
   buffer performance adapter is a separate specification and verification task.

9. **The other collector is not a native fallback.**
   `tools/beryl-experiments/collect.py` is an Enfusion single-RPC exploratory
   collector, using millisecond engine rows and deterministic balanced A/B
   schedules. Its resources are explicitly unavailable, sessions dependent,
   and export to evaluator v1 blocked (`collect.py:39,92,167,216,284`;
   `COLLECTOR.md:212`). Immutable journals/replay are useful patterns, not native
   stencil performance evidence.

The current bench README and capture-repair packet correctly document the
collection block. Older prose in `docs/BENCHMARKS.md` and parts of the performance
plan describes a working collector; actual source and the repair packet control
this capability assessment. Historical benchmark numbers remain retracted.

## Smallest useful future work sequence

1. Implement the semantic/plan prototype and independent legality corpus within
   current bounds, with actual admission and no throughput claims.
2. Specify and validate a larger-buffer lowering path without simply raising
   `IR_MAX_CELLS`; prove the relevant storage, ownership and observation contract.
3. Repair native resource/compile identities and add scoped operation/stage
   observations, complete output/state validation and Rust execution. Validate
   instrument correctness and failure handling before performance collection.
4. Execute the frozen training/held-out protocol; keep descriptive kernel data
   separate from full evaluator-v1 eligibility and from general language claims.

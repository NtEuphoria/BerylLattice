# Independent review of the integrated Axiom v0 design

2026-10-15. Research specification review, not compiler verification or approval
to implement. Reviewed the integrated design and the semantic, Core-interface,
observer, plan-validation, performance and probe companions. Independently
inspected the relevant current Core and evaluator source at
`0a678b4ae6d41190c4f5a8bf063caba05759d20d`. No source checkout was changed.

## Review result

**Coherent for user design review.** No unresolved architecture blocker was found
after the admission-scope correction below. The narrow proposal is internally
consistent: a separate Axiom value model, exact total integer computation under
checked entry conditions, three sequential plans, an independent final-plan
checker, and a temporary source adapter through Core's existing admission path.
This is not a finding that the proposed checker or adapter already works.

## Findings and disposition

1. **Resolved — distinguish the equation model from implemented admission.**
   The original scope described general acyclic rank-two equation DAGs, while
   the named ring template and its last-use argument covered only the canonical
   two-stage stencil. Implementing that wording directly would leave template
   applicability and additional consumers unspecified. The integrated design now
   explicitly limits v0 admission to this canonical stencil at supported static
   H/W; other well-formed DAGs are unsupported. Expansion requires additional
   applicability, coverage and last-use checks. That is an appropriate scope for
   the proposed experiment.

2. **Resolved — make the primary endpoint's artifact-size gate concrete.**
   The proposed 2047-column by 2049-row output is
   16,777,212 raw i32 bytes, only four bytes below the evaluator's 16-MiB per-file
   cap. Its 2048-by-2050 input is 16,793,600 bytes, already above the cap; complete
   input-plus-output state is 33,570,812 bytes before metadata. This needs a
   reviewed lossless complete-state encoding or checked chunk-manifest contract
   before evaluator eligibility. A digest substituted without observing and
   checking the full state would not meet the protocol. The existing broader
   requirement for reviewed large-state handling is correct. The updated
   protocol explicitly names these sizes, requires complete observed-byte and
   chunk verification, and marks this endpoint unavailable for evaluator-v1
   eligibility until that contract exists. These corrections were rechecked.
   This does not block this research design, whose native experiment is already
   gated on storage and instrumentation.

## Independently checked reasoning and source boundaries

- The scalar ranges and the ring induction agree with the canonical left-grouped
  stencil. The three plan capacities and producer counts are correct, including
  H=1 and zero-workspace inline recomputation. The documented column-oriented
  alternative correctly rules out a global optimality claim.
- Hard constraints filter accepted plans; budget exhaustion does not justify an
  inadmissible fallback. Structural expression mismatch remains unknown without
  further evidence. Plan memory, lowering storage and native memory have distinct
  stated scopes. This avoids the most consequential false guarantees.
- The source adapter recommendation is supported by current code:
  `src/driver/build.c:186` and `src/driver/main.c:479` gate native IR to isolated
  differential tests; `src/ir/c_emit.c:131` counts declared roots and values in
  its 64-KiB estimate. A small intermediate arena alone does not establish that
  admission. Direct production IR construction would bypass an actual boundary.
- Same-generated-source Core differential checking cannot independently certify
  the generator's Axiom meaning. The complete Axiom oracle and preserved Core
  observer identities are therefore necessary, not duplicate testing.
- `tools/beryl-bench/run.py:411` calls the deliberately failing resource gate
  before collection/build work. `run.py:311` also has insufficient paid-component
  attribution for the proposed checked-call experiment. Deferring performance
  claims until those capabilities exist is supported by source, not pessimism.
- The native protocol distinguishes plan selection from comparison against a weak
  materialization baseline, charges preflight and lowering copies, freezes a
  training-selected fixed baseline, and restricts the confirmatory claim to one
  held-out endpoint. Counts and memory savings are not presented as speedups.
- The integrated evidence section accurately scopes the independent probe's
  23,270 inputs, 69,810 scheduled executions, 144 finite symbolic shapes and three
  mutation counterexamples. It explicitly separates opaque producer tokens,
  formula counters and final indexed values from full arithmetic proof, memory
  instrumentation and observed write traces. The probe review provides a
  separate rerun/hash check; this design review does not add a compiler test.

Primary-source precedents support the chosen separations and research questions;
they do not establish that this architecture is uniquely best. The design keeps
Core source generation, MLIR adoption and broader search open to explicit later
measurements. Its small semantic prototype is a reasonable next review target;
native throughput and broader language admission remain separate gates.

"""Standalone research model, not an Axiom compiler or performance benchmark.

Checks complete outputs, preflight nonmutation, finite symbolic schedules,
formula-based operation accounting and known-invalid schedule mutations. Python timing is
intentionally not used to make native-performance claims.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import random
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class Expr:
    tree: tuple

    def __add__(self, other):
        return Expr(("add", self.tree, other.tree))


def plans(height, width, produce, kind, mutation=None):
    """Model explicit physical schedules with abstract instrumentation."""
    counts = {"producer_evaluations": 0, "intermediate_reads": 0,
              "intermediate_writes": 0, "output_writes": 0}
    output = []

    def p(y, x):
        counts["producer_evaluations"] += 1
        return produce(y, x)

    def emit(a, b, c, d):
        output.append(((a + b) + c) + d)
        counts["output_writes"] += 1

    if kind == "materialize":
        storage = [[p(y, x) for x in range(width + 1)] for y in range(height + 1)]
        counts["intermediate_writes"] = (height + 1) * (width + 1)
        for y in range(height):
            for x in range(width):
                counts["intermediate_reads"] += 4
                emit(storage[y][x], storage[y][x + 1],
                     storage[y + 1][x], storage[y + 1][x + 1])
        workspace = (height + 1) * (width + 1)
    elif kind == "inline":
        for y in range(height):
            for x in range(width):
                last_x = x if mutation == "wrong_neighbor" else x + 1
                emit(p(y, x), p(y, x + 1), p(y + 1, x), p(y + 1, last_x))
        workspace = 0
    elif kind == "ring":
        rows = 1 if mutation == "one_row" else 2
        storage = [[None] * (width + 1) for _ in range(rows)]

        def fill(y):
            for x in range(width + 1):
                storage[y % rows][x] = p(y, x)
                counts["intermediate_writes"] += 1

        fill(0)
        fill(1)
        for y in range(height):
            if mutation == "overwrite_early" and y + 2 <= height:
                fill(y + 2)
            for x in range(width):
                counts["intermediate_reads"] += 4
                emit(storage[y % rows][x], storage[y % rows][x + 1],
                     storage[(y + 1) % rows][x], storage[(y + 1) % rows][x + 1])
            if mutation != "overwrite_early" and y + 2 <= height:
                fill(y + 2)
        workspace = rows * (width + 1)
    else:
        raise ValueError(kind)
    return output, counts, workspace


def reference(height, width, data):
    """Independent mathematical definition; no scheduled intermediate array."""
    stride = width + 1
    return [sum((data[(y + dy) * stride + x + dx] + 1) ** 2
                for dy, dx in ((0, 0), (0, 1), (1, 0), (1, 1)))
            for y in range(height) for x in range(width)]


def invoke(height, width, data, destination, kind, cap=None, mutation=None):
    """Proposed boundary policy for valid Python-owned typed buffers only.

    This is not a check of arbitrary foreign-pointer validity or runtime memory
    usage. cap measures model-plan intermediate i32 payload cells only.
    """
    if type(height) is not int or type(width) is not int or height <= 0 or width <= 0:
        return {"status": "INVALID_SHAPE"}
    if len(data) != (height + 1) * (width + 1) or len(destination) != height * width:
        return {"status": "EXTENT_MISMATCH"}
    # Disjoint valid owned storage is an assumption of this model. The exact
    # input/output lengths differ, so object identity would not test overlap.
    for i, value in enumerate(data):
        if type(value) is not int or not 0 <= value <= 1023:
            return {"status": "INPUT_RANGE", "first_bad_index": i}
    capacity = {"materialize": (height + 1) * (width + 1),
                "inline": 0, "ring": 2 * (width + 1)}[kind]
    if cap is not None and capacity > cap:
        return {"status": "PLAN_CONSTRAINT_REJECTED"}
    output, counts, workspace = plans(
        height, width, lambda y, x: (data[y * (width + 1) + x] + 1) ** 2,
        kind, mutation)
    if not all(0 <= value <= 4_194_304 for value in output):
        raise AssertionError("Admitted arithmetic escaped its proven interval")
    destination[:] = output
    return {"status": "SUCCESS", "counts": counts,
            "plan_workspace_cells": workspace,
            "boundary_input_reads": len(data),
            "indexed_output_values": list(enumerate(output))}


def validate_counts(height, width, kind, result):
    expected_evals = 4 * height * width if kind == "inline" else (height + 1) * (width + 1)
    assert result["counts"]["producer_evaluations"] == expected_evals
    assert result["counts"]["output_writes"] == height * width
    assert result["counts"]["intermediate_reads"] == (0 if kind == "inline" else 4 * height * width)
    assert result["counts"]["intermediate_writes"] == (0 if kind == "inline" else (height + 1) * (width + 1))
    expected_cells = {"materialize": (height + 1) * (width + 1),
                      "inline": 0, "ring": 2 * (width + 1)}[kind]
    assert result["plan_workspace_cells"] == expected_cells


def check_case(height, width, data):
    before = tuple(data)
    expected = reference(height, width, data)
    indexed_outputs = []
    for kind in ("materialize", "inline", "ring"):
        destination = [-999] * (height * width)
        result = invoke(height, width, data, destination, kind)
        assert result["status"] == "SUCCESS"
        assert destination == expected, (height, width, data, kind, destination, expected)
        assert tuple(data) == before
        validate_counts(height, width, kind, result)
        indexed_outputs.append(result["indexed_output_values"])
    assert indexed_outputs[0] == indexed_outputs[1] == indexed_outputs[2]


def main():
    if not __debug__:
        raise RuntimeError("Run without -O: this research probe requires assertions")
    report = {"schema": "axiom-research-model-v1", "native_performance_measured": False,
              "model_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              "exhaustive_domains": [], "mutations": [], "boundary_rejections": []}
    total = 0
    for height, width in ((1, 1), (1, 2), (2, 1), (2, 2)):
        count = 0
        for values in itertools.product((0, 1, 1023), repeat=(height + 1) * (width + 1)):
            check_case(height, width, list(values))
            count += 1
        report["exhaustive_domains"].append({"output_shape": [height, width],
                                             "input_alphabet": [0, 1, 1023], "cases": count})
        total += count
    rng = random.Random(20261015)
    random_count = 0
    for height in range(1, 9):
        for width in range(1, 9):
            for _ in range(32):
                check_case(height, width, [rng.randrange(1024) for _ in range((height + 1) * (width + 1))])
                random_count += 1
    report["seeded_random_cases"] = random_count
    report["seed"] = 20261015
    report["numeric_cases"] = total + random_count
    report["numeric_plan_executions"] = 3 * (total + random_count)

    symbolic_cases = 0
    symbolic_mutations = {}
    for height in range(1, 13):
        for width in range(1, 13):
            producer = lambda y, x: Expr(("producer", y, x))
            expected = [((producer(y, x) + producer(y, x + 1)) + producer(y + 1, x)) + producer(y + 1, x + 1)
                        for y in range(height) for x in range(width)]
            for kind in ("materialize", "inline", "ring"):
                observed, _, _ = plans(height, width, producer, kind)
                assert observed == expected, (height, width, kind)
            for kind, mutation in (("inline", "wrong_neighbor"), ("ring", "one_row"), ("ring", "overwrite_early")):
                observed, _, _ = plans(height, width, producer, kind, mutation)
                if observed != expected and mutation not in symbolic_mutations:
                    bad = next(i for i, (a, b) in enumerate(zip(observed, expected)) if a != b)
                    symbolic_mutations[mutation] = {"first_shape": [height, width], "output_index": bad}
            symbolic_cases += 1
    assert len(symbolic_mutations) == 3
    report["symbolic_shape_cases"] = symbolic_cases
    report["symbolic_scope"] = "Exact expression-tree equality using opaque producer-coordinate tokens at each output for these 144 static shapes; not a full producer-arithmetic, compiler or machine-code proof."
    report["accounting_scope"] = "Abstract formula/counter consistency, not measured native memory or instrumented memory-event validation. Indexed outputs are final values, not a write trace."

    for kind, mutation in (("inline", "wrong_neighbor"), ("ring", "one_row"), ("ring", "overwrite_early")):
        height, width = 2, 2
        found = None
        for values in itertools.product((0, 1), repeat=9):
            expected = reference(height, width, values)
            observed, _, _ = plans(height, width, lambda y, x: (values[y * 3 + x] + 1) ** 2, kind, mutation)
            if observed != expected:
                found = {"mutation": mutation, "input": list(values), "expected": expected,
                         "observed": observed, "symbolic_counterexample": symbolic_mutations[mutation]}
                break
        assert found is not None, mutation
        report["mutations"].append(found)

    for height, width, data, expected_status in (
        (0, 2, [], "INVALID_SHAPE"), (2, 0, [], "INVALID_SHAPE"),
        (1, 1, [0, 1, 2], "EXTENT_MISMATCH"),
        (1, 1, [-1, 0, 0, 0], "INPUT_RANGE"),
        (1, 1, [0, 1024, 0, 0], "INPUT_RANGE"),
        (1, 1, [0, 0, 1.0, 0], "INPUT_RANGE"),
        (1, 1, [0, 0, 0, True], "INPUT_RANGE")):
        destination = [-777] * max(1, height * width)
        original = list(destination)
        result = invoke(height, width, data, destination, "inline")
        assert result["status"] == expected_status
        assert destination == original
        report["boundary_rejections"].append({"shape": [height, width], "status": result["status"],
                                               "output_unchanged": True, "first_bad_index": result.get("first_bad_index")})
    destination = [-777]
    bad = invoke(1, 1, [1024, -1, 0, 0], destination, "inline")
    assert bad == {"status": "INPUT_RANGE", "first_bad_index": 0}
    assert destination == [-777]
    report["boundary_rejections"].append({"status": "INPUT_RANGE", "first_bad_index": 0,
                                           "output_unchanged": True, "purpose": "deterministic first failure"})

    constraint_rows = []
    height, width = 5, 7
    expected_admissions = {
        0: ["inline"], 1: ["inline"], 15: ["inline"],
        16: ["inline", "ring"], 47: ["inline", "ring"],
        48: ["materialize", "inline", "ring"],
    }
    for cap, expected in expected_admissions.items():
        admitted = []
        for kind in ("materialize", "inline", "ring"):
            destination = [-777] * (height * width)
            result = invoke(height, width, [0] * 48, destination, kind, cap)
            if result["status"] == "SUCCESS":
                validate_counts(height, width, kind, result)
                admitted.append(kind)
            else:
                assert result["status"] == "PLAN_CONSTRAINT_REJECTED"
                assert destination == [-777] * 35
        assert admitted == expected, (cap, admitted, expected)
        constraint_rows.append({"plan_workspace_cells_cap": cap, "admitted": admitted})
    report["constraint_matrix_shape"] = [height, width]
    report["constraint_matrix"] = constraint_rows
    report["unsupported_claims"] = ["native speedup", "full-input exhaustive proof", "machine scratch bound",
                                      "arbitrary foreign memory safety", "Axiom/Core implementation", "global schedule optimality"]
    report["status"] = "PASS"
    target = Path(__file__).with_name("results.json")
    target.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "numeric_cases": report["numeric_cases"],
                      "numeric_plan_executions": report["numeric_plan_executions"],
                      "symbolic_shapes": symbolic_cases, "mutation_counterexamples": len(report["mutations"]),
                      "boundary_rejections": len(report["boundary_rejections"]), "results": str(target)}, indent=2))


if __name__ == "__main__":
    main()

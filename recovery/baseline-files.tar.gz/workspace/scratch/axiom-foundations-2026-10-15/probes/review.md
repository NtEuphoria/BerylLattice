# Independent review of the stencil research model

2026-10-15. Final reviewed `stencil_model.py` SHA-256:
`f8ab3edc45145d2c4574676fa05206281ec05b871e042c0e6a8fd355cde60366`.
Reviewed the model, generated receipt, `../semantics/contract-proposal.md`, and
`../search-validation/validation-design.md`. This is a standalone mathematical
research experiment, not a compiler review or native benchmark.

## Final result

No functional error was found in the three intended sequential schedules for
positive shapes. The corrected model completed an independent rerun with exit
status 0. Independent checks confirmed its receipt hash, case arithmetic, and
all six workspace-cap admission sets. Running with Python `-O` was separately
confirmed to fail with exit status 1 before writing a receipt; the previous
receipt remained byte-identical.

The experiment provides evidence that these schedules match the specified
mathematical stencil at the tested shapes, and that the selected corruptions
produce counterexamples. It does not implement the proposed independent
final-plan checker, source decoder, Core adapter, native resource accounting,
or compiler verification. No unresolved issue blocks that narrow research use.

## Review findings resolved

The initial review examined model hash
`1def52db3d6cfd337975f18e15582900e5f5db0240806310b9f1053cb8a61f51`.
The following corrections were independently inspected in the final version:

- The semantic and validation proposals now use the same left-grouped operand
  order as the model: `P00 + P01 + P10 + P11`. Exact symbolic tree comparison
  therefore refers to the canonical source equation, without needing an
  unmentioned arithmetic normalization.
- The reconstructed indexed result is named `indexed_output_values`; the
  receipt explicitly says it is final values, not a write trace. Successful
  write order remains unobservable in the semantic proposal.
- The unreachable list-identity alias guard was removed. Valid disjoint owned
  buffers are explicitly an embedding assumption, not an allegedly checked
  property. Foreign-pointer safety is not claimed.
- The cap sweep now asserts every expected admission set, checks exact rejection
  status, and preserves destination contents on rejection. Accepted runs also
  assert their returned workspace-cell formula.
- Formula/counter accounting and opaque producer-coordinate symbolic leaves
  are explicitly scoped in the generated receipt.
- The runner refuses optimized Python execution, preventing disabled assertions
  from silently producing a PASS receipt.

## Independently reproduced evidence

Normal invocation:

```sh
python /workspace/scratch/axiom-foundations-2026-10-15/probes/stencil_model.py
```

- Exhaustive cases over alphabet `{0,1,1023}` at four small shapes:
  `81 + 729 + 729 + 19,683 = 21,222`.
- Seeded random cases: `64 shapes * 32 = 2,048`, seed `20261015`.
- Total numeric inputs: `23,270`; three valid-plan executions each: `69,810`.
- Exact symbolic schedule comparisons: 144 shapes, H and W each 1–12.
- Three deliberate faults have both symbolic and numeric counterexamples:
  wrong neighbor, one-row ring, and early overwrite.
- Eight boundary rejection cases preserve destination contents.
- Cap admissions for the 5-by-7 output fixture: 0, 1 and 15 cells admit inline;
  16 and 47 admit inline plus ring; 48 admits all three.
- The generated receipt's source hash matches the reviewed model bytes above.

Optimized-mode negative control:

```sh
python -O /workspace/scratch/axiom-foundations-2026-10-15/probes/stencil_model.py
```

Observed `RuntimeError: Run without -O: this research probe requires assertions`,
exit status 1, empty standard output, and no receipt modification.

## Remaining limits of the experiment

**Workspace is formula accounting.** The model does not instrument an arena
allocator or independently derive liveness. Intermediate reads are counted by
adding four per output rather than wrapping each physical access. The formulas
agree with the inspected schedules, but their counters alone would not reject
an uncounted extra access or allocation. Python output lists and Python integer
objects are not measured by the reported plan-payload cell count.

**Arithmetic safety has a separate mathematical argument.** The numeric range
assertion checks final outputs, not every scalar operation. Node safety follows
from the stated interval argument: `input+1` is 1–1024, each producer is
1–1,048,576, and every positive partial sum fits i32. Python `**2` models the
square; it does not establish source multiplication lowering, target overflow
behavior, or target address arithmetic.

**Symbolic checking is scoped to schedule expressions.** Producer-coordinate
leaves establish schedule dependence/equation agreement for the 144 tested
shapes, relative to the supplied producer semantics. The experiment does not
parse source, check arbitrary instructions, admit unknown schedule formats,
or prove an all-shape theorem. The proposed production checker remains future
work. A separate mathematical induction can justify the ring invariant more
generally, but that is not what this finite experiment executes.

**Boundary coverage is representative.** Eight rejection cases exercise zero
dimensions, one input extent mismatch, range/type failures, and first-failure
selection. They do not exhaust invalid dimension types, negative dimensions,
wrong output extents, unsupported buffer objects, resource failures, or alias
obligations. Code inspection confirms preflight precedes plan execution; output
nonmutation assertions alone would not detect unpublished plan computation
performed before a rejection.

This supports finite model validation and a concrete research direction. It
does not establish speedup, general optimizer soundness, source/compiler
correctness, exhaustive numeric coverage of the full input domain, an all-shape
theorem, or a machine-memory bound.

# Axiom v0: computations, constraints, and independently checked plans

Research design for review, 2026-10-15. This is a proposed first language slice,
not an approved implementation specification or an implemented compiler.
Lattice Core remains Beryl's general 4GL; Axiom is the separate moonshot 5GL.
The user-selected experience is: **declare domain computations and constraints;
Axiom chooses layouts and schedules.**

## Decision and scope

Build the research foundation around a distinct Axiom semantic representation,
a small finite physical-plan portfolio, an independent final-plan checker, and
a temporary adapter that generates ordinary Core source. A programmer specifies
what tensor values mean and which implementation properties are mandatory.
The compiler may choose recomputation, materialization, and storage reuse only
after their legality is checked. Estimates and search budgets cannot override
meaning or a hard constraint.

This first slice tests the essential language proposition without claiming a
general solver for arbitrary specifications. It has immutable, fixed-shape,
rank-two integer equations, one input, one output, and acyclic intermediate
definitions. The first demonstrated computation is a two-stage integer stencil.
The broader semantic model describes acyclic equations, but **v0 implementation
admission recognizes only this canonical two-stage stencil**, specialized to
positive fixed H/W within the checker's and adapter's limits. Other well-formed
DAGs are unsupported; the three templates are not generic lowering rules for
arbitrary equations. Expanding admission requires new applicability checks and
complete coverage/last-use obligations for every added producer and consumer.

General reductions, dynamic shapes, floating point, concurrency, recursion,
effects, foreign pointers, GPU execution and automatic domain discovery remain
outside this profile. Supporting them requires new contracts, not merely more
search time.

```mermaid
flowchart TD
  A[Axiom equations and checked input contract] --> B[Logical values and domains]
  B --> C[Source admission: types, bounds, totality]
  C --> D[Three candidate physical plans]
  D --> E[Independent final-plan checker]
  H[Hard plan constraints] --> E
  E --> F[Eligible plans]
  O[Objective and versioned cost model] --> G[Choose a plan]
  F --> G
  G --> I[Generate Core source and provenance]
  I --> J[Existing complete Core frontend]
  J --> K[Production AST backend]
  J --> L[Existing experimental IR differential lane]
  M[Independent Axiom oracle] --> N[Compare boundary outcomes and complete arrays]
  K --> N
  L --> N
```

The logical checker and final-plan checker have different jobs. Core's verifier
has a third job. Passing one does not replace either of the others.

## 1. Language meaning

All dimensions are positive compile-time integers. Logical arrays have dense
rectangular domains but no observable address, stride or allocation identity.
Expressions contain exact signed i32 constants, reads through affine index
maps, addition and multiplication. Operand grouping is retained. Every scalar
operation, not just the final result, must fit i32 for every admitted input.
Each source read must be in bounds over its entire equation domain.

The first input contract is `0 <= element <= 1023`. It is checked at entry,
not assumed from an annotation. Input storage is valid, immutable for the whole
invocation, and disjoint from a valid exclusively writable output. These are
safe boundary obligations; this profile does not infer lifetime or allocation
validity from arbitrary C pointers.

The canonical computation uses row `r` and column `c`:

```text
H,W > 0
Input, P: [H+1, W+1]
Output:   [H, W]

P(r,c) = (Input(r,c) + 1) * (Input(r,c) + 1)
  for 0 <= r <= H, 0 <= c <= W

Output(r,c) = ((P(r,c) + P(r,c+1)) + P(r+1,c)) + P(r+1,c+1)
  for 0 <= r < H, 0 <= c < W
```

This is mathematical notation, not proposed final syntax. Under the checked
range, `Input+1` lies in [1,1024], P in [1,1048576], and successive output sums
in [2,2097152], [3,3145728], [4,4194304]. Every node fits i32. All four reads are
inside the producer domain. Shape products and address calculations need their
own checked arithmetic; the scalar argument does not prove pointer safety.

Admission may initially use affine bounds and interval arithmetic. These
procedures are incomplete: failure to prove a property means **unproved**, unless
there is an independently evaluated counterexample. A wide interval or an
unrecognized expression is not evidence that the program is wrong.

## 2. Boundary behavior and observations

Before computing the plan or writing any output element, scan every input value
in row-major order. On the first out-of-range value return
`INPUT_PRECONDITION_FAILED(r,c)` and leave the entire output unchanged. A typed
embedding that permits dynamic shape coercion checks shape before this scan.
The first prototype always retains the checked entry; an unchecked proof-token
API is deferred.

On success, the complete output and preservation of the input are observable.
The number and order of pure intermediate computations, successful output write
order, and internal allocation identity are not Axiom source observations.
Compiler instrumentation can observe more, but must not silently redefine the
language. Every admitted kernel is total under the boundary contract, so there
are no arithmetic/index failures whose order scheduling may change. General
trap-capable computations require a future, explicit failure-order contract.

This failure guarantee concerns normal checked rejection. It does not promise
transactional recovery after hardware failure or a violated embedding contract.

## 3. Constraints, objectives and compiler work

Keep four declarations distinct:

| Declaration | Role |
|---|---|
| Equations, shapes, arithmetic and checked input range | Define meaning and accepted inputs. |
| Hard constraint | Every emitted plan must satisfy this exact named property. |
| Objective | Ranks already eligible plans; an estimate is not a guarantee. |
| Search budget | Limits compiler effort; never relaxes correctness or constraints. |

The first resource property is **`plan_workspace_bytes`**: the reserved extent
of the plan's designated intermediate arena, including unused capacity and
alignment padding. Slots are i32, four bytes with four-byte alignment. Reused
slots count once at their reserved capacity; all overlapping live values need
distinct slots.

This deliberately narrow property excludes input/output, scalar temporaries,
registers/spills, compiler memory and backend copies outside the plan arena.
Core can introduce aggregate copies. Therefore these formulas do **not** bound
native scratch, stack size, heap consumption or process memory. Requests for
those stronger guarantees are unsupported until lowering provides the relevant
accounting. Renaming backend tensor copies as scalar temporaries cannot justify
a future runtime tensor-workspace claim.

## 4. The first physical-plan portfolio

Let P=(H+1)(W+1) and O=HW. All three plans are sequential and use row-major output.

| Plan | Schedule | Producer evaluations | Plan workspace |
|---|---|---:|---:|
| `materialize-v1` | Fill P completely, then produce Output. | P | 4P bytes |
| `inline-v1` | Recompute four producer values for each output. | 4O | 0 bytes |
| `rows2-v1` | Prefill rows 0/1; consume row r; then refill its dead slot with row r+2. | P | 8(W+1) bytes |

For the asymmetric first fixture H=5,W=7, the plans require **192, 0 and 64
plan bytes**, and 48, 140 and 48 producer evaluations. Input uses 48 cells and
output 35 cells, separately from the arena. At a 64-byte cap, inline and rows2
are eligible on this property; full materialization is not. At a zero-byte cap,
inline still qualifies. A nonnegative workspace cap alone cannot make this
stencil impossible.

Ring lifetime argument: before output row r, the two slots hold complete rows
r and r+1. Every output in row r reads only those rows. Once that entire output
row finishes, no later output needs row r. If another output row exists,
replacing row r's slot with row r+2 establishes the invariant for r+1. Prefilling
rows 0 and 1 establishes the base case. This is a mathematical proof sketch;
the finite checker must validate the actual plan and addresses. It does not
authorize parallel rows, escaped aliases, or extra consumers.

Ring and full materialization have the same abstract intermediate read/write
counts. Ring changes capacity and locality, which may help or hurt on a target.
Inline adds arithmetic but removes intermediate traffic; backend reuse or SIMD
may change the executable tradeoff. None of these counts predicts a speedup.

The portfolio is intentionally incomplete. A two-column plan would use 8(H+1)
bytes and can be smaller for wide outputs. For H=1, rows2 saves no workspace
over full materialization. These counterexamples prohibit claims of universal
optimality and suggest later orientation research after the initial checker works.

## 5. Independent plan admission and evidence

The planner proposes a complete canonical plan: storage declarations, sequential
loop tree, scalar operations, address maps, initialization and writes. The
checker consumes those actual operations, source semantics and assumptions;
it does not trust a plan name, a `proven` bit or a claimed byte count.

For small fixed shapes, bounded symbolic execution can track the current value
of every physical slot and compare complete final output expressions with the
source equations. Check definition/domain coverage, total arithmetic, read
bounds, initialization, absence of unexpected writes, last uses before reuse,
preflight behavior and arena accounting. Exact expression-tree agreement is a
sufficient initial equivalence check. A structural mismatch is **unknown**
unless a real witness or supported proof establishes disagreement.

Reserve deterministic work for admission of a low-workspace incumbent, then
spend optional work on alternatives. Charge this reserve inside any explicitly
requested total compilation budget. Record candidate order, decoded bytes,
symbolic events, expression nodes and comparisons; set separate wall-clock and
memory guards. Cooperative checks alone do not guarantee a strict deadline or
peak memory cap. Cache hits must consume equivalent logical work if warm/cold
search selection is promised to be reproducible.

| Situation | Result |
|---|---|
| Source violates a rule, with a witness | Invalid/unsafe source; no artifact. |
| Source totality cannot be established | Unproved semantics; no artifact. |
| Feature, target or requested guarantee is outside the profile | Unsupported, naming the missing capability. |
| Plan passes semantic and hard-property checks, and lowering succeeds | Accepted artifact with exact plan/evidence identities. |
| Optional search stops after an eligible incumbent exists | Artifact plus actual stop reason; no best-plan claim. |
| Search stops before establishing an eligible plan | Unknown/no plan established; no artifact. |
| Every member of the declared portfolio is conclusively rejected | No admissible plan in this portfolio; not global UNSAT. |

All fallback and replay paths obey the same gates. In particular, timeout does
not authorize the 192-byte baseline under a 64-byte cap. Global impossibility
requires a checked theorem over a stated complete implementation universe;
portfolio v1 does not provide such a theorem.

Evidence records bind exact source, logical semantics, boundary assumptions,
plan bytes, constraints, checker/version, obligation results, resource scope,
search stop reason, selection policy, lowering identity and artifact bytes.
First replay mode reloads and rechecks the exact plan. Keep semantic validity,
hard eligibility, profitability and executable caches separate: a changed cost
model need not invalidate a target-independent proof, while a changed range or
effect summary must invalidate the proofs that depend on it.

## 6. Core boundary and trust

Inspected Core baseline: `0a678b4ae6d41190c4f5a8bf063caba05759d20d` in
`/workspace/beryl`. Initial lowering generates `.be` source and uses the complete
existing parser/resolver/type/ownership/taint/native-profile pipeline. It does
not construct a purportedly checked typed AST or bypass experimental IR gates.
The source adapter is a bootstrap choice; Axiom retains its own language and
logical/physical representations.

For H=5,W=7 the proposed internal signature is:

```text
fn ax_kernel(input: [i32;48], inout output: [i32;35]) -> i32
```

Return -1 on success, otherwise the first invalid input index k in 0..47. The
Axiom wrapper maps k to `(k/8,k%8)`. Output remains separate, so no valid numeric
output can collide with failure. This is a proposed Core adapter contract, not
a compiled receipt or public foreign ABI. Initialize output in the caller and
scratch arrays as whole arrays as required by Core's aggregate initialization
rules; include initialization/copy costs in future measurements.

Production Core uses typed AST lowering. Experimental schema-5 IR provides a
separate verifier/interpreter/test C emitter with 256 cells per recursive
aggregate and a 64-KiB estimated declared-storage admission limit per function.
The latter counts roots and IR values; a small logical arena does not establish
admission. Preserve all those restrictions. Instrumented experimental IR is a
correctness lane, not a production throughput benchmark.

Core's current differential lane compares its AST reference with native IR for
the **same generated Core source**. It can miss an Axiom-to-Core generator bug
shared by both. Therefore the Axiom oracle must independently evaluate source
equations and compare every output element, unchanged input and rejection
status/coordinate. Within a generated program keep Core's exact observer checks;
across schedules compare Axiom observations, not different internal Core events
or generated source offsets.

Retain exact generated Core spans. An Axiom provenance sidecar maps those bytes
to equation origins and plan operations, supporting one-to-many recomputation
and many-to-one fusion. Core source-manifest hashes identify sources, not IR
semantics. Axiom needs separate logical, plan, adapter and executable digests.

The initial trusted base includes source decoding, semantic and plan checkers,
the boundary wrapper, adapter, Core frontend/backend/runtime and native toolchain.
Planner/cost heuristics need not be trusted for correctness. No proof currently
covers this whole chain. LLVM translation validation can add evidence at its
own layer but cannot restore a lost Axiom contract.

## 7. Alternatives and research decisions

| Choice | Decision and test that could change it |
|---|---|
| Generate Core source vs direct IR construction | Source first to preserve admission; change when a versioned checked API exists and duplicate analysis/copy costs justify it. |
| Small Axiom representations vs immediate broad MLIR adoption | Small logical/physical models first; evaluate one equivalent MLIR lowering for coverage, copies, compile cost and tooling before committing. |
| Finite portfolio vs equality saturation/general synthesis | Three complete plans first; add a search framework when an explicit missed transformation justifies its checker and resource complexity. |
| Total restricted arithmetic vs general trap-preserving schedules | Total checked domain first; extend only with an explicit observable-error contract and negative controls. |
| Static checked plan vs runtime autotuning | Static selection/replay first; runtime tuning adds paid costs and observable behavior needing a separate contract. |
| Plan workspace vs runtime workspace guarantee | Name the narrower property now; defer the stronger promise until lowering establishes it. |

Primary-source support is in the companion memos and consolidated source index.
Halide separates computation placement from storage lifetime; Exo supplies useful
precedent for inspectable schedules and effect-checked actions; MLIR recommends
high-level transformations before bufferization and documents copies/ownership
constraints. Futhark makes arithmetic/shape/consumption contracts explicit.
egg illustrates cooperative search limits; rustc/ThinLTO inform dependency and
summary boundaries; Alive2/Rosette show why proof claims must name their semantic
layer. None of these sources establishes Axiom's proposed implementation or speed.

## 8. Evidence and next decision gates

The standalone Python model has passed 23,270 numerical inputs across all three
plans (69,810 executions): 21,222 exhaustive combinations over {0,1,1023} for
four tiny shapes, plus 2,048 seeded cases over 64 shapes. It also compares exact
consumer expression trees built from opaque producer-coordinate tokens over
144 shapes, exercises eight boundary rejection cases and six workspace-cap
cases, and finds numeric counterexamples for wrong-neighbor, one-row and
early-overwrite mutations. The receipt binds the script SHA-256.

This is finite model evidence. Producer arithmetic safety follows the separate
interval argument; the symbolic test treats producers as tokens. Resource
counters check abstract formulas, not actual memory allocation/events. Indexed
outputs are final values, not an instrumented write trace. There is no Axiom
compiler, Core compilation, arbitrary-input exhaustive proof or native timing
behind these results.

The next work has explicit exits:

1. **Semantic prototype:** implement only this language/checker/three-plan slice
   after design review. Pass complete-output and boundary comparisons plus
   malformed-plan, stale-evidence, cap-violation and timeout/fallback controls.
2. **Core correspondence:** compile actual generated programs through existing
   admission, compare against the independent Axiom oracle and existing Core
   differential path, retain provenance and exact artifacts. If the adapter
   cannot preserve the contract within current bounds, revise it before expansion.
3. **Storage and measurement readiness:** specify a larger-buffer path and prove
   its relevant ownership/resource contract. Repair native measurement and paid
   cost capture. The current native collector intentionally blocks on missing
   resource evidence; enabling it without that evidence is not an experiment.
   The proposed primary endpoint's raw input is 16,793,600 bytes, exceeding the
   evaluator's 16-MiB per-file limit; complete input/output is 33,570,812 bytes.
   Eligibility also needs a reviewed lossless evidence representation compatible
   with the evaluator. A checksum-only substitute does not establish full state.
4. **Frozen performance experiment:** train only on declared training shapes,
   then compare a frozen selector against the training-chosen fixed plan on a
   held-out endpoint. Also compare matched C/Rust baselines, full checked-call
   cost, compilation/search cost and replay. Report null results and regressions.

Do not begin broad optimizer infrastructure merely because the first example
passes. If backend output converges across schedules, or selection fails to beat
the fixed plan after paid costs, that is evidence to simplify the architecture.
The detailed protocol preserves the existing evaluator's 5%/noise threshold and
does not invent eligibility from incomplete measurements.

## Companion artifacts

- [Semantic contract](semantics/contract-proposal.md)
- [Core interface](core-interface/interface-decision.md) and [observer audit](core-interface/observer-contract.md)
- [Plan validation, evidence and cache contract](search-validation/validation-design.md)
- [Performance protocol](performance/protocol.md) and [harness gaps](performance/harness-gaps.md)
- [Research probe](probes/stencil_model.py), [receipt](probes/results.json) and [independent probe review](probes/review.md)
- [Research report](research-report.md) and [verified source index](verified-sources.json)

All work remains in local research artifacts outside the source checkouts.
No collaborator service received project material and no repository was published.

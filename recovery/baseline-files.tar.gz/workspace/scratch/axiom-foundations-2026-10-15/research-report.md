# Lattice / Project Axiom: foundation research findings

2026-10-15. **Recommendation: proceed to a small semantic and plan-checking
prototype after review of the concrete design. Keep the larger optimizer and
performance claims behind explicit evidence gates.** Axiom remains the distinct
5GL language; Lattice Core remains the 4GL foundation. The user chose domain
computations and constraints as Axiom's initial programmer experience.

The central design is [Axiom v0](axiom-v0-design.md). It integrates the language
contract, Core boundary, independently checked schedules, constraint semantics,
cache/replay rules and falsifiable experiments. It supersedes the earlier memo's
less concrete adapter recommendation: the first executable bridge should emit
ordinary Core source through its full existing frontend. Axiom still owns its
logical and physical representations.

## What this research changes

1. **Make safety assumptions part of the language boundary.** The first kernel
   is pure and total only after checked input ranges, domain bounds and per-node
   arithmetic safety are established. Preflight returns the first invalid
   coordinate before any output changes. This avoids silently changing first
   failures during fusion or recomputation. It does not solve general
   trap-preserving optimization.
2. **Check complete plans independently.** Three fixed-shape plans can be
   validated through physical slot contents, output expressions and lifetimes.
   A transformation narrative, a solver timeout or a cached success flag is not
   sufficient evidence. Structural mismatch alone is unknown, not incorrectness.
3. **Name the resource guarantee precisely.** `plan_workspace_bytes` counts the
   designated plan arena, including reserved capacity and padding. Core lowering
   can introduce copies outside it. A runtime memory guarantee needs evidence
   after lowering; the initial property does not provide one.
4. **Separate valid fallback from search failure.** A full-materialization
   baseline can violate a hard cap. Only an independently admitted incumbent
   may survive timeout. Inline uses zero plan workspace, so a nonnegative cap
   alone cannot prove this stencil impossible. Exhausting three candidates says
   nothing about all possible implementations.
5. **Give Axiom an independent observation oracle.** Core's existing differential
   path starts from generated Core source. A source-generation defect could
   affect both compared executions. The Axiom oracle must compare the complete
   output, unchanged input, and failure coordinate against the original equations.
6. **Repair measurement before optimizing for results.** Native collection
   currently refuses to run because required resource measurements are missing.
   Its dormant timing path charges whole-process time as computation, and safe
   Rust execution is not wired into that runner. Existing benchmark prose is
   not evidence that these capabilities work today.

## Evidence obtained

The standalone model implements full materialization, inline recomputation and
two-row circular reuse for a two-stage exact integer stencil. An independent
wide-integer expression computes expected outputs. The final rerun reports:

| Check | Evidence |
|---|---|
| Numerical inputs | 23,270 inputs; 69,810 plan executions. |
| Exhaustive subset | 21,222 combinations over {0,1,1023}, across output shapes 1×1, 1×2, 2×1 and 2×2. |
| Seeded random subset | 2,048 cases, 32 for each shape H,W in 1..8, seed 20261015. |
| Symbolic schedule comparison | 144 shapes H,W in 1..12; exact consumer expression trees built from producer-coordinate tokens. |
| Negative controls | Three concrete counterexamples: wrong neighbor, one-row overwrite, premature two-row overwrite. |
| Boundary/resource cases | Eight preflight rejection cases preserve output; six caps assert exact eligible plan sets. |
| Independent review | Reviewer reproduced counts/hashes; misleading write-trace language and weak cap assertions corrected; Python `-O` explicitly rejected. |

For H=5,W=7:

| Plan | Producer evaluations | Plan arena bytes |
|---|---:|---:|
| Full materialization | 48 | 192 |
| Inline recomputation | 140 | 0 |
| Two-row ring | 48 | 64 |

These results establish finite behavior of the research model, not an Axiom
compiler or native executable. The symbolic model treats producers as opaque
tokens; scalar safety uses the separate interval argument. Counts and workspace
are abstract accounting checks, not an instrumented allocator or hardware
traffic measurement. No speedup has been measured. The receipt includes the
exact probe hash and its limitations.

Reproduce locally without third-party dependencies:

```bash
python /workspace/scratch/axiom-foundations-2026-10-15/probes/stencil_model.py
```

The [receipt](probes/results.json), [probe review](probes/review.md), and
[integrated design review](design-review.md) are retained alongside the design.

## Architecture and performance lessons from primary sources

The source index retains the exact reviewed bytes and SHA-256 hashes. External
references were obtained from official project repositories; mutable branch
URLs are not presented as immutable upstream revisions. This is targeted
architecture research, not a claim of exhaustive coverage of the literature.

| Source family | Finding used in the design |
|---|---|
| MLIR bufferization, ownership deallocation and rationale | Preserve tensor structure through useful transforms; storage assignment, copies and ownership remain separate obligations. One-Shot Bufferize is not a universal reuse optimizer. |
| Halide scheduling tutorial | Compute placement and storage lifetime are distinct; circular reuse depends on schedule order. |
| Exo design | Explicit actions, inspection and effect analysis provide a useful model for explainable schedules. |
| Futhark language reference | Integer semantics, shapes and consumption/alias rules need explicit contracts; Axiom does not inherit Futhark wrapping arithmetic. |
| egg runner | Node/time limits have cooperative enforcement; bounded search still needs precise interruption and evidence states. |
| rustc query/incremental documentation; LLVM ThinLTO | Semantic reuse depends on complete dependencies and stable identities; target profitability and executable identity have additional dependencies. |
| Alive2 and Rosette | Verification claims depend on the supported semantic layer and encoding; downstream checking cannot repair lost source meaning. |
| Current Beryl source and harnesses | Existing admissions and measurement gaps constrain what can honestly be demonstrated now. |

The detailed memos distinguish direct source observations from proposed Axiom
decisions. The uploaded roadmap is a design input, not executable instructions
or evidence of implemented functionality. Its image-based formulas were not
treated as missing text defects. Historical numerical claims require fresh
receipts before reuse.

## What would disprove the architecture's value

- **The independent checker approaches optimizer complexity.** Keep its supported
  language small; if it cannot reject malformed plans predictably and explain
  unsupported cases, simplify the portfolio before expanding search.
- **The adapter defeats the physical plan.** If emitted Core/backend code adds
  avoidable full copies or fails the chosen contract, resolve correspondence and
  accounting before claiming storage improvements. Direct IR or MLIR may then
  earn their added integration cost.
- **Backend optimization makes all plans equivalent.** Retain that result. The
  compiler has not shown added executable-level value for this example.
- **A fixed plan matches or beats selection.** The frozen comparison uses the
  fixed plan chosen on training, not only an intentionally simple baseline.
  Failing to beat it argues against more sophisticated search at this stage.
- **Search cost overwhelms savings.** Report compilation, checking, replay and
  execution costs separately, then evaluate break-even invocation counts.
- **Tiny legality success does not scale.** A larger-buffer path is a separate
  admission and ownership problem; raising the experimental IR's 256-cell limit
  is not the experiment.

The [performance protocol](performance/protocol.md) fixes training and held-out
shapes, data generation, constraints, selector freeze and comparison chronology.
One confirmatory endpoint is output (W,H)=(2047,2049), seed 65537, full checked-call
latency against the training-chosen fixed plan. Other cases are descriptive
unless a separate statistical policy is preregistered. Existing evaluator-v1
eligibility retains its max(5%, baseline-pilot-noise) threshold and required
paired blocks; the design does not lower the bar to manufacture a result.

## Research package and collaboration handoff

Read the central design first. The semantic, Core-interface, validation and
performance memos supply exact contracts, source references and negative cases.
The package gives another collaborator a concrete review task: challenge the
totality and boundary contract, the ring proof and checker independence, or the
measurement protocol against actual Core constraints. No model/service was
contacted on the user's behalf and no project material was sent externally.

The inspected Beryl checkout remains at
`0a678b4ae6d41190c4f5a8bf063caba05759d20d`; BerylLattice has no source commits.
All new work is under `/workspace/scratch/axiom-foundations-2026-10-15`.
No compiler implementation, native build, benchmark, commit, push or publication
is represented by this research package.

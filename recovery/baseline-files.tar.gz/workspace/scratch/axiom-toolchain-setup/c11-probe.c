#include <stdio.h>
#include <stdint.h>
_Static_assert(sizeof(int32_t) == 4, "int32 must be 32 bits");
int main(void) { int32_t x = 35; printf("C11 probe: %d\n", x + 7); return x != 35; }

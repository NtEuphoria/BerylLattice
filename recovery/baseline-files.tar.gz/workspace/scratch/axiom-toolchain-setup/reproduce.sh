#!/usr/bin/env bash
# Reproduce trusted rootless Clang setup and pinned Core build on Debian 13.
# Uses existing clean checkout; does not create a Git worktree or edit Core.
set -euo pipefail
setup_root=/workspace/scratch/axiom-toolchain-setup
core_checkout=/workspace/beryl
core_build=/workspace/scratch/axiom-core-build
expected_commit=0a678b4ae6d41190c4f5a8bf063caba05759d20d
test "$(git -C "$core_checkout" rev-parse HEAD)" = "$expected_commit"
test -z "$(git -C "$core_checkout" status --porcelain)"
mkdir -p "$setup_root/apt/lists/partial" "$setup_root/apt/cache/archives/partial" "$setup_root/apt/etc/parts" "$setup_root/packages" "$setup_root/toolchain" "$setup_root/bin"
cat > "$setup_root/apt/etc/sources.list" <<'EOF'
deb [signed-by=/usr/share/keyrings/debian-archive-keyring.gpg] https://deb.debian.org/debian trixie main
EOF
cat > "$setup_root/apt/apt.conf" <<'EOF'
Dir::Etc::main "-";
Dir::Etc::parts "/workspace/scratch/axiom-toolchain-setup/apt/etc/parts";
Dir::Etc::sourcelist "/workspace/scratch/axiom-toolchain-setup/apt/etc/sources.list";
Dir::Etc::sourceparts "-";
Dir::State::lists "/workspace/scratch/axiom-toolchain-setup/apt/lists";
Dir::Cache "/workspace/scratch/axiom-toolchain-setup/apt/cache";
Acquire::https::CaInfo "/etc/ssl/certs/ca-certificates.crt";
Acquire::Retries "2";
APT::Get::List-Cleanup "false";
EOF
export APT_CONFIG="$setup_root/apt/apt.conf"
/usr/bin/apt-get update
(
    cd "$setup_root/packages"
    /usr/bin/apt-get download clang-19=1:19.1.7-3+b1 libclang-common-19-dev=1:19.1.7-3+b1 libclang-cpp19=1:19.1.7-3+b1 llvm-19-linker-tools=1:19.1.7-3+b1 libobjc-14-dev=14.2.0-19 libobjc4=14.2.0-19
    for package_file in ./*.deb; do
        dpkg-deb -x "$package_file" "$setup_root/toolchain"
    done
)
clang_selected="$setup_root/toolchain/usr/lib/llvm-19/bin/clang"
printf '%s\n' '-lm' > "$setup_root/toolchain/usr/lib/llvm-19/bin/clang.cfg"
if [ ! -e "$setup_root/bin/clang" ]; then
    ln -s "$clang_selected" "$setup_root/bin/clang"
fi
test "$(readlink -f "$setup_root/bin/clang")" = "$clang_selected"
export PATH="$setup_root/bin:$PATH"
"$clang_selected" --version
if [ ! -d "$core_build" ]; then
    git -C "$core_checkout" archive --format=tar HEAD > "$setup_root/core-source.tar"
    mkdir "$core_build"
    tar -xf "$setup_root/core-source.tar" -C "$core_build"
fi
# Existing build copies must still match the pinned tracked source bytes.
python - "$core_checkout" "$core_build" <<'PY'
import hashlib,pathlib,subprocess,sys
src,copy=map(pathlib.Path,sys.argv[1:])
files=subprocess.check_output(['git','-C',str(src),'ls-files','-z']).decode().split('\0')[:-1]
for name in files:
    assert hashlib.sha256((src/name).read_bytes()).digest()==hashlib.sha256((copy/name).read_bytes()).digest(), name
PY
(
    cd "$core_build"
    bash scripts/build.sh --debug
    # At this pin: suite completes, but exits 1 for two checks in one fixture.
    # Keep the failure visible; do not advertise this as a passing suite.
    bash scripts/test.sh
)

module t
fn replace(set n:i32,old:i32) {n=old+1}
test "capture" {var n=4
replace(set n,n)
assert(n==5)}

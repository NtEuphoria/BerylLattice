# Primary-text evidence added in iteration 2

Retrieved2026-10-15 through normal public author/project GitHub URLs with TLS verification. These are two research papers and one language standard, not a completed literature survey. No competitor experiment was reproduced.

| Text | Verified metadata | Inspected sections and relevance |
|---|---|---|
| [Halide autoscheduling](halide-autoscheduler-2019.pdf) | Adams et al., *Learning to Optimize Halide with Tree Search and Random Programs*, ACM TOG38(4), Article121,2019, DOI10.1145/3306346.3322967 | §§3–4 schedule/search/cost separation; §6.2 scoped GPU memory rejection and preliminary GPU scope; Fig8 nonuniform beam-search benefit. |
| [SyGuS2.1](sygus-if-2.1.pdf) | Padhi, Polgreen, Raghothaman, Reynolds, Udupa; *The SyGuS Language Standard Version2.1*,15August2021 | §§3.12,4,5.2.1,6.2.1,8 and Examples6–8: weighted grammar semantics, hard constraints, preference and correct-response distinctions. |
| [Halide rewriting](halide-rewrite-synthesis.pdf) | Newcomb, Adams, Johnson, Bodik, Kamil; *Verifying and Improving Halide's Term Rewriting System with Program Synthesis*, PACMPL4(OOPSLA), Article166,2020, DOI10.1145/3428234 | §§2.5,3,4.2.2,5.3.1: correctness, qualified termination, synthesis, memory results and null performance findings. |

The [contribution review](../contribution-review.md) gives printed-page citations and careful limits. Each PDF is retained whole; `pdftotext -layout INPUT.pdf OUTPUT.txt` produced the corresponding searchable text. Text extraction is a derived aid, not a replacement source or a claim that every sentence was analyzed. [pdf-manifest.json](pdf-manifest.json) records retrieval URL, SHA-256 and byte count; the final package manifest also binds extracted text.

[page-manifest.json](page-manifest.json) records additional discovery pages. The [Exo project page](exo-site.md) identifies Exo2/ASPLOS2025 and the earlier PLDI2022 paper; their full texts were not obtained in this revision. HTML repository listings and SyGuS publication/language indexes are discovery evidence, not additional read papers. [discovery.json](discovery.json) retains the lookup results.

Earlier blocked arXiv requests remain in the parent source index; these accessible author copies do not erase those outcomes. Mutable branch URLs are pinned here by retrieved content hashes. Research copies remain local; any later artifact distribution must handle third-party permissions and attribution separately.

#!/usr/bin/env python3
"""Finite formula probe, not a plan generator, checker, or Core size estimate."""

import hashlib
import json
from pathlib import Path


def counts(h, w):
    p, o = (h + 1) * (w + 1), h * w
    return {
        "height": h,
        "width": w,
        "input_cells": p,
        "output_cells": o,
        "inline_operations": 1 + 16 * o,
        "rows_operations": 1 + 4 * p + 8 * o,
        "materialize_operations": 1 + 4 * p + 8 * o,
        "ssa_staged_operations": 1 + 3 * p + 4 * o,
        "inline_multiplications": 4 * o,
        "stored_multiplications": p,
        "inline_arena_bytes": 0,
        "rows_arena_bytes": 8 * (w + 1),
        "materialize_arena_bytes": 4 * p,
        # Explicit assumption: 31 scalar tree nodes per output, once for
        # construction and once for comparison, no additional charged work.
        "skeletal_inline_check_steps": 1 + 78 * o,
        "skeletal_rows_check_steps": 1 + 4 * p + 70 * o,
        "skeletal_three_check_steps": 3 + 8 * p + 218 * o,
    }


def main():
    shapes = [
        counts(h, w)
        for h in range(1, 128)
        for w in range(1, 128)
        if (h + 1) * (w + 1) <= 256
    ]
    metrics = [
        "output_cells", "inline_operations", "rows_operations",
        "materialize_operations", "ssa_staged_operations",
        "skeletal_inline_check_steps", "skeletal_rows_check_steps",
        "skeletal_three_check_steps",
    ]
    maxima = {
        metric: {
            "value": max(s[metric] for s in shapes),
            "shapes": [[s["height"], s["width"]] for s in shapes
                       if s[metric] == max(t[metric] for t in shapes)],
        }
        for metric in metrics
    }
    exceptions = [
        [s["height"], s["width"]]
        for s in shapes
        if s["stored_multiplications"] > s["inline_multiplications"]
        or s["rows_arena_bytes"] > s["materialize_arena_bytes"]
    ]
    result = {
        "scope": "formula enumeration only; no generated plan or compiler executed",
        "shape_count": len(shapes),
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "maxima": maxima,
        "h5_w7": counts(5, 7),
        "dominance_formula_exceptions": exceptions,
        "limitations": [
            "Operation counts assume one shared const(1) and exact documented expansions.",
            "Check-step figures exclude source-read expansion bookkeeping, producer-cost matching, decoding and all other unspecified charges.",
            "No JSON byte size, emitted Core bytes, compiler limits, liveness, or native memory bound is established.",
        ],
    }
    print(json.dumps(result, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()

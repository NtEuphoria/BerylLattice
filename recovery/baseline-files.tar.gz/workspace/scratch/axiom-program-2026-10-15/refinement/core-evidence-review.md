# Core bridge and research evidence review

Read-only source review, 2026-10-15. The inspected checkout reports commit `0a678b4ae6d41190c4f5a8bf063caba05759d20d`. Scope: plans 02/03, `prototype-contract.md`, and the actual Core driver, process implementation, evaluator and collector. No compiler build, test, installation, network operation or source edit was performed. This document records research/planning corrections, not implementation or native validation.

## Findings that should change the plans

### 1. Define the compile artifact before offering the CLI

**Blocking interface ambiguity, Plan02 Tasks2/5.** `emit_core` requires input data and initial output, and produces a fixed-case test witness. The proposed `compile SOURCE --clang PATH --core PATH --out DIR` supplies neither. No public general-purpose runtime ABI is defined. A binary containing a literal-input test witness is not an executable interface that accepts arbitrary Axiom inputs.

This distinction matters in the pinned compiler: production C emission supplies an executable entry only when there is a user `main`; test mode synthesizes a main that runs tests ([c_backend.c](/workspace/beryl/src/back/c_backend.c:1565)). Experimental IR is available only through differential tests ([main.c](/workspace/beryl/src/driver/main.c:479)). Calling ordinary `beryl build` on only the proposed kernel does not provide the missing executable entry contract.

**Refinement:** explicitly distinguish checked Core kernel-source artifacts from fixed-case witness bundles and their binaries. A witness command must name a case manifest containing exact input/initial-output bytes or identities; alternatively make witness creation an explicit part of `conformance`. Give `compile` a precise, narrower source-artifact meaning, or defer that name until the runtime entry is designed. Do not add a native ABI to resolve this ambiguity during the first milestone. Pin a complete minimal generated source specimen and its expected observation before large-scale adapter implementation; source inspection alone does not establish that H5/W7 lowers successfully.

### 2. The outer process runner needs a real nested-process ownership design

**Blocking cleanup assumption, Plan02 Task3.** Beryl puts each spawned compiler/native child into its own process group using `setpgid`, then kills that group on completion/cancellation ([process.c](/workspace/beryl/src/driver/process.c:317)). Therefore a Python wrapper's `start_new_session=True` plus `killpg(beryl_pid, SIGKILL)` cannot be assumed to kill Beryl's nested compiler/native groups.

`--timeout-ms` is a separate budget for each reference execution/native subprocess, not the total driver invocation ([main.c](/workspace/beryl/src/driver/main.c:703)). A differential run with native evidence performs reference execution, compiler version capture, native compilation, three additional evidence passes and native execution; each can consume a separate timeout ([build.c](/workspace/beryl/src/driver/build.c:108), [reference_driver.c](/workspace/beryl/src/driver/reference_driver.c:110)). Reusing 120 seconds as the outer whole-operation limit would change the contract.

**Refinement:** specify an independent whole-pipeline deadline, signal Beryl cooperatively first so its handler can perform owned-child cleanup, and define a verified platform mechanism for forced cleanup of remaining nested groups. A fake-process test should create a nested group like the real driver, not only a sleeping direct child. Record uncertain cleanup as an error. Keep diagnostic process duration separate from any future checked-call timing.

Also narrow `NativeRun.exit/signal`: the POSIX Core report collapses a signaled native process into `128 + signal` ([process.c](/workspace/beryl/src/driver/process.c:338)). It does not preserve the distinction between that signal and an ordinary exit with the same numeric code. Preserve Core's reported status/code and label an exact native signal unavailable unless independently observed; the outer Python process return code has a different scope.

### 3. Specify lane-specific success and exact stdout framing now

**Contract omission, Plan02 Task3.** The retained `reference.stdout.log` also contains the terminal Core test summary. It is not solely witness scalars: the reference evaluator appends `ok  1 test, 0 assertions\n` for a successful single test with no assertions ([value.c](/workspace/beryl/src/reference/value.c:243)). Native stdout for the differential execution is named `differential.stdout.log` through its process log name ([reference_driver.c](/workspace/beryl/src/driver/reference_driver.c:119)). The outer CLI can additionally forward compiler diagnostics, so parsing all its integers is unsound.

“Require its actual completed comparison” cannot apply literally to all three lanes. The reference lane deliberately never sets `compared=true`. Conversely `compared=true` alone is insufficient for differential success because it is set before the equality result is known ([reference_driver.c](/workspace/beryl/src/driver/reference_driver.c:125)).

**Refinement:** define a strict grammar of exactly the required signed-i32 scalar lines followed by the expected single terminal summary and no extra bytes. Cross-check the report's test/assertion counts. Reference success requires completed successful reference execution with one selected test; AST/IR differential success additionally requires successful native execution, `status=success`, `compared=true`, matching requested/selected lowering and, for IR, admitted schema-5 profile. Missing or partial reports are errors, not numerical mismatches. Test a record with `compared=true,status=failure` and a successful reference-only record with `compared=false`.

Run each invocation with a dedicated working directory, because Core chooses `.beryl-cache` relative to its current working directory ([reference_driver.c](/workspace/beryl/src/driver/reference_driver.c:74)); the public routes provide no result-directory flag. Discover only the invocation's newly created job, check it belongs to that directory, and retain its nested evidence. Do not choose the newest job from a shared cache.

### 4. Independent large-shape expected state is a missing native gate

**Blocking semantic gap, Plan03 Tasks1/3.** Chunk verification proves representation integrity; baseline/candidate byte equality proves agreement. Neither proves the stencil result. The existing evaluator merely checks that the two supplied state/events/stdout references have equal hashes ([evaluate.py](/workspace/beryl/tools/beryl-experiments/evaluate.py:220)). It does not run an oracle.

The proposed Plan01 source admission allows at most 256 input cells, so it cannot automatically be described as the primary H2049/W2047 oracle. Plan03 currently explicitly requires input preservation, but does not give the large-shape independent output/status oracle a public interface or completion gate. The earlier protocol does require independent reference comparison for every measured invocation and permits state deduplication only after actual comparison ([protocol.md](/workspace/scratch/axiom-foundations-2026-10-15/performance/protocol.md:302)).

**Refinement:** make a separately specified, scalable wide-integer oracle and streaming bytewise comparison an explicit prerequisite for native admission. Bind oracle version, exact logical semantics, shape/input/initial-output identity and expected status/first-invalid coordinate. It must remain independent of the selected plan, emitter and native collector. Do not widen Plan01's accepted profile implicitly. Add a negative control in which baseline and candidate produce the same wrong complete output; format verification and pair equality should pass, but semantic admission must fail.

### 5. Freeze the external-state-to-evaluator mapping rather than leaving it implicit

**Blocking integration design, Plan03 Tasks1/4.** Evaluator-v1 treats `semantic.state` as an opaque referenced file. It never traverses a chunk manifest. Its exact schemas also prohibit adding acquisition fields to an existing measurement object ([evaluate.py](/workspace/beryl/tools/beryl-experiments/evaluate.py:169)). An independently verified manifest can serve as the opaque equality object only if an external gate owns and records all the missing obligations.

**Refinement:** define a versioned export contract with: (1) canonical semantic state manifest as the evaluator's state file; (2) distinct per-invocation acquisition/comparison sidecars; (3) an external admission envelope binding every directly and indirectly referenced file, all sidecars, request bytes, evaluator/Python/verifier identities and exact semantic contract; (4) complete revalidation of that closure immediately before and after evaluation. Evaluator `Reader.unchanged()` checks only its direct references ([evaluate.py](/workspace/beryl/tools/beryl-experiments/evaluate.py:100)), so it cannot catch a changed chunk behind an unchanged manifest. Pin/retain immutable snapshots or equivalent controlled storage throughout admission/evaluation. A copied or fabricated `AdmissionResult` must not authorize unrelated bytes.

The current fail-closed fallback is correct: until this export contract is reviewed, synthetic fixtures can exercise the package but native eligibility remains unavailable. State clearly that evaluator acceptance alone does not certify chunk completeness or oracle agreement.

### 6. Separate semantic identity, provenance and size accounting precisely

**Necessary schema refinements, Plan03 Task1.** `StateMetadata` currently includes semantic/kernel/input identity, acquisition mode and run ID; the later sidecar rule needs to state exactly which fields leave the semantic object. In particular a generated-Core kernel identity changes with the plan and cannot remain in the evaluator's byte-equality object. Use logical semantic identity there; put emitted kernel, plan, binary, run, collector and acquisition identities in the sidecar. Include the initial-output identity in the invocation contract so rejection preservation is defined, and enforce status/first-bad-index/shape consistency. Two equal post-states need not imply equivalent invocations with different initial output.

Repeated chunk *content* is legal: all-zero arrays can contain many equal 1-MiB chunks. Reject duplicated logical offsets/roles or missing coverage, not repeated hashes/content-addressed filenames. Add an explicit repeated-content positive test alongside duplicate-coverage negative tests.

Evaluator-v1's 256-MiB budget deduplicates by resolved path, not by SHA-256, and also caps referenced file count at 16,384 ([evaluate.py](/workspace/beryl/tools/beryl-experiments/evaluate.py:80)). Two separate files containing equal bytes count twice. The external verifier needs both exact expanded logical-length checks and artifact-store accounting, including manifests, sidecars, pilot and evaluation closure; “unique bytes” alone is ambiguous. Immutable content-addressed sharing can keep repeated successful observations small only after each run's actual state has been acquired and compared. Without deduplication, even eight primary-size states exceed 256 MiB. Do not pool all shape/seed state into a single request merely because each individual chunk is small.

### 7. Make evaluator CLI/root behavior concrete

**Straightforward plan precision, Plan03 Task4.** The current parser supports exactly `freeze|evaluate --input PATH [--output PATH]`; output is opened exclusively with `xb`, and every reference resolves relative to the input file's parent ([evaluate.py](/workspace/beryl/tools/beryl-experiments/evaluate.py:303)). It uses current wall-clock time internally, so a replay is not expected to reproduce receipt timestamps or freeze bytes.

**Refinement:** specify a pinned Python executable plus evaluator path in argv, a self-contained evidence root with exact relative paths, and fresh output filenames. Preserve both process result and evaluator JSON error/success. Synthetic fixtures must have valid historical chronology rather than rely on a nonexistent CLI `--now` option. Bind the Python version and evaluator source hash; never execute commands from receipt contents.

### 8. Strengthen dataset identities without claiming to discover hidden tuning

**Research-contract refinement, Plan03 Task2.** The frozen workload identity includes cap, entry contract and cache regime. That is appropriate for a measurement stratum, but using only that composite ID for contamination checks allows the same shape/input to be renamed under another regime or generator label. The evaluator checks only its workload fingerprint's literal absence from a declared prior list ([evaluate.py](/workspace/beryl/tools/beryl-experiments/evaluate.py:265)).

**Refinement:** distinguish dataset content identity from full measurement-stratum identity, retain all known training/selection accesses in a ledger, and specify whether the held-out claim is input-level or shape-level. Add a same-bytes/different-generator-label or different-cache-regime negative control where the declared holdout rule requires exclusion. Explicitly retain the trust boundary: no validator can discover unreported tuning. A baseline A/A pilot of the primary workload is an allowed predeclared role, not candidate selection feedback.

### 9. Keep reproducibility claims at the identity actually recorded

**Precision, Plan02 Tasks1/5.** Core's source fingerprint hashes source *paths and content hashes*, so byte-identical generated source saved under different paths can have different Core source fingerprints ([identity.c](/workspace/beryl/src/driver/identity.c:6)). Record raw generated-byte SHA-256 separately from loaded-source-manifest identity. Do not require those path-sensitive fingerprints to remain equal across arbitrary output directories.

The native evidence explicitly fingerprints the selected Clang executable but not all dependent SDK/linker binaries ([build.c](/workspace/beryl/src/driver/build.c:100)). Exact argv and executable hashes are valuable traceability; “all toolchain bytes” or fully reproducible native builds would overstate that capture. Describe the scope, retain dependencies where feasible, and leave unsupported environmental identity unavailable. Since `--save-native-evidence` requires LLVM IR/assembly/driver-jobs capture as well as C11 compilation, a C11-only preflight is necessary but not sufficient for this lane.

## Verified aspects that should stay

- All three written Core CLI forms are consistent with the current parser. Reference plus explicit `--lowering ast` is valid; native optimization overrides are prohibited for reference. `--release` controls Clang O2, while `--opt off` controls Beryl's own optimization policy.
- Full frontend admission, initialized whole-array scratch and a separate initialized `inout` output are appropriate. Direct typed-AST/IR construction is not justified by these plans. Source-only inspection does not prove the H5/W7 quota/initialization path passes.
- Scalar observation of status, every input and every output is the right tiny-profile mechanism. Different generated programs' source-offset traces should not be compared across plans; Core already compares exact same-source native/reference traces within each run.
- Retaining IR's 256-cell aggregate, table and declared-storage limits is correct. Large-buffer lowering, plan-v2 checking and native measurement remain separate research gates.
- The native collector is actually closed at `collect()` before building: `resources_of({}, None)` raises unavailable ([run.py](/workspace/beryl/tools/beryl-bench/run.py:407)). Its dormant `paid_costs` places whole-process time in `compute`; dormant build code omits selected Clang forwarding to Beryl and treats executable file size as text size ([run.py](/workspace/beryl/tools/beryl-bench/run.py:287)). Plan03 correctly refuses to paper over these gaps.
- Evaluator resource fields require exact integers; null/unavailable belongs in external admission records and must prevent export to a native evaluator-v1 measurement. The exact paid/resource keys, fixed max(5%, pilot noise) threshold, balanced even 30–1024 blocks, synthetic/native distinction and prohibition on automatic adoption are accurately represented.

## Recommended research completion boundary

Resolve the artifact-kind/case-input contract, nested-process ownership, lane-specific observation predicates, independent large-shape oracle and external complete-state export schema in the documents. Preserve executable verification as an explicitly future milestone. This review supplies source-grounded feasibility constraints; it does not establish native conformance, measured resources, performance eligibility or a working Axiom compiler.

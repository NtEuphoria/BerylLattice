# Iteration 2: research findings, corrections and review

2026-10-15. Three focused agent reviews challenged the checker contract, Core/evidence boundary and novelty argument. The primary agent checked the relevant Core/evaluator source, inspected primary-text passages, revised the plans, and requested focused re-reviews. This is design review and finite model evidence; no Axiom compiler or native benchmark was run.

The entire earlier packet is preserved in [iteration-1.tar.gz](../../axiom-program-2026-10-15-history/iteration-1.tar.gz), SHA-256 `e2fa8a8cea8953fae52e9fa56f315e19ef26b225c5dede6522e77ddb33af1a97`. The original [planning self-review](../plan-review.md) is explicitly historical. Foundation documents and source checkouts are unchanged.

## Material findings

**The proposed memory tradeoff had a missing valid implementation.** SSA-staged producer values need no designated scratch arena. At H5/W7 that plan performs 48 multiplications, reserves zero arena bytes and retains up to 49 SSA values after an operation. The independent control passed the finite corpus. The resource claim now names its exclusions, and the checker plan requires acceptance of this control.

**The initial selection problem is analytic.** Rows2 weakly dominates full materialization under the two proposed metrics. Inline is feasible under every nonnegative arena cap. The updated experiment includes a formula-based selector and explicitly restricts optimization claims to the named portfolio. The study tests correctness, bounded checking and evidence handling; it does not yet justify an expensive search algorithm.

**The closest literature is closer than the initial source-only review established.** Two full papers and the SyGuS2.1 standard were retrieved from ordinary public author/project copies. Halide2019 includes a scoped GPU memory rejection rule; SyGuS specifies hard weighted constraints and optimization objectives; Halide2020 studies verified/synthesized rewrites with qualified resource results. These overlap with proposed Axiom features and sharpen the research question. No novelty claim follows from the current comparison.

## Correction dispositions

| Review finding | Resolution in the current plans |
|---|---|
| Scalar retention escapes arena accounting | Valid SSA control retained; arena-only scope explicit; separate abstract/native storage research. |
| Producer classification is underspecified checker work | Objective is now every `mul` opcode, named `multiplication_ops`; no producer-expression matcher. |
| Valid deep DAGs could be incorrectly rejected | Iterative bounded traversal; safe completed cases pass, exhausted cases remain unknown. |
| Huge declared scratch can allocate unbounded checker storage | Sparse symbolic scratch, explicit capacity bound, separate execution admission before allocation. |
| Partial checks blur constraint truth and eligibility | `constraint_status`, `check_complete`, null unavailable counts and derived eligibility. |
| In-memory plan constructors bypass decoder invariants | Checker validates direct Plan/Operation objects as well as decoded plans. |
| Exact replay has no expected identities | Strict ReplayManifest input; exact source/plan/version binding, then fresh checks. |
| Additional replay cap has no checker context | Keyword-only additional_cap; effective_cap and constraint_digest in the result. |
| Public source evaluation bypasses profile admission | `evaluate_source` admits first, then evaluates the retained independent source AST. |
| Optional search budget has no defined API | Explicit optional allowance after the eligible inline incumbent; all calls consume total checker allowance. |
| Checker event budget sounds like total compile-time bound | Parsing, generation, decoding, allocation, hashing and wall time have separate scopes. |
| Body checking implicitly proves range-rejection behavior | Separate valid-input body theorem and preflight-wrapper lemma. |
| `compile` has no input case or defined native ABI | Explicit fixed-case `witness --plan --case`; distinct source/binary artifact kinds. |
| Fixed-plan witness silently substitutes another incumbent | Lowering failure remains that plan's failure; fallback belongs to a separate selection request. |
| Outer process-group kill misses Core nested groups | Cooperative cleanup plus verified forced-ownership mechanism; separate pipeline deadline and uncertain-cleanup error. |
| Reference/differential success predicates are conflated | Lane-specific report checks; exact scalar/terminal-summary grammar; per-run cache directory. |
| Artifact hashes claim too much reproducibility | Binary bytes, path-sensitive Core source identity and unobserved toolchain dependencies are distinguished. |
| Complete output equality is mistaken for correctness | Independent scalable oracle gate; same-wrong-output negative control. |
| Semantic manifests include plan-specific identity | Logical invocation/state identity separated from acquisition, emitted kernel, plan and binary sidecars. |
| Chunk deduplication and byte limits are ambiguous | Logical offsets checked; repeated content allowed; aggregate accounting by resolved path and full closure. |
| Local successful checks masquerade as full export admission | Distinct ChronologyResult, MeasurementAdmission and ExportAdmission; export binds complete request/closure/tools. |
| Evaluator does not inspect indirect chunks | External export-v1 envelope verifies retained immutable closure before/after evaluation. |
| Dataset labels can evade contamination checks | Content identity separated from measurement stratum; explicit holdout level and declared access ledger. |

The underlying [checker review](checker-review.md), [Core/evidence review](core-evidence-review.md) and [contribution review](contribution-review.md) retain the original findings. Some quoted old interfaces describe the pre-revision proposal; the current contract and implementation plans own the revised names.

## New evidence and its limits

The [SSA control probe](probes/ssa_control.py) was run after final metric/baseline changes. It passed 955 shapes, 21,965 labeled input cases, 87,860 complete-state stream comparisons, 10,952 expanded-portfolio selections and 10,952 analytic original-portfolio comparisons. A wrong-neighbor mutation was detected. Numeric inputs are sampled, not exhaustive over i32; all admitted shapes are enumerated. The script refuses Python `-O` because its research checks use assertions. This is not the proposed executable checker.

The independent [formula probe](checker/count_model.py) enumerated the same shape domain and was rerun. Its operation counts agree with constructed streams. Its skeletal checker-fuel numbers are conditional estimates, not a final implementation budget guarantee.

Primary PDFs, extracted text, discovery pages and retrieval hashes are indexed [here](papers/README.md). Relevant sections were inspected; retrieval is not exhaustive scholarship or reproduction of the authors' experiments. The full Exo/Exo2, validator and memory/rematerialization comparison remains outstanding.

The final package verification checks authored local links, external/source evidence hashes, probe receipts, plan task counts, the prior archive, pinned Core commit and clean checkouts. The machine-readable [artifact manifest](../artifact-manifest.json) records exact files and validation results. These checks do not prove the planned implementation will pass its future tests.

## Next bounded research step

Keep the correctness prototype contract small and auditable. The [resource study](resource-contract-research.md) now sequences representation accounting, actual lowering inspection, compact schedule certificates and useful constrained selection, with explicit ways each hypothesis can fail. Develop a private technical note around those results; pursue public paper submission only after a defensible contribution and complete evidence exist. No implementation, external model contact or publication was performed in this revision.

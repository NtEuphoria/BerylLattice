# Resource contracts: the omitted SSA control and next experiments

Private research note, 2026-10-15. This changes the interpretation of the proposed Axiom prototype; it does not implement the language or establish a native memory bound. The current decision is to keep plan-v1's explicitly named arena property, admit the counterexample, and study stronger storage contracts separately.

## The finding

Let `P=(H+1)(W+1)` input/producer cells and `O=HW` output cells. The allowed finite plan can define all `P` producer values in SSA, then consume those definitions. SSA IDs are operands, so this needs no scratch arena. The original portfolio omitted this legitimate implementation.

For every positive H,W:

```text
4O - P = (H-1)(3W-1) + 2(W-1) >= 0
full_arena - rows2_arena = 4(H-1)(W+1) >= 0
```

The SSA plan has P multiplications and zero arena bytes. It weakly dominates all three original plans under those two metrics, tying inline only at H=W=1. Rows2 weakly dominates full materialization, tying its metrics when H=1. These are algebraic facts for the stated constructions, not proofs of optimality over all programs.

The independent [probe](probes/ssa_control.py) constructs all four streams and checks all 955 positive shapes with P<=256. It compares complete status/input/output on 10 valid and 13 invalid cases per shape: 21,965 labeled cases and 87,860 stream invocations. It also checks 10,952 selections for the expanded portfolio and 10,952 comparisons with an analytic selector for the original portfolio. A well-formed wrong-neighbor mutation passes structural checks but fails the numeric oracle. Full results are retained in [results.json](probes/results.json).

At H5/W7 the actual constructed streams give:

| Plan | Mul operations | Arena bytes | Stream operations | Peak live SSA values after operations | Conservative transient SSA values |
|---|---:|---:|---:|---:|---:|
| Inline | 140 | 0 | 561 | 5 | 6 |
| Two rows | 48 | 64 | 473 | 5 | 6 |
| Full materialization | 48 | 192 | 473 | 4 | 5 |
| SSA-staged control | 48 | 0 | 285 | 49 | 50 |

Operation counts exclude wrapper preflight and emitter initialization. Liveness counts actual final operand uses in these exact streams. The after-operation count retires last-use operands; the transient diagnostic also counts the new result before retirement, assuming no destructive reuse. These are scalar payload counts, not Python allocations, register counts, stack sizes or measurements. Different instruction interleaving can change the counts.

The separate [formula probe](checker/count_model.py) reaches the same 955 shapes through an independent enumeration. Maximum stream lengths are 3,601 inline, 2,825 rows2/full and 1,669 SSA-staged. Its checker-fuel estimates depend on a skeletal 31-node source tree and omit unresolved bookkeeping; they are not proof that the proposed 100,000-step checker always succeeds. Actual decoder sizes, Core admission and executable checker cost remain unmeasured.

## What changes now

1. Keep `plan_workspace_bytes` as exactly four times reserved scratch capacity. Explain SSA exclusion wherever the property is presented.
2. Count all mul opcodes as `multiplication_ops`. The earlier producer-expression classification was unnecessary, underspecified work and did not cover arbitrary plans transparently.
3. Require the checker to accept the SSA control when its full semantics and constraints pass. Known generator labels confer no privilege.
4. Keep the three-generator selector as a frozen conformance experiment. An analytic baseline chooses inline for arena minimization; for multiplication minimization it chooses inline until rows2 fits, except the 1×1 tie. At H=1 and larger W, full/rows2 tie and lexical stable ID chooses materialize. All other admitted H>1 shapes choose rows2 once it fits. No nonnegative arena cap proves source infeasibility because inline needs no arena.
5. Separate a valid-input body theorem, checked-boundary rejection lemma and empirical Core correspondence. No result from this probe closes the implementation or lowering proof gap.

## Three possible resource properties

| Property | Exact scope | What would establish it | Current decision |
|---|---|---|---|
| Designated arena capacity | Reserved plan scratch cells, including unused cells | Header capacity, initialized accesses, bounds and effective-cap check | Retain for the tiny checker study. |
| Abstract execution storage | Arena plus simultaneously retained scalar payload under a specified abstract machine | Operational storage semantics, liveness/reuse argument and independent accounting | Research next; diagnostics are not yet a hard language feature. |
| Post-lowering native storage | Explicitly enumerated objects/register spills/frames/runtime obligations for a stated target | Stage-to-stage resource relation and final representation accounting under runtime assumptions | Longer-term research; no present guarantee. |

For a candidate abstract machine, define each scalar as a four-byte cell, allocate a result before freeing operands at their final use, and keep the arena reserved throughout the body. A result with no uses is freed immediately after its defining transition. A conservative payload measure is `4*(scratch_capacity_cells + peak_transient_ssa_cells)`. On these streams H5/W7 gives 24 bytes inline, 88 rows2, 212 full and 200 SSA-staged. This restores a storage/recomputation distinction **in that proposed machine**. It excludes caller arrays, address metadata, control state and runtime/backend storage; it is neither a selected new constraint nor a native upper bound. A model with destructive operand reuse needs a different transition relation and proof.

Counting every SSA definition ever created is not an acceptable replacement: dead scalar values do not all need simultaneous retention. Likewise, observed peak RSS is not a hard bound, grammar-production weights are not automatically peak liveness, and adding a register estimate to the arena does not constrain spills introduced later.

## Falsifiable sequence

**Experiment A — representation accountability.** Compare equivalent arena and SSA encodings while retaining complete output semantics. The current probe establishes the counterexample. Before admitting a stronger abstract property, specify each allocation/free event and show that scratch loads, shared operands, dead results, long chains and last-use boundaries are counted. Move a real use later to extend a value’s lifetime, and insert an unused result to test transient allocation followed by immediate retirement. Check local live counts and the resulting peak: neither change necessarily increases the global maximum. Reject the model if its description cannot be implemented by an independent checker without trusting planner labels.

**Experiment B — lowering correspondence.** After Plan02 exists, retain Core/C/LLVM/assembly for all four streams where admitted. Determine whether copies, zeroing, scalar replacement, common-subexpression elimination or spills change the anticipated tradeoffs. First measure and explain the emitted objects; do not add a hard native property until all later storage-introducing stages have a contract. If optimized plans converge, record that null result and revise the selection rationale.

**Experiment C — compact schedule certificates.** Before large shapes, define a loop plan with explicit iteration domains and certificate obligations. For rows2, show initialized logical rows r and r+1 before consumer row r, correct modulo-slot mapping, no overwrite before the last read, and safe refill after the row. Extend to one shared producer with two consumers to test whether the invariant language handles a different lifetime. A certificate that secretly expands all iterations fails the scaling objective. A checker theorem must cover the certificate language, not only one hard-coded template.

**Experiment D — useful constrained choice.** Introduce new source structure only when it exposes a real distinction: shared consumers, differing stencil radii/orientation, or independent stages. Freeze the supported semantics and compare against the best training-selected fixed plan and simple analytic rules. Solver/e-graph/learned scheduling is justified by a measured missed opportunity, not by the 5GL label. Recompute all paid costs and holdout rules before claiming benefit.

Each experiment may invalidate the next. Successful checking is useful without a publishable novelty result. An unsuccessful storage hypothesis is a design correction to retain, not a reason to omit the control.

## Closest-work obligations

The [full-text review](contribution-review.md) establishes Halide 2019's scoped GPU shared-memory filter, SyGuS 2.1 weighted constraints/objectives, and Halide 2020 rewrite verification and qualified resource results. These rule out broad novelty claims based on those features alone. Next prioritize full Exo/Exo2 correctness boundaries, verified translation/scheduling validators, and memory/recomputation scheduling. Checkmate and dynamic tensor rematerialization are discovery leads only; no theorem or bibliographic claim from those works is asserted here without reading them.

The strongest provisional long-term question is whether Axiom can make a programmer's precisely named storage constraint checkable across representations at acceptable cost. The current research step is deliberately smaller: make the final-plan contract honest and independently testable before building on it.

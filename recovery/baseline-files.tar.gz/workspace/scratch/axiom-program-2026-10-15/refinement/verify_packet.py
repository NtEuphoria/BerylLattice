#!/usr/bin/env python3
"""Verify local research evidence/links; never run product or native tests.

Run after any packet edit. Writes artifact-manifest.json, excluding itself from
self-hashing only in the sense that the manifest does not contain its own hash.
The verification script IS included in the manifest. Numeric probe execution is
recorded separately; this checks its source/receipt identity and exact claims.
"""
import hashlib
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import unquote

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'artifact-manifest.json'

def require(condition, message):
    if not condition:
        raise SystemExit(message)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def checked(record, path):
    require(path.is_file(), f'missing source: {path}')
    require(sha(path) == record['sha256'], f'stale source: {path}')
    if 'bytes' in record:
        require(path.stat().st_size == record['bytes'], f'wrong length: {path}')

plans = sorted((ROOT / 'docs/superpowers/plans').glob('*.md'))
authored = sorted(ROOT.glob('*.md')) + plans + [ROOT / 'sources/README.md']
authored += sorted((ROOT / 'refinement').glob('*.md'))
authored += [ROOT / 'refinement/papers/README.md']
links = 0
for file in authored:
    content = file.read_text()
    for target in re.findall(r'\[[^\]\n]*\]\(([^\)\n]+)\)', content):
        target = target.strip('<>')
        if re.match(r'^[A-Za-z][A-Za-z0-9+.-]*://', target) or target.startswith('#'):
            continue
        target = re.sub(r':\d+$', '', unquote(target.split('#', 1)[0]))
        if not target:
            continue
        path = Path(target) if target.startswith('/') else file.parent / target
        require(path.exists(), f'broken link from {file.relative_to(ROOT)}: {target}')
        links += 1
require(len(plans) == 3, 'expected three implementation plans')
tasks = sum(len(re.findall(r'^### Task \d+:', p.read_text(), re.M)) for p in plans)
steps = sum(p.read_text().count('- [ ]') for p in plans)
require(tasks == 16, 'task count changed without review')

previous = json.loads((ROOT.parent / 'axiom-foundations-2026-10-15/verified-sources.json').read_text())
for entry in previous['external_snapshots']:
    checked(entry, Path(entry['cached_path']))
for entry in previous['repository_sources']:
    checked(entry, Path(entry['path']))
user_doc = previous['user_document']
if 'sha256' in user_doc:
    path = user_doc.get('path') or user_doc.get('cached_path')
    require(path is not None, 'missing user document path')
    checked(user_doc, Path(path))
source_entries = json.loads((ROOT / 'sources/manifest.json').read_text())
for entry in source_entries:
    if entry['status'] == 'retrieved':
        checked(entry, ROOT / 'sources' / entry['file'])
paper_root = ROOT / 'refinement/papers'
pdfs = json.loads((paper_root / 'pdf-manifest.json').read_text())
pages = json.loads((paper_root / 'page-manifest.json').read_text())
for entry in pdfs + pages:
    checked(entry, paper_root / entry['file'])
for entry in pdfs:
    text = (paper_root / entry['file']).with_suffix('.txt')
    require(text.stat().st_size > 10000, 'empty/truncated derived paper text')

probe_path = ROOT / 'refinement/probes/ssa_control.py'
probe = json.loads(probe_path.with_name('results.json').read_text())
require(probe['source_sha256'] == sha(probe_path), 'stale SSA probe receipt')
require(probe['status'] == 'passed', 'probe did not pass')
require(probe['totals']['shapes'] == 955, 'shape count mismatch')
require(probe['totals']['stream_invocations_compared'] == 87860, 'comparison count mismatch')
require(probe['selection']['expanded_portfolio_checks'] == 10952, 'expanded selection count mismatch')
require(probe['selection']['original_portfolio_analytic_checks'] == 10952, 'analytic count mismatch')
require(probe['negative_mutation_control']['numeric_verifier'] == 'rejected', 'negative control missed')
representative = probe['representative_H5_W7']['metrics']
require(representative['ssa-staged-v1']['peak_live_ssa_boundary_cells'] == 49, 'liveness mismatch')
require(representative['ssa-staged-v1']['plan_workspace_bytes'] == 0, 'arena mismatch')
formula_path = ROOT / 'refinement/checker/count_model.py'
formula = json.loads(formula_path.with_name('count_model_results.json').read_text())
require(formula['source_sha256'] == sha(formula_path), 'stale formula receipt')
require(formula['shape_count'] == 955 and not formula['dominance_formula_exceptions'], 'formula mismatch')
require(formula['maxima']['inline_operations']['value'] == 3601, 'operation maximum mismatch')

archive = ROOT.parent / 'axiom-program-2026-10-15-history/iteration-1.tar.gz'
require(sha(archive) == 'e2fa8a8cea8953fae52e9fa56f315e19ef26b225c5dede6522e77ddb33af1a97', 'historical archive changed')
def git(*args, cwd):
    return subprocess.run(['git', *args], cwd=cwd, check=True, text=True, capture_output=True).stdout.strip()
core = Path('/workspace/beryl')
commit = git('rev-parse', 'HEAD', cwd=core)
require(commit == previous['repository_commit'], 'Core pin changed')
for repo in (core, Path('/workspace/BerylLattice')):
    require(not git('status', '--porcelain=v1', cwd=repo), f'checkout changed: {repo}')

# Pin additional Core source inspected during this revision, beyond the inherited index.
source_paths = [
    'src/driver/process.c', 'src/driver/reference_driver.c', 'src/driver/build.c',
    'src/driver/main.c', 'src/driver/identity.c', 'src/reference/value.c',
    'src/back/c_backend.c', 'tools/beryl-experiments/evaluate.py',
    'tools/beryl-bench/run.py',
]
repo_evidence = [{'path': str(core / p), 'sha256': sha(core / p),
                  'bytes': (core / p).stat().st_size} for p in source_paths]
validation = {
    'authored_documents': len(authored), 'implementation_tasks': tasks,
    'checkable_steps': steps, 'local_links_verified': links,
    'prior_external_source_hashes_verified': len(previous['external_snapshots']),
    'prior_repository_source_hashes_verified': len(previous['repository_sources']),
    'iteration_1_external_hashes_verified': sum(e['status'] == 'retrieved' for e in source_entries),
    'new_primary_full_texts_verified': len(pdfs), 'new_discovery_page_hashes_verified': len(pages),
    'prior_user_document_hash_verified': 'sha256' in user_doc,
    'historical_archive_verified': True, 'core_commit': commit,
    'source_checkouts_clean': True, 'probe_source_receipt_bindings_verified': 2,
    'ssa_probe': {'shapes': 955, 'labeled_cases': 21965, 'stream_comparisons': 87860,
                  'expanded_portfolio_selections': 10952, 'analytic_portfolio_comparisons': 10952,
                  'wrong_neighbor_control': 'rejected'},
    'compiler_implementation_or_native_tests_run': False,
    'native_memory_or_performance_claim': False,
    'review_kind': 'three independent focused agent reviews, root source checks, focused re-reviews',
}
files = []
for path in sorted(ROOT.rglob('*')):
    if path.is_file() and path != MANIFEST and '__pycache__' not in path.parts:
        files.append({'file': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size, 'sha256': sha(path)})
result = {
    'schema': 'axiom-research-program-v2', 'date': '2026-10-15',
    'scope': 'local research/design refinement and finite model probes; no product implementation or publication',
    'validation': validation, 'repository_evidence': repo_evidence,
    'prior_archive': {'path': str(archive), 'sha256': sha(archive)}, 'files': files,
}
MANIFEST.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': 'passed', 'files_bound': len(files), **validation}, sort_keys=True))

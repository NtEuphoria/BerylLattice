# Planning self-review

2026-10-15. This is the planning author's self-review, not an independent agent review or a compiler test. No agents were spawned for this planning round. The earlier foundation design/probe retain their separate reviews.

## Coverage

| Foundation requirement | Owning task or explicit research gate |
|---|---|
| Exact source semantics and canonical admission | Plan01 Task1; prototype contract. |
| Checked entry, complete output and deterministic first rejection | Plan01 Task2; Plan02 Task4. |
| Explicit resource scope and hard constraints | Plan01 Tasks4/6/7. |
| Three schedules, reuse lifetime and counterexamples | Plan01 Tasks4/5. |
| Independent checker, unknown states and deterministic work | Plan01 Tasks4/6. |
| Replay, identities and immutable handoff | Plan01 Task7; Plan02 Tasks2/5. |
| Existing complete Core admission and observation limits | Plan02 Tasks1–4. |
| Source provenance and independent generator oracle | Plan02 Tasks2/4. |
| Complete-state evidence and honest measurement admission | Plan03 Tasks1–4. |
| Large-buffer/loop lowering and native measurement | Explicit G4 prerequisite designs; not falsely specified as implemented APIs. |
| Proof scope, novelty and publication | Research-program R1–R6; paper blueprint and full-text review gate. |

## Ambiguities corrected during review

- **Source constraint override:** replay/CLI caps are additional constraints; null cannot erase a source cap, and a larger override cannot weaken it. Added a direct regression case.
- **State identity versus acquisition provenance:** run IDs, timestamps, absolute paths and plan identities must not enter canonical semantic state. They remain in a separate bound acquisition sidecar. Added identical-state/different-run test.
- **Representation scope:** unrolled operations are explicitly plan-v1 for tiny fixed shapes. They do not claim the scalability or all-shape theorem of a future structured-loop representation.
- **Objective meaning:** producer evaluation counts are derived from checked expressions; all opcodes are also reported. Counts are not latency or total-work guarantees.
- **Named interfaces:** fixed AdmittedKernel, CheckResult and SearchResult field names and provided exact assertion examples. Source/oracle/checker/planner imports have explicit separation.
- **Current Core versus historical helper:** source establishes schema5/CLI gates; the older schema4 experimental helper is not an assumed current test command.
- **Resource receipt vocabulary:** listed all eight paid components and six resource fields exactly; required metric absence remains unavailable.
- **Prototype source promise:** extra valid DAGs/equivalent algebra remain unsupported by the named profile, not falsely invalid or silently accepted.

## Remaining deliberate gates

The provisional `.ax` syntax and Python/unrolled-v1 choices are planning refinements for review. Native toolchain availability, actual generated-Core admission, complete-state evaluator compatibility, loop-plan soundness, larger-buffer storage and native instrumentation need implementation/design evidence at their specified gates. None is represented by a placeholder function that an implementer must guess.

Full paper access was denied for two attempted arXiv PDFs; some guessed project documentation paths returned404. The source investigation is useful but not a completed literature/novelty review. Current venue policy/deadline research is also outstanding. These limits appear in the research findings/program and publication gates.

## Verification performed on the planning packet

Final verification checks local document references, retained primary-source hashes, plan headers/task counts, exact source checkout identities and absence of repository changes. It does not run future tests, build a compiler, validate a new checker or measure native performance. The machine-readable artifact manifest records the final file hashes and actual check counts.

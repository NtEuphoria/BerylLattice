# Project Axiom: detailed research and implementation plan

Start with the [research program](research-program.md). It connects the proposed language prototype, correctness arguments, native correspondence, performance prerequisites and publication decisions.

| Document | Purpose |
|---|---|
| [Research findings](research-findings.md) | Additional primary-source investigation, alternatives and what is/is not a novelty claim. |
| [Prototype contract](prototype-contract.md) | Proposed `.ax` syntax, exact record/operation formats, resource limits and boundary behavior. |
| [Plan01](docs/superpowers/plans/01-axiom-correctness-prototype.md) | Seven tasks for parser, oracle, independent checker, plans, selection and replay. |
| [Plan02](docs/superpowers/plans/02-core-bridge-and-correspondence.md) | Five tasks for actual Core source lowering and independent complete-state correspondence. |
| [Plan03](docs/superpowers/plans/03-research-evidence-infrastructure.md) | Four tasks for complete state, frozen experiments and honest evidence admission. |
| [Paper blueprint](paper-blueprint.md) | Manuscript structure, required evidence, figures, related-work extraction and publication gates. |
| [Planning review](plan-review.md) | Coverage, corrected ambiguities and deliberate remaining gates. |
| [Source index](sources/README.md) | Exact retrieved sources and failed-access records. |

The previous [foundation design](../axiom-foundations-2026-10-15/axiom-v0-design.md) and [model receipt](../axiom-foundations-2026-10-15/probes/results.json) remain the baseline. This round produced plans and research artifacts only. No compiler implementation, native test, benchmark, commit, push or publication occurred. Research material remains local.

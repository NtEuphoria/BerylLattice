# Lattice / Project Axiom: research, implementation and publication program

2026-10-15, iteration 2. **The next implementation milestone remains a small correctness prototype; this research revision first corrects its resource model, replay interfaces and evidence contracts.** The three-plan portfolio is a conformance fixture with an analytic selector. It is not yet evidence for useful optimization or a novel programming-language mechanism.

This package is a plan with standalone mathematical research probes, not a compiler execution receipt. The previous foundation and iteration-1 archive are preserved. The [revision review](refinement/revision-review.md) records the changes. Axiom is the separate 5GL project; Lattice Core remains the 4GL language and first executable substrate.

## 1. The research thesis

Test whether a language can let programmers describe computations and hard implementation constraints, while a bounded planner chooses an implementation that an independent checker admits, with meaningful explanations and safe behavior when search fails.

The first study isolates five obligations:

1. **Meaning:** the source has explicit inputs, result equations, arithmetic and rejection behavior.
2. **Legality:** the final physical plan implements that meaning under the stated assumptions.
3. **Eligibility:** every hard property is checked at its named scope.
4. **Correspondence:** executable lowering preserves the checked plan's meaning, with empirical evidence and an explicit trusted base.
5. **Value:** planning improves something measurable enough to justify its complexity and paid costs.

Correctness and novelty are different questions. A successful integration can be useful engineering without constituting a new research result. The publication argument must establish which question our mechanism answers better or more precisely than its strongest antecedents.

## 2. What is known, proposed and unproved

| Category | State |
|---|---|
| Core baseline | Source inspected at `0a678b4ae6d41190c4f5a8bf063caba05759d20d`; production AST and explicitly gated schema5 IR paths. |
| Mathematical schedules | Prior probe passed23,270 inputs/69,810 executions;144 finite symbolic shapes;three faulty-schedule witnesses. This is not new evidence from this planning round. |
| Axiom source language/checker | Proposed; no compiler implementation yet. |
| Core generator | Interface specified; actual generated stencil has not been compiled here. |
| Plan workspace | H5/W7 full/inline/ring use192/0/64 declared arena bytes. A legitimate SSA-staged control uses0 arena bytes and48 multiplications, with49 peak live SSA values in the probe. Arena scope excludes these values as well as native copies/spills. |
| Native performance | Unmeasured; current collector deliberately blocks on missing resource evidence. |
| Novelty | Open. The prior23 external snapshots are supplemented by three full primary texts and author/project discovery pages. Halide scoped memory filters and weighted SyGuS are explicit close precedents. Citation coverage remains incomplete. |

The [research findings](research-findings.md) distinguish direct source facts from proposals and unexamined competitor properties. The [prototype contract](prototype-contract.md) turns the existing design into exact source/record/operation interfaces. Nothing in these documents promises that a fixed-shape stencil is already a general 5GL.

## 3. Work packages, dependencies and exits

```mermaid
flowchart TD
  R[Related-work and theorem scope] --> S[Review source and prototype contract]
  S --> A[Plan01: parser, oracle, plans, checker, selection, replay]
  A --> B[Plan02: Core bridge and complete correspondence]
  A --> T[Checker argument and adversarial evaluation]
  B --> P[Private technical report and reproducibility capsule]
  B --> L[Large-buffer and structured-loop design experiments]
  L --> M[Native storage and measurement qualification]
  E[Plan03: state and experiment evidence tooling] --> M
  M --> H[Frozen held-out performance study]
  T --> P
  R --> P
  H --> F[Full empirical paper if contribution and evidence justify it]
  P --> F
```

| Milestone | Concrete deliverable | Exit evidence | Stop/revise condition |
|---|---|---|---|
| G0 contract | Source syntax, statuses, formats and narrow admission | Review examples, ambiguous cases and exact interfaces | User-facing expectations require broader semantics than the bounded study. |
| G1 correctness prototype | Runnable parser/oracle/checker/three-plan CLI/replay | Positive corpus, negative controls, budget and stale-record tests | Checker must trust planner metadata or silently relax constraints. |
| G2 native correspondence | Core source generator and retained executable witnesses | Independent complete observations in actual admitted lanes | Small representative programs cannot preserve the boundary contract or fit admission. |
| G3 scientific model | Checker theorem/argument and adversarial study | Explicit assumptions, operation induction, mutation classes and cost curves | Claimed theorem exceeds what implementation/model actually checks. |
| G4 infrastructure | Large-buffer design, versioned loop checking and real measurement | Actual storage/accounting experiments, complete-state evidence, collector verification | Required metrics or lowering remain unavailable. Do not reopen native collection. |
| G5 performance | Frozen comparisons and negative/null results | Reproducible target/workload-specific result, all costs disclosed | No advantage over a training-selected fixed plan or unacceptable regression/cost. |
| G6 publication | Reviewed manuscript and artifact | Supported claims, close-work comparison and deliberate disclosure decision | Novelty unclear, irreproducible results or unsupported broad claims. |

G1–G3 can produce a useful internal technical report even if G4/G5 fail. That report may describe a bounded mechanism and negative findings honestly; it cannot claim performance or generality that was not established.

## 4. Implementation order and why

Execute the [correctness prototype plan](docs/superpowers/plans/01-axiom-correctness-prototype.md) first. It defines seven reviewable tasks: frontend/admission; independent source evaluator; strict plan format; independent checker; three generators/conformance; selection/budgets; exact replay/CLI. The checker precedes generators so its first fixtures are not produced by the same code it is supposed to distrust.

Execute the [Core bridge plan](docs/superpowers/plans/02-core-bridge-and-correspondence.md) next. It defines five tasks: toolchain/isolated build; source/provenance emitter; process/observation adapter; actual correspondence/mutations; integrated compilation capsule. Use the actual current CLI and source—not historical schema4 helper assumptions. The first report must enumerate unavailable lanes rather than silently count skipped tests as success.

The [evidence infrastructure plan](docs/superpowers/plans/03-research-evidence-infrastructure.md) has four independently useful tasks: complete-state chunks; frozen experiment identities; measurement admission; existing evaluator adapter. It may be implemented after G1 without waiting for native optimization, but synthetic fixtures stay synthetic. Larger-buffer and collector repair receive their own concrete designs after their research experiments; this plan does not invent missing APIs.

The source compiler is initially Python3.12/stdlib. This lowers the cost of changing semantics and evidence formats. Native execution still comes from Core. Python compiler timings and memory are separate from generated program timings. Reimplementing the prototype in C11 is conditional on measured compiler bottlenecks or production integration needs.

## 5. Research questions and experiments

### R1: Does the checker admit correct plans without sharing planner mistakes?

Hypothesis: the independent symbolic event checker accepts the three schedules and the valid SSA-staged control, and rejects or explicitly declines supported faulty mutations without trusting plan labels or supplied facts.

Experiment: manually authored positive plans; generated plans; serialized mutations targeting bounds, initialization, output coverage, SSA identity, storage lifetime, reserved capacity, semantics identity and stale assumptions. Evaluate against the independent source AST and numeric counterexamples. Keep equivalent mutations as controls: a checker may return unknown, but must not report a false counterexample. Report invalid/unknown/valid counts by class, not just aggregate “mutation score.”

Measure check work, wall time, peak compiler memory, decoded size and expression nodes separately over admitted shapes, including thin and asymmetric cases. The compiler-memory measurement is a diagnostic with its own scope, not plan workspace. A larger checker is not automatically a better checker; compare implementation size and trusted dependencies as descriptive evidence.

### R2: What exactly can be proved?

Proposed model theorem: for admitted source, valid boundary input and well-formed fixed plan, if checking completes with semantic-valid and constraint-satisfied, the abstract plan produces the source output, preserves input, respects initialization/bounds and reserves at most the effective declared-arena cap. This theorem covers valid input; a separate wrapper lemma establishes first-invalid rejection and unchanged output. Their composition is a checked-entry claim, not a native compiler theorem.

Proof obligations:

- Sound source profile admission and input precondition establish per-node totality.
- Induct over the operation sequence: each SSA register denotes its recorded expression, initialized scratch slots denote their most recent stored expressions, and all addresses are within their buffer domains.
- Output coverage and structural agreement establish the source's complete output tensor.
- Arena accounting establishes only the designated scratch property; it excludes even plan-level SSA storage. The SSA-staged control is deliberately admitted to expose this limit. See [resource-contract research](refinement/resource-contract-research.md).
- Budget interruptions never yield accepted partial evidence; replay does not change assumptions or bytes.

Initially write a complete mathematical argument and adversarial examples. If the paper claims formal verification, mechanize the model and audit its assumptions. A Lean/Rocq proof of a separate checker model still does not verify the Python decoder/checker, Core emitter or native compiler; implementation refinement/extraction is a separate theorem. Do not label the entire compiler verified because one model theorem passes.

### R3: Is the plan's physical intent preserved by lowering?

For each plan retain emitted Core/C/LLVM/assembly where supported. Identify actual intermediate objects, copies, zeroing, checks and code size. Compare all output and input values, not only a checksum. Deliberately corrupt the generator while letting Core compare its two internally consistent executions; the independent Axiom oracle should catch the semantic defect.

If all three optimized executables become equivalent, retain that finding. It weakens the example's claim for added optimization value but may still validate language/checker engineering. If Core creates full-size copies, investigate whether an admitted existing source form avoids them before proposing backend changes. Neither measured peak memory nor a smaller declared arena proves a native upper bound.

### R4: Does bounded search behave usefully and reproducibly?

Sweep work quotas across exact candidate-check boundaries; interrupt during decoding/checking/selection/publication; replay corrupted/stale records. Compare cold and warm behavior under the same logical accounting. Record selected incumbent, unexamined candidates and stop reason. Test cap0/63/64/191/192 for H5/W7, including inadmissible full-materialization fallback. None of these nonnegative caps makes inline infeasible.

Version1 selection minimizes counted mul opcodes or designated arena bytes; no latency claim. Compare it to the analytic selector for the same three candidates, including H=1 label ties. The SSA-staged positive control dominates these metrics outside that portfolio; no global optimality claim follows. `total_check_steps` counts only specified checker events; source admission, decoding, generation and physical time have separate bounds. A future frozen runtime model needs held-out evaluation and genuinely differing best plans; retrospective best measured performance is descriptive, not a deployable baseline.

### R5: Does selection pay for itself?

After G4, run the existing detailed [performance protocol](../axiom-foundations-2026-10-15/performance/protocol.md). Main baseline: the best fixed feasible plan chosen on training. Additional comparisons: analytic selector, same-backend plans and SSA control where admitted, manual C and safe Rust under matched contracts, exact replay versus fresh planning. Materialization alone is an ablation. Use actual runtime inputs; literal-input correctness witnesses are not throughput programs.

Primary measurement: checked-call latency including mandatory range scan, necessary initialization/copies and cleanup. Internal kernel timing is a decomposition, not a replacement. State collection/validation occurs outside this interval with a matched cache/reset procedure; report its cost separately. Compiler/search/checking costs are separately observed and included in an application total whenever that application actually pays them.

The primary held-out endpoint is (W,H)=(2047,2049), seed65537, one fixed comparison. The current evaluator uses an exact median paired-improvement interval and threshold max(5%, pilot noise); even30–1024 balanced independent pairs. Choose sample count before held-out observation, justify sampling independence and report the actual coverage. Other shapes/seeds are separate workloads; do not pool them into an IID interval or infer a family-wide claim without a new statistical plan.

For additional compile cost ΔC>0 and observed per-invocation saving Δt>0, a descriptive break-even estimate is ceil(ΔC/Δt). Report the estimators and uncertainty; it is not a guaranteed invocation count. If Δt<=0 there is no amortization argument from runtime savings. Include negative results, resource/code growth and worst observed regressions.

### R6: Does the programmer abstraction generalize?

Only after G2/G3, add one source feature at a time with its own applicability and correctness rules. Candidate progression:

1. Multiple stages and shared consumers: exposes true last-use and recomputation choices.
2. Row/column orientation and layouts: separates schedule from storage and tests wide/thin cases.
3. Reductions or scans: forces explicit grouping, overflow and dependence semantics. Reordering is not inherited from scalar totality.
4. Dynamic shapes and buffer views: requires runtime shape/address proofs and genuine lifetime/alias contracts.
5. Floating point, concurrency or heterogeneous targets: separate semantic profiles with rounding/error, synchronization and target resource assumptions.

Do not count six shape variants of one stencil as six independent application domains. A full language paper should test varied source forms and realistic declarative tasks. Broader specification synthesis is a future research question, not something an optimizer flag automatically supplies.

## 6. Risk register and decision rules

| Risk | Early signal | Response |
|---|---|---|
| No defensible novelty | Closest work already offers the claimed composition | Reframe as an engineering report or identify a genuinely different theorem/constraint/problem. |
| Checker/planner share bugs | Expected expressions come from scheduling helpers | Enforce import boundaries, manual fixtures, independent source evaluation and corrupt-generator controls. |
| Syntax promises more than admission | Users write harmless variants rejected unexpectedly | Explicitly label v0 profile and return precise unsupported diagnostics; broaden only deliberately. |
| Unrolling explodes code/checking | Large sources, Core quota rejection, checker scaling | Keep v1 small; design plan-v2 rather than raise quotas blindly. |
| Storage claim is misleading | SSA staging evades the arena metric; copies/spills add further storage | Retain the valid control, name arena scope, measure abstract liveness separately and specify post-lowering accounting before strengthening the claim. |
| Native collector cannot measure required resources | Null/unavailable metrics persist | Keep v1 eligibility closed; use a separately reviewed exploratory profile if useful. |
| Selector adds no value | Fixed plan matches held-out performance | Simplify selection; publish null results or change workload based on a new frozen hypothesis. |
| Benchmark contamination | Holdout used for tuning after an unexpected result | Mark exploratory and create a new held-out study; preserve history. |
| Scope grows faster than evidence | Dynamic shapes/GPU/general solvers arrive before G2 | Return to one admitted feature and its complete contract. |

## 7. Effort, review cadence and collaboration

Use dependency gates as the schedule. For a single experienced implementer, a provisional planning allowance is 1–2 engineering weeks for G1 and another1–2 for G2, with scope corrections possible after the first compiled witness. These are estimates, not observed productivity or delivery commitments. G3 can develop alongside those milestones. G4 is an open research dependency and has no responsible fixed completion date until storage and measurement feasibility are established. Paper submission is gated by contribution/evidence, not a calendar promise.

Recommended implementation: one owner coordinates the tightly coupled Plan01 interfaces, with focused checker and correspondence reviews. This research revision used three independent agent assignments covering checker contracts, Core/evidence feasibility and contribution/prior art, followed by root source checks and focused re-reviews. They found the SSA control and concrete interface gaps; agreement alone is not experimental evidence. Parallel work owns separate artifacts and keeps interface changes coordinated.

For Gemini or another collaborator, hand off the exact design/source commit, hypothesis, artifact hashes, task boundary, acceptance tests and known limits. Ask for counterexamples to one claim or an independent related-work comparison. Keep answers as proposed evidence until checked; model agreement is not a correctness proof. No external model service has been contacted here.

## 8. Publication sequence

First create a private technical note with semantics, checker argument, implementation boundaries and reproducible conformance evidence. Use the [paper blueprint](paper-blueprint.md). Begin problem/related-work/method sections now; leave measured-result claims absent until data exists.

A workshop/tool demonstration may fit an early narrow artifact if its actual contribution and venue criteria match. A full compiler/language paper needs a defensible novelty argument and broader evidence. Current venue deadlines, policies, artifact expectations and simultaneous-submission rules have not been checked; choose a venue after the contribution is clear, then verify its current official requirements.

Before public release, prepare the actual manuscript/artifact and identify which Axiom details it discloses. The user's project is confidential; draft preparation is not publication authorization. Any later publication decision should concern that concrete package. Research can continue privately regardless.

Longer-term papers should arise from distinct established results—e.g. a scalable checking theorem, an enforceable post-lowering storage contract or a demonstrated language abstraction—not artificial subdivisions of the same three-plan experiment.

## 9. Reproducibility and current limitations

Retain exact source/toolchain/target identities, canonical source/plan/constraint/ranking hashes, all admitted/unknown/rejected results, complete semantic state, raw observations and analysis scripts. Source snapshots and paper access attempts are in `sources/`; failed lookups do not count as read sources. Comparison versions are explicit: the TVM examples are v0.14 historical interfaces, while several other sources are mutable main/master snapshots. No competitor ranking follows from that mixed-version inspection.

Current environment: Python supports the research probes; Clang was absent on PATH during inspection. No compiler build, installation, native benchmark, repository edit, commit or publication occurred. Direct arXiv retrieval of Souper/DaCe remains unavailable; three other full texts were retrieved through ordinary author/project GitHub copies with TLS verification. This is a deeper targeted review, not completed novelty research. Full Exo/Exo2, translation-validation and memory/recomputation comparisons and citation expansion remain gates before a novelty claim.

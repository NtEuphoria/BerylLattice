# Axiom paper blueprint and claim discipline

Working title: **Axiom: A Bounded Study of Independently Checked Physical Plans**.

This is a private research outline, not a manuscript with completed results. “Checked” is deliberately scoped; neither the full compiler nor native memory is currently proved correct/bounded. The novelty hypothesis remains open.

## Intended research question

Can a small independent final-plan checker make bounded implementation search useful and predictable for a declarative language with explicit hard constraints, without making the checker as complex as the optimizer?

Iteration2 narrows the immediate test: does a named physical resource relation and checking boundary provide a substantive auditability, enforcement or scaling benefit? The current three-plan ranking is analytic, and SSA staging defeats its implied arena/work tradeoff. These are findings to report, not exclusions to hide. Compare scoped Halide memory filters, weighted SyGuS and verified rewrite systems as actual antecedents; see the [full-text review](refinement/contribution-review.md).

Audience: programming-language/compiler researchers interested in semantic contracts, scheduling/storage and trustworthy optimization. The paper must make its theorem, supported domain and experimental boundary understandable without knowing Beryl or this conversation. Core is an implementation substrate, not an assumed contribution.

## Proposed structure and required evidence

| Section | Argument | Required artifact |
|---|---|---|
| Introduction | A concrete scheduling/storage choice with a hard constraint and inconclusive search | One source program and exact accepted/rejected/unknown outcomes; no invented motivating performance number. |
| Related work | Compare actual guarantees and mechanisms, not slogans | Full-text comparison of closest works, verified citations, unknown fields marked. |
| Language model | Equations, domains, exact arithmetic, boundary observations, constraints vs objectives | Grammar/profile, source semantics, unsupported examples. |
| Physical plans | Named arena and SSA lifetime are different resource scopes | Versioned schema, three plans, valid SSA control, ring invariant and malformed plans. |
| Checking and search | Conditional soundness and failure-safe incumbent selection | Formal statement/argument, checker work model, trusted-base diagram, timeout/cache cases. |
| Implementation | Exact prototype and Core bridge with preserved admission | Source commit, toolchain, code/provenance artifacts, actual supported cases. |
| Evaluation | Correctness controls, checker costs, usefulness and limits | Preregistered experiments, complete raw evidence, appropriate baselines and negative results. |
| Limitations | Small fixed domain, native trust, unrolling, resource scope and novelty limits | Explicit unsupported list and counterexamples to overbroad claims. |
| Conclusion | Only what the results establish | Traceable claim-to-evidence table. |

Do not write a results-bearing abstract in advance. A proposal abstract may state the question and planned method in future tense. A completed-paper abstract must be rewritten around actual findings; the architecture is not guaranteed to outperform anything.

## Planned figures and tables

1. Source → checked plan → Core diagram with trusted boundaries and evidence types.
2. One stencil shown as full, inline, circular-storage and SSA-staged plans; exact lifetime invariant and omitted-storage counterexample.
3. State machine separating semantic status, constraint status, check completion, derived eligibility, search stop and lowering outcome.
4. Negative-control table with actual counterexamples and distinct invalid/unknown outcomes.
5. Checker scaling versus source cells, plan operations and expression nodes; separate deterministic work and physical time/memory.
6. Native performance/resource plots only after qualification; full checked-call costs, analytic selector and training-selected fixed-plan baseline included.
7. Claim/evidence matrix covering full-state correctness, resource scope, native correspondence and novelty.

The initial 23,270-case mathematical probe can be a clearly labeled preliminary experiment. It must not be presented as 23,270 compiled programs, an exhaustive proof over all input values, or the future checker's evaluation.

## Related-work extraction form

For each close paper/software version record:

- Verified title, authors, year, venue/version, DOI/URL and exact inspected text.
- User specification and admitted computations; mathematical/finite-width/float semantics.
- Search space, grammar, schedule/storage representation and objectives.
- Semantic checks, hard resource properties, failure/timeout behavior and fallback.
- Proof scope and trusted components; whether checks cover final plans, rewrites or lowered code.
- Replay/cache identity and invalidation assumptions.
- Evaluated workload diversity, baseline strength, target/compiler versions and paid tuning costs.
- Exact overlap with Axiom, possible distinction, and what remains unknown.

Start with Halide/autoscheduling, Exo, TVM/Ansor/meta-scheduling, DaCe, Futhark, MLIR/Polly, SyGuS/cvc5, Souper and translation-validation literature. Expand through citations rather than claiming that this initial list is exhaustive. Software documentation and paper evidence are separate columns.

## Claim gates

| Wording | Minimum evidence |
|---|---|
| “Implemented” | Runnable code and actual interface receipts. |
| “Checked plan correctness” | Exact semantics/assumptions, checker and its conditional soundness argument; implementation/model distinction stated. |
| “Formally verified” | Mechanized theorem with audited assumptions and exact verified component; no extrapolation to unverified lowering. |
| “Respects hard workspace constraints” | The named plan/runtime scope and complete accounting at that scope. |
| “Faster” | Frozen meaningful comparison on stated target/workload with uncertainty and paid costs. |
| “Generalizes” | Distinct admitted source families and held-out evidence, not only more stencil dimensions. |
| “Novel” | Defensible full-text comparison against strongest antecedents. |

## Artifact capsule

Include build/run instructions, pinned source/toolchain identities, source programs, exact plans/check results, mutation fixtures, source oracle, semantic state, raw measurements, analysis scripts, manifests and licenses for distributed materials. Third-party cached source files are research inputs; check their licenses and distribute pointers or properly attributed permitted copies. A fresh reviewer must be able to distinguish a missing toolchain, unsupported case, failed semantic check and a measured regression.

Record actual model/tool use and human review responsibilities according to the eventual venue's verified policy. Do not invent model versions or treat model agreement as independent experimental evidence. Attribution and disclosure are manuscript preparation work; no external submission has been performed.

## Publication decision

G1/G2 alone may justify an internal technical report or a narrow tool artifact. A full paper requires a contribution stronger than assembling familiar components around one hand-picked stencil. If the mechanism is not novel or the selector gives no benefit, retain a useful language prototype and publish only the narrower result that the evidence supports, if appropriate. Decide public scope from the complete private manuscript and artifacts because Project Axiom is confidential.

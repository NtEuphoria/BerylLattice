# Proposed implementation refinements for Axiom v0

2026-10-15. Companion to the [foundation design](../axiom-foundations-2026-10-15/axiom-v0-design.md). These are concrete planning decisions for review, not implemented language features. They preserve the foundation's semantics and explicitly narrow implementation admission.

## Workspace and technology

Future local source root: `/workspace/BerylLattice/axiom/`, with a Python package `axiom`, standard-library `unittest`, fixtures and examples. Python minimum 3.12; no third-party dependency for the correctness prototype. The existing `/workspace/beryl` checkout is an external pinned compiler dependency, not vendored or renamed. No production Core change is needed for the first milestone. Research documents stay in this scratch package until the intended repository/disclosure boundary is settled. No push or publication is part of execution.

Use the existing isolated cloud checkout at implementation time. BerylLattice is currently unborn; no extra Git worktree is needed or requested. Preserve existing user changes and use disposable source snapshots outside the checkout for Core builds that regenerate tracked outputs. Do not manufacture remote history now.

## Provisional source syntax

One UTF-8 `.ax` file, at most 65,536 bytes. ASCII identifiers `[A-Za-z_][A-Za-z0-9_]*`; whitespace and `//` line comments; semicolons terminate declarations. No imports, strings, escapes, macros or execution during parsing. Preserve UTF-8 byte offsets for diagnostics even in comments. Reject NUL and invalid UTF-8. Integer tokens have at most ten decimal digits before conversion; optional unary minus is allowed only on literals, not as subtraction.

```text
module demo;
shape H = 5;
shape W = 7;
input image: i32[H+1,W+1] in 0..=1023;
let p[r in 0..H+1,c in 0..W+1] =
  (image[r,c]+1)*(image[r,c]+1);
output result[r in 0..H,c in 0..W] =
  ((p[r,c]+p[r,c+1])+p[r+1,c])+p[r+1,c+1];
require plan_workspace_bytes <= 64;
prefer multiplication_ops;
```

Only H and W shape constants are initially recognized, each positive, with `(H+1)*(W+1) <= 256`. All range upper bounds are exclusive except the explicitly inclusive input-value interval. Constant shape/index expressions admit identifiers, integer literals and `+`; scalar expressions admit integer literals, reads, `+`, `*` and parentheses, with multiplication precedence and left associativity. A comma separates the two axes. Expression nesting is limited to 32. No implicit halo or padding semantics.

Exactly one input, producer and output equation are required. Names and bound-axis names may vary; resolve identities and alpha-normalize before comparing to the canonical stencil. Preserve addition/multiplication grouping. Extra producers, alternative equivalent algebra, changed scalar constants/ranges and additional consumers are `UNSUPPORTED_PROFILE` after structural validation, not alleged semantic counterexamples. Syntax errors, duplicate names and undefined reads are invalid source. H/W outside the implementation profile are unsupported; nonpositive dimensions are invalid. A mathematically well-formed general DAG is not promised acceptance.

`require` is optional: omission means no plan-workspace cap. A supplied cap is a nonnegative integer at most 2^31-1. Unknown hard-property names return `UNSUPPORTED_CONSTRAINT`; do not ignore them. `prefer` is optional, default `multiplication_ops`; the other supported value is `plan_workspace_bytes`. These are exact abstract objectives, not estimated latency. The selection key is the requested quantity, then the other quantity, then the stable plan ID. Runtime-tuned objectives need a future versioned contract.

The parser may decode broader expressions for diagnostics, but admission only yields the canonical `AdmittedKernel`. The original source AST remains available to an independent source evaluator. Do not replace the oracle with a call to a schedule generator.

## Immutable records and module boundaries

Public records are frozen dataclasses with tuples, enums and exact integers. Reject bool where an integer is expected. No public success bit is treated as a proof. Canonical JSON uses UTF-8, sorted keys, compact separators and no NaN/floats. Reject duplicate keys, unknown fields, wrong types, unknown versions and values outside decoder quotas before constructing executable objects. SHA-256 identifies exact canonical bytes; it does not prove semantics.

| Type | Required fields |
|---|---|
| `SourceModule` | source bytes/hash; module name; H/W declarations; input/producer/output ASTs; spans; cap; objective. |
| `AdmittedKernel` | source snapshot hash; canonical semantic hash; H/W; input interval [0,1023]; canonical source expressions; cap; objective; semantic version. |
| `Plan` | format version 1; semantic hash; stable plan ID; scratch capacity in cells; ordered operation tuple. |
| `Operation` | opcode plus typed operands and source-origin IDs; result SSA ID when applicable. |
| `Limits` | `source_bytes=65536`, `plan_bytes=2097152`, `plan_operations=20000`, `expression_nodes=100000`, `check_steps=100000`; all positive, independently scoped. |
| `CheckResult` | semantic status valid/invalid/unknown; constraint status satisfied/violated/unknown; check_complete; reason; first witness if available; workspace_bytes; multiplication_ops and opcode_counts (null until complete operation scan); work_used; source/plan/checker identities; effective_cap and constraint_digest. |
| `ExecutionResult` | success or input-precondition failure; first invalid linear index or null; complete output tuple; unchanged input tuple. |
| `SearchResult` | all attempt records; termination reason; selected_plan, selected_plan_bytes and selected_check (all null or mutually matching); objective/key; budget accounting version. |
| `ReplayManifest` | schema version; exact source/plan hashes; semantic/constraint/ranking hashes; semantics/plan/checker/accounting versions; original effective cap; saved check record. |
| `CoreBundle` | artifact_kind=core_witness_source; generated `.be` bytes/hash; provenance; logical/plan/emitter identities; case identity; observation layout. A kernel-only source artifact has a distinct kind and no executable-entry claim. |

`SourceModule`, `AdmittedKernel`, errors and enums live in `model.py`; `Plan`/`Operation` in `plan_format.py`; result records live with their owner modules and are imported by name, not duplicated. Serialization has one versioned specification in `codec.py`. The test oracle does not import the planner, plan checker or Core emitter. The checker does not import the planner.

The semantic hash covers normalized equations, shapes, arithmetic and boundary assumptions, but excludes names, formatting, constraints and objectives. Source snapshot, constraint-set and ranking-policy hashes are separate and all appear in the attempt record. A command-line/replay cap is an **additional** constraint: effective cap is the minimum of all supplied caps, treating absent caps as unbounded. An override can never weaken the source's hard constraint. A null replay cap means no additional constraint, not permission to erase the source cap.

`check_plan(kernel, plan, limits, *, additional_cap=None)` explicitly consumes that context. It records effective_cap and constraint_digest over the versioned property, source cap, additional cap and effective cap. Replay passes its cap through this same interface; a saved CheckResult for cap64 cannot stand for a fresh check under cap0. Do not mutate source-derived kernel fields to conceal the override. In-memory Plan/Operation objects receive the same structural validation as decoded plans at the checker boundary, including exact integer types, field/opcode shapes, bounds and SSA ordering; planner construction is not privileged.

Status enums use `StrEnum` with the literal lowercase values above; Objective has values `multiplication_ops` and `plan_workspace_bytes`. `multiplication_ops` is the count of every `mul` opcode in the finite stream, including dead or extra multiplication. No producer-expression classifier is involved. This replaces iteration 1's producer-evaluation metric; on the three generators they coincide, but arbitrary plans need not. It is not total arithmetic, latency or energy.

Eligibility is a derived predicate: `check_complete and semantic_status == 'valid' and constraint_status == 'satisfied'`. A known arena-cap fact can be satisfied while semantics is unknown. `workspace_bytes` may be known from a validated header before checking finishes; whole-plan `multiplication_ops` and `opcode_counts` are null until a full operation scan completes. Partial counters belong in explicitly labeled progress diagnostics. An exhausted check never has `check_complete=true` or semantic-valid. A concrete well-formedness or arithmetic witness can establish invalidity before completion; absence of that witness does not establish validity.

## Physical plan v1

The first format is a finite **unrolled** operation stream for fixed small shapes, not the future scalable loop IR. Allowed operations are `const(dst,value)`, `input_load(dst,index)`, `add(dst,a,b)`, `mul(dst,a,b)`, `scratch_store(index,value_id)`, `scratch_load(dst,index)` and `output_store(index,value_id)`. Index operands are explicit nonnegative integer constants. SSA result IDs are distinct dense nonnegative integers in definition order; reads must refer to earlier definitions. There are no branches, loops, calls, input stores, hidden buffers or output reads.

The only scratch arena is contiguous i32 cells with four-byte alignment. Workspace bytes are exactly `4*scratch_capacity_cells`, including unused reserved cells. This property counts only that arena: SSA values, registers, spills, input/output and backend storage are excluded. Decode capacity as a nonnegative integer no larger than 2^31-1. The symbolic checker uses a sparse map keyed by touched slots, never an allocation proportional to declared capacity. An interpreter/backend may impose a separate execution limit and return unsupported before allocation even when the symbolic cap check succeeds. Every scratch access is within its declared capacity. Empty scratch is legal; reads require initialization. Output indices are in `[0,H*W)` and each must be written exactly once. The checker validates actual operations; plan IDs are labels, not admission shortcuts. No arena overlaps input/output.

The planner expands the three specified schedules into this format. Producer occurrences use one input load, `z=input+1`, and `z*z`; source grouping is retained in consumer additions. A single common constant register is allowed. The checker constructs full symbolic scalar expression DAGs from individual input symbols, not opaque producer tokens. It propagates node intervals and compares each output with a separately constructed source expression. Hash-consing may accelerate exact structural equality but cannot introduce algebraic rewrites. A structurally unequal yet unrefuted expression is unknown.

The checker must also accept a manually authored **SSA-staged control**: compute every producer into a retained SSA value, then consume those values with no scratch. It has `(H+1)(W+1)` multiplications and zero arena bytes, dominating the three-generator portfolio under these two metrics except ties. Do not reject it for lacking a known plan ID. Keep it outside the frozen three-generator selector as an adversarial positive control; any optimality statement is only over the named portfolio. A diagnostic last-use analysis may report live scalar counts, but creates no new hard memory guarantee. See [resource study](refinement/resource-contract-research.md).

This representation trades code size for checker simplicity. Structured loops change the invariant and complexity obligations, not just the encoding. There is no all-shape template theorem. Every fixed specialization is checked independently. Source generation may exceed Core quotas; report unsupported admission instead of increasing them. A future plan-v2 loop representation requires a new design and checking argument before native throughput experiments.

## Boundary, search and replay

Reference invocation uses owned Python tuples/lists with valid lengths; it cannot certify foreign memory. Public `evaluate_source` first admits its SourceModule, then evaluates the retained original AST; syntactically valid unsupported source cannot bypass the profile through `eval`. Input must remain stable and output must be disjoint. Scan input row-major, rejecting first value outside [0,1023] before entering the scalar kernel or changing output. Return the unchanged caller output on rejection. Static plan construction/checking need not wait for runtime input. Do not expose an unchecked public execution entry. The internal scalar-plan interpreter is test infrastructure, not a public bypass or native throughput path.

Candidate order is `inline-v1`, `rows2-v1`, `materialize-v1`. Charge one `check_steps` unit before each source-AST node visit constructing expected expressions, each physical operation, and each node-pair visit in exact comparison. Repeated conceptual visits cost the same even if memoized. Source parsing/admission, decoding, plan generation, allocation, hashing and physical CPU time are outside this counter; their separate byte/node/operation quotas and operational deadlines still apply. This is deterministic **checker work**, not a total compiler-time bound. Version the accounting and do not use an uncharged producer classifier. Build expression DAGs without recursive expansion; compare with an iterative traversal so a long well-decoded chain cannot bypass the quota through stack exhaustion.

`select_plan(kernel, limits, total_check_steps, objective, optional_check_steps=None)` uses the total allowance for every checker call, including the initial inline candidate. After a completed eligible initial candidate, further checking is also bounded by the optional allowance; null means no additional limit and zero means stop after that incumbent. Unless the initial inline candidate is eligible, stop with no artifact and its precise failure/unknown reason. No reserve is silently waived or invented. Per-call `limits.check_steps` remains an additional bound. The objective argument must match `kernel.objective`; policy changes require a new admitted request. Search may return a previously fully eligible incumbent after later exhaustion. No candidate mutates a previously checked plan. Search failure under a budget is not constraint infeasibility: every nonnegative arena cap permits a correct inline plan if checking completes.

For H=5,W=7 and objective multiplication_ops: cap 0 selects inline; cap 64 selects rows2; uncapped selects rows2 because it ties full materialization's producer count with less workspace. This is an abstract ranking, not a latency prediction. For objective plan_workspace_bytes, inline wins. For H=W=1, producer counts tie and inline wins on workspace.

Exact replay is `replay(source, plan_bytes, manifest_bytes, limits, cap) -> CheckResult`. Strictly decode the ReplayManifest, verify the exact source/plan hashes and supported versions, rerun source admission and full checking, and recompute effective constraints. A whitespace-only source change fails exact replay even if its semantic hash is unchanged; checking that new source is a distinct fresh operation. A mismatched checker/accounting version is an unsupported replay, not a reused proof. Invalid manifest identity yields a typed diagnostic before any success record. A new additional cap can tighten the source constraint, with the original cap retained as history; it never reuses previous eligibility. Ranking-policy changes require fresh selection, not plan replay. A successful replay checks one plan, with no optimality claim. No proof-cache reuse, incremental edit reuse or runtime autotuning in v0.

The valid-input plan theorem is separate from the boundary-wrapper lemma. The wrapper scans the entire input, returns the first invalid index and preserves the original output on rejection; only then may it enter a checked body. `check_plan` contains no preflight opcodes and cannot alone prove rejection behavior. The composed checked entry and the native emitter must satisfy both obligations.

## Core and observation contract

Generated sources use the existing complete Core driver and preserve its spans. H5/W7 adapter: input `[i32;48]`, separate initialized `inout` output `[i32;35]`, return i32 -1 on success or first failing input index 0..47. Other shapes specialize lengths and index bounds. Scratch arrays are initialized as required by Core. Those additional initializations/copies are recorded separately from the plan arena claim.

Generate a single isolated test witness per shape/input/plan as needed to remain within quotas. Scalar-print status, every input element and every output element in that fixed order. No checksum-only comparison. Expected observations come from the independent source evaluator. Different plans have different generated spans; compare Axiom values/status across plans, while preserving Core's own exact event comparison within each generated source.

The driver must reread or retain immutable source/plan bytes through emission and recheck before accepting an externally supplied `CheckResult`. Write artifacts via temporary files and atomic replacement; interrupted work cannot leave an accepted manifest pointing to missing or different bytes. Record source, plan, emitter, compiler, runtime/toolchain, flags and executable identities. This is traceability, not end-to-end formal verification.

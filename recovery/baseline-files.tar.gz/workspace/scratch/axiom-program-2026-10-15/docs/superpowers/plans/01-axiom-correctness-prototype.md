# Axiom Correctness Prototype Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking. Native execution is recommended for this first tightly coupled prototype; no implementation is authorized by this planning document alone.

**Goal:** Parse one declarative stencil family, independently check three physical plans, select only eligible plans and replay exact evidence.

**Architecture:** Python owns a small source AST, independent source evaluator and immutable explicit physical plans. A checker reconstructs expressions and storage facts from actual operations; the planner is outside its trust boundary. Core lowering is the next plan, not a dependency of this executable correctness prototype.

**Tech Stack:** Python 3.12+, standard library, `unittest`, deterministic canonical JSON and SHA-256.

**Spec:** [Prototype contract](../../../prototype-contract.md), implementing the [foundation design](../../../../axiom-foundations-2026-10-15/axiom-v0-design.md).

## Global Constraints

- Axiom is the distinct language; Core's source repository remains unchanged in this plan.
- One canonical two-stage stencil; input [H+1,W+1], output [H,W], H/W positive and input cells <=256.
- Input interval [0,1023]; exact i32 per scalar node; output range [4,4194304].
- Preflight scans row-major before plan computation/output writes; failure preserves complete output and first invalid index.
- `plan_workspace_bytes` counts reserved intermediate arena bytes; it is not native memory.
- Formats and checkers are versioned; unknown, unsupported and invalid are distinct.
- Limits: source bytes 65536; plan bytes 2097152; plan operations 20000; expression nodes 100000; check steps 100000 by default.
- No solver, learned model, third-party package, general DAG lowering, unchecked public entry or public release.
- Tests and diagnostics must work under Python `-O`; product checks use explicit conditions, not `assert` statements.

## Review Focus

- UTF-8 comments before an error: byte offsets must identify the actual source bytes; Task 1.
- JSON duplicate keys, booleans masquerading as integers and oversized integer tokens: reject before execution; Task 3.
- A valid but structurally different expression: return unknown rather than false inequivalence; Task 4.
- Exhaustion immediately after a valid incumbent and stale cap on replay: preserve only independently eligible artifacts; Tasks 6–7.
- Additional reserved but unused scratch: account for it and reject a violated cap; Task 4.

## Files and boundaries

All implementation paths below are relative to future `/workspace/BerylLattice/axiom/`. Do not create them during research planning.

```text
src/axiom/model.py          source records, spans, diagnostics and limits
src/axiom/frontend.py       lexer/parser and canonical profile admission
src/axiom/reference.py      source-AST evaluation and checked boundary
src/axiom/plan_format.py    immutable plan and operation types
src/axiom/codec.py          strict versioned decoding/canonical encoding
src/axiom/checker.py        independent symbolic/storage/range checker
src/axiom/planner.py        three physical plan constructors
src/axiom/selection.py      budgets, ranking and incumbent state
src/axiom/evidence.py       exact replay and atomic artifact publication
src/axiom/__main__.py       CLI, no duplicated compiler logic
tests/test_*.py             tests owned by the corresponding tasks
tests/fixtures/            source/plan/negative-control artifacts
examples/stencil.ax        the contract's H5/W7 example
docs/prototype.md           exact supported contract and commands
```

Run commands from this future root with `PYTHONPATH=src`. Each task ends with a local commit of only its named files after checking the diff. Do not push. If the checkout is still unborn, create its first local commit only when implementation begins; follow the workspace skill then. Keep generated receipts outside tracked source unless deliberately small fixtures.

### Task 1: Source parsing and exact profile admission

**Files:** Create `src/axiom/__init__.py`, `model.py`, `frontend.py`, `examples/stencil.ax`, `tests/__init__.py`, `tests/helpers.py`, `tests/test_frontend.py`, `tests/fixtures/source/invalid_utf8.ax` and `tests/fixtures/source/extra_producer.ax`.

**Interfaces:** `parse_source(data: bytes) -> SourceModule`; `admit_source(module: SourceModule) -> AdmittedKernel`. Invalid/unsupported input raises `DiagnosticError(code: str, span: Span, message: str)`; Span stores byte offset/length. Define all source records, objective enums, `Limits`, and typed expression variants here according to the contract. Other modules do not reparse source text.

- [ ] Write `test_canonical_and_alpha_renamed_stencil`, asserting H/W=5/7, input interval=(0,1023), cap=64, objective=`producer_evaluations`, and equal semantic hashes after identifier renaming but distinct snapshot hashes.
- [ ] Define test-only `stencil_source(h: int, w: int, cap: int | None=64, objective: str='producer_evaluations') -> bytes` in `tests/helpers.py`, rendering only the contract's literal source template. It must not import planner/checker/emitter. Pin the admission assertions:

```python
k = admit_source(parse_source(stencil_source(5, 7, 64)))
assert (k.height, k.width, k.cap) == (5, 7, 64)
assert k.input_interval == (0, 1023)
assert k.objective == 'producer_evaluations'
```

Use exact AdmittedKernel field names `height`, `width`, `cap`, `input_interval`, `objective`, `source_digest`, `semantic_digest`, `source_expressions`, `semantics_version` in all tasks.
- [ ] Write `test_byte_spans_after_utf8_comment`, duplicate/undefined-name, range-bound, expression-depth, huge-token, invalid-UTF8 and NUL tests. A valid extra producer, changed square constant or reassociated source expression must return `UNSUPPORTED_PROFILE`; nonpositive H/W is `INVALID_SHAPE`.
- [ ] Run `PYTHONPATH=src python -m unittest tests.test_frontend -v`; confirm tests fail for the missing interface, not accidental fixture errors.
- [ ] Implement bounded lexing/parsing and exact canonical-profile recognition, preserving source grouping. Define normalization explicitly: declaration/axis identity renaming only; no algebraic normalization or arbitrary constant propagation.
- [ ] Run the same command normally and with `python -O`; both must pass. Commit as `feat(axiom): parse and admit the bounded stencil source`.

### Task 2: Independent source evaluator and failure observations

**Files:** Create `reference.py`, `tests/test_reference.py`, `tests/fixtures/inputs/`.

**Interfaces:** Consume SourceModule/AdmittedKernel from Task 1. Produce `evaluate_source(module: SourceModule, data: tuple[int,...], initial_output: tuple[int,...]) -> ExecutionResult`. Define ExecutionResult with status, first_bad_index, output and input_after. Evaluate the source AST mathematically; do not import planner/checker/plan_format.

- [ ] Write tests with exact results: H=W=1/all-zero input gives `(4,)`; all-1023 gives `(4194304,)`; input `(0,0,0,1)` gives `(7,)`. Verify H5/W7 coordinate-sensitive data against a separately written four-neighbor formula in the tests.
- [ ] Write `test_preflight_first_failure_preserves_destination`: data `(1024,-1,0,0)`, destination `(-777,)`, first bad index 0 and unchanged destination. Reject float/bool elements and wrong extents with typed boundary diagnostics; typed buffers do not promise foreign-pointer checking.

```python
m = parse_source(stencil_source(1, 1))
r = evaluate_source(m, (1024, -1, 0, 0), (-777,))
assert r.status == 'input_precondition_failed'
assert r.first_bad_index == 0
assert r.output == (-777,)
```
- [ ] Run `PYTHONPATH=src python -m unittest tests.test_reference -v` and observe the expected missing-interface failure.
- [ ] Implement source-AST evaluation using Python integers and explicit i32 node checks. Enforce complete preflight before evaluating any equation; instrument a test-only evaluation callback to assert zero equation visits on rejection.
- [ ] Run tests and import-dependency assertions; commit as `feat(axiom): add an independent checked source evaluator`.

### Task 3: Versioned physical-plan format and strict codec

**Files:** Create `plan_format.py`, `codec.py`, `tests/test_codec.py`, `tests/fixtures/plans/`.

**Interfaces:** Define Plan/Operation as in the contract. Produce `encode_plan(plan: Plan) -> bytes`, `decode_plan(data: bytes, limits: Limits) -> Plan`, `plan_digest(plan: Plan) -> str`. Decode errors carry code/field path and never return a partial Plan. Canonical source/receipt serialization uses the same primitive encoding policy but separate schemas.

- [ ] Write round-trip/canonical-byte tests for a manually authored inline 1×1 plan. Reordered JSON object keys canonicalize identically; operation order remains significant.
- [ ] Write `test_duplicate_keys_and_bool_indices_rejected`, unknown field/op/version, float/NaN, negative index/capacity, oversized file/operation count and overlong integer token tests. Parse limits apply before integer conversion and before accumulating unbounded containers.
- [ ] Run `PYTHONPATH=src python -m unittest tests.test_codec -v`; observe missing codec failure.
- [ ] Implement explicit type/shape/size validation and canonical encoding. Do not execute source expressions during decoding; do not deserialize Python objects or use pickle/eval.
- [ ] Run normally and with `-O`; commit as `feat(axiom): define strict physical plan artifacts`.

### Task 4: Independent final-plan checker

**Files:** Create `checker.py`, `tests/test_checker.py`, manually authored positive/negative plan fixtures.

**Interfaces:** `check_plan(kernel: AdmittedKernel, plan: Plan, limits: Limits) -> CheckResult`. Define CheckResult fields named `semantic_status`, `hard_status`, `reason`, `witness`, `workspace_bytes`, `producer_evaluations`, `opcode_counts`, `work_used`, `source_digest`, `plan_digest`, `checker_version`. No planner import. `check_steps` is a deterministic total allowance for this call.

- [ ] Author a valid 1×1 inline plan without a planner. Assert semantic valid, hard eligible, workspace 0 and output expressions matching the four source cells.
- [ ] Add fixtures for scratch read before write, overwritten live row, wrong input/output index, duplicate/missing output, undefined/redefined SSA register, bad semantic digest, extra reserved scratch, unknown operation and unsafe transformed arithmetic. Invalid requires a concrete violated condition/witness; supported structural mismatch without refutation is unknown.
- [ ] Add `test_extra_reserved_cells_count`: a semantically correct plan with 17 reserved scratch cells under cap64 is hard-inadmissible with workspace68, even if only16 cells are touched. Add a safe equivalent altered expression whose exact tree differs and require unknown.
- [ ] Run `PYTHONPATH=src python -m unittest tests.test_checker -v`; confirm failure before implementing.
- [ ] Implement symbolic execution of actual operations: track initialized scratch expressions and ranges, SSA definitions, complete output coverage and reserved capacity. Construct expected source expressions independently from the admitted source AST. Check i32 bounds per operation using intervals; an inconclusive interval is unknown unless a real witness exists.
- [ ] Define work accounting version1: charge one step before each source-AST node visit used to construct an expected output, each physical operation and each node-pair visit in structural comparison. Count repeated visits even if memoized; expression-node allocation has its separate quota. Exhaustion cannot produce valid/eligible. Include constructor/decoder quotas separately in the receipt.
- [ ] Run normal/`-O` tests, including each quota boundary and the import isolation test; commit as `feat(axiom): independently check physical plan semantics and storage`.

### Task 5: Three generators and positive/negative conformance

**Files:** Create `planner.py`, `tests/test_planner.py`, `tests/test_conformance.py`.

**Interfaces:** `make_plan(kernel: AdmittedKernel, plan_id: str) -> Plan`; supported IDs exactly `inline-v1`, `rows2-v1`, `materialize-v1`. Use plan types/codec; no calls into checker internals or source oracle implementation.

- [ ] Write tests asserting H5/W7 workspace capacities 0/16/48 cells and producer occurrences140/48/48. Check output correctness through Task4 and independent numeric interpretation in tests; do not let the planner manufacture its own expected values.

```python
k = admit_source(parse_source(stencil_source(5, 7, None)))
expected = {'inline-v1': (0, 140), 'rows2-v1': (64, 48),
            'materialize-v1': (192, 48)}
for name, counts in expected.items():
    checked = check_plan(k, make_plan(k, name), Limits())
    assert checked.semantic_status == 'valid'
    assert checked.hard_status == 'eligible'
    assert (checked.workspace_bytes, checked.producer_evaluations) == counts
```
- [ ] Write mutations of the serialized operation stream for wrong neighbor, one-row alias and early overwrite. Require checker invalid/unknown as justified and retain actual numeric counterexamples from the independent source evaluator where available. A mutation that is semantically equivalent must not be mislabeled invalid.
- [ ] Run `PYTHONPATH=src python -m unittest tests.test_planner tests.test_conformance -v`; observe missing generators.
- [ ] Implement exact fixed-shape expansion of the three schedules. Ring refill occurs only after the entire consuming row; all scratch capacity is explicit. Count producer work from actual operations/realizations and independently verify the count in tests; do not trust a planner-supplied cost field during selection.
- [ ] Run edge shapes `(1,1),(1,7),(7,1),(2,3),(3,2),(5,7),(15,15),(1,127),(127,1)` subject to actual limits. Exhaust {0,1,1023} for the four tiny shapes and 32 seeded cases per H/W in1..8. Preserve counts separately from the old probe's receipt.
- [ ] Commit as `feat(axiom): generate and validate the three stencil schedules`.

### Task 6: Selection, deterministic budgets and interruption

**Files:** Create `selection.py`, `tests/test_selection.py`.

**Interfaces:** `select_plan(kernel: AdmittedKernel, limits: Limits, total_check_steps: int, objective: Objective) -> SearchResult`. Define SearchResult and attempt records. Search uses fixed candidate order, fresh checking and derived objective quantities; no timing objective in v0.

- [ ] Write selection assertions: H5/W7 cap0→inline, cap64→rows2, uncapped→rows2 for producer objective; workspace objective→inline; H1/W1→inline. Changing plan labels cannot change computed legality.

```python
for cap, name in [(0, 'inline-v1'), (64, 'rows2-v1'), (None, 'rows2-v1')]:
    k = admit_source(parse_source(stencil_source(5, 7, cap)))
    r = select_plan(k, Limits(), 100000, k.objective)
    assert r.selected_plan is not None
    assert r.selected_plan.plan_id == name
```
- [ ] Write zero-total-budget/no-artifact; exact inline-check-budget/eligible-inline plus exhaustion; later candidate failure; checker exception; cancellation before/after committed incumbent; full materialization violating cap64. Runtime cancellation is not a reproducibility promise.
- [ ] Run `PYTHONPATH=src python -m unittest tests.test_selection -v` and observe missing selection.
- [ ] Implement state transitions with distinct validity, eligibility, search-stop and artifact states. Charge all checking against total allowance; never waive incumbent admission. Rank only eligible candidates by objective, secondary quantity and stable ID. Unknown candidates prevent a conclusive portfolio-infeasible label.
- [ ] Run tests with repeated warm/cold executions and stable work receipts; commit as `feat(axiom): select eligible plans under explicit work budgets`.

### Task 7: Exact replay, evidence publication and CLI

**Files:** Create `evidence.py`, `__main__.py`, `tests/test_evidence.py`, `tests/test_cli.py`, `docs/prototype.md`.

**Interfaces:** `write_attempt(directory: Path, module: SourceModule, result: SearchResult) -> Path`; `replay(source: bytes, plan_bytes: bytes, limits: Limits, cap: int | None) -> CheckResult`. Output manifest binds exact bytes and completed checks. No executable build yet.

- [ ] Write tampered source/plan/checker-version, stale cap64→0, truncated/duplicate-key cache, interrupted write and replaced-file tests. A saved unknown result is attempt history, not a permanent negative cache entry. Exact replay rechecks rather than trusting serialized validity.
- [ ] Assert that source cap64 plus replay cap192 or null still has effective cap64. A command-line override cannot weaken a hard source requirement.
- [ ] Write CLI tests for `check SOURCE`, `plan SOURCE --out DIR --check-steps N`, `replay SOURCE PLAN`, and `eval SOURCE --input INPUT_JSON --output-initial OUTPUT_JSON`. Exit codes:0 completed success;2 invalid input/source;3 unsupported;4 no eligible plan established;5 infrastructure failure;6 runtime precondition rejection. JSON output includes the more precise statuses. No plan/receipt is advertised accepted before its files exist with matching hashes.
- [ ] Run `PYTHONPATH=src python -m unittest tests.test_evidence tests.test_cli -v`; observe missing implementation.
- [ ] Implement canonical manifests, atomic replacement and immutable byte retention; shell commands are not evaluated. Before later emission, the adapter must recheck the exact source/plan. Include all assumptions and accounting versions in records.
- [ ] Run the full suite `PYTHONPATH=src python -m unittest discover -s tests -v`, repeat the externally reachable decoder/checker/CLI tests with `-O`, and run the H5/W7 example through plan/replay. Commit as `feat(axiom): expose checked planning and exact replay`.

## Completion and review gate

The deliverable is a runnable correctness prototype, complete receipts and a reviewed checker argument—not native Axiom code or a speedup. Review the parser/admission, symbolic semantics, work accounting and exact artifact binding together. List every trusted component. Compare the new implementation's results against the old probe but do not inherit its PASS status. Move to Plan02 only when positive cases, concrete negative controls and fail-closed unknown paths pass. Preserve a useful prototype even if Core integration is subsequently unsupported.

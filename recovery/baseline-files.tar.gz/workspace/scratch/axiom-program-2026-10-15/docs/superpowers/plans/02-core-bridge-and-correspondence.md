# Axiom Core Bridge Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Produce actual Core programs from checked Axiom plans and compare their complete observations with the independent Axiom source evaluator.

**Architecture:** A source emitter consumes immutable checked plan bytes, generates an ordinary `.be` kernel plus isolated witness, and retains byte-level provenance. A process adapter invokes the pinned Core compiler through existing admission. Production AST and experimental IR differential paths remain separate result lanes.

**Tech Stack:** Plan01 Python package, Beryl commit `0a678b4ae6d41190c4f5a8bf063caba05759d20d`, C11/Clang, existing Core CLI, standard-library subprocess and hashing.

**Spec:** [Prototype contract](../../../prototype-contract.md), [Core interface](../../../../axiom-foundations-2026-10-15/core-interface/interface-decision.md), [observer contract](../../../../axiom-foundations-2026-10-15/core-interface/observer-contract.md).

## Global Constraints

- Plan01 must pass first. All source/plan bytes are rechecked before emission; an externally supplied success record is insufficient.
- Existing complete Core frontend admission is mandatory. Do not directly populate typed AST or call IR C emission to bypass gates.
- H5/W7: input48/output35; return -1 success or first invalid input index; output is separate and initialized.
- Every input and output scalar plus status is observed. Different plan source offsets are not compared as if they were identical Core events.
- IR keeps 256 cells per aggregate, 64-KiB declared-storage estimate and fixed native execution budgets.
- No throughput claim, new native ABI, raw-pointer interface, Core limit increase or benchmark-collector repair in this plan.
- Record compiler/Clang binaries, known toolchain components and exact argv; unobserved SDK/linker dependencies remain explicit limits. Missing Clang is unavailable, not a passed test.

## Review Focus

- A compiler path containing spaces: argument lists preserve it and receipts capture the actual executable; Task1/3.
- Input failure at the last element: all output remains sentinel-valued and first invalid index is exact; Task2/4.
- A source generator defect shared by both Core lanes: independent Axiom observations catch it; Task4.
- Unsupported Core lowering or process timeout: unavailable/error stays distinct from semantic mismatch; Task3.
- Old schema-4 experimental helper docs: do not apply them as commands for current schema5; Task1.

## File map and shared interfaces

Paths relative to future `/workspace/BerylLattice/axiom/`:

```text
src/axiom/core_toolchain.py    identity/preflight and isolated Core build receipts
src/axiom/core_emit.py         source and provenance generation
src/axiom/core_runner.py       process isolation, output capture, result classification
src/axiom/core_observe.py      complete scalar observation decoding
tests/test_core_*.py           unit/protocol/negative controls
tests/integration/             actual compiler correspondence cases
docs/core-bridge.md            supported commands, limitations and receipts
```

Result records live in the owning module. `Toolchain` holds absolute compiler/Clang paths and hashes, Core source identity, version stdout and build receipts. `NativeRun` holds lane, argv, outer returncode, Core-reported subprocess status/code, stage/whole-run timeout and cleanup status, stdout/stderr paths/hashes, result/job paths and classification. Core folds native signals into 128+signal, which is ambiguous with an ordinary exit code; an exact native signal is unavailable unless separately observed. `Observation` holds status, input tuple and output tuple. Failed/partial runs retain diagnostics without advertising conformance.

### Task 1: Toolchain preflight and reproducible isolated build

**Files:** Create `core_toolchain.py`, `tests/test_core_toolchain.py`, `docs/core-bridge.md`.

**Interfaces:** `inspect_toolchain(core_source: Path, clang: Path) -> ToolchainPreflight`; `build_core(snapshot: Path, clang: Path, output: Path) -> Toolchain`. No default search that silently selects a different Clang. Use a disposable copy of the pinned source outside the existing checkout, with inventories before/after; no extra Git worktree is needed. Record expected build-generated headers separately.

- [ ] Test missing executable, nonzero version probe, different source commit, dirty source inventory, paths with spaces and unsuccessful compile/run. Failures must be unavailable/error, with no success receipt.
- [ ] Run `PYTHONPATH=src python -m unittest tests.test_core_toolchain -v`; confirm missing implementation failure.
- [ ] Implement identity capture and isolated build using the existing `scripts/build.sh --debug` and `scripts/test.sh`. Both scripts name `clang`; expose the selected executable as `clang` in a private PATH directory and record the resolved target. Do not change global alternatives or edit Core scripts.
- [ ] At execution time obtain a normal supported Clang installation if absent; record exact version/binary and source of installation. No exact package build is invented in this plan. Native results remain unavailable until the tool exists and its C11 compile/run preflight succeeds.
- [ ] In the isolated snapshot, run `bash scripts/build.sh --debug`, then `bash scripts/test.sh`, with the private PATH. Expected: actual compiler version probe/build and unit suite succeed. Record generated runtime-header changes; any source difference outside expected regeneration blocks pinning the build as the inspected commit until reconciled.
- [ ] Qualify the requested native-evidence flags with an actual tiny witness: C11 compilation alone does not prove LLVM IR, assembly and driver-job captures work. Distinguish binary-byte hashes from Core's path-sensitive loaded-source fingerprints; do not demand equal source-manifest hashes across arbitrary output directories.
- [ ] Verify current schema5 source, not the historical schema4 `tools/beryl-ir-experiments/README.md` protocol. Commit only Axiom toolchain adapter/tests/docs as `feat(axiom): pin and probe the Core toolchain`.

### Task 2: Core source emission and provenance

**Files:** Create `core_emit.py`, `tests/test_core_emit.py`.

**Interfaces:** `emit_core(source: bytes, plan_bytes: bytes, limits: Limits, data: tuple[int,...], initial_output: tuple[int,...]) -> CoreBundle`. It parses/admit/checks exact bytes internally. CoreBundle has artifact_kind `core_witness_source`, source bytes/hash, mapping entries, logical/plan/emitter identities, exact case identity and observation layout. A kernel-only artifact is distinct (`core_kernel_source`) and has no native executable-entry claim. Fixed-case binaries are `core_witness_executable`, never a reusable Axiom ABI.

- [ ] Write source-inspection tests asserting the H5/W7 signature, -1 success, returned first invalid index, complete preflight preceding stores/computation, whole-array scratch initialization, checked arithmetic and deterministic scalar observation order.
- [ ] Pin one minimal complete hand-reviewed witness source and expected scalar observation before implementing the emitter. A literal-input witness is for correspondence; do not reuse it as a runtime performance workload that might be constant folded.
- [ ] Write stale/tampered plan, source-span bounds and unknown-operation tests. Every mapping references actual generated byte ranges and valid Axiom origins; synthetic wrapper/initialization operations have explicit roles.
- [ ] Run `PYTHONPATH=src python -m unittest tests.test_core_emit -v`; observe missing emitter failure.
- [ ] Implement direct translation of each validated unrolled operation into named scalar Core statements. Generate static element accesses and no extra calls/effects. Initialize arrays according to existing Core syntax and admission. Emit a standalone test block with runtime function call, status, all input and output values printed in fixed order.
- [ ] Check generated bytes are stable and mappings support repeated origins. Test canonical source→plan→source identities even if plan names are altered. Commit as `feat(axiom): lower checked plans through Core source`.

### Task 3: Isolated process runner and observation parser

**Files:** Create `core_runner.py`, `core_observe.py`, `tests/test_core_runner.py`, `tests/test_core_observe.py`.

**Interfaces:** `run_core(bundle: CoreBundle, toolchain: Toolchain, lane: Literal['reference','ast','ir'], directory: Path, release: bool=False, pipeline_timeout_ms: int=1200000) -> NativeRun`; `decode_observation(stdout: bytes, kernel: AdmittedKernel) -> Observation`. Per-stage Core timeout remains120000ms; the independent whole-pipeline default is1200000ms. Record both; neither is a performance measurement.

- [ ] Use fake executables to test argv, spaces, timeout, malformed/partial output and missing files. The cleanup control must spawn a child in a distinct process group, as Core does. Send cooperative SIGTERM to Core first; on a bounded grace timeout, use a verified platform ownership mechanism (such as an owned cgroup) to terminate all nested groups. Killing only the outer process group is insufficient. If forced cleanup cannot be verified, return infrastructure error and do not claim process isolation. Select and demonstrate that mechanism on the target environment before accepting the runner.
- [ ] Parse exactly `1+(H+1)*(W+1)+H*W` signed-i32 scalar lines followed by `ok  1 test, 0 assertions\n`, with no extra payload, and cross-check report test counts. Use retained `reference.stdout.log` and `differential.stdout.log`; the outer CLI may include diagnostics. Reject omitted/extra/out-of-range values and altered summary.
- [ ] Run the owned tests and observe missing runner/parser failure.
- [ ] Implement argv-based calls with a dedicated working directory per invocation; Core creates `.beryl-cache` relative to it. Retain only newly created jobs belonging to that invocation, never the newest job in a shared cache. Pin source-inspected stdout/report framing against the first real smoke run.
- [ ] Use these source-verified command forms, substituting explicit paths:

```text
beryl test --backend reference --lowering ast --timeout-ms 120000 witness.be
beryl test --backend differential --lowering ast --opt off --clang CLANG --save-native-evidence --timeout-ms 120000 witness.be
beryl test --backend differential --lowering ir --opt off --clang CLANG --save-native-evidence --timeout-ms 120000 witness.be
```

- [ ] Require lane-specific success. Reference: completed successful reference execution and one test; `compared=false` is normal. Differential: additionally completed native success, report status success, compared true, requested/selected lowering agreement, and schema5 admitted profile for IR. Test `compared=true,status=failure` as rejection. Compare Axiom observations independently only after lane admission. `--release` is the optional O2 lane; `--opt off` does not disable Clang optimization. No invented CLI flags.
- [ ] Run tests and commit as `feat(axiom): retain complete Core correspondence evidence`.

### Task 4: Actual correspondence and mutation campaign

**Files:** Create `tests/integration/test_core_correspondence.py`, `tests/integration/test_core_mutations.py`, explicit input/shape manifests.

**Interfaces:** Consume Plan01 source evaluator, planner/checker and Tasks1–3 bundle/runner/observation interfaces. No duplicated source arithmetic inside the emitter or expected-output producer.

- [ ] Define a quick mandatory corpus: H/W `(1,1),(1,7),(7,1),(2,3),(3,2),(5,7)`; all-zero, all-1023, alternating extremes, coordinate ramp, corner impulses and two fixed random seeds. Each case runs all three plans when admitted. Invalid-input cases place -1/1024 at first/middle/last input, including two invalid elements to establish first failure.
- [ ] Add a slower nightly corpus with every impulse position for H5/W7, larger admitted shapes and additional seeds. Do not compile the old 23,270-input mathematical corpus one executable per input by default; retain that exhaustive work in Plan01 and use deliberate native sampling.
- [ ] Write tests that deliberately alter one generated Core neighbor, skip the final output store and shift the returned failing index. Recompute artifact hashes as a faulty emitter would: the independent source oracle must still reject the behavior. This establishes that hashes alone are not the correspondence check.
- [ ] Before implementing test orchestration, run `PYTHONPATH=src python -m unittest discover -s tests/integration -v` and confirm no false pass from absent toolchains: missing prerequisites must be visibly unavailable and cannot satisfy the native milestone.
- [ ] Execute reference, AST differential and admitted IR differential lanes on the pinned build. Repeat the quick corpus with native O2. Compare status, every input and output, and unchanged sentinel output on range rejection. Inspect exact error categories; reduce a failing case before modifying the compiler or emitter.
- [ ] Record a lane-by-case matrix. A core supported-shape rejection is a documented limitation; H5/W7 across all intended plans must either pass or trigger a revised adapter design. No raised limits or silent lane skipping qualifies as completion.
- [ ] Commit the tests/receipts schema as `test(axiom): establish independent Core correspondence`.

### Task 5: Integrated CLI and reproducibility capsule

**Files:** Extend `__main__.py`, `evidence.py`, `docs/core-bridge.md`; create `tests/test_compile_cli.py`.

**Interfaces:** Add `witness SOURCE --plan PLAN --case CASE_JSON --clang PATH --core PATH --out DIR`, and `conformance --manifest PATH --toolchain RECEIPT --out DIR`. CASE_JSON strictly contains schema_version, input and initial_output exact i32 arrays; its canonical hash binds the invocation. Recheck source/plan, then build/run the explicit fixed-case witness. Defer a general `compile` command until its runtime-entry contract exists. Preserve Plan01 exit categories. Source emission, successful build and observed conformance are separate result dimensions and artifact kinds.

- [ ] Write tests for missing/wrong-shape case input, stale evidence, output interruption and compiler failure after a valid plan. The explicit fixed-plan witness command never silently substitutes another plan; retain that plan's lowering failure. Any later selector-driven fallback is a separate request with its own complete gates and case identity.
- [ ] Run owned tests, implement commands without duplicating checker/runner logic, and publish immutable artifact manifests only after all referenced files exist and hash correctly.
- [ ] Run Plan01 tests plus quick native conformance in a fresh output directory; replay the same saved plan and compare source/artifact identities where deterministic. Native binary reproducibility may depend on toolchain paths/build IDs; record those facts rather than assume byte identity proves behavior.
- [ ] Commit as `feat(axiom): package checked Core witness capsules`.

## Completion boundary

Deliver actual executable witnesses, independent complete observations, provenance, negative controls and a precise trusted-base statement. The Core source adapter is now empirically connected to Axiom semantics for the tested cases. It is not a proof of all compiled inputs, a runtime memory bound or a throughput result. Large shapes, loop-plan v2 and measurement infrastructure remain Plan03 prerequisites.

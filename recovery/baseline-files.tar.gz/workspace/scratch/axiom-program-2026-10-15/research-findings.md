# Axiom: extended research and novelty assessment

2026-10-15, iteration 2. This extends the [foundation design](../axiom-foundations-2026-10-15/axiom-v0-design.md). The earlier23 external snapshots are now supplemented by three full primary texts from public author/project copies. Their exact files and citations are in the [contribution review](refinement/contribution-review.md) and [paper manifest](refinement/papers/pdf-manifest.json). This remains a targeted investigation, not an exhaustive survey or evidence of priority. No competitor was installed or benchmarked.

## Findings that change the plan

### The arena metric omits an allowed form of retained storage

An unrolled plan can compute every producer once into SSA values and consume them later with zero scratch operations. At H5/W7 it uses48 multiplications and zero declared arena bytes, versus inline's140/0 and rows2's48/64. It is valid under the proposed plan semantics. The [standalone control](refinement/probes/ssa_control.py) evaluates it alongside the three schedules; its liveness analysis exposes retained scalars that the arena metric excludes.

This defeats the intended work/storage tradeoff over the permitted plan language, while leaving the narrow arena theorem intact. The revised contract admits the control, renames the objective to mechanically counted `multiplication_ops`, and limits selection claims to the named portfolio. A separate [resource research program](refinement/resource-contract-research.md) asks how to account for scalars and preserve a stronger property through lowering. Rejecting the valid control would hide the limitation.

### Full papers already specify scoped resource filters and hard synthesis costs

Adams et al., **Learning to Optimize Halide with Tree Search and Random Programs** (TOG2019, DOI10.1145/3306346.3322967), §6.2 p121:8, uses symbolic analysis to reject GPU schedules exceeding per-block shared memory. §§3–4 also describe a broad schedule space, bounded beam search and distinct learned cost/benchmarking roles. Thus even a scoped hard-memory filter is not a standalone novelty claim. This does not establish a whole-native-memory theorem or every property proposed for Axiom.

The **SyGuS Language Standard2.1** (Padhi et al.,2021), §5.2.1 and Examples6–8, defines weighted derivations and hard weight constraints. §§3.12/8.3 specify optimization objectives; §§4/6.2.1 separate correctness from preference. These are direct precedents for hard constraints and objectives. Derivation weights can differ for identical terms and do not automatically model live storage or runtime.

Newcomb et al., **Verifying and Improving Halide's Term Rewriting System with Program Synthesis** (OOPSLA2020, DOI10.1145/3428234), §§3–4, verifies rewrites and studies termination/synthesis under explicit assumptions. §5.3.1 reports memory benefits in some experiments alongside null runtime/code-size effects. This makes checked rewrites a close comparison and supplies a useful example of restrained result reporting; no experiment was reproduced here.

The [contribution review](refinement/contribution-review.md) provides printed page/section citations and qualifications. The remaining research hypothesis needs a substantive benefit in physical resource semantics, checking scope or scalable certificates. Combining familiar labels is insufficient.

### Automatic planning and explainable schedules are established precedents

Halide's `AutoschedulerParams` names heuristic and learned schedulers; `AutoSchedulerResults` includes target, parameters, generated schedule source and features ([source](sources/halide-pipeline.h), lines 35–63 and 115–124). Therefore neither “the compiler chooses a schedule” nor “the compiler shows its schedule” is a credible standalone novelty claim. Those comments are evidence for this interface, not a current inventory or performance comparison of every Halide scheduler.

TVM v0.14's `tune_tasks` separates builder, runner, database, cost model and task scheduler; it exposes global/per-task trial limits and module-equality policies ([source](sources/tvm-meta-schedule.py), lines 29–140). Its `TuningRecord` retains a trace, workload, measured seconds, target and argument information ([source](sources/tvm-database.py), lines 37–153). Bounded tuning and replay records also have clear precedent. Axiom should borrow the separation of responsibilities, while explicitly defining which fields establish semantic validity and which are only measurement history. These inspected files do not establish whether the complete TVM system supplies a particular Axiom-style hard-memory contract; that remains an unanswered comparison question.

### Transformation preconditions and failure categories are not new by themselves

MLIR's Transform dialect distinguishes success, recoverable failure and irrecoverable failure. Recoverable failure is expected before payload modification, while invalid mutation is irrecoverable. Handles become invalid after consumed operations; expensive dynamic checks are optional ([source](sources/mlir-transform.md), lines 239–332). This supports explicit failure states and immutable checked-plan handoff. It also means “transformations can reject an inapplicable rewrite” is not our contribution. An implementation built on Transform must account for its handle lifetime and mutation semantics; replaying an instruction list does not alone establish equivalence.

DaCe separates source programs from SDFGs and supports reusable transformations ([README](sources/dace-readme.md), lines 10–26). Its transformation API distinguishes `can_be_applied` from `apply`, with explicit `verify`/`permissive` options ([implementation](sources/dace-transformation.py), lines 126–140, 301–391). Its validator includes shape/symbol/access checks and warnings for some uncertain dynamic accesses ([validator](sources/dace-validation.py), lines 250–400, 1020–1075). These facts make DaCe a relevant representation/transformation comparison. They do not justify calling it unsound or claiming its entire validation story lacks equivalence checking. Axiom must state its own smaller theorem precisely rather than infer a competitor's missing feature from a partial inspection.

### Specification-driven synthesis already separates grammars and meaning

cvc5's official SyGuS example separately defines a grammar and universally quantified semantic constraints for synthesized functions ([example](sources/cvc5-sygus.py), lines 37–101). This is precedent for distinguishing the allowed implementation space from the desired behavior. It does not supply a physical storage model, an optimizer cost model or our complete boundary contract. A future solver experiment must state its grammar, arithmetic theory, resource model, completeness scope and timeout interpretation. The example uses mathematical integers; it cannot establish Axiom's per-node i32 safety automatically.

Souper describes LLVM peephole superoptimization using SMT and documents both in-memory and persistent query caching. The inspected README explicitly warns that its Redis cache is not versioned and must be cleared on upgrade ([source](sources/souper-readme.md), opening paragraph and caching section). This is a concrete reason to bind Axiom cache records to semantics/checker/toolchain identities. It is not evidence that every present Souper deployment shares that limitation, nor that source-level totality follows from an LLVM refinement check.

### Lowering position determines what the optimizer can still understand

Polly documents extracting mathematical computation/access models from LLVM IR, transforming them and regenerating LLVM IR. Its discussion of early versus late placement identifies a tradeoff between source correspondence and opportunities exposed by inlining ([source](sources/polly-architecture.rst), opening and final sections). Treat “default today” in this document as historical wording, not independently verified current configuration. Axiom should retain shapes, source arithmetic grouping and boundary assumptions in its own logical representation; recovering these after arbitrary lowering is an additional analysis problem.

The prior MLIR bufferization/ownership research remains decisive: preserve useful tensor transformations before storage lowering; a legal copy can invalidate a stronger resource promise; deallocation and buffer assignment are separate contracts. The prior Halide/Exo/Futhark/rustc/Alive2/Rosette notes supply scheduling, aliasing, arithmetic, dependency and proof-boundary details.

## Candidate contribution and explicit non-claims

**Research hypothesis:** a small independently checked physical-plan format can make a precisely named implementation/resource relation easier to audit or enforce at acceptable cost, compared with a same-domain checked-rewrite or validation alternative. The small portfolio first tests that mechanism, not search difficulty or broad optimization value.

This hypothesis is worth testing; novelty is not established. Its components have precedents. Potential value lies in a rigorously specified composition and demonstrated usability or implementation benefit. The first stencil is a tractable test case, not sufficient evidence for a general 5GL or a broad compiler paper.

| Proposed claim | Current status | Evidence needed |
|---|---|---|
| Axiom expresses computations independently of physical scheduling | Proposed source contract | Parser, source evaluator, three physically distinct outputs from one source. |
| Final-plan checking detects bad plans without trusting the planner | Mathematical model precedent; implementation absent | Independent checker, mutation corpus, soundness argument, checker cost and residual trusted base. |
| Hard constraints survive interruption and replay | Designed, not implemented | State-machine controls, exact identity binding, cap/filter and interruption tests. |
| Declared plan workspace is enforced | Formula-level evidence; known SSA-storage exclusion | Recompute designated arena/access facts; retain SSA positive control; never call it total intermediate memory. |
| Native intermediate memory is bounded | Unsupported | Validated post-lowering storage accounting with a stated scope and complete runtime assumptions. |
| Automatic selection improves runtime | Unmeasured | Native path, valid instrumentation, frozen selector, held-out comparison against a training-selected fixed plan. |
| The approach is novel | Open | Paper-level related-work review, feature/theorem comparison and adversarial external reading. |
| The language generalizes beyond one stencil | Unsupported by v0 | Additional source forms, applicability proofs and diverse independent workloads. |

## Alternatives and decision experiments

1. **Small Python research compiler vs immediate C11 production frontend.** Choose Python 3.12 standard library for the bounded prototype: exact integers, immutable records, transparent testing and low build burden. Its runtime is not an Axiom throughput result. Keep the Core adapter external. Reconsider C11 only after profiling compiler workloads or defining a production embedding requirement; a rewrite is not assumed.
2. **Finite unrolled physical plans vs a general loop IR.** For at most 256 input cells, use an explicit SSA-like event sequence. This makes initialization, exact reads and output coverage directly inspectable. It trades code size for a small checker. A structured-loop plan is a separately versioned later design, mandatory before large-buffer performance work. Do not infer scalable compilation from this prototype.
3. **Final-plan checking vs trusting transformations.** Choose final-plan checking first. A later comparison can implement one checked rewrite sequence and compare checker complexity, rejection precision, proof scope and cost, without claiming either is universally superior.
4. **Three-plan portfolio vs SyGuS/e-graphs.** Keep the three generators as conformance fixtures, with an analytic selector and the valid SSA control outside that portfolio. Use a solver only after identifying a reproducible choice that the analytic selector cannot resolve under the stated objectives. Keep common oracles/constraints. No solver installation is needed for this revision.
5. **Core source adapter vs direct IR/MLIR.** Use full Core admission now. Later compare equivalent adapters on supported operations, copies, source mapping, compile cost and native code. Preserve unsupported outcomes; do not remove Core limits to obtain a successful run.
6. **Exact replay vs incremental proofs.** Exact source/plan rechecking first. Fine-grained dependency reuse is deferred until fresh versus cached equivalence tests exist. No edit-stable identity claim is made by hashing the whole source.

## Paper-level research still required

The network provided ordinary project/author GitHub access; no web-search connector was available. Failed guessed paths and blocked Souper/DaCe arXiv requests remain recorded. Three full primary texts are now available and their relevant sections were inspected; foundational Halide/Exo/Exo2, verified validators and rematerialization literature still need closer comparison. Current venue policies/deadlines and comprehensive citation searches remain unverified. No paper was reconstructed from its abstract or README.

Before a novelty claim, perform this explicit review:

- Search combinations of “translation validation scheduling”, “resource constrained program synthesis”, “proof carrying optimization”, “verified tensor compiler”, “memory bounded scheduling”, “polyhedral scheduling memory reuse”, “Halide autoscheduler”, “Exo scheduling verification”, “TVM meta schedule”, “DaCe transformations” and “syntax guided synthesis cost”. Record database/date/query/results, including negative searches.
- Include work that specifies source semantics, schedule legality, storage bounds, proof/checking mechanisms, bounded-search behavior or reproducible optimization. Follow citations backward and forward. Do not select only papers whose abstracts appear different from Axiom.
- For each close work, record the actual theorem, assumptions, target, failure/timeout behavior, resource scope, trusted base and evaluated workloads. Mark unexamined fields unknown, not absent.
- Read the strongest likely antecedents in full before choosing a novelty sentence. Have a reviewer argue that Axiom is merely an integration of existing ideas; revise the claim if that argument holds.
- Verify bibliographic metadata and version from the paper/publisher or author source. The DaCe README supplies an SC 2019 citation and Souper supplies an arXiv link; neither counts as having read those papers in this round.

The implementation plan can proceed without a novelty assertion. The paper's submission gate cannot.

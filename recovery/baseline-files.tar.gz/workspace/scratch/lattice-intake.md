# Lattice research intake

Internal working notes, 2026-10-14. Kept outside both repositories; not published.
This is an orientation record, not an approved language specification.

## Direction supplied by the user

- Lattice is Beryl's deep research department for programming languages.
- `NtEuphoria/beryl` is the existing project that will become Lattice Core,
  the normal 4GL language currently being developed.
- Project Axiom is a private, next-generation moonshot 5GL language project
  in its own right. The user explicitly reaffirmed this distinction after
  the roadmap review.
- The user expects collaboration with Gemini 4 Argon and occasionally other models.
- The assistant is taking the department-lead role in this collaboration.
- On 2026-10-15, the user selected Axiom's first programmer experience:
  declare domain computations and constraints; Axiom chooses layouts and
  schedules. The user also explicitly invoked Superpowers for the ongoing work.

The original Google Doc could not be read because the cloud egress proxy
returned HTTP 403. The user subsequently supplied `Beryl Architecture and
Optimization Roadmap.docx`; its architecture, responsibilities, benchmarks and
evidence gates have now been reviewed. See `lattice-roadmap-review.md` beside
this file for the updated interpretation and source comparison.

The roadmap proposes optional, budgeted synthesis over Core's shared semantics
and verified IR as an implementation direction for Axiom. This proposal does
not reduce Axiom's identity to a Core optimization mode or settle its language
design. Array-pipeline fusion and buffer reuse come first in that roadmap;
layout/schedule search and heterogeneous targets follow separate evidence gates.
The document is background, not authorization to execute its build plans,
publish results, rename repositories or modify the compiler. The user's current
name, Lattice Core, takes precedence over the document's Beryl Core terminology.
No direct Argon connection has been established.

## Repository baseline

- Main project: `/workspace/beryl`.
- Origin: `https://github.com/NtEuphoria/beryl.git`.
- Remote default branch: `v0.2-performance`.
- Inspected commit: `0a678b4ae6d41190c4f5a8bf063caba05759d20d`.
- Latest commit title: `feat(beryl): publish core authoring checkpoint`.
- Research checkout: `/workspace/BerylLattice`; valid empty Git repository
  with no commits. Its origin currently advertises no branches.
- No source files were edited. No compiler build or application tests were
  executed during this orientation. Clang is not currently on PATH.

## Source-grounded findings

1. Beryl's production compiler is C11. It performs parsing, name resolution,
   type/default processing, ownership/access analysis and provenance analysis,
   then emits native C or EnforceScript. See `README.md`, `src/sema/`,
   `src/back/` and `src/driver/build.c`.
2. The native production path emits from the typed AST. An explicit IR path
   exists but is gated to isolated differential tests. The native build
   boundary verifies IR and exact source identity before emitting C.
   See `src/driver/build.c:186`.
3. The experimental IR supports a bounded plain-value domain: bool, i32,
   finite f32, plain records, fixed arrays and explicit access modes. It
   excludes owned storage and partial moves. See `src/ir/ir.h:109`.
4. The reference/differential driver compares native results and ordered
   event traces with reference execution. This is a useful basis for future
   semantics experiments, within its admitted subset.
   See `src/driver/reference_driver.c:57`.
5. Complete ownership/storage lifecycle support, production IR and released
   automatic optimization remain unfinished. No Rust performance advantage
   is established by the current checkpoint. See
   `docs/advanced/CORE_AUTHORING_2026_10_14.md:142`.
6. The latest stated priority is core compiler and 4GL authoring work;
   further Reforger validation is parked. See the same checkpoint at line 3.
7. `docs/INTERNALS.md:17` says there is no MIR. Read that historical statement
   alongside the current experimental IR source; it is not a complete map
   of today's implementation.

Repository documentation records historical tests and performance experiments.
Their raw build receipts are not present in this checkout, and those results
have not been independently reproduced in this cloud instance.

## Proposed working discipline

Preserve Beryl's existing evidence-oriented collaboration pattern. Each
experiment or model handoff should identify its question, exact source revision,
semantic assumptions, supported domain, artifact locations, checks actually
executed, failures and unresolved issues. Independent review should examine
the same artifacts. See `docs/AI_WORKFLOW.md`.

Keep Axiom material in private working artifacts until its intended repository
and publication boundary are established. Do not infer public release authority
from a request to collaborate on the project.

## Research direction after reading the uploaded roadmap

The brief defines 4GL/5GL as project-track labels. Axiom explores legal
implementations under explicit budgets and falls back to validated Core code
when optional search is inconclusive. Profiles guide profitability; they do
not establish correctness. Explicit optimization contracts distinguish a
disproved requirement, unsupported analysis and exhausted budgets.

The initial recommendation was one pure, total, fixed-array producer/consumer
pipeline on one CPU target. The 2026-10-15 primary-source research retains that
as a legality control and proposes a small declarative stencil as the first
language demonstration, with materialization, recomputation and circular-storage
plans. Both need an unchanged baseline, independent checks, rejection/fallback
cases and pass ablations. These are recommendations, not implemented or approved
experiments. The current schema-5 experimental IR is a starting point; its
256-cell aggregate bound limits performance conclusions. The roadmap's full BIR,
CFG/AEGraphs and Perceus infrastructure must not be presumed to exist.

Current research synthesis: `axiom-foundations-2026-10-15/axiom-v0-design.md` and
`research-report.md`, beside this file's directory. The earlier
`lattice-research-2026-10-15/decision-memo.md` remains background. The newer package
specifies boundary semantics, the Core source adapter, independent plan checks,
named plan-workspace constraints, and a frozen future performance protocol.
Its standalone mathematical probe has finite positive and negative evidence;
it is not an Axiom compiler or native benchmark. Independent review is retained.

The first implementation admission is the canonical two-stage integer stencil
under fixed shapes and checked input ranges. General DAG support, stronger
runtime memory bounds and larger-buffer lowering remain later decisions.
Production compiler implementation and repository renaming have not begun.

## Saved cloud configuration

The draft now retains both checkouts at their inspected states and adds
`docs.google.com` to the custom allowed domains. Persistence was confirmed by
reading the draft back. Saving the draft does not apply network changes or
publish a new environment snapshot. Review and save the environment settings,
then publish when appropriate. The brief can also be pasted into the chat.

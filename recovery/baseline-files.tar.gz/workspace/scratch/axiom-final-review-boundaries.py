from axiom.frontend import parse_source, admit_source
from axiom.checker import check_plan
from axiom.codec import decode_plan, encode_plan
from axiom.core_emit import emit_core
from axiom.core_runner import _validate_bundle
from axiom.core_observe import decode_observation
from axiom.model import Limits
from axiom.planner import make_plan
from axiom.reference import evaluate_source
from tests.helpers import stencil_source
from tests.plan_interpreter import interpret_plan
from pathlib import Path
import json

def require(condition, message):
 if not condition: raise RuntimeError(message)
limits=Limits(); checks=valid=invalid=emissions=0
for h,w in ((1,1),(1,7),(7,1),(2,3),(3,2),(5,7),(15,15),(1,127),(127,1)):
 for renamed in (False,True):
  source=stencil_source(h,w,cap=None)
  if renamed: source=source.replace(b'H',b'Height').replace(b'W',b'Width').replace(b'image',b'frame').replace(b'result',b'dest')
  module=parse_source(source); kernel=admit_source(module); n=(h+1)*(w+1); initial=tuple(-700000-i for i in range(h*w))
  plans=[]
  for name in ('inline-v1','rows2-v1','materialize-v1'):
   plan=decode_plan(encode_plan(make_plan(kernel,name)),limits)
   require(check_plan(kernel,plan,limits).eligible,'fresh checker'); checks+=1
   plans.append(plan)
  for data in (tuple([0]*n),tuple([1023]*n),tuple((i*317+19)%1024 for i in range(n))):
   expected=evaluate_source(module,data,initial)
   hand=tuple(sum((data[i]+1)**2 for i in (r*(w+1)+c,r*(w+1)+c+1,(r+1)*(w+1)+c,(r+1)*(w+1)+c+1)) for r in range(h) for c in range(w))
   require(expected.output==hand and expected.input_after==data and expected.first_bad_index is None,'source oracle')
   for plan in plans:
    require(interpret_plan(plan,data,h*w)==hand,'physical values'); valid+=1
   raw=('\n'.join(map(str,(-1,*data,*hand)))+'\nok  1 test, 0 assertions\n').encode()
   require(decode_observation(raw,kernel).output==hand,'observation decode')
  for where in (0,n//2,n-1):
   data=list(range(n));data[where]=1024;data[-1]=-1;data=tuple(data)
   expected=evaluate_source(module,data,initial)
   require(expected.first_bad_index==where and expected.output==initial and expected.input_after==data,'preflight preservation'); invalid+=1
  # Emitter identity/mapping and runtime validation without launching a compiler.
  for plan in plans:
   bundle=emit_core(source,encode_plan(plan),limits,data,initial)
   _validate_bundle(bundle); emissions+=1
result=dict(status='pass',optimized=not __debug__,source_specializations=18,fresh_checks=checks,valid_plan_interpretations=valid,boundary_failures=invalid,emission_runner_identity_boundaries=emissions,native_execution=False)
Path('/workspace/scratch/axiom-final-review-boundaries.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))

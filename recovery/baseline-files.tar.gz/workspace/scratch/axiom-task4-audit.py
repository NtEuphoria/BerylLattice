"""Read-only final audit of the actual mandatory native evidence."""
from collections import Counter
from dataclasses import asdict
from hashlib import sha256
import json
from pathlib import Path
import sys

from axiom.core_observe import Observation, decode_observation
from axiom.frontend import admit_source, parse_source
from axiom.reference import evaluate_source

root = Path(sys.argv[1])
manifest = json.loads((root/'quick-manifest.json').read_text())
rows = [json.loads(line) for line in (root/'lane-matrix.jsonl').read_text().splitlines()]
cases = {case['case_id']: case for case in manifest['cases']}
assert len(cases) == 108
required = {(case_id, plan, setting['lane'], setting['release'])
            for case_id in cases for plan in manifest['plans'] for setting in manifest['lanes']}
actual = {(row['case_id'], row['plan_id'], row['lane'], row['release']) for row in rows}
assert len(rows) == len(required) == len(actual) == 1620 and actual == required
assert json.loads((root/'quick-complete.json').read_text())['matched'] == 1620
expected = {}
for case_id, case in cases.items():
    source = case['source_utf8'].encode('utf-8')
    assert sha256(source).hexdigest() == case['source_sha256']
    module = parse_source(source)
    result = evaluate_source(module, tuple(case['input']), tuple(case['initial_output']))
    oracle = Observation(-1 if result.first_bad_index is None else result.first_bad_index,
                         result.input_after, result.output)
    expected[case_id] = admit_source(module), oracle
native_cells = 0
for row in rows:
    kernel, oracle = expected[row['case_id']]
    assert row['classification'] == 'matched' and row['mutation'] is None
    run = row['run']
    assert run['classification'] == 'success' and run['cleanup_verified']
    assert not run['pipeline_timed_out'] and not run['stage_timed_out']
    assert sha256((Path(run['cwd'])/'witness.be').read_bytes()).hexdigest() == run['generated_source_sha256']
    assert row['expected'] == json.loads(json.dumps(asdict(oracle)))
    for name in ('reference', 'native'):
        path = run[name+'_stdout_path']
        if path is None:
            assert name == 'native' and row['lane'] == 'reference'
            continue
        raw = Path(path).read_bytes()
        assert sha256(raw).hexdigest() == run[name+'_stdout_sha256']
        assert decode_observation(raw, kernel) == oracle
        assert row['observations'][name] == json.loads(json.dumps(asdict(oracle)))
    if row['lane'] != 'reference':
        native_cells += 1
        argv_paths = [Path(job)/'compile.argv.json' for job in run['job_paths']
                      if (Path(job)/'compile.argv.json').exists()]
        assert len(argv_paths) == 1
        argv = json.loads(argv_paths[0].read_text())
        assert ('-O2' if row['release'] else '-O0') in argv
        assert Path(argv[0]).is_absolute()
summary = dict(cells=len(rows), native_cells=native_cells,
    classifications=dict(Counter(row['classification'] for row in rows)),
    shapes=dict(Counter(row['case_id'].split('/')[0] for row in rows)),
    plans=dict(Counter(row['plan_id'] for row in rows)),
    lane_release=dict(Counter(row['lane']+('/O2' if row['release'] else '/debug') for row in rows)),
    independent_oracle='axiom.reference.evaluate_source',
    verified='exact 1620 unique keys; 108 exact sources; every retained reference/native scalar and stdout hash; all native O0/O2 argv')
(root/'verified-summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary, indent=2))
